local ADDON_NAME, ns = ...

local VERSION = "2.4.6"
local QUEST_PIN_SIZE = 25
local FLIGHT_PIN_SIZE = 18
local INSTANCE_PIN_SIZE = 18
local RARE_PIN_SIZE = 18
local UPDATE_INTERVAL = 0.25
local TOOLBAR_BUTTON_SIZE = 20
local TOOLBAR_SPACING = 3
local TOOLBAR_PADDING = 4
local SIZE_BUTTON_WIDTH = 18
local ICON_SCALE_MIN = 0.40
local ICON_SCALE_MAX = 1.30
local ICON_SCALE_STEP = 0.10

-- Recommended outdoor questing ranges. Classic zones use the original Classic
-- recommendations; Forever-specific zones use published Forever ranges.
-- Informational only: this never changes quest availability or filtering.
-- Cities, continents and zones without a confirmed useful range are intentionally omitted.
local ZONE_LEVEL_RANGES = {
    [1411] = { 1, 10 },  -- Durotar
    [1412] = { 1, 10 },  -- Mulgore
    [1413] = { 10, 25 }, -- The Barrens
    [1416] = { 30, 40 }, -- Alterac Mountains
    [1417] = { 30, 40 }, -- Arathi Highlands
    [1418] = { 35, 45 }, -- Badlands
    [1419] = { 45, 55 }, -- Blasted Lands
    [1420] = { 1, 10 },  -- Tirisfal Glades
    [1421] = { 10, 20 }, -- Silverpine Forest
    [1422] = { 51, 58 }, -- Western Plaguelands
    [1423] = { 53, 60 }, -- Eastern Plaguelands
    [1424] = { 20, 35 }, -- Hillsbrad Foothills
    [1425] = { 40, 50 }, -- The Hinterlands
    [1426] = { 1, 10 },  -- Dun Morogh
    [1427] = { 45, 50 }, -- Searing Gorge
    [1428] = { 50, 58 }, -- Burning Steppes
    [1429] = { 1, 10 },  -- Elwynn Forest
    [1430] = { 55, 60 }, -- Deadwind Pass
    [1431] = { 18, 30 }, -- Duskwood
    [1432] = { 10, 20 }, -- Loch Modan
    [1433] = { 15, 25 }, -- Redridge Mountains
    [1434] = { 30, 45 }, -- Stranglethorn Vale
    [1435] = { 35, 45 }, -- Swamp of Sorrows
    [1436] = { 10, 20 }, -- Westfall
    [1437] = { 20, 30 }, -- Wetlands
    [1438] = { 1, 10 },  -- Teldrassil
    [1439] = { 10, 20 }, -- Darkshore
    [1440] = { 18, 30 }, -- Ashenvale
    [1441] = { 25, 35 }, -- Thousand Needles
    [1442] = { 15, 27 }, -- Stonetalon Mountains
    [1443] = { 30, 40 }, -- Desolace
    [1444] = { 40, 50 }, -- Feralas
    [1445] = { 35, 45 }, -- Dustwallow Marsh
    [1446] = { 40, 50 }, -- Tanaris
    [1447] = { 45, 55 }, -- Azshara
    [1448] = { 48, 55 }, -- Felwood
    [1449] = { 48, 55 }, -- Un'Goro Crater
    [1451] = { 55, 60 }, -- Silithus
    [1452] = { 53, 60 }, -- Winterspring

    -- Forever 1.60.1 zones with published level ranges.
    [2482] = { 60, 60 }, -- Mount Hyjal
    [2521] = { 1, 12 },  -- Zephras Isle
    [2548] = { 35, 45 }, -- Riverglades
}

local activePins = {}
local pinPool = {}
local buttons = {}
local toolbar
local zoneLevelText
local settings
local enabled = true
local lastMapID
local lastCanvasW, lastCanvasH
local lastQuestCount = 0
local lastFlightCount = 0
local lastInstanceCount = 0
local lastRareCount = 0
local completed = {}
local completedAuthoritative = false
local completionDirty = true
local professionSkillLines
local worldMapHooked = false

-- Intentionally limited to features with a reliable source or an explicitly labeled curated subset.
-- Quest starts: bundled ATT-derived Forever database.
-- Flight points: native WoW taxi API.
-- Dungeon/raid entrances: native API when available, with a small ATT-derived fallback database.
-- Rare: curated ATT-derived outdoor rare selection, not a complete rare database.
local FILTERS = {
    { key="quest",    atlas="QuestNormal", icon="Interface\\GossipFrame\\AvailableQuestIcon" },
    { key="flight",   icon="Interface\\Icons\\Ability_Mount_Gryphon_01" },
    { key="instance", icon="Interface\\Icons\\Spell_Arcane_PortalStormWind" },
    { key="rare",     icon="Interface\\AddOns\\ForeverQuestMap\\Media\\rare_skull.tga" },
}
local FILTER_INFO = {}
for _, v in ipairs(FILTERS) do FILTER_INFO[v.key] = v end

local function Print(msg)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cffffd200ForeverQuestMap:|r " .. tostring(msg))
    end
end

local function EnsureSettings()
    ForeverQuestMapDB = ForeverQuestMapDB or {}
    ForeverQuestMapDB.filters = ForeverQuestMapDB.filters or {}
    local defaults = { quest=true, flight=false, instance=false, rare=false }
    for k, v in pairs(defaults) do
        if ForeverQuestMapDB.filters[k] == nil then ForeverQuestMapDB.filters[k] = v end
    end
    if ForeverQuestMapDB.enabled == nil then ForeverQuestMapDB.enabled = true end
    if type(ForeverQuestMapDB.iconScale) ~= "number" or ForeverQuestMapDB.iconScale ~= ForeverQuestMapDB.iconScale then ForeverQuestMapDB.iconScale = 0.80 end
    if ForeverQuestMapDB.iconScale < ICON_SCALE_MIN then ForeverQuestMapDB.iconScale = ICON_SCALE_MIN end
    if ForeverQuestMapDB.iconScale > ICON_SCALE_MAX then ForeverQuestMapDB.iconScale = ICON_SCALE_MAX end
    settings = ForeverQuestMapDB
    enabled = settings.enabled ~= false
end

local function Normalize(v)
    if type(v) ~= "number" then return nil end
    if v > 1 then v = v / 100 end
    if v < 0 or v > 1 then return nil end
    return v
end

local function GetVectorXY(pos)
    if not pos then return nil end
    if type(pos.GetXY) == "function" then
        local ok, x, y = pcall(pos.GetXY, pos)
        if ok then return Normalize(x), Normalize(y) end
    end
    if type(pos.GetX) == "function" and type(pos.GetY) == "function" then
        local ok1, x = pcall(pos.GetX, pos)
        local ok2, y = pcall(pos.GetY, pos)
        if ok1 and ok2 then return Normalize(x), Normalize(y) end
    end
    if type(pos) == "table" then
        return Normalize(pos.x or pos[1]), Normalize(pos.y or pos[2])
    end
end

local function GetMapID()
    if WorldMapFrame and type(WorldMapFrame.GetMapID) == "function" then
        local ok, id = pcall(WorldMapFrame.GetMapID, WorldMapFrame)
        if ok and type(id) == "number" then return id end
    end
end

local function GetCanvas()
    if not WorldMapFrame then return nil end
    -- Prefer the actual scroll child because its size matches normalized map coordinates.
    if WorldMapFrame.ScrollContainer and WorldMapFrame.ScrollContainer.Child then
        return WorldMapFrame.ScrollContainer.Child
    end
    if type(WorldMapFrame.GetCanvas) == "function" then
        local ok, f = pcall(WorldMapFrame.GetCanvas, WorldMapFrame)
        if ok and f then return f end
    end
    if WorldMapDetailFrame then return WorldMapDetailFrame end
    if WorldMapButton then return WorldMapButton end
end

local function GetToolbarAnchor()
    if WorldMapFrame and WorldMapFrame.ScrollContainer then return WorldMapFrame.ScrollContainer end
    return GetCanvas() or WorldMapFrame
end

local function IsMapShown()
    return WorldMapFrame and type(WorldMapFrame.IsShown) == "function" and WorldMapFrame:IsShown()
end

local function ApplyRareSkullTexture(texture)
    if not texture then return end
    texture:SetTexture("Interface\\AddOns\\ForeverQuestMap\\Media\\rare_skull.tga")
    if type(texture.SetTexCoord) == "function" then texture:SetTexCoord(0.08, 0.92, 0.08, 0.92) end
    if type(texture.SetVertexColor) == "function" then texture:SetVertexColor(1, 1, 1, 1) end
    texture:Show()
end

local function ApplyTexture(texture, category)
    if not texture then return end
    if category == "rare" then
        ApplyRareSkullTexture(texture)
        return
    end
    local info = FILTER_INFO[category] or FILTER_INFO.quest
    local atlasOK = false
    if info.atlas and type(texture.SetAtlas) == "function" then
        atlasOK = pcall(texture.SetAtlas, texture, info.atlas, false)
    end
    if not atlasOK then
        texture:SetTexture(info.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
        if type(texture.SetTexCoord) == "function" then texture:SetTexCoord(0.06, 0.94, 0.06, 0.94) end
    elseif type(texture.SetTexCoord) == "function" then
        texture:SetTexCoord(0, 1, 0, 1)
    end
    if type(texture.SetVertexColor) == "function" then texture:SetVertexColor(1, 1, 1, 1) end
    texture:Show()
end

local function SetCircularMask(owner, texture, enabled)
    if not owner or not texture then return end

    if enabled then
        if not owner.FQMCircleMask and type(owner.CreateMaskTexture) == "function" then
            local ok, mask = pcall(owner.CreateMaskTexture, owner, nil, "ARTWORK")
            if ok and mask then
                owner.FQMCircleMask = mask
                if type(mask.SetTexture) == "function" then
                    pcall(mask.SetTexture, mask, "Interface\\CharacterFrame\\TempPortraitAlphaMask")
                end
                if type(mask.SetAllPoints) == "function" then
                    pcall(mask.SetAllPoints, mask, owner)
                end
            end
        end

        if owner.FQMCircleMask and not owner.FQMCircleMaskApplied and type(texture.AddMaskTexture) == "function" then
            local ok = pcall(texture.AddMaskTexture, texture, owner.FQMCircleMask)
            if ok then owner.FQMCircleMaskApplied = true end
        end
    elseif owner.FQMCircleMask and owner.FQMCircleMaskApplied and type(texture.RemoveMaskTexture) == "function" then
        pcall(texture.RemoveMaskTexture, texture, owner.FQMCircleMask)
        owner.FQMCircleMaskApplied = nil
    end
end

local function QuestTitle(id)
    if C_QuestLog and type(C_QuestLog.GetTitleForQuestID) == "function" then
        local ok, s = pcall(C_QuestLog.GetTitleForQuestID, id)
        if ok and s and s ~= "" then return s end
    end
    if type(QuestUtils_GetQuestName) == "function" then
        local ok, s = pcall(QuestUtils_GetQuestName, id)
        if ok and s and s ~= "" then return s end
    end
    return "Quest " .. tostring(id)
end

local function QuestLevel(id)
    if C_QuestLog and type(C_QuestLog.GetQuestDifficultyLevel) == "function" then
        local ok, n = pcall(C_QuestLog.GetQuestDifficultyLevel, id)
        if ok and type(n) == "number" and n > 0 then return n end
    end
end

local function RequestQuestData(id)
    if C_QuestLog and type(C_QuestLog.RequestLoadQuestByID) == "function" then
        pcall(C_QuestLog.RequestLoadQuestByID, id)
    end
end

local function ShowPinTooltip(pin)
    if not GameTooltip or not pin or not pin.fqmData then return end
    local d = pin.fqmData
    GameTooltip:SetOwner(pin, "ANCHOR_RIGHT")
    if d.category == "quest" then
        local first = true
        for _, id in ipairs(d.quests or {}) do
            RequestQuestData(id)
            local title = QuestTitle(id)
            local lvl = QuestLevel(id)
            local line = lvl and ("[" .. lvl .. "] " .. title) or title
            if first then
                GameTooltip:SetText(line, 1, 0.82, 0)
                first = false
            else
                GameTooltip:AddLine(line, 1, 0.82, 0)
            end
        end
        if first then GameTooltip:SetText("Dostupny quest", 1, 0.82, 0) end
    elseif d.category == "instance" then
        GameTooltip:SetText(d.name or "Dungeon / raid", 0.55, 0.82, 1)
        if d.kind then GameTooltip:AddLine(d.kind, 0.75, 0.75, 0.75) end
    elseif d.category == "rare" then
        GameTooltip:SetText(d.name or "Rare", 1, 0.55, 0.15)
        if d.note then GameTooltip:AddLine(d.note, 0.85, 0.85, 0.85, true) end
    else
        GameTooltip:SetText(d.name or "Letovy bod", 1, 0.82, 0)
    end
    GameTooltip:Show()
end

-- Safety path: plain child frames only. No AcquirePin/RemoveAllPins/MapCanvasPinMixin.
local function ReleasePins()
    for i = #activePins, 1, -1 do
        local p = activePins[i]
        if p then
            p:Hide()
            p.fqmData = nil
            p.fqmX = nil
            p.fqmY = nil
            p:ClearAllPoints()
            pinPool[#pinPool + 1] = p
        end
        activePins[i] = nil
    end
end

local function AddPin(x, y, data)
    x, y = Normalize(x), Normalize(y)
    if not x or not y then return nil end
    local parent = GetCanvas()
    if not parent or type(parent.GetWidth) ~= "function" or type(parent.GetHeight) ~= "function" then return nil end
    local w, h = parent:GetWidth(), parent:GetHeight()
    if not w or not h or w < 1 or h < 1 then return nil end

    local p = table.remove(pinPool)
    if not p then
        p = CreateFrame("Button", nil, parent)
        p.Texture = p:CreateTexture(nil, "OVERLAY")
        p.Texture:SetAllPoints(p)
        p:SetScript("OnEnter", ShowPinTooltip)
        p:SetScript("OnLeave", function(self)
            if GameTooltip and GameTooltip:IsOwned(self) then GameTooltip:Hide() end
        end)
    else
        p:SetParent(parent)
    end

    local category = data and data.category or "quest"
    local baseSize = QUEST_PIN_SIZE
    if category == "flight" then baseSize = FLIGHT_PIN_SIZE
    elseif category == "instance" then baseSize = INSTANCE_PIN_SIZE
    elseif category == "rare" then baseSize = RARE_PIN_SIZE end
    local scale = (settings and settings.iconScale) or 0.80
    local size = math.floor(baseSize * scale + 0.5)
    p:SetSize(size, size)
    p.fqmData = data
    p.fqmX, p.fqmY = x, y
    ApplyTexture(p.Texture, category)
    SetCircularMask(p, p.Texture, category == "flight")
    p:ClearAllPoints()
    p:SetPoint("CENTER", parent, "TOPLEFT", x * w, -y * h)
    if type(p.SetFrameStrata) == "function" then p:SetFrameStrata("HIGH") end
    if type(p.SetFrameLevel) == "function" then
        local parentLevel = 0
        if type(parent.GetFrameLevel) == "function" then parentLevel = parent:GetFrameLevel() or 0 end
        p:SetFrameLevel(parentLevel + 40)
    end
    p:Show()
    activePins[#activePins + 1] = p
    return p
end

local function RepositionPins()
    local parent = GetCanvas()
    if not parent then return end
    local w, h = parent:GetWidth(), parent:GetHeight()
    if not w or not h or w < 1 or h < 1 then return end
    for _, p in ipairs(activePins) do
        if p and p.fqmX and p.fqmY then
            p:ClearAllPoints()
            p:SetPoint("CENTER", parent, "TOPLEFT", p.fqmX * w, -p.fqmY * h)
        end
    end
end

local function BuildCompletionCache()
    if not completionDirty then return end
    wipe(completed)
    completedAuthoritative = false

    if type(GetQuestsCompleted) == "function" then
        local t = {}
        local ok, ret = pcall(GetQuestsCompleted, t)
        if ok then
            if type(ret) == "table" then t = ret end
            if next(t) then
                for id, v in pairs(t) do
                    if v then completed[tonumber(id) or id] = true end
                end
                completedAuthoritative = true
            end
        end
    end

    if not completedAuthoritative and C_QuestLog and type(C_QuestLog.GetAllCompletedQuestIDs) == "function" then
        local ok, t = pcall(C_QuestLog.GetAllCompletedQuestIDs)
        if ok and type(t) == "table" then
            for _, id in ipairs(t) do completed[id] = true end
            completedAuthoritative = true
        end
    end
    completionDirty = false
end

local function IsCompleted(id)
    BuildCompletionCache()
    if completed[id] then return true end
    if completedAuthoritative then return false end
    if C_QuestLog and type(C_QuestLog.IsQuestFlaggedCompleted) == "function" then
        local ok, v = pcall(C_QuestLog.IsQuestFlaggedCompleted, id)
        if ok then return v == true end
    end
    if type(IsQuestFlaggedCompleted) == "function" then
        local ok, v = pcall(IsQuestFlaggedCompleted, id)
        if ok then return v == true end
    end
    return false
end

local function IsOnLog(id)
    if C_QuestLog and type(C_QuestLog.IsOnQuest) == "function" then
        local ok, v = pcall(C_QuestLog.IsOnQuest, id)
        if ok and v then return true end
    end
    if type(GetQuestLogIndexByID) == "function" then
        local ok, n = pcall(GetQuestLogIndexByID, id)
        if ok and type(n) == "number" and n > 0 then return true end
    end
    return false
end

local function Contains(t, v)
    if type(t) ~= "table" then return false end
    for _, x in ipairs(t) do if x == v then return true end end
    return false
end

local function FactionAllowed(r)
    if not r.faction then return true end
    local f = UnitFactionGroup and UnitFactionGroup("player") or nil
    return not f or r.faction == f
end

local function RaceClassAllowed(r)
    local raceID = UnitRace and select(3, UnitRace("player")) or nil
    local classID = UnitClass and select(3, UnitClass("player")) or nil
    if r.races and raceID and not Contains(r.races, raceID) then return false end
    if r.classes and classID and not Contains(r.classes, classID) then return false end
    return true
end

local function LoadProfessionLines()
    if professionSkillLines ~= nil then return end
    professionSkillLines = {}
    if type(GetProfessions) ~= "function" or type(GetProfessionInfo) ~= "function" then return end
    local ps = { GetProfessions() }
    for _, idx in ipairs(ps) do
        if idx then
            local ok, _, _, _, _, _, _, skillLine = pcall(GetProfessionInfo, idx)
            if ok and type(skillLine) == "number" then professionSkillLines[skillLine] = true end
        end
    end
end

local function SkillAllowed(r)
    if not r.requireSkill then return true end
    LoadProfessionLines()
    -- Fail closed for profession-only quests to avoid false-positive quest pins.
    return professionSkillLines and professionSkillLines[r.requireSkill] == true
end

local function PrereqsSatisfied(id, r, seen, depth)
    if type(r.sourceQuests) ~= "table" or #r.sourceQuests == 0 then return true end
    if not completedAuthoritative then return true end
    depth = (depth or 0) + 1
    if depth > 20 then return true end
    seen = seen or {}
    if seen[id] then return true end
    seen[id] = true
    for _, sid in ipairs(r.sourceQuests) do
        if not IsCompleted(sid) then
            local sr = ns.QuestData and ns.QuestData[sid]
            local virtualOK = sr and sr.isBreadcrumb == true
            if not virtualOK and sr and not sr.qg and not sr.qgs and not IsOnLog(sid) then
                virtualOK = PrereqsSatisfied(sid, sr, seen, depth)
            end
            if not virtualOK then
                seen[id] = nil
                return false
            end
        end
    end
    seen[id] = nil
    return true
end

local function IsQuestAvailable(id, r)
    if type(r) ~= "table" then return false end
    local level = UnitLevel and UnitLevel("player") or 1
    if r.minLevel and level < r.minLevel then return false end
    if not FactionAllowed(r) or not RaceClassAllowed(r) or not SkillAllowed(r) then return false end
    if IsOnLog(id) then return false end
    if not r.repeatable and IsCompleted(id) then return false end
    if r.altQuests then
        for _, aid in ipairs(r.altQuests) do if IsCompleted(aid) then return false end end
    end
    -- Seasonal quests need a reliable calendar/event signal before they can be shown accurately.
    if r.isYearly or r.isMonthly then return false end
    if not PrereqsSatisfied(id, r) then return false end
    return true
end

local function CoordsForMap(r, mapID)
    local out = {}
    if type(r.coords) == "table" then
        for _, c in ipairs(r.coords) do
            if c[3] == mapID and type(c[1]) == "number" and type(c[2]) == "number" then
                out[#out + 1] = { c[1], c[2] }
            end
        end
    elseif r.mapID == mapID and type(r.x) == "number" and type(r.y) == "number" then
        out[1] = { r.x, r.y }
    end
    return out
end

local function AddQuestPins(mapID)
    if not ns.QuestData or not ns.QuestByMap then return 0 end
    BuildCompletionCache()
    local ids = ns.QuestByMap[mapID]
    if type(ids) ~= "table" then return 0 end

    local groups = {}
    for _, id in ipairs(ids) do
        local r = ns.QuestData[id]
        if IsQuestAvailable(id, r) then
            for _, c in ipairs(CoordsForMap(r, mapID)) do
                local key = string.format("%.3f:%.3f", c[1], c[2])
                local g = groups[key]
                if not g then
                    g = { x=c[1], y=c[2], quests={} }
                    groups[key] = g
                end
                g.quests[#g.quests + 1] = id
            end
        end
    end

    local n = 0
    for _, g in pairs(groups) do
        table.sort(g.quests)
        if AddPin(g.x, g.y, { category="quest", quests=g.quests }) then n = n + 1 end
    end
    return n
end

local function TaxiNodes(mapID)
    if not C_TaxiMap then return nil end
    for _, name in ipairs({ "GetTaxiNodesForMap", "GetAllTaxiNodes" }) do
        local fn = C_TaxiMap[name]
        if type(fn) == "function" then
            local ok, t = pcall(fn, mapID)
            if ok and type(t) == "table" then return t end
        end
    end
end

local function TaxiFactionAllowed(v)
    if v == nil or v == 0 then return true end
    local f = UnitFactionGroup and UnitFactionGroup("player") or nil
    if f == "Horde" then return v == 1 end
    if f == "Alliance" then return v == 2 end
    return true
end

local function AddFlightPins(mapID)
    local t = TaxiNodes(mapID)
    if type(t) ~= "table" then return 0 end
    local seen, n = {}, 0
    for _, node in ipairs(t) do
        local x, y = GetVectorXY(node.position)
        if not x then x = Normalize(node.x) end
        if not y then y = Normalize(node.y) end
        if x and y and TaxiFactionAllowed(node.faction) then
            local k = string.format("%.4f:%.4f", x, y)
            if not seen[k] then
                seen[k] = true
                if AddPin(x, y, { category="flight", name=node.name or "Flight Master" }) then n = n + 1 end
            end
        end
    end
    return n
end

local function AddInstancePins(mapID)
    local points, n = {}, 0
    local function IsNear(x, y)
        for _, p in ipairs(points) do
            local dx, dy = p[1] - x, p[2] - y
            if (dx * dx + dy * dy) < 0.000144 then return true end -- about 1.2% of map
        end
        return false
    end
    local function Add(x, y, name, kind)
        x, y = Normalize(x), Normalize(y)
        if not x or not y or IsNear(x, y) then return end
        points[#points + 1] = { x, y }
        if AddPin(x, y, { category="instance", name=name or "Dungeon / raid", kind=kind }) then n = n + 1 end
    end

    -- Prefer the client's own entrance data when the Forever build exposes it.
    if C_EncounterJournal and type(C_EncounterJournal.GetDungeonEntrancesForMap) == "function" then
        local ok, t = pcall(C_EncounterJournal.GetDungeonEntrancesForMap, mapID)
        if ok and type(t) == "table" then
            for _, info in ipairs(t) do
                local x, y = GetVectorXY(info.position)
                if not x then x = Normalize(info.x) end
                if not y then y = Normalize(info.y) end
                if x and y then Add(x, y, info.name, nil) end
            end
        end
    end

    -- Fallback / supplement for classic entrances not exposed by the native provider.
    local fallback = ns.InstanceByMap and ns.InstanceByMap[mapID]
    if type(fallback) == "table" then
        for _, info in ipairs(fallback) do Add(info.x, info.y, info.name, info.kind) end
    end
    return n
end

local function AddRarePins(mapID)
    local t = ns.RareByMap and ns.RareByMap[mapID]
    if type(t) ~= "table" then return 0 end
    local n = 0
    for _, info in ipairs(t) do
        if AddPin(info.x, info.y, { category="rare", name=info.name, note=info.note }) then n = n + 1 end
    end
    return n
end


-- ---------------------------------------------------------------------------
-- Safe minimap proximity overlay
--
-- This subsystem never changes Minimap textures, masks, zoom, tracking or CVars.
-- It only creates small child frames over the existing minimap.
--   * blue  X: nearby known dungeon/raid entrance (exact static map position)
--   * red   X: nearby curated rare spawn position from the same bundled data as world map
--   * red   !: separate proximity alert at the top of the minimap when a rare/rareelite/
--              worldboss unit is actually exposed by the client via nameplate/target/mouseover.
-- ---------------------------------------------------------------------------
local MINIMAP_UPDATE_INTERVAL = 0.25
local MINIMAP_MARKER_SIZE = 10
local MINIMAP_RARE_MARKER_SIZE = 10
local RARE_SKULL_ICON = "Interface\\AddOns\\ForeverQuestMap\\Media\\rare_skull.tga"
local MINIMAP_EDGE_FACTOR = 0.88
local minimapStaticPins = {}
local minimapRareAlert
local minimapStaticCache = {}
local minimapStaticCacheKey
local nearbyRareUnits = {}
local GetMinimapRadius
local IsRotatingMinimap

local function IsSecretValue(v)
    if type(issecretvalue) ~= "function" then return false end
    local ok, result = pcall(issecretvalue, v)
    return ok and result == true
end

local function RawVectorXY(pos)
    if pos == nil or IsSecretValue(pos) then return nil end
    local x, y
    if type(pos.GetXY) == "function" then
        local ok, a, b = pcall(pos.GetXY, pos)
        if ok then x, y = a, b end
    elseif type(pos.GetX) == "function" and type(pos.GetY) == "function" then
        local ok1, a = pcall(pos.GetX, pos)
        local ok2, b = pcall(pos.GetY, pos)
        if ok1 and ok2 then x, y = a, b end
    elseif type(pos) == "table" then
        x, y = pos.x or pos[1], pos.y or pos[2]
    end
    if IsSecretValue(x) or IsSecretValue(y) then return nil end
    if type(x) ~= "number" or type(y) ~= "number" then return nil end
    return x, y
end

local function ResolveZoneMapID(mapID)
    if type(mapID) ~= "number" then return nil end
    if not C_Map or type(C_Map.GetMapInfo) ~= "function" then return mapID end
    local id = mapID
    for _ = 1, 8 do
        local ok, info = pcall(C_Map.GetMapInfo, id)
        if not ok or type(info) ~= "table" then return id end
        local mapType = info.mapType
        if not IsSecretValue(mapType) and type(mapType) == "number" and mapType == 3 then
            return id
        end
        local parent = info.parentMapID
        if IsSecretValue(parent) or type(parent) ~= "number" or parent <= 0 or parent == id then
            return id
        end
        id = parent
    end
    return id
end

local function WorldPositionForMapPoint(mapID, x, y)
    if not C_Map or type(C_Map.GetWorldPosFromMapPos) ~= "function" then return nil end
    x, y = Normalize(x), Normalize(y)
    if not x or not y then return nil end
    local ok, continentID, worldPos = pcall(C_Map.GetWorldPosFromMapPos, mapID, { x=x, y=y })
    if not ok or IsSecretValue(continentID) or type(continentID) ~= "number" then return nil end
    local wx, wy = RawVectorXY(worldPos)
    if not wx then return nil end
    return continentID, wx, wy
end

local function GetPlayerMinimapState()
    if not C_Map or type(C_Map.GetBestMapForUnit) ~= "function" or type(C_Map.GetPlayerMapPosition) ~= "function" then return nil end
    local okMap, mapID = pcall(C_Map.GetBestMapForUnit, "player")
    if not okMap or IsSecretValue(mapID) or type(mapID) ~= "number" then return nil end

    -- Static POIs are stored in the same normalized zone coordinates used by the
    -- world map. Read the player's position on that exact zone map as well.
    -- This keeps a rare/instance marker anchored to one fixed map coordinate
    -- instead of depending on a second world-position conversion.
    local zoneMapID = ResolveZoneMapID(mapID)
    if type(zoneMapID) ~= "number" then return nil end
    local okPos, pos = pcall(C_Map.GetPlayerMapPosition, zoneMapID, "player")
    if not okPos or not pos then return nil end
    local px, py = RawVectorXY(pos)
    if not px then return nil end

    if type(C_Map.GetMapWorldSize) ~= "function" then return nil end
    local okSize, mapWidth, mapHeight = pcall(C_Map.GetMapWorldSize, zoneMapID)
    if not okSize or IsSecretValue(mapWidth) or IsSecretValue(mapHeight) then return nil end
    if type(mapWidth) ~= "number" or type(mapHeight) ~= "number" or mapWidth <= 0 or mapHeight <= 0 then return nil end

    return zoneMapID, px, py, mapWidth, mapHeight
end

local function AddStaticMinimapPoint(out, category, mapID, x, y)
    x, y = Normalize(x), Normalize(y)
    if not x or not y then return end
    out[#out + 1] = { category=category, mapID=mapID, x=x, y=y }
end

local function BuildStaticMinimapCache(zoneMapID)
    local wantInstance = settings and settings.filters and settings.filters.instance == true
    local wantRare = settings and settings.filters and settings.filters.rare == true
    local key = tostring(zoneMapID) .. ":" .. (wantInstance and "1" or "0") .. ":" .. (wantRare and "1" or "0")
    if key == minimapStaticCacheKey then return minimapStaticCache end

    minimapStaticCacheKey = key
    minimapStaticCache = {}
    if type(zoneMapID) ~= "number" or (not wantInstance and not wantRare) then return minimapStaticCache end

    if wantInstance then
        local seen = {}
        local function AddInstancePoint(x, y)
            x, y = Normalize(x), Normalize(y)
            if not x or not y then return end
            local k = string.format("%.4f:%.4f", x, y)
            if seen[k] then return end
            seen[k] = true
            AddStaticMinimapPoint(minimapStaticCache, "instance", zoneMapID, x, y)
        end

        if C_EncounterJournal and type(C_EncounterJournal.GetDungeonEntrancesForMap) == "function" then
            local ok, t = pcall(C_EncounterJournal.GetDungeonEntrancesForMap, zoneMapID)
            if ok and type(t) == "table" then
                for _, info in ipairs(t) do
                    local x, y = GetVectorXY(info.position)
                    if not x then x = Normalize(info.x) end
                    if not y then y = Normalize(info.y) end
                    if x and y then AddInstancePoint(x, y) end
                end
            end
        end

        local fallback = ns.InstanceByMap and ns.InstanceByMap[zoneMapID]
        if type(fallback) == "table" then
            for _, info in ipairs(fallback) do
                AddInstancePoint(info.x, info.y)
            end
        end
    end

    if wantRare then
        local rareList = ns.RareByMap and ns.RareByMap[zoneMapID]
        if type(rareList) == "table" then
            for _, info in ipairs(rareList) do
                if type(info) == "table" then
                    AddStaticMinimapPoint(minimapStaticCache, "rare", zoneMapID, info.x, info.y)
                end
            end
        end
    end

    return minimapStaticCache
end

local MINIMAP_MARKER_COLORS = {
    instance = { 0.20, 0.55, 1.00 },
    rare     = { 1.00, 0.12, 0.05 },
}

local function CreateMinimapCross(category)
    if not Minimap then return nil end
    local f = CreateFrame("Frame", nil, Minimap)
    local size = MINIMAP_MARKER_SIZE
    if category == "rare" then size = MINIMAP_RARE_MARKER_SIZE end
    f:SetSize(size, size)
    f:EnableMouse(false)
    if type(Minimap.GetFrameLevel) == "function" and type(f.SetFrameLevel) == "function" then
        local ok, level = pcall(Minimap.GetFrameLevel, Minimap)
        if ok and type(level) == "number" then pcall(f.SetFrameLevel, f, level + 8) end
    end
    if category == "rare" then
        local tex = f:CreateTexture(nil, "OVERLAY")
        tex:SetAllPoints(f)
        ApplyRareSkullTexture(tex)
        f.FQMTexture = tex
    else
        local label = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetAllPoints(f)
        label:SetText("X")
        if type(label.SetJustifyH) == "function" then label:SetJustifyH("CENTER") end
        if type(label.SetJustifyV) == "function" then label:SetJustifyV("MIDDLE") end
        local c = MINIMAP_MARKER_COLORS[category] or { 1, 1, 1 }
        label:SetTextColor(c[1], c[2], c[3], 1)
        if type(label.GetFont) == "function" and type(label.SetFont) == "function" then
            local fontPath, fontSize = label:GetFont()
            if fontPath and fontSize then pcall(label.SetFont, label, fontPath, math.max(fontSize, 9), "OUTLINE") end
        end
        f.FQMLabel = label
    end
    f:Hide()
    return f
end

local function AcquireStaticMinimapCross(index, category)
    local f = minimapStaticPins[index]
    if not f then
        f = CreateMinimapCross(category)
        minimapStaticPins[index] = f
    elseif f.FQMCategory ~= category then
        if category == "rare" and f.FQMTexture then
            ApplyRareSkullTexture(f.FQMTexture)
        elseif f.FQMLabel then
            local c = MINIMAP_MARKER_COLORS[category] or { 1, 1, 1 }
            f.FQMLabel:SetTextColor(c[1], c[2], c[3], 1)
        end
    end
    if f then f.FQMCategory = category end
    return f
end

local function HideStaticMinimapCrosses(fromIndex)
    fromIndex = fromIndex or 1
    for i = fromIndex, #minimapStaticPins do
        local f = minimapStaticPins[i]
        if f then f:Hide() end
    end
end

local function SafeRareClassification(unit)
    if unit == nil or IsSecretValue(unit) or type(UnitClassification) ~= "function" then return nil end
    local ok, classification = pcall(UnitClassification, unit)
    if not ok or classification == nil or IsSecretValue(classification) or type(classification) ~= "string" then return nil end
    return classification
end

local function IsRareUnit(unit)
    local classification = SafeRareClassification(unit)
    return classification == "rare" or classification == "rareelite" or classification == "worldboss"
end

local function PruneRareUnits()
    for unit in pairs(nearbyRareUnits) do
        if IsSecretValue(unit) or not IsRareUnit(unit) then nearbyRareUnits[unit] = nil end
    end
end

local function SafeUnitName(unit)
    if unit == nil or IsSecretValue(unit) or type(UnitName) ~= "function" then return nil end
    local ok, name = pcall(UnitName, unit)
    if not ok or name == nil or IsSecretValue(name) or type(name) ~= "string" or name == "" then return nil end
    return name
end

local function GetNearbyRareNames()
    PruneRareUnits()
    local names, seen = {}, {}
    local function AddUnit(unit)
        if not IsRareUnit(unit) then return end
        local name = SafeUnitName(unit)
        if name and not seen[name] then
            seen[name] = true
            names[#names + 1] = name
        end
    end
    for unit in pairs(nearbyRareUnits) do AddUnit(unit) end
    for _, unit in ipairs({ "target", "mouseover", "softenemy" }) do AddUnit(unit) end
    table.sort(names)
    return names
end

local function HasNearbyRare()
    local names = GetNearbyRareNames()
    return #names > 0, names
end

local function ShowRareAlertTooltip(self)
    if not GameTooltip then return end
    local names = self and self.FQMRareNames
    if type(names) ~= "table" or #names == 0 then return end
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("Rare poblíž", 1, 0.82, 0)
    for _, name in ipairs(names) do
        GameTooltip:AddLine(name, 1, 1, 1)
    end
    GameTooltip:Show()
end

local function HideRareAlertTooltip(self)
    if GameTooltip and GameTooltip:IsOwned(self) then GameTooltip:Hide() end
end

local function UpdateRareMinimapAlert()
    if not Minimap then return end
    local detected, names = HasNearbyRare()
    local show = enabled and settings and settings.filters and settings.filters.rare == true and detected
    if show then
        if not minimapRareAlert then
            minimapRareAlert = CreateMinimapCross("instance")
            if minimapRareAlert then
                minimapRareAlert:SetSize(15, 15)
                if minimapRareAlert.FQMLabel then
                    minimapRareAlert.FQMLabel:SetText("!")
                    minimapRareAlert.FQMLabel:SetTextColor(1.00, 0.12, 0.05, 1)
                    if type(minimapRareAlert.FQMLabel.GetFont) == "function" and type(minimapRareAlert.FQMLabel.SetFont) == "function" then
                        local fontPath, fontSize = minimapRareAlert.FQMLabel:GetFont()
                        if fontPath and fontSize then
                            pcall(minimapRareAlert.FQMLabel.SetFont, minimapRareAlert.FQMLabel, fontPath, math.max(fontSize + 3, 13), "OUTLINE")
                        end
                    end
                end
                minimapRareAlert:EnableMouse(true)
                minimapRareAlert:SetScript("OnEnter", ShowRareAlertTooltip)
                minimapRareAlert:SetScript("OnLeave", HideRareAlertTooltip)
            end
        end
        if minimapRareAlert then
            minimapRareAlert.FQMRareNames = names
            minimapRareAlert:ClearAllPoints()
            minimapRareAlert:SetPoint("TOP", Minimap, "TOP", 0, -7)
            minimapRareAlert:Show()
            if GameTooltip and GameTooltip:IsOwned(minimapRareAlert) then ShowRareAlertTooltip(minimapRareAlert) end
        end
    elseif minimapRareAlert then
        minimapRareAlert.FQMRareNames = nil
        HideRareAlertTooltip(minimapRareAlert)
        minimapRareAlert:Hide()
    end
end

GetMinimapRadius = function()
    if C_Minimap and type(C_Minimap.GetViewRadius) == "function" then
        local ok, r = pcall(C_Minimap.GetViewRadius)
        if ok and not IsSecretValue(r) and type(r) == "number" and r > 0 then return r end
    end
    -- Forever exposes GetViewRadius; this is only a conservative fallback.
    local zoom = 0
    if Minimap and type(Minimap.GetZoom) == "function" then
        local ok, z = pcall(Minimap.GetZoom, Minimap)
        if ok and type(z) == "number" then zoom = z end
    end
    local diameter = ({ [0]=466.6667, [1]=400, [2]=333.3333, [3]=266.3333, [4]=200, [5]=133.3333 })[zoom] or 466.6667
    return diameter * 0.5
end

IsRotatingMinimap = function()
    if type(GetCVar) ~= "function" then return false end
    local ok, v = pcall(GetCVar, "rotateMinimap")
    if not ok or IsSecretValue(v) then return false end
    local rotate = tostring(v) == "1"
    if rotate and C_Minimap and type(C_Minimap.IsRotateMinimapIgnored) == "function" then
        local ok2, ignored = pcall(C_Minimap.IsRotateMinimapIgnored)
        if ok2 and ignored == true then rotate = false end
    end
    return rotate
end

local function UpdateStaticMinimapCrosses()
    if not Minimap or not enabled or not settings or not settings.filters then
        HideStaticMinimapCrosses(1)
        return
    end
    if type(Minimap.IsShown) == "function" and not Minimap:IsShown() then
        HideStaticMinimapCrosses(1)
        return
    end
    if settings.filters.instance ~= true and settings.filters.rare ~= true then
        HideStaticMinimapCrosses(1)
        return
    end

    local zoneMapID, playerX, playerY, mapWidth, mapHeight = GetPlayerMinimapState()
    if not zoneMapID then
        HideStaticMinimapCrosses(1)
        return
    end

    local points = BuildStaticMinimapCache(zoneMapID)
    local radius = GetMinimapRadius()
    if type(radius) ~= "number" or radius <= 0 then
        HideStaticMinimapCrosses(1)
        return
    end

    local halfW = (Minimap:GetWidth() or 0) * 0.5
    local halfH = (Minimap:GetHeight() or 0) * 0.5
    if halfW <= 0 or halfH <= 0 then
        HideStaticMinimapCrosses(1)
        return
    end

    local rotate = IsRotatingMinimap()
    local mapSin, mapCos = 0, 1
    if rotate and type(GetPlayerFacing) == "function" then
        local ok, facing = pcall(GetPlayerFacing)
        if ok and not IsSecretValue(facing) and type(facing) == "number" then
            mapSin, mapCos = math.sin(facing), math.cos(facing)
        else
            rotate = false
        end
    end

    local shown = 0
    for _, point in ipairs(points) do
        local categoryOn = settings.filters[point.category] == true
        if categoryOn and point.mapID == zoneMapID then
            -- Map X grows east/right and map Y grows south/down. Convert the
            -- fixed world-map POI coordinate into yard offsets from the player.
            -- As the player walks, only this relative offset changes; point.x/y
            -- themselves never move.
            local xDist = (point.x - playerX) * mapWidth
            local yDist = (point.y - playerY) * mapHeight
            if rotate then
                local dx, dy = xDist, yDist
                xDist = dx * mapCos - dy * mapSin
                yDist = dx * mapSin + dy * mapCos
            end
            local diffX = xDist / radius
            local diffY = yDist / radius
            local dist2 = diffX * diffX + diffY * diffY
            if dist2 <= (MINIMAP_EDGE_FACTOR * MINIMAP_EDGE_FACTOR) then
                shown = shown + 1
                local pin = AcquireStaticMinimapCross(shown, point.category)
                if pin then
                    pin:ClearAllPoints()
                    pin:SetPoint("CENTER", Minimap, "CENTER", diffX * halfW, -diffY * halfH)
                    pin:Show()
                end
            end
        end
    end
    HideStaticMinimapCrosses(shown + 1)
end

local function UpdateMinimapOverlay()
    if not settings then EnsureSettings() end
    if not enabled then
        HideStaticMinimapCrosses(1)
        if minimapRareAlert then minimapRareAlert:Hide() end
        return
    end
    UpdateStaticMinimapCrosses()
    UpdateRareMinimapAlert()
end

local minimapEventFrame = CreateFrame("Frame")
for _, event in ipairs({ "NAME_PLATE_UNIT_ADDED", "NAME_PLATE_UNIT_REMOVED", "PLAYER_ENTERING_WORLD", "ZONE_CHANGED", "ZONE_CHANGED_NEW_AREA", "PLAYER_TARGET_CHANGED", "UPDATE_MOUSEOVER_UNIT" }) do
    pcall(minimapEventFrame.RegisterEvent, minimapEventFrame, event)
end
minimapEventFrame:SetScript("OnEvent", function(_, event, unit)
    if event == "NAME_PLATE_UNIT_ADDED" then
        if unit ~= nil and not IsSecretValue(unit) and IsRareUnit(unit) then nearbyRareUnits[unit] = true end
    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        if unit ~= nil and not IsSecretValue(unit) then nearbyRareUnits[unit] = nil end
    elseif event == "PLAYER_ENTERING_WORLD" or event == "ZONE_CHANGED" or event == "ZONE_CHANGED_NEW_AREA" then
        wipe(nearbyRareUnits)
        minimapStaticCacheKey = nil
    end
end)

local minimapElapsed = 0
minimapEventFrame:SetScript("OnUpdate", function(_, dt)
    minimapElapsed = minimapElapsed + dt
    if minimapElapsed < MINIMAP_UPDATE_INTERVAL then return end
    minimapElapsed = 0
    UpdateMinimapOverlay()
end)

local function UpdateButtonVisual(b)
    if not b or not settings then return end
    local on = settings.filters[b.fqmKey] == true
    if b.Border then
        if on then b.Border:SetVertexColor(1, 0.82, 0, 1)
        else b.Border:SetVertexColor(0.35, 0.35, 0.35, 1) end
    end
    if b.Icon then
        b.Icon:SetDesaturated(not on)
        b.Icon:SetAlpha(on and 1 or 0.52)
    end
end

local function ShowSizeTooltip(b)
    if not GameTooltip then return end
    GameTooltip:SetOwner(b, "ANCHOR_BOTTOM")
    GameTooltip:SetText("Velikost ikonek", 1, 0.82, 0)
    GameTooltip:Show()
end

local function ShowButtonTooltip(b)
    if not GameTooltip then return end
    GameTooltip:SetOwner(b, "ANCHOR_BOTTOM")
    local on = settings.filters[b.fqmKey] == true
    if b.fqmKey == "rare" then
        GameTooltip:SetText("Nektere rare", 1, 0.82, 0)
        GameTooltip:AddLine(on and "ZAPNUTO" or "VYPNUTO", on and 0.2 or 1, on and 1 or 0.25, on and 0.2 or 0.25)
    elseif on then
        GameTooltip:SetText("ZAPNUTO", 0.2, 1, 0.2)
    else
        GameTooltip:SetText("VYPNUTO", 1, 0.25, 0.25)
    end
    GameTooltip:Show()
end

local Refresh

local function PositionToolbar()
    if not toolbar then return end
    local a = GetToolbarAnchor()
    if not a then return end
    toolbar:ClearAllPoints()
    toolbar:SetPoint("TOPRIGHT", a, "TOPRIGHT", -10, -10)
end

local function UpdateZoneLevelText(mapID)
    if not zoneLevelText then return end
    local range = mapID and ZONE_LEVEL_RANGES[mapID]
    if not range then
        zoneLevelText:SetText("")
        zoneLevelText:Hide()
        return
    end

    if range[1] == range[2] then
        zoneLevelText:SetText("Oblast LVL: " .. tostring(range[1]))
    else
        zoneLevelText:SetText("Oblast LVL: " .. tostring(range[1]) .. "-" .. tostring(range[2]))
    end
    zoneLevelText:Show()
end

local function CreateToolbar()
    if toolbar or not WorldMapFrame then return end
    local w = TOOLBAR_PADDING * 2 + #FILTERS * TOOLBAR_BUTTON_SIZE + 2 * SIZE_BUTTON_WIDTH + (#FILTERS + 1) * TOOLBAR_SPACING
    toolbar = CreateFrame("Frame", "ForeverQuestMapToolbar", WorldMapFrame)
    toolbar:SetSize(w, TOOLBAR_BUTTON_SIZE + TOOLBAR_PADDING * 2)
    toolbar:SetFrameStrata("HIGH")
    toolbar:SetFrameLevel((WorldMapFrame:GetFrameLevel() or 0) + 80)

    local bg = toolbar:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture("Interface\\Buttons\\WHITE8X8")
    bg:SetVertexColor(0.03, 0.03, 0.03, 0.78)

    for i, info in ipairs(FILTERS) do
        local b = CreateFrame("Button", nil, toolbar)
        b:SetSize(TOOLBAR_BUTTON_SIZE, TOOLBAR_BUTTON_SIZE)
        b:SetPoint("LEFT", toolbar, "LEFT", TOOLBAR_PADDING + (i - 1) * (TOOLBAR_BUTTON_SIZE + TOOLBAR_SPACING), 0)
        b.fqmKey = info.key

        local border = b:CreateTexture(nil, "BORDER")
        border:SetPoint("TOPLEFT", b, "TOPLEFT", -1, 1)
        border:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 1, -1)
        border:SetTexture("Interface\\Buttons\\WHITE8X8")
        b.Border = border

        local icon = b:CreateTexture(nil, "ARTWORK")
        icon:SetPoint("TOPLEFT", b, "TOPLEFT", 2, -2)
        icon:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -2, 2)
        b.Icon = icon
        ApplyTexture(icon, info.key)
        SetCircularMask(b, icon, info.key == "flight")

        b:SetScript("OnClick", function(self)
            settings.filters[self.fqmKey] = not settings.filters[self.fqmKey]
            UpdateButtonVisual(self)
            Refresh()
        end)
        b:SetScript("OnEnter", ShowButtonTooltip)
        b:SetScript("OnLeave", function(self)
            if GameTooltip and GameTooltip:IsOwned(self) then GameTooltip:Hide() end
        end)
        buttons[#buttons + 1] = b
    end

    local function CreateSizeButton(text, delta, xOffset)
        local b = CreateFrame("Button", nil, toolbar)
        b:SetSize(SIZE_BUTTON_WIDTH, TOOLBAR_BUTTON_SIZE)
        b:SetPoint("LEFT", toolbar, "LEFT", xOffset, 0)

        local border = b:CreateTexture(nil, "BORDER")
        border:SetPoint("TOPLEFT", b, "TOPLEFT", -1, 1)
        border:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 1, -1)
        border:SetTexture("Interface\\Buttons\\WHITE8X8")
        border:SetVertexColor(0.35, 0.35, 0.35, 1)

        local label = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        label:SetPoint("CENTER", b, "CENTER", 0, 0)
        label:SetText(text)
        label:SetTextColor(1, 0.82, 0)

        b:SetScript("OnClick", function()
            local v = (settings and settings.iconScale) or 0.80
            v = math.floor((v + delta) * 100 + 0.5) / 100
            if v < ICON_SCALE_MIN then v = ICON_SCALE_MIN end
            if v > ICON_SCALE_MAX then v = ICON_SCALE_MAX end
            settings.iconScale = v
            Refresh()
        end)
        b:SetScript("OnEnter", ShowSizeTooltip)
        b:SetScript("OnLeave", function(self)
            if GameTooltip and GameTooltip:IsOwned(self) then GameTooltip:Hide() end
        end)
    end

    local sizeStart = TOOLBAR_PADDING + #FILTERS * (TOOLBAR_BUTTON_SIZE + TOOLBAR_SPACING)
    CreateSizeButton("-", -ICON_SCALE_STEP, sizeStart)
    CreateSizeButton("+",  ICON_SCALE_STEP, sizeStart + SIZE_BUTTON_WIDTH + TOOLBAR_SPACING)

    zoneLevelText = toolbar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    zoneLevelText:SetPoint("TOPRIGHT", toolbar, "BOTTOMRIGHT", 0, -3)
    zoneLevelText:SetWidth(w)
    zoneLevelText:SetHeight(16)
    if type(zoneLevelText.SetJustifyH) == "function" then zoneLevelText:SetJustifyH("RIGHT") end
    if type(zoneLevelText.SetTextColor) == "function" then zoneLevelText:SetTextColor(1, 0.82, 0) end
    if type(zoneLevelText.GetFont) == "function" and type(zoneLevelText.SetFont) == "function" then
        local fontPath, fontSize = zoneLevelText:GetFont()
        if fontPath and fontSize then
            pcall(zoneLevelText.SetFont, zoneLevelText, fontPath, fontSize + 2, "OUTLINE")
        end
    end
    if type(zoneLevelText.SetShadowColor) == "function" then zoneLevelText:SetShadowColor(0, 0, 0, 1) end
    if type(zoneLevelText.SetShadowOffset) == "function" then zoneLevelText:SetShadowOffset(2, -2) end
    zoneLevelText:Hide()

    PositionToolbar()
    toolbar:Show()
    for _, b in ipairs(buttons) do UpdateButtonVisual(b) end
end

Refresh = function()
    if not enabled or not IsMapShown() then
        ReleasePins()
        if zoneLevelText then zoneLevelText:Hide() end
        return
    end
    if not settings then EnsureSettings() end
    local mapID = GetMapID()
    if not mapID then
        ReleasePins()
        if zoneLevelText then zoneLevelText:Hide() end
        return
    end

    UpdateZoneLevelText(mapID)
    ReleasePins()
    local q, f, d, r = 0, 0, 0, 0
    if settings.filters.quest then q = AddQuestPins(mapID) end
    if settings.filters.flight then f = AddFlightPins(mapID) end
    if settings.filters.instance then d = AddInstancePins(mapID) end
    if settings.filters.rare then r = AddRarePins(mapID) end
    lastQuestCount, lastFlightCount, lastInstanceCount, lastRareCount, lastMapID = q, f, d, r, mapID
    PositionToolbar()
end

local frame = CreateFrame("Frame")
local events = {
    "PLAYER_LOGIN", "QUEST_LOG_UPDATE", "QUEST_ACCEPTED", "QUEST_TURNED_IN",
    "QUEST_REMOVED", "QUEST_DATA_LOAD_RESULT", "PLAYER_LEVEL_UP", "SKILL_LINES_CHANGED",
}
for _, e in ipairs(events) do pcall(frame.RegisterEvent, frame, e) end

frame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        EnsureSettings()
        CreateToolbar()
        if WorldMapFrame and not worldMapHooked then
            worldMapHooked = true
            if type(WorldMapFrame.HookScript) == "function" then
                WorldMapFrame:HookScript("OnShow", function()
                    CreateToolbar()
                    PositionToolbar()
                    if C_Timer and C_Timer.After then
                        C_Timer.After(0.05, Refresh)
                        C_Timer.After(0.35, Refresh)
                    else
                        Refresh()
                    end
                end)
                WorldMapFrame:HookScript("OnHide", function()
                    ReleasePins()
                    if toolbar then toolbar:Hide() end
                end)
                WorldMapFrame:HookScript("OnSizeChanged", function()
                    PositionToolbar()
                    RepositionPins()
                end)
            end
        end
        if IsMapShown() then Refresh() end
    else
        completionDirty = true
        professionSkillLines = nil
        if IsMapShown() then Refresh() end
    end
end)

local elapsed = 0
frame:SetScript("OnUpdate", function(_, dt)
    if not enabled or not IsMapShown() then return end
    elapsed = elapsed + dt
    if elapsed < UPDATE_INTERVAL then return end
    elapsed = 0

    if not toolbar then
        CreateToolbar()
    elseif not toolbar:IsShown() then
        toolbar:Show()
    end

    local id = GetMapID()
    local c = GetCanvas()
    local w = c and c:GetWidth() or 0
    local h = c and c:GetHeight() or 0
    if id ~= lastMapID then
        Refresh()
    elseif w ~= lastCanvasW or h ~= lastCanvasH then
        lastCanvasW, lastCanvasH = w, h
        PositionToolbar()
        RepositionPins()
    end
end)

SLASH_FOREVERQUESTMAP1 = "/fqm"
SlashCmdList.FOREVERQUESTMAP = function(msg)
    if not settings then EnsureSettings() end
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")
    if msg == "on" then
        enabled = true
        settings.enabled = true
        if toolbar then toolbar:Show() end
        Refresh()
        Print("zapnuto")
    elseif msg == "off" then
        enabled = false
        settings.enabled = false
        ReleasePins()
        if toolbar then toolbar:Hide() end
        Print("vypnuto")
    elseif msg == "refresh" then
        completionDirty = true
        lastMapID = nil
        Refresh()
        Print("obnoveno")
    elseif msg == "reset" then
        ForeverQuestMapDB = nil
        EnsureSettings()
        for _, b in ipairs(buttons) do UpdateButtonVisual(b) end
        completionDirty = true
        Refresh()
        Print("nastaveni resetovano")
    elseif msg == "status" then
        local meta = ns.QuestDataMeta or {}
        Print("v" .. VERSION .. " | mapa " .. tostring(GetMapID()) ..
            " | quest " .. lastQuestCount .. " | flight " .. lastFlightCount ..
            " | vstupy " .. lastInstanceCount .. " | rare " .. lastRareCount ..
            " | DB " .. tostring(meta.questCount or 0) .. " questu / " .. tostring(meta.coordCount or 0) .. " bodu" ..
            " | velikost " .. tostring(math.floor(((settings and settings.iconScale) or 0.80) * 100 + 0.5)) .. "%")
    else
        Print("/fqm on | off | refresh | reset | status")
    end
end
