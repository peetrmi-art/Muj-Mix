-- NPC greetings/options and available/active quest titles. Only rendered text changes.
-- Mouse mode keeps the proven 0.13.42 path. Gamepad mode never hooks GossipFrame
-- or its action rows; an addon-owned ticker refreshes public text only.
local _, A = ...
local font="Interface\\AddOns\\ForeverCestina\\Fonts\\ForeverSerif-Medium.ttf"
local watched=setmetatable({},{__mode="k"})
local hooked=setmetatable({},{__mode="k"})
local gamepadStates=setmetatable({},{__mode="k"})
local refreshing=false
local loggedIn=false
local function controller()
 -- Use the same active UI style as GossipFrame itself. Enabled controller
 -- hardware alone does not mean the player is using the gamepad interface.
 if InputUtil and type(InputUtil.IsGamepadUIEnabled)=="function" then
  local ok,value=pcall(InputUtil.IsGamepadUIEnabled)
  if ok and A.Accessible(value) and type(value)=="boolean" then return value end
 end
 -- Preserve the conservative old route if the native style API is unavailable.
 return A.GamepadActive and A.GamepadActive()
end
local function enabled()
 return (not A.DB or A.DB.enabled~=false) and not (IsShiftKeyDown and IsShiftKeyDown())
end
local function npcName()
 local name=UnitName and UnitName("npc")
 if A.Accessible(name) and type(name)=="string" then return name end
end
-- Cache only source patterns, never player values or rendered NPC text.
local indexedEntries,indexedCount,npcIndex=nil,0,{}
local function normalize(text)
 if not A.Accessible(text) or type(text)~="string" then return end
 return A.Normalize((text:gsub("%$[Bb]","\n")))
end
local function gender(text,sex)
 return (text:gsub("%$[Gg]([^:;]*):([^;]*);",function(male,female)
  return sex==2 and male or female
 end))
end
local function playerSex()
 if type(UnitSex)~="function" then return end
 local ok,sex=pcall(UnitSex,"player")
 if ok and A.Accessible(sex) and (sex==2 or sex==3) then return sex end
end
local function escape(text)
 return (text:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])","%%%1"))
end
local function compile(entry)
 local result={}
 local male,female=normalize(gender(entry.en,2)),normalize(gender(entry.en,3))
 local maleCS,femaleCS=gender(entry.cs,2),gender(entry.cs,3)
 for sex=2,3 do
  local en=sex==2 and male or female
  local parts,keys,pos={"^"},{},1
  while true do
   local first,last,key=en:find("%$([NnCcRr])",pos)
   if not first then break end
   keys[#keys+1]=key:lower()
   parts[#parts+1]=escape(en:sub(pos,first-1))
   parts[#parts+1]="(.-)"
   pos=last+1
  end
  parts[#parts+1]=escape(en:sub(pos)).."$"
  result[#result+1]={pattern=table.concat(parts),keys=keys,
   cs=sex==2 and maleCS or femaleCS,
   sex=male==female and maleCS~=femaleCS and sex or nil}
  if male==female and maleCS==femaleCS then break end
 end
 return result
end
function A.TranslateGossip(npc,text)
 if not A.Accessible(npc) or type(npc)~="string" then return end
 local clean=normalize(text)
 if not clean or clean=="" or #clean>16000 then return end
 local entries=A.GossipEntries or {}
 if indexedEntries~=entries or indexedCount~=#entries then
  indexedEntries,indexedCount,npcIndex=entries,#entries,{}
  for _,entry in ipairs(entries) do
   local bucket=npcIndex[entry.npc]
   if not bucket then bucket={};npcIndex[entry.npc]=bucket end
   bucket[#bucket+1]={entry=entry,clean=A.Normalize(entry.en)}
  end
 end
 local sex=playerSex()
 -- Preserve established literal translations before considering templates.
 for pass=1,2 do
 for _,item in ipairs(npcIndex[npc] or {}) do
  if (item.clean==clean)==(pass==1) then
  item.rules=item.rules or compile(item.entry)
  for _,rule in ipairs(item.rules) do
   local captures={clean:match(rule.pattern)}
   if (not rule.sex or rule.sex==sex) and ((#rule.keys==0 and clean:match(rule.pattern)) or (#rule.keys>0 and #captures==#rule.keys)) then
    local values,valid={},true
    for i,key in ipairs(rule.keys) do
     local value=captures[i]
     if value=="" or #value>120 or value:find("%$") or (values[key] and values[key]~=value) then valid=false end
     values[key]=value
    end
    if valid then
     local cs=rule.cs:gsub("%$[Bb]","\n")
     cs=cs:gsub("%$([NnCcRr])",function(key)return values[key:lower()] or "$"..key end)
     if not cs:find("%$[%w]") then return cs end
    end
   end
  end
  end
 end
 end
end
local function translated(kind,object,text)
 if not enabled() then return nil end
 if kind=="quest" then
  local id=object.GetID and object:GetID()
  return A.TranslateQuestTitle(id,text)
 elseif kind=="option" and A.GossipOptionTranslations and A.GossipOptionTranslations[text] then
  return A.GossipOptionTranslations[text]
 elseif kind=="goodbye" then
  if text=="Goodbye" then return "Sbohem" end
 else
  return A.TranslateGossip(npcName(),text)
 end
end
-- Original mouse/keyboard path from 0.13.42.
local function apply(object,state)
 if controller() or state.busy then return end
 state.busy=true
 local ok,err=pcall(function()
  local text=object:GetText()
  if not A.Accessible(text) or type(text)~="string" then return end
  local cs=translated(state.kind,object,text)
  if cs then
   state.base=state.base or A.CaptureFont(state.fs)
   A.SetLocalizedFont(state.fs,state.base,font,state.kind=="goodbye" and 0 or 1)
   state.changed=true
   object:SetText(cs)
  elseif state.changed then
   A.RestoreFont(state.fs,state.base);state.changed=false
  end
 end)
 state.busy=false
 if not ok then A.NoteError("NPC text",err) end
end
local function watch(object,kind)
 if not object or not object.SetText or not object.GetText or watched[object] then return false end
 local fs=object.GetFontString and object:GetFontString() or object
 if not fs or not fs.GetFont then return false end
 local state={kind=kind,fs=fs};watched[object]=state
 hooksecurefunc(object,"SetText",function() apply(object,state) end)
 if object.SetFormattedText then hooksecurefunc(object,"SetFormattedText",function() apply(object,state) end) end
 -- The parchment theme can assign a font object after text has been measured.
 if fs.SetFontObject then hooksecurefunc(fs,"SetFontObject",function()
  if controller() then return end
  if state.changed and not state.busy then
   state.busy=true
   A.SafeCall("NPC theme font",A.SetLocalizedFont,fs,state.base,font,kind=="goodbye" and 0 or 1)
   state.busy=false
  end
 end) end
 return true
end
local function watchFrame(frame)
 if not frame then return false end
 if frame.GreetingText then return watch(frame.GreetingText,"greeting") end
 if frame.GetFontString and frame.Setup then
  return watch(frame,frame.UpdateTitleForQuest and "quest" or "option")
 end
 return false
end
-- Native ScrollBox measures direct-child template buttons, then initializes
-- visible rows inside the ScrollBox. Only the visible rows receive the theme's
-- RegisterFontString call. Measure the same text with the same native font base;
-- otherwise even the existing rebuild still reserves a smaller template row.
local function syncMouseMeasurements(frame)
 local scroll=frame.GreetingPanel and frame.GreetingPanel.ScrollBox
 local refs={}
 if scroll and scroll.GetFrames then
  for _,row in ipairs(scroll:GetFrames() or {}) do
   if not (row.IsForbidden and row:IsForbidden()) then
   local object=row.GreetingText or (row.GetFontString and row.Setup and row)
   local state=object and watched[object]
   if state then
    refs[state.kind]=state.changed and state.base or A.CaptureFont(state.fs)
   end
   end
  end
 end
 local changed=false
 if frame.GetChildren then for _,child in ipairs({frame:GetChildren()}) do
  if not (child.IsForbidden and child:IsForbidden()) then
   changed=watchFrame(child) or changed
   local object=child.GreetingText or (child.GetFontString and child.Setup and child)
   local state=object and watched[object]
   local base=state and refs[state.kind]
   if base then
    local old=state.base or A.CaptureFont(state.fs)
    if old.path~=base.path or old.size~=base.size or old.flags~=base.flags or old.spacing~=base.spacing then
     if state.changed then A.SetLocalizedFont(state.fs,base,font,1,0)
     else A.RestoreFont(state.fs,base) end
     state.base=base
     changed=true
    end
   end
  end
 end end
 return changed
end
local function attachMouse(frame)
 if controller() or not frame or hooked[frame] or not frame.Update or not frame.RegisterFontString then return end
 hooked[frame]=true
 -- Called before native Setup on each newly acquired/recycled visible row.
 hooksecurefunc(frame,"RegisterFontString",function(_,fs)
  if controller() then return end
  if fs and fs.GetParent then A.SafeCall("NPC row hooks",watchFrame,fs:GetParent()) end
 end)
 hooksecurefunc(frame,"Update",function()
  if controller() or refreshing then return end
  refreshing=true
  A.SafeCall("NPC window",function()
   local added=syncMouseMeasurements(frame)
   local panel=frame.GreetingPanel
   if panel then
    local button=panel.GoodbyeButton
    if button then
     watch(button,"goodbye")
     button:SetText("Goodbye")
    end
   end
   -- Reuse the existing single native rebuild, after template metrics agree.
   if added and not (InCombatLockdown and InCombatLockdown()) then frame:Update() end
  end)
  refreshing=false
 end)
end
-- Controller path: no hooks/callbacks on Blizzard rows or GossipFrame. We only
-- rewrite the already-rendered public FontString from an addon-owned timer.
local function applyGamepad(object,kind)
 if not object or not object.GetText then return end
 local fs=object.GetFontString and object:GetFontString() or object
 if not fs or not fs.GetText or not fs.SetText or not fs.GetFont then return end
 local state=gamepadStates[fs]
 if not state then state={kind=kind,object=object};gamepadStates[fs]=state end
 local text=object:GetText()
 if not A.Accessible(text) or type(text)~="string" then return end
 if text~=state.cs and text~=state.en then state.en=text end
 if not state.en then state.en=text end
 local cs=translated(kind,object,state.en)
 if cs then
  if not state.base then
   local ok,base=pcall(A.CaptureFont,fs);if not ok then return end;state.base=base
  end
  if not state.changed then A.SafeCall("NPC gamepad font",A.SetLocalizedFont,fs,state.base,font,1);state.changed=true end
  state.cs=cs
  if fs:GetText()~=cs then fs:SetText(cs) end
 else
  if state.cs and fs:GetText()==state.cs then fs:SetText(state.en) end
  if state.changed and state.base then A.SafeCall("NPC gamepad font restore",A.RestoreFont,fs,state.base) end
  state.changed=nil;state.cs=nil
 end
end
local function scanGamepad(frame,depth)
 depth=depth or 0
 if not frame or depth>10 or (frame.IsForbidden and frame:IsForbidden()) then return end
 -- Never localize the native Goodbye action button in controller mode.
 local panel=_G.GossipFrame and GossipFrame.GreetingPanel
 if panel and frame==panel.GoodbyeButton then return end
 if frame.GreetingText then applyGamepad(frame.GreetingText,"greeting") end
 if frame.GetFontString and frame.Setup then
  applyGamepad(frame,frame.UpdateTitleForQuest and "quest" or "option")
 end
 if frame.GetChildren then for _,child in ipairs({frame:GetChildren()}) do scanGamepad(child,depth+1) end end
end
local function capture()
 if not A.DB or not C_GossipInfo then return end
 local npc=npcName();if not npc or #npc>200 then return end
 local function record(kind,text)
  if not A.Accessible(text) or type(text)~="string" or #text<2 or #text>8000
      or A.TranslateGossip(npc,text) then return end
  local samples=A.DB.gossipSamples
  if type(samples)~="table" then samples={};A.DB.gossipSamples=samples end
  for _,v in ipairs(samples) do if v.npc==npc and v.kind==kind and v.en==text then return end end
  if #samples>=200 then return end
  samples[#samples+1]={npc=npc,kind=kind,en=text}
 end
 if C_GossipInfo.GetText then record("greeting",C_GossipInfo.GetText()) end
 local options=C_GossipInfo.GetOptions and C_GossipInfo.GetOptions()
 if A.Accessible(options) and type(options)=="table" then
  for _,option in ipairs(options) do
   if A.Accessible(option) and type(option)=="table" then record("option",option.name) end
  end
 end
end
local events=CreateFrame("Frame")
for _,e in ipairs({"ADDON_LOADED","PLAYER_LOGIN","GOSSIP_SHOW","MODIFIER_STATE_CHANGED"}) do events:RegisterEvent(e) end
events:SetScript("OnEvent",function(_,event,key)
 if event=="PLAYER_LOGIN" then loggedIn=true end
 if controller() then
  if event=="GOSSIP_SHOW" then
   A.SafeCall("NPC capture",capture)
   -- Run once after all GOSSIP_SHOW handlers have populated the native rows,
   -- in our own frame's update phase instead of waiting for the 0.15s ticker.
   -- Never attach a handler to Blizzard frames or invoke their Update/actions.
   events:SetScript("OnUpdate",function(self)
    self:SetScript("OnUpdate",nil)
    if controller() and _G.GossipFrame and GossipFrame:IsShown() then
     A.SafeCall("NPC gamepad first display",scanGamepad,GossipFrame,0)
    end
   end)
  end
  -- No native Update call and no native frame hook in controller mode.
  return
 end
 -- Do not install irreversible native frame hooks before the final controller
 -- state is available at PLAYER_LOGIN.
 if not loggedIn then return end
 local frame=_G.GossipFrame
 local alreadyHooked=frame and hooked[frame]
 A.SafeCall("NPC install",attachMouse,frame)
 if event=="GOSSIP_SHOW" then
  A.SafeCall("NPC capture",capture)
  -- Covers a switch from controller UI to mouse before this first interaction,
  -- including native-first event ordering. Finish before the event is painted.
  if not alreadyHooked and frame and hooked[frame] and frame:IsShown()
      and not (InCombatLockdown and InCombatLockdown()) then
   A.SafeCall("NPC first window",frame.Update,frame)
  end
 end
 if event=="MODIFIER_STATE_CHANGED" and (key=="LSHIFT" or key=="RSHIFT")
     and GossipFrame and GossipFrame:IsShown() and not (InCombatLockdown and InCombatLockdown()) then
  A.SafeCall("NPC original",GossipFrame.Update,GossipFrame)
 end
end)
if C_Timer and C_Timer.NewTicker then
 C_Timer.NewTicker(0.15,function()
  if controller() and _G.GossipFrame and GossipFrame:IsShown() then
   A.SafeCall("NPC gamepad refresh",scanGamepad,GossipFrame,0)
  end
 end)
end
