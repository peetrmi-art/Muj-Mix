-- Own implementation: correlate known NPC events with a NEW public bubble.
-- This is not a native ownership API. Ambiguous/player-colliding text stays EN.
-- No native hooks, attributes, callbacks, bindings, geometry or global fonts.
local _, A = ...
local receiver = CreateFrame("Frame")
local pending, active, veto = {}, {}, {}
local blackout, elapsed = 0, 0
local retryAt = 0
local font = "Interface\\AddOns\\ForeverCestina\\Fonts\\ForeverSerif-Medium.ttf"
local public = A.Accessible
local function call(o, method, ...)
    if not public(o) or o == nil then return nil end
    local f = o[method]
    if not public(f) or type(f) ~= "function" then return nil end
    local ok, v = pcall(f, o, ...)
    if ok and public(v) then return v end
end
local function safe(o)
    return public(o) and o ~= nil and call(o,"IsForbidden") == false
        and call(o,"IsProtected") == false
end
local function open()
    local combat = InCombatLockdown()
    -- Combat alone does not forbid public text; per-frame guards still apply.
    -- Unknown combat state and actual chat restrictions remain fail-closed.
    if not public(combat) or type(combat) ~= "boolean" then return false end
    if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown then
        local v = C_ChatInfo.InChatMessagingLockdown()
        if not public(v) or v ~= false then return false end
    end
    return true
end
local function enabled()
    local shift = IsShiftKeyDown()
    return (not A.DB or A.DB.enabled ~= false) and public(shift) and shift == false
end
local function report(key)
    if not A.DB then return end
    A.DB.npcBubbleStatus = A.DB.npcBubbleStatus or {version="0.13.109"}
    local r = A.DB.npcBubbleStatus
    r[key] = math.min((r[key] or 0) + 1, 1000000)
end
local function text(v)
    return public(v) and type(v) == "string" and #v <= 2048
end
local function translated(event, message, speaker, recipient)
    for _, row in ipairs(A.NPCBubbleEntries or {}) do
        if row.event == event and row.speaker == speaker then
            local en, cs = row.en, row.cs
            local eligible = true
            if en:find("$N",1,true) then
                if not text(recipient) or recipient == "" or #recipient > 100
                    or recipient:find("[|$\r\n]") then
                    -- Skip only this name-dependent row, not later literal text.
                    eligible = false
                else
                    en = en:gsub("%$N", function() return recipient end)
                    cs = cs:gsub("%$N", function() return recipient end)
                end
            end
            if eligible and en == message then return cs end
        end
    end
end
-- Public chat filter uses the SAME exact dictionary. No AddMessage override.
local function chatTranslation(event,message,speaker,recipient)
    if not open() or not enabled() or not text(message) or not text(speaker) then return end
    return translated(event,message,speaker,recipient)
end
local function chatFilter(_,event,message,speaker,language,channel,recipient,...)
    local ok, cs = pcall(chatTranslation,event,message,speaker,recipient)
    if not ok then A.NoteError("NPCChat",cs); return false end
    if cs then return false,cs,speaker,language,channel,recipient,... end
    return false
end
local chatRegistered = false
local function registerChat()
    if chatRegistered then return end
    local add = ChatFrame_AddMessageEventFilter or (ChatFrameUtil and ChatFrameUtil.AddMessageEventFilter)
    if type(add) ~= "function" then return end
    add("CHAT_MSG_MONSTER_SAY",chatFilter)
    add("CHAT_MSG_MONSTER_YELL",chatFilter)
    chatRegistered = true
end
-- Only the public hierarchy observed on build 70009: bubble -> child.String.
local function snapshot()
    if not C_ChatBubbles or not C_ChatBubbles.GetAllChatBubbles then return nil end
    local list = C_ChatBubbles.GetAllChatBubbles(false)
    if not public(list) or type(list) ~= "table" then return nil end
    local out, count = {}, 0
    for _, bubble in pairs(list) do
        count = count + 1
        if count > 32 then return nil end
        if safe(bubble) and call(bubble,"IsShown") == true then
            local n = call(bubble,"GetNumChildren")
            if A.PublicNumber(n) and n <= 4 then
                local children = {bubble:GetChildren()}
                for _, child in ipairs(children) do
                    if safe(child) then
                        local fs = child.String
                        if safe(fs) and call(fs,"GetObjectType") == "FontString" then
                            local s = call(fs,"GetText")
                            if text(s) then out[fs] = {bubble=bubble, child=child, text=s} end
                        end
                    end
                end
            end
        end
    end
    return out
end
local function writable(fs, state)
    return open() and safe(state.bubble) and safe(state.child) and safe(fs)
end
local function restoreFont(fs, s)
    if not s.fontChanged then return end
    local path, size, flags = fs:GetFont()
    if public(path) and A.PublicNumber(size) and public(flags)
        and path == font and size == s.size and (flags or "") == (s.flags or "") then
        if fs:SetFont(s.path, s.size, s.flags) == false then error("Bubble font restore rejected") end
    end
    s.fontChanged = false
end
local function restore(fs, s)
    if not writable(fs,s) then return false end
    local current = call(fs,"GetText")
    if not text(current) then return false end
    if current == s.cs then fs:SetText(s.en) end
    restoreFont(fs,s)
    return true
end
local function show(fs,s)
    if not s.fontChanged then
        s.fontChanged = true -- retain recovery state even on partial failure
        if fs:SetFont(font,s.size,s.flags) == false then error("Bubble font rejected") end
    end
    fs:SetText(s.cs)
end
local function count(t) local n=0; for _ in pairs(t) do n=n+1 end; return n end
local function update()
    local now = GetTime()
    for s, expiry in pairs(veto) do if expiry < now then veto[s] = nil end end
    if not open() then pending = {}; return end
    local view = snapshot()
    if not view then pending = {}; return end
    -- Retain only our own state. Native objects receive no addon fields.
    for fs,s in pairs(active) do
        local v = view[fs]
        local cancelled = s.cancelled or veto[s.en] or now < blackout or now > s.expires
        for other, value in pairs(view) do
            if other ~= fs and value.text == s.en then cancelled = true end
        end
        if not v or (v.text ~= s.cs and v.text ~= s.en) or cancelled then
            if restore(fs,s) then active[fs] = nil end
        elseif writable(fs,s) then
            if enabled() then
                if v.text == s.en then show(fs,s) end
            elseif v.text == s.cs then restore(fs,s) end
        end
    end
    for en,p in pairs(pending) do
        if now > p.expires or veto[en] or now < blackout or not enabled() then
            pending[en] = nil
        else
            local candidate, total = nil, 0
            for fs,v in pairs(view) do
                if v.text == en or (active[fs] and active[fs].en == en) then
                    total = total + 1
                    if not p.before[fs] and not active[fs] then candidate = fs end
                end
            end
            if total > 1 then pending[en] = nil; report("ambiguous")
            elseif candidate and total == 1 and count(active) < 16 then
                local v = view[candidate]
                local path,size,flags = candidate:GetFont()
                pending[en] = nil
                if text(path) and A.PublicNumber(size) and size > 0 and size < 100
                    and public(flags) and (flags == nil or type(flags) == "string") then
                    local s = {en=en,cs=p.cs,path=path,size=size,flags=flags,
                        bubble=v.bubble,child=v.child,expires=now+45}
                    active[candidate] = s
                    if writable(candidate,s) then show(candidate,s); report("translated") end
                end
            end
        end
    end
end
local function onEvent(_, event, message, speaker, _, _, recipient)
    local now = GetTime()
    for s,expiry in pairs(veto) do if expiry < now then veto[s] = nil end end
    if event == "PLAYER_ENTERING_WORLD" then
        registerChat()
        pending = {}; veto = {}; blackout = now + 1
        for _,s in pairs(active) do s.cancelled = true end
        return
    end
    if event ~= "CHAT_MSG_MONSTER_SAY" and event ~= "CHAT_MSG_MONSTER_YELL" then
        -- Player SAY/YELL/PARTY bubble sources, including party leader messages.
        if not text(message) then
            blackout = now + 60; pending = {}
            for _,s in pairs(active) do s.cancelled = true end
        else
            if count(veto) >= 128 then veto = {}; blackout = now + 60 end
            veto[message] = now + 60; pending[message] = nil
            for _,s in pairs(active) do if s.en == message then s.cancelled = true end end
        end
        return
    end
    if now < retryAt or not open() or not enabled() or now < blackout or not text(message)
        or not text(speaker) or veto[message] then return end
    local cs = translated(event,message,speaker,recipient)
    if not cs then return end
    if pending[message] then
        pending[message] = nil; veto[message] = now + 60; report("ambiguous"); return
    end
    for _,s in pairs(active) do
        if s.en == message then s.cancelled = true; veto[message] = now+60; return end
    end
    if count(pending) >= 16 then return end
    local view = snapshot()
    if not view then return end
    local before = {}
    for fs,v in pairs(view) do if v.text == message then before[fs] = true end end
    pending[message] = {cs=cs,before=before,expires=now+2}
end
local function guarded(fn,...)
    if fn == update and GetTime() < retryAt then return end
    local ok, err = pcall(fn,...)
    if not ok then
        A.NoteError("NPCBubbles",err)
        report("errors"); pending = {}; blackout = GetTime()+2
        for fs,s in pairs(active) do
            s.cancelled = true
            local restored,done = pcall(restore,fs,s)
            if restored and done then active[fs] = nil end
        end
        retryAt = GetTime()+2
    end
end
for _, event in ipairs({"CHAT_MSG_MONSTER_SAY","CHAT_MSG_MONSTER_YELL",
    "CHAT_MSG_SAY","CHAT_MSG_YELL","CHAT_MSG_PARTY","CHAT_MSG_PARTY_LEADER",
    "PLAYER_ENTERING_WORLD"}) do receiver:RegisterEvent(event) end
receiver:SetScript("OnEvent",function(...) guarded(onEvent,...) end)
receiver:SetScript("OnUpdate",function(_,dt)
    elapsed = elapsed + dt
    -- Pending speech: inspect each frame as soon as the public bubble exists.
    -- No fixed grace delay; player veto and ambiguity checks still apply.
    -- Active maintenance keeps its original cadence; idle never scans.
    if not next(pending) and elapsed < 0.1 then return end
    elapsed = 0
    if next(pending) or next(active) then guarded(update) end
end)
registerChat()
