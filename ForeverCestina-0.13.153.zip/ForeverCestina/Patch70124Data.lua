-- Exact public client text captured in the saved 70124 session, reviewed 2026-10-01.
-- Records have no individual build timestamp; full source matching remains required.
-- Additive variants only. No predicted future talents or UI changes.
local _, A = ...
local function R(name, en, cs)
    A.Rules[#A.Rules+1] = {name=name, en=en, cs=cs}
end

R("Light's Vigil",
  "The caster's next Holy Shock on this target will active Light's Vigil, healing the target and their party for {1}.",
  "Příští Holy Shock seslaný původním sesilatelem na tento cíl aktivuje Light's Vigil a vyléčí cíl i jeho skupinu za {1} zdraví.")
R("Light's Vigil", "Deals {1} Holy damage.", "Způsobí {1} svatého poškození.")
R("Light's Vigil", "Deals {1} damage.", "Způsobí {1} poškození.")

R("Create Firestone",
  "Creates a Greater Firestone which can be used to enchant your weapon with Fire, increasing your spell critical strike chance by {1}% and the damage done by your Fire spells by up to {2}. Conjured items disappear if logged out for more than 15 minutes.",
  "Vytvoří Greater Firestone k očarování tvé zbraně ohněm. Zvýší šanci kouzel na kritický zásah o {1} % a poškození tvých ohnivých kouzel až o {2}. Vykouzlené předměty zmizí, pokud zůstaneš odhlášený déle než 15 minut.")
R("Create Firestone",
  "Creates a Major Firestone which can be used to enchant your weapon with Fire, increasing your spell critical strike chance by {1}% and the damage done by your Fire spells by up to {2}. Conjured items disappear if logged out for more than 15 minutes.",
  "Vytvoří Major Firestone k očarování tvé zbraně ohněm. Zvýší šanci kouzel na kritický zásah o {1} % a poškození tvých ohnivých kouzel až o {2}. Vykouzlené předměty zmizí, pokud zůstaneš odhlášený déle než 15 minut.")

R("Berserk",
  "Requires Cat Form, Bear Form, Dire Bear Form Causes your Primal Bite ability to strike up to {1} targets, removes its cooldown, and increases the critical strike chance of your Combo Point-generating abilities by {2}%. Clears and grants immunity to Fear effects for the duration. Lasts {3} sec.",
  "Vyžaduje Cat Form, Bear Form nebo Dire Bear Form.\nPrimal Bite může zasáhnout více cílů (nejvýše {1}) a nemá dobu obnovy. Šance na kritický zásah schopností vytvářejících kombinované body se zvýší o {2} %. Odstraní strach a po dobu účinku poskytuje imunitu vůči strachu. Trvá {3} s.")
R("Devouring Contagion",
  "Reduces the mana cost of your Devouring Plague by {1}%. Targets that die while Devouring Plague is active spreads it, jumping to a nearby enemy within {2} yards for the remaining duration.",
  "Snižuje spotřebu many Devouring Plague o {1} %. Pokud cíl během jeho trvání zemře, Devouring Plague přeskočí na blízkého nepřítele do {2} yardů. Přenese se jen zbývající doba trvání.")
R("Improved Slam",
  "Reduces the global cooldown and cast time of your Slam ability by {1} sec. In addition, Slam no longer interrupts or delays your melee swing and Slam's cooldown is reduced by {2} sec.",
  "Zkracuje globální dobu obnovy a dobu sesílání Slam o {1} s. Slam navíc nepřerušuje ani neodkládá tvůj automatický útok na blízko a jeho doba obnovy se zkracuje o {2} s.")
R("Hellfire Effect", "Deals {1} Fire damage.", "Způsobí {1} ohnivého poškození.")
