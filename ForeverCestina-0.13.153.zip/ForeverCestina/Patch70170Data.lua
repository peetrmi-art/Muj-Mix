-- Exact English sources: Spell/SpellName DB2, 1.60.1.70170, checked 2026-10-02.
-- Numeric values/durations are always taken from the current public client text.
-- Data only: no hooks, timers, layout, CVar changes or client mechanics corrections.
local _, A = ...
local function R(name,en,cs) A.Rules[#A.Rules+1]={name=name,en=en,cs=cs} end

A.SpellIDs[400624]="Heating Up"
A.SpellIDs[400625]="Heating Up"
A.SpellIDs[437032]="Soul Harvest"
A.SpellIDs[1322605]="Shifting Power"
A.SpellIDs[1322670]="Improved Shifting Power"
A.SpellIDs[1323377]="Revelation"
A.SpellIDs[1323392]="Revelation"
A.SpellIDs[1323400]="Revelation"
A.SpellIDs[1323410]="Revelation"
A.SpellIDs[1323418]="Revelation"
A.SpellIDs[1323419]="Revelation"
A.SpellIDs[1323420]="Totemic Recall"

R("Expose Armor",
  "Finishing move that exposes the target for {1} sec, reducing Armor per combo point: 1 point : {2} Armor 2 points: {3} Armor 3 points: {4} Armor 4 points: {5} Armor 5 points: {6} Armor",
  "Dokončovací útok, který na {1} s odhalí slabiny cíle a sníží jeho zbroj podle počtu kombinovaných bodů:\n1 bod: {2} zbroje\n2 body: {3} zbroje\n3 body: {4} zbroje\n4 body: {5} zbroje\n5 bodů: {6} zbroje")

R("Chastise",
  "Chastise the target, causing {1} Holy damage and Immobilizing them for up to {2} sec. Only works against Humanoids. This spell causes very low threat.",
  "Potrestá cíl, způsobí mu {1} svatého poškození a znehybní jej až na {2} s. Funguje pouze na humanoidy. Vytváří velmi nízkou hrozbu.")

R("Aquatic Form",
  "Shapeshift into Aquatic Form, increasing swim speed by {1}% and allowing the druid to breathe underwater. Also protects the caster from Polymorph effects. The act of shapeshifting frees the caster of Polymorph and Movement Impairing effects.",
  "Promění tě do Aquatic Form, zvýší rychlost plavání o {1} % a umožní dýchat pod vodou. Poskytuje imunitu vůči Polymorph.\nZměna podoby odstraní Polymorph a účinky omezující pohyb.")

R("Spearing Strike",
  "A brutal attack that deals {1}% weapon damage, plus an additional {2}% weapon damage against Giants, Dragonkin, and mounted targets.",
  "Brutální útok způsobující {1} % poškození zbraně. Proti obrům, drakům a cílům na jízdním zvířeti způsobí navíc {2} % poškození zbraně.")

R("Raging Blows",
  "Causes your Whirlwind to also strike with your Off Hand weapon, and reduces the Rage cost of your Cleave ability by {1}.",
  "Whirlwind udeří také zbraní v levé ruce a spotřeba zuřivosti Cleave se sníží o {1}.")

R("Binding Heal",
  "Heal yourself and a friendly target for {1}. This causes low threat.",
  "Vyléčí tebe a přátelský cíl za {1} zdraví. Vytváří nízkou hrozbu.")

R("Prayer of Mending",
  "Places a spell on the target that heals them for {1} the next time they take damage or receive non-periodic healing. When the heal occurs, Prayer of Mending jumps to a party or raid member within {2} yds. Jumps up to {3} times and lasts {4} sec after each jump. This spell can only be placed on one target at a time per caster.",
  "Očaruje cíl. Až příště utrpí poškození nebo obdrží přímé léčení, vyléčí se za {1} zdraví. Poté Prayer of Mending přeskočí na člena skupiny nebo raidu do {2} yardů. Přeskočí až {3}krát a po každém přeskočení trvá {4} s. Každý sesilatel může mít toto kouzlo současně jen na jednom cíli.")

R("Lacerating Strikes",
  "Your Mongoose Bite also causes the target to Bleed for damage equal to {1}% of the damage done by Mongoose Bite over {2} sec",
  "Mongoose Bite také způsobí krvácení, které během {2} s způsobí poškození rovné {1} % poškození Mongoose Bite.")

R("Trickster's Dance",
  "Increases your pet's chance to Dodge by {1}% and decreases the time between your pet's attacks by {2}% for {3} sec.",
  "Na {3} s zvýší šanci tvého zvířete na úhyb o {1} % a zkrátí prodlevu mezi jeho útoky o {2} %.")

R("Predator's Edge",
  "Increases your melee critical strike damage by {1}% and your Off Hand weapon damage by {2}%.",
  "Zvyšuje poškození tvých kritických zásahů na blízko o {1} % a poškození zbraně v levé ruce o {2} %.")

R("Improved Stings",
  "Increases the damage of your Serpent Sting ability by {1}%, reduces the cooldown of your Viper Sting ability by {2} sec, and increases the duration of your Scorpid Sting ability by {3} sec.",
  "Zvyšuje poškození Serpent Sting o {1} %, zkracuje dobu obnovy Viper Sting o {2} s a prodlužuje trvání Scorpid Sting o {3} s.")

R("Sniper Shot",
  "A long-range shot that deals ranged damage plus {1} and increases the range of your next {2} Shots by {3} yards for {4} sec.",
  "Střela na velkou vzdálenost, která způsobí poškození útoku na dálku plus {1}. Na {4} s zvýší dosah tvých příštích {2} střel o {3} yardů.")

R("Sniper Shot",
  "Shot range increased by {1}.",
  "Dosah střel zvýšen o {1}.")

R("Venom",
  "Finishing move that increases the damage of your Poisons by {1}% and your chance to apply Poisons by {2}%. Lasts longer per combo point: 1 point : 9 sec 2 points: 12 sec 3 points: 15 sec 4 points: 18 sec 5 points: 21 sec",
  "Dokončovací útok, který zvýší poškození tvých jedů o {1} % a šanci na jejich aplikaci o {2} %. Doba trvání závisí na počtu kombinovaných bodů:\n1 bod: 9 s\n2 body: 12 s\n3 body: 15 s\n4 body: 18 s\n5 bodů: 21 s")

R("Spirit Bond",
  "Regenerating {1}% of total health every {2} sec.",
  "Každé {2} s obnovuje {1} % celkového zdraví.")

R("Twist of Light",
  "Reduces the Mana cost of your Seal spells by {1}%, and when you replace your Seal of Command, Seal of Righteousness, Seal of Fury, or Seal of Justice with a different Seal, you gain an Echo of that Seal. Your next melee attack applies the replaced Seal's effects, consuming the Echo.",
  "Snižuje spotřebu many kouzel Seal o {1} %. Když nahradíš Seal of Command, Seal of Righteousness, Seal of Fury nebo Seal of Justice jinou pečetí, získáš ozvěnu původní pečeti. Tvůj příští útok na blízko vyvolá účinky původní pečeti a ozvěnu spotřebuje.")

R("Voice of Truth",
  "Grants you immunity to Silence and Interrupt effects for {1} sec.",
  "Na {1} s poskytne imunitu vůči umlčení a přerušení sesílání.")

R("Light's Vigil",
  "Applies Light's Vigil to the target for {1} sec. Your next Holy Shock cast on them triggers no cooldown and causes enemy targets to suffer {2} Holy damage and refund {3}% of Light's Vigil's Mana cost, or allied targets to heal their party for {4}. You may only have one Light's Vigil active per party.",
  "Na {1} s umístí na cíl Light's Vigil. Příští Holy Shock seslaný na tento cíl nespustí dobu obnovy. Nepřátelskému cíli způsobí {2} svatého poškození a vrátí {3} % many spotřebované na Light's Vigil; u přátelského cíle vyléčí jeho skupinu za {4} zdraví. V každé skupině můžeš mít aktivní pouze jeden Light's Vigil.")

R("Moonkin Form",
  "Shapeshift into Moonkin Form, increasing Omen of Clarity's chance to trigger by {1}%, Armor contribution from items by {2}%, and all party members within {3} yards have their Critical Strike chance increased by {4}%, exclusive with Leader of the Pack. Also protects the caster from Polymorph effects and prevents the use of healing spells. The act of shapeshifting frees the caster of Polymorph and Movement Impairing effects.",
  "Promění tě do Moonkin Form. Zvýší šanci na spuštění Omen of Clarity o {1} % a příspěvek předmětů ke zbroji o {2} %. Členům skupiny do {3} yardů zvýší šanci na kritický zásah o {4} %; tento účinek se nesčítá s Leader of the Pack. Poskytuje imunitu vůči Polymorph a znemožňuje používat léčivá kouzla.\nZměna podoby odstraní Polymorph a účinky omezující pohyb.")

R("Templar's Bulwark",
  "Absorbs {1} damage.",
  "Pohltí {1} poškození.")

R("Iron Creed",
  "Increases the threat generated by your Holy Strike ability by {1}%. While Righteous Fury is active, Holy Strike also reduces your damage taken by {2}% for {3} sec.",
  "Zvyšuje hrozbu vytvářenou Holy Strike o {1} %. Když je aktivní Righteous Fury, Holy Strike také na {3} s sníží přijímané poškození o {2} %.")

R("Heating Up",
  "Non-periodic critical strikes with Fireball, Frostfire Bolt, Fire Blast, and Scorch reduce the cast time of your next Pyroblast cast within {1} sec by {2}%, stacking up to {3} times.",
  "Přímé kritické zásahy kouzly Fireball, Frostfire Bolt, Fire Blast a Scorch zkrátí dobu sesílání příštího Pyroblast seslaného během {1} s o {2} %. Účinek se sčítá až {3}krát.")

R("Heating Up",
  "Your next Pyroblast spell has its cast time reduced by {1}%.",
  "Doba sesílání tvého příštího Pyroblast je zkrácena o {1} %.")

R("Dual Wield Specialization",
  "Increases your off-hand weapon damage by {1}% and chance to hit with off-hand attacks by {2}%.",
  "Zvyšuje poškození zbraně v levé ruce o {1} % a šanci na zásah útoky levou rukou o {2} %.")

R("Dire Bear Form",
  "Shapeshift into Dire Bear Form, increasing Attack Power by {1}, Armor contribution from items by {2}%, and Health by {3}. Also protects the caster from Polymorph effects and allows the use of various bear abilities. The act of shapeshifting frees the caster of Polymorph and Movement Impairing effects.",
  "Promění tě do Dire Bear Form. Zvýší sílu útoku o {1}, příspěvek předmětů ke zbroji o {2} % a zdraví o {3}. Poskytuje imunitu vůči Polymorph a umožní používat medvědí schopnosti.\nZměna podoby odstraní Polymorph a účinky omezující pohyb.")

R("Dire Bear Form",
  "Immune to Polymorph effects. Increases Attack Power by {1}, Armor contribution from items by {2}%, and Health by {3}.",
  "Imunita vůči Polymorph. Síla útoku zvýšena o {1}, příspěvek předmětů ke zbroji o {2} % a zdraví o {3}.")

R("Dual Wield",
  "Allows one-hand and Off Hand weapons to be equipped in the Off Hand.",
  "Umožňuje vybavit levou ruku jednoručními zbraněmi a zbraněmi určenými pro levou ruku.")

R("Shadowmeld",
  "Slips into the shadows, reducing the chance for enemies to detect your presence. Lasts until cancelled or upon moving.",
  "Skryje tě ve stínech a sníží šanci, že tě nepřátelé odhalí. Trvá do zrušení nebo dokud se nepohneš.")

R("Eureka!",
  "Your next {1} non-periodic damaging or healing abilities have their Mana cost reduced by {2}% and deal {3}% more damage or healing.",
  "Tvé příští {1} schopnosti s přímým poškozením nebo léčením spotřebují o {2} % méně many a způsobí o {3} % více poškození nebo léčení.")

R("Eureka!",
  "Next {1} non-periodic damaging or healing abilities cost {2}% less Mana and deal {3}% more damage or healing.",
  "Příští {1} schopnosti s přímým poškozením nebo léčením spotřebují o {2} % méně many a způsobí o {3} % více poškození nebo léčení.")

R("Eureka!",
  "Your next {1} non-periodic damaging abilities have their Energy cost reduced by {2}% and deal {3}% more damage.",
  "Tvé příští {1} schopnosti s přímým poškozením spotřebují o {2} % méně energie a způsobí o {3} % více poškození.")

R("Eureka!",
  "Next {1} non-periodic damaging abilities cost {2}% less Energy and deal {3}% more damage.",
  "Příští {1} schopnosti s přímým poškozením spotřebují o {2} % méně energie a způsobí o {3} % více poškození.")

R("Soul Harvest",
  "Mana regeneration increased by {1}% and allows {2}% of Mana regeneration to continue while casting.",
  "Regenerace many zvýšena o {1} %. Během sesílání pokračuje {2} % regenerace many.")

R("Soul Harvest",
  "Increases Mana regeneration by {1}% and allows {2}% of Mana regeneration to continue while casting.",
  "Zvyšuje regeneraci many o {1} % a umožňuje, aby během sesílání pokračovalo {2} % regenerace many.")

R("Wild Growth",
  "Heals the target and their party for {1} over {2} sec. Party members must be within {3} yds of target. The amount healed is applied quickly at first, and slows down as Wild Growth reaches its full duration.",
  "Vyléčí cíl a jeho skupinu za {1} zdraví během {2} s. Členové skupiny musí být do {3} yardů od cíle. Léčení je nejsilnější na začátku a postupně slábne.")

R("Light's Vigil",
  "Activated by Holy Shock. Heals the target and their party for {1}. Party members must be within {2} yds of target.",
  "Aktivuje se kouzlem Holy Shock. Vyléčí cíl a jeho skupinu za {1} zdraví. Členové skupiny musí být do {2} yardů od cíle.")

R("Primal Bite",
  "Bite the target, dealing {1}% normal damage plus {2} and generating a high amount of threat.",
  "Kousne cíl, způsobí {1} % běžného poškození plus {2} a vytvoří vysokou hrozbu.")

R("Holy Shock",
  "Heals {1} damage.",
  "Vyléčí {1} zdraví.")

R("Trueshot Aura",
  "Increases the Ranged Attack Power of party members within {1} yds by {2}.",
  "Zvyšuje sílu útoku na dálku členů skupiny do {1} yardů o {2}.")

R("Seal of Fury",
  "Fills you with divine fury for {1} sec, causing melee attacks to deal an additional {2} Holy damage. While a shield is equipped, each attack also grants an absorb shield equal to {3}% of the Holy damage dealt. Only one Seal can be active on the Paladin at any one time. Unleashing this Seal's energy inflicts{4} Holy damage to an enemy and taunts the target to attack you for {5} sec.",
  "Na {1} s tě naplní božskou zuřivostí. Útoky na blízko způsobí navíc {2} svatého poškození. Pokud máš štít, každý útok také vytvoří ochranný štít pohlcující poškození ve výši {3} % způsobeného svatého poškození. Současně můžeš mít aktivní jen jednu pečeť.\nUvolnění energie této pečeti způsobí nepříteli {4} svatého poškození a přinutí jej na tebe útočit po dobu {5} s.")

R("Seal of Fury",
  "Melee attacks inflict an additional {1} Holy damage.",
  "Útoky na blízko způsobují navíc {1} svatého poškození.")

R("Seal of Fury",
  "Fills you with divine fury for {1} sec, causing melee attacks to inflict an additional {2} Holy damage. While a shield is equipped, each attack also grants an absorb shield equal to {3}% of the Holy damage dealt. Only one Seal can be active on the Paladin at any one time. Unleashing this Seal's energy inflicts {4} Holy damage to an enemy and taunts the target to attack you for {5} sec.",
  "Na {1} s tě naplní božskou zuřivostí. Útoky na blízko způsobí navíc {2} svatého poškození. Pokud máš štít, každý útok také vytvoří ochranný štít pohlcující poškození ve výši {3} % způsobeného svatého poškození. Současně můžeš mít aktivní jen jednu pečeť.\nUvolnění energie této pečeti způsobí nepříteli {4} svatého poškození a přinutí jej na tebe útočit po dobu {5} s.")

R("Curse of the Elements",
  "Curses the target for {1} sec, reducing Magic resistances by {2} and increasing Magic damage taken by {3}%. Only one Curse per Warlock can be active on any one target.",
  "Na {1} s prokleje cíl, sníží jeho magické odolnosti o {2} a zvýší přijímané magické poškození o {3} %. Na jednom cíli může být současně jen jedna kletba od každého warlocka.")

R("Vampiric Embrace",
  "Afflicts your target with Shadow energy that causes all party members to be healed for {1}% of any Shadow spell damage you deal for {2} sec.",
  "Na {2} s naplní cíl stínovou energií. Tvé stínové poškození způsobené kouzly tomuto cíli léčí všechny členy skupiny za {1} % způsobeného poškození.")

R("Travel Form",
  "Shapeshift into Travel Form, increasing movement speed by {1}%. Also protects the caster from Polymorph effects. Only useable outdoors. The act of shapeshifting frees the caster of Polymorph and Movement Impairing effects.",
  "Promění tě do Travel Form a zvýší rychlost pohybu o {1} %. Poskytuje imunitu vůči Polymorph. Lze použít pouze venku.\nZměna podoby odstraní Polymorph a účinky omezující pohyb.")

R("Cat Form",
  "Shapeshift into Cat Form, increasing Attack Power by {1} plus Agility. Also protects the caster from Polymorph effects and allows the use of various cat abilities. The act of shapeshifting frees the caster of Polymorph and Movement Impairing effects.",
  "Promění tě do Cat Form. Zvýší sílu útoku o {1} a o hodnotu obratnosti. Poskytuje imunitu vůči Polymorph a umožní používat kočičí schopnosti.\nZměna podoby odstraní Polymorph a účinky omezující pohyb.")

R("Cat Form",
  "Immunity to Polymorph effects. Increases Attack Power by {1} plus Agility.",
  "Imunita vůči Polymorph. Síla útoku zvýšena o {1} a o hodnotu obratnosti.")

R("Bear Form",
  "Shapeshift into Bear Form, increasing Attack Power by {1}, Armor contribution from items by {2}%, and Health by {3}. Also protects the caster from Polymorph effects and allows the use of various bear abilities. The act of shapeshifting frees the caster of Polymorph and Movement Impairing effects.",
  "Promění tě do Bear Form. Zvýší sílu útoku o {1}, příspěvek předmětů ke zbroji o {2} % a zdraví o {3}. Poskytuje imunitu vůči Polymorph a umožní používat medvědí schopnosti.\nZměna podoby odstraní Polymorph a účinky omezující pohyb.")

R("Bear Form",
  "Immune to Polymorph effects. Increases Attack Power by {1}, Armor contribution from items by {2}%, and Health by {3}.",
  "Imunita vůči Polymorph. Síla útoku zvýšena o {1}, příspěvek předmětů ke zbroji o {2} % a zdraví o {3}.")

R("Wrack",
  "Tears the target apart from within, inflicting {1} Shadow damage every {2} sec and increasing the damage they take from your other Shadow damage over time effects by {3}% for {4} sec.",
  "Trhá cíl zevnitř, způsobuje {1} stínového poškození každé {2} s a na {4} s zvyšuje poškození z tvých ostatních stínových účinků způsobujících poškození v čase o {3} %.")

R("Wrack",
  "Inflicts {1} Shadow damage every {2} sec and increases damage taken from the caster's other Shadow damage over time effects by {3}%.",
  "Způsobuje {1} stínového poškození každé {2} s a zvyšuje poškození z ostatních stínových účinků tohoto sesilatele způsobujících poškození v čase o {3} %.")

R("Devouring Contagion",
  "Reduces the mana cost of your Devouring Plague by {1}%. Targets that die while Devouring Plague is active spreads it, jumping to a nearby enemy within {2} yds for the remaining duration.",
  "Snižuje spotřebu many Devouring Plague o {1} %. Pokud cíl během jeho trvání zemře, Devouring Plague přeskočí na blízkého nepřítele do {2} yardů. Přenese se jen zbývající doba trvání.")

R("Penance",
  "Healing for {1} every {2} sec for {3} sec.",
  "Léčí za {1} zdraví každé {2} s po dobu {3} s.")

R("Chastise",
  "Chastise the target, causing {1} Holy damage and immobilizing them for up to {2} sec. Only works against Humanoids. This spell causes very low threat.",
  "Potrestá cíl, způsobí mu {1} svatého poškození a znehybní jej až na {2} s. Funguje pouze na humanoidy. Vytváří velmi nízkou hrozbu.")

R("Setup",
  "Gives you a {1}% chance to add a Combo Point to your target after Dodging one of their attacks or fully resisting one of their spells.",
  "Když uhneš útoku svého cíle nebo plně odoláš jeho kouzlu, máš {1}% šanci získat proti tomuto cíli kombinovaný bod.")

R("Inner Focus",
  "When activated, reduces the Mana cost of your next spell by {1}% and increases its critical effect chance by {2}% if it is a non-periodic spell and capable of a critical effect.",
  "Po aktivaci sníží spotřebu many příštího kouzla o {1} % a zvýší jeho šanci na kritický účinek o {2} %, pokud jde o neperiodické kouzlo schopné kritického účinku.")

R("Inner Focus",
  "The Mana cost of your next spell is reduced by {1}% and its non-periodic critical effect chance is increased by {2}%.",
  "Spotřeba many příštího kouzla snížena o {1} % a jeho šance na neperiodický kritický účinek zvýšena o {2} %.")

R("Eureka!",
  "Your next {1} non-periodic damaging abilities have their Rage cost reduced by {2}% and deal {3}% more damage.",
  "Tvé příští {1} schopnosti s přímým poškozením spotřebují o {2} % méně zuřivosti a způsobí o {3} % více poškození.")

R("Eureka!",
  "Next {1} non-periodic damaging abilities cost {2}% less Rage and deal {3}% more damage.",
  "Příští {1} schopnosti s přímým poškozením spotřebují o {2} % méně zuřivosti a způsobí o {3} % více poškození.")

R("Eureka!",
  "Your next {1} non-periodic damaging abilities have their Mana cost reduced by {2}% and deal {3}% more damage.",
  "Tvé příští {1} schopnosti s přímým poškozením spotřebují o {2} % méně many a způsobí o {3} % více poškození.")

R("Eureka!",
  "Next {1} non-periodic damaging abilities cost {2}% less Mana and deal {3}% more damage.",
  "Příští {1} schopnosti s přímým poškozením spotřebují o {2} % méně many a způsobí o {3} % více poškození.")

R("Light's Vigil",
  "Activated by Holy Shock. Heals the target and their party for {1}. Party members must be within {2} yds of the target.",
  "Aktivuje se kouzlem Holy Shock. Vyléčí cíl a jeho skupinu za {1} zdraví. Členové skupiny musí být do {2} yardů od cíle.")

R("Shield Specialization",
  "Restoring {1}% of maximum Mana.",
  "Obnovuje {1} % maximální many.")

R("Spirit Tap",
  "Gives you a {1}% chance to increase your Spirit by {2}% for {3} sec after killing a non-trivial target or when an enemy afflicted by your Vampiric Embrace dies. For the duration, {4}% of your Mana regeneration will continue while casting.",
  "S {1}% šancí zvýší tvého ducha o {2} % na {3} s po zabití netriviálního cíle nebo po smrti nepřítele ovlivněného tvým Vampiric Embrace. Během účinku pokračuje {4} % regenerace many i při sesílání.")

R("Champion of the Light",
  "Increases your spell damage by up to {1}% of your Intellect.",
  "Zvyšuje poškození tvých kouzel až o {1} % tvého intelektu.")

R("Touch of the Grave",
  "Steals life from target enemy equal to {1}% of your maximum Health.",
  "Ukradne nepřátelskému cíli zdraví ve výši {1} % tvého maximálního zdraví.")

R("Soul Harvest",
  "Killing a non-trivial target afflicted by your Drain Soul increases your Mana regeneration by {1}% for {2} sec and allows {3}% of normal Mana regeneration to continue while casting.",
  "Zabití netriviálního cíle ovlivněného tvým Drain Soul zvýší regeneraci many o {1} % na {2} s a umožní, aby během sesílání pokračovalo {3} % běžné regenerace many.")

R("Thunderstomp",
  "Shakes the ground with thundering force, doing {1} Nature damage to all enemies within {2} yds.",
  "Otřese zemí a způsobí {1} přírodního poškození všem nepřátelům do {2} yardů.")

R("Bloodrage",
  "Generates {1} rage at the cost of health, and then generates an additional {2} rage over {3} sec.",
  "Za cenu zdraví vytvoří {1} zuřivosti a během {3} s vytvoří dalších {2} zuřivosti.")

R("Shifting Power",
  "Instantly convert {1} Mana into {2} Energy. Shifting Power's cost is reduced by effects that reduce the cost of Shapeshifting.",
  "Okamžitě přemění {1} many na {2} energie. Spotřebu many Shifting Power snižují účinky, které snižují spotřebu many při změně podoby.")

R("Improved Shifting Power",
  "Reduces the cooldown of your Shifting Power spell by {1} sec.",
  "Zkracuje dobu obnovy Shifting Power o {1} s.")

R("Boosted Rest",
  "You cannot gain more rested experience from a Camp Tent for {1} sec.",
  "Po dobu {1} s nemůžeš získat další odpočinkové zkušenosti ze stanu Camp Tent.")

R("Revelation",
  "Critical Strike chance of your next non-periodic spell increased by {1}%.",
  "Šance příštího neperiodického kouzla na kritický zásah zvýšena o {1} %.")

R("Shifting Power",
  "Requires Cat Form Instantly convert {1} Mana into {2} Energy. Shifting Power's cost is reduced by effects that reduce the cost of Shapeshifting.",
  "Vyžaduje Cat Form.\nOkamžitě přemění {1} many na {2} energie. Spotřebu many Shifting Power snižují účinky, které snižují spotřebu many při změně podoby.")
