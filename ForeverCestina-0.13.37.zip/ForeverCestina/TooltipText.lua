local _, A = ...
-- Only change public FontString output. Never write tooltipData, lineData or
-- processingInfo: even restoring their old values leaves Lua table slots tainted.
local function current(font)
    if not font or not font.GetText then return nil,false end
    local value=font:GetText()
    return value,A.Accessible(value) and (value==nil or type(value)=='string')
end
function A.WriteTooltipRowText(tip,font,en,cs,right)
    local value,ok=current(font)
    if not ok or type(value)~='string' or type(en)~='string' or type(cs)~='string' then return end
    -- Native AddLine expands public plural markup (e.g. 1 |4hour:hrs;).
    -- Compare normalized current text, but keep the exact displayed original
    -- for Shift/rollback. No stale text or native input table is rewritten.
    if value~=en and A.Normalize(value)~=A.Normalize(en) then return end
    en=value
    local wrap=font.CanWordWrap and font:CanWordWrap()
    if not A.Accessible(wrap) then return end
    if not A.PrepareTooltipInputFont(tip,font) then return end
    local saved={font=font,en=en,cs=cs,wrap=wrap,outWrap=not right,localized=true}
    local wrote,err=pcall(function()
        if font.SetWordWrap then font:SetWordWrap(saved.outWrap) end
        font:SetText(cs)
    end)
    if not wrote then
        pcall(function()
            local now,readable=current(font)
            if readable and now==cs then font:SetText(en) end
            if wrap~=nil and font.SetWordWrap then font:SetWordWrap(wrap) end
            if A.ReleaseTooltipInputFont then A.ReleaseTooltipInputFont(font) end
        end)
        error(err)
    end
    return saved
end
function A.ToggleTooltipRowText(tip,saved,localize)
    local font=saved.font
    local value,ok=current(font)
    -- A foreign writer, empty or secret value invalidates this row. Never
    -- substitute a previous spell for the current engine output.
    if not ok or value~=(saved.localized and saved.cs or saved.en) then return false end
    if localize then
        if not A.PrepareTooltipInputFont(tip,font) then return false end
    elseif A.ReleaseTooltipInputFont then A.ReleaseTooltipInputFont(font) end
    if font.SetWordWrap then
        local wrap=localize and saved.outWrap
        if not localize then wrap=saved.wrap end
        if wrap~=nil then font:SetWordWrap(wrap) end
    end
    saved.localized=localize
    font:SetText(localize and saved.cs or saved.en)
    return true
end
