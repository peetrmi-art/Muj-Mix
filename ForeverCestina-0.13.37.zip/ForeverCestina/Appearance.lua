local _, A = ...
-- Optional presentation settings. The selected size is frozen at addon load;
-- changing the draft never touches any live tooltip, global font or CVar.
local FONT='Interface\\AddOns\\ForeverCestina\\Fonts\\ForeverSerif-Medium.ttf'
local function sizeValue(value)
    if A.PublicNumber(value) and value%1==0 and value>=12 and value<=18 then return value end
    return 0 -- 0 means the original per-element sizes, not a zero-size font.
end
local function options(db)
    if type(db)~='table' or type(db.appearance)~='table' then return {} end
    return db.appearance
end
local activeSize=0
local initialized=false
local function initialize()
    if initialized then return end
    activeSize=sizeValue(options(_G.ForeverCestinaDB).tooltipSize)
    initialized=true
end
function A.GetTooltipFontSize(base)
    return activeSize~=0 and activeSize or base.size+(A.TooltipFontSizeDelta or 1)
end
function A.GetAppearanceSize() return activeSize end
function A.ValidAppearanceSize(value) return sizeValue(value) end
local function outOfCombat()
    if type(InCombatLockdown)~='function' then return false end
    local ok,combat=pcall(InCombatLockdown)
    return ok and A.Accessible(combat) and (combat==false or combat==nil)
end
local function reloadFunction()
    if C_UI and type(C_UI.Reload)=='function' then return C_UI.Reload end
    if type(ReloadUI)=='function' then return ReloadUI end
end
-- Called only by the explicit Apply button, never by a timer or combat event.
-- Do not change activeSize before a fresh load: cached baselines remain valid.
function A.ApplyAppearanceSize(value)
    if not outOfCombat() then return false,'Velikost lze uložit pouze mimo boj.' end
    if not A.PublicNumber(value) or (value~=0 and sizeValue(value)~=value) then return false,'Vyber velikost od 12 do 18, nebo původní velikosti.' end
    local reload=reloadFunction()
    if not reload then return false,'Obnovení UI není v tomto klientu dostupné. Nastavení se nezměnilo.' end
    if type(A.DB)~='table' then return false,'Nastavení addonu zatím není načtené.' end
    local old=A.DB.appearance
    local updated={}
    for key,v in pairs(options(A.DB)) do updated[key]=v end
    updated.tooltipSize=value;A.DB.appearance=updated
    local ok,err=pcall(reload)
    if not ok or err==false then
        A.DB.appearance=old
        A.NoteError('Appearance reload',err)
        return false,'Obnovení UI se nezdařilo. Nastavení se nezměnilo.'
    end
    return true
end
local anchors={
    {'RIGHT','LEFT',-4,0}, {'BOTTOMRIGHT','TOPLEFT',0,0},
    {'BOTTOM','TOP',0,4}, {'BOTTOMLEFT','TOPRIGHT',0,0},
    {'LEFT','RIGHT',4,0}, {'TOPLEFT','BOTTOMRIGHT',0,0},
    {'TOP','BOTTOM',0,-4}, {'TOPRIGHT','BOTTOMLEFT',0,0},
}
local function positionValue(value)
    if A.PublicNumber(value) and value%1==0 and value>=1 and value<=#anchors then return value end
    return 1
end
local button,panel,draft,valueText,preview,statusText,apply,minus,plus
local creating=false
local panelFailed=false
local ICON_TEXTURE='Interface\\AddOns\\ForeverCestina\\Media\\CzechFlag'
local function label(parent,text,size,x,y,width)
    local fs=parent:CreateFontString(nil,'OVERLAY')
    if fs:SetFont(FONT,size,'')==false then error('Schválené písmo pro nastavení nelze načíst.') end
    fs:SetPoint('TOPLEFT',parent,'TOPLEFT',x,y)
    fs:SetWidth(width);fs:SetHeight(0);fs:SetJustifyH('LEFT');fs:SetWordWrap(true)
    fs:SetText(text)
    return fs
end
local function push(parent,text,x,y,width,fn)
    local b=CreateFrame('Button',nil,parent,'UIPanelButtonTemplate')
    b:SetPoint('TOPLEFT',parent,'TOPLEFT',x,y);b:SetSize(width,26)
    -- Only this button's private FontString is styled; no shared Font objects.
    local fs=b:GetFontString()
    if fs:SetFont(FONT,13,'')==false then error('Písmo tlačítka není dostupné.') end
    b:SetText(text)
    b:SetScript('OnClick',function()
        A.SafeCall('Appearance click',fn)
    end)
    return b
end
local function position()
    if not button or not _G.Minimap then return end
    local index=positionValue(options(A.DB).minimapPosition)
    local anchor=anchors[index]
    button:ClearAllPoints();button:SetPoint(anchor[1],Minimap,anchor[2],anchor[3],anchor[4])
end
function A.CycleAppearanceIcon()
    if not outOfCombat() or not button or type(A.DB)~='table' then return false end
    local previous=A.DB.appearance
    local updated={};for key,v in pairs(options(A.DB)) do updated[key]=v end
    updated.minimapPosition=positionValue(updated.minimapPosition)%#anchors+1
    A.DB.appearance=updated
    local ok,err=pcall(position)
    if not ok then A.DB.appearance=previous;A.NoteError('Appearance icon position',err);return false end
    return true
end
local function update()
    if not panel then return end
    valueText:SetText(draft==0 and 'Původní velikosti' or ('Velikost: '..draft))
    if preview:SetFont(FONT,draft==0 and 14 or draft,'')==false then error('Písmo náhledu není dostupné.') end
    preview:SetSpacing(2)
    preview:SetText('Žluťoučký kůň. Dosah: 20 yardů.\nUkázka velikosti českých vysvětlivek.')
    local allowed=outOfCombat()
    if allowed and reloadFunction() then apply:Enable() else apply:Disable() end
    if draft~=0 and draft<=12 then minus:Disable() else minus:Enable() end
    if draft~=0 and draft>=18 then plus:Disable() else plus:Enable() end
    statusText:SetText(allowed and 'Questy, seznam cílů a menu se nemění.\nZměna se použije až po obnovení UI.' or 'Probíhá boj. Uložení je dočasně vypnuté.\nNic se samo neuloží ani neobnoví.')
end
local function makePanel()
    local p=CreateFrame('Frame','ForeverCestinaAppearance',UIParent,'BasicFrameTemplateWithInset')
    -- Publish only for cleanup on a rejected UI operation, not for translation.
    panel=p;p:Hide();p:SetSize(440,366);p:SetPoint('CENTER');p:SetClampedToScreen(true)
    p:SetFrameStrata('DIALOG');p:EnableMouse(true)
    p.TitleText:SetFont(FONT,14,'');p.TitleText:SetText('ForeverCestina – velikost písma')
    label(p,'Společná velikost českých vysvětlivek\nKouzla, talenty a vysvětlivky nastavení.',14,20,-42,400)
    valueText=label(p,'',15,20,-100,265)
    minus=push(p,'-',294,-94,48,function()draft=draft==0 and 13 or math.max(12,draft-1);update()end)
    plus=push(p,'+',354,-94,48,function()draft=draft==0 and 15 or math.min(18,draft+1);update()end)
    push(p,'Sjednotit na 14',20,-136,185,function()draft=14;update()end)
    push(p,'Původní velikosti',218,-136,184,function()draft=0;update()end)
    label(p,'Náhled (pouze toto okno):',12,20,-178,398)
    preview=label(p,'',14,20,-202,398)
    statusText=label(p,'',12,20,-282,398)
    apply=push(p,'Uložit a obnovit UI',20,-326,248,function()
        local ok,message=A.ApplyAppearanceSize(draft)
        if not ok then statusText:SetText(message) end
    end)
    push(p,'Zrušit',282,-326,120,function()p:Hide()end)
    -- Escape uses the normal UI special-frame mechanism, with no key rebinding.
    if type(UISpecialFrames)=='table' then UISpecialFrames[#UISpecialFrames+1]='ForeverCestinaAppearance' end
    p:RegisterEvent('PLAYER_REGEN_DISABLED');p:RegisterEvent('PLAYER_REGEN_ENABLED')
    p:SetScript('OnEvent',function()if p:IsShown() then A.SafeCall('Appearance status',update) end end)
    A.AppearancePanel=p
end
function A.OpenAppearance()
    if not outOfCombat() then return false end
    if creating or panelFailed then return false end
    creating=true
    local ok,err=pcall(function()
        if not panel then makePanel() end
        draft=sizeValue(options(A.DB).tooltipSize)
        update();panel:Show()
    end)
    creating=false
    if not ok then
        if panel then pcall(panel.Hide,panel) end
        panelFailed=true;A.NoteError('Appearance panel',err);return false
    end
    return true
end
local function showButtonHint(owner)
    local tip=_G.GameTooltip
    if not tip or type(tip.SetOwner)~='function' or type(tip.AddLine)~='function' then return end
    local ok=pcall(function()
        tip:SetOwner(owner,'ANCHOR_LEFT')
        if type(tip.ClearLines)=='function' then tip:ClearLines() end
        tip:AddLine('ForeverCestina',1,.82,0)
        tip:AddLine('Kliknutí: velikost vysvětlivek',1,1,1,true)
        tip:AddLine('Pravé tlačítko: posun ikony',.75,.75,.75,true)
        tip:Show()
    end)
    if not ok and type(tip.Hide)=='function' then pcall(tip.Hide,tip) end
end
local function hideButtonHint()
    local tip=_G.GameTooltip
    if tip and type(tip.Hide)=='function' then pcall(tip.Hide,tip) end
end
local function buildButton()
    -- Keep the launcher deliberately simple: one bundled TGA and standard Button APIs.
    -- This avoids optional BackdropTemplate/SetColorTexture dependencies during login.
    local candidate=CreateFrame('Button',nil,UIParent)
    candidate:Hide();candidate:SetSize(34,34);candidate:SetFrameStrata('HIGH');candidate:SetClampedToScreen(true)
    if type(candidate.SetFrameLevel)=='function' and Minimap and type(Minimap.GetFrameLevel)=='function' then
        local ok,level=pcall(Minimap.GetFrameLevel,Minimap)
        if ok and A.PublicNumber(level) then candidate:SetFrameLevel(level+8) end
    end
    candidate:SetNormalTexture(ICON_TEXTURE)
    if type(candidate.GetNormalTexture)=='function' then
        local texture=candidate:GetNormalTexture()
        if texture and type(texture.SetAllPoints)=='function' then texture:SetAllPoints(candidate) end
    end
    if type(candidate.SetHighlightTexture)=='function' then
        candidate:SetHighlightTexture('Interface\\Buttons\\ButtonHilight-Square','ADD')
    end
    candidate:RegisterForClicks('LeftButtonUp','RightButtonUp')
    candidate:SetScript('OnClick',function(_,which)
        if which=='RightButton' then A.CycleAppearanceIcon() else A.OpenAppearance() end
    end)
    candidate:SetScript('OnEnter',showButtonHint)
    candidate:SetScript('OnLeave',hideButtonHint)
    return candidate
end
function A.InstallAppearanceButton()
    if button then
        if not UIParent or not Minimap or not outOfCombat() then return false end
        local ok,err=pcall(function()position();button:Show()end)
        if not ok then A.NoteError('Appearance icon position',err);return false end
        return true
    end
    if not UIParent or not Minimap or not outOfCombat() then return false end
    local candidate
    local ok,err=pcall(function()
        candidate=buildButton()
        button=candidate;position();candidate:Show()
        A.AppearanceButton=candidate
    end)
    if not ok then
        if candidate then pcall(candidate.Hide,candidate) end
        button=nil;A.AppearanceButton=nil
        -- Do not permanently disable the launcher after a transient login/UI error.
        -- PLAYER_ENTERING_WORLD / PLAYER_REGEN_ENABLED gets a bounded natural retry.
        A.NoteError('Appearance icon',err);return false
    end
    return true
end
-- UI creation is separate from the translation pipeline and happens only on lifecycle events,
-- never on every tooltip/frame. PLAYER_ENTERING_WORLD covers clients where Minimap
-- is not ready yet at PLAYER_LOGIN. No ticker or permanent polling is used.
local events=CreateFrame('Frame')
events:RegisterEvent('ADDON_LOADED');events:RegisterEvent('PLAYER_LOGIN')
events:RegisterEvent('PLAYER_ENTERING_WORLD');events:RegisterEvent('PLAYER_REGEN_ENABLED')
events:SetScript('OnEvent',function(_,event,name)
    if event=='ADDON_LOADED' then
        if name=='ForeverCestina' then
            initialize()
            A.InstallAppearanceButton()
        end
    else
        if event=='PLAYER_LOGIN' then initialize() end
        A.InstallAppearanceButton()
    end
end)
SLASH_FOREVERCESTINAAPPEARANCE1='/fczfont'
SlashCmdList.FOREVERCESTINAAPPEARANCE=function()A.OpenAppearance()end
