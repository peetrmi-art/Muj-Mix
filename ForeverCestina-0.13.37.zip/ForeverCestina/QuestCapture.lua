-- Automatically retain missing NPC dialog while the user plays normally.
local _, A = ...
local getters={
 QUEST_DETAIL={description="GetQuestText",objectives="GetObjectiveText"},
 QUEST_PROGRESS={progress="GetProgressText"},
 QUEST_COMPLETE={completion="GetRewardText"},
}
local frame=CreateFrame("Frame")
for event in pairs(getters) do frame:RegisterEvent(event) end
frame:SetScript("OnEvent",function(_,event)
 A.SafeCall("Quest dialog capture",function()
  if not A.DB or not GetQuestID then return end
  local id=GetQuestID()
  if not A.PublicNumber(id) or id<=0 then return end
  for field,name in pairs(getters[event] or {}) do
   local getter=_G[name]
   if type(getter)=="function" then
    local text=getter()
    if A.Accessible(text) and type(text)=="string" and text~="" and #text<=16000
      and not A.TranslateQuest(id,field,text) then
     A.DB.questSamples=A.DB.questSamples or {}
     local row=A.DB.questSamples[id] or {};A.DB.questSamples[id]=row
     row[field]=text;row.build=A.DB.client and A.DB.client.build
    end
   end
  end
 end)
end)
