local _, A = ...
local pending = {}
local function init()
    ForeverCestinaDB = type(ForeverCestinaDB) == "table" and ForeverCestinaDB or {}
    A.DB = ForeverCestinaDB
    A.DB.samples = type(A.DB.samples) == "table" and A.DB.samples or {}
    A.DB.clientSpells = type(A.DB.clientSpells) == "table" and A.DB.clientSpells or {}
    A.DB.count = 0
    for _ in pairs(A.DB.samples) do A.DB.count = A.DB.count + 1 end
    if A.DB.enabled == nil then A.DB.enabled = true end
    A.DB.version = A.Version
    if GetBuildInfo then local v,b,_,toc = GetBuildInfo(); A.DB.client = {version=v,build=b,toc=toc} end
end
local function readSpell(id, request)
    if not C_Spell or not C_Spell.GetSpellDescription then return end
    local ok, text = pcall(C_Spell.GetSpellDescription, id)
    if ok and A.Accessible(text) and type(text) == "string" and text ~= "" then
        local name = A.SpellIDs[id]
        if C_Spell.GetSpellName then
            local nameOK, clientName = pcall(C_Spell.GetSpellName, id)
            if nameOK and A.Accessible(clientName) and type(clientName) == "string" and clientName ~= "" then name = clientName end
        end
        local translated = A.Translate(name, text)
        A.DB.clientSpells[id] = {name=name,en=text,cs=translated}
        A.Record(name, text, translated, "C_Spell.GetSpellDescription:"..id)
        pending[id] = nil
    elseif request and C_Spell.RequestLoadSpellData then
        pending[id] = true
        pcall(C_Spell.RequestLoadSpellData, id)
    end
end
function A.Scan()
    if not A.DB then init() end
    local ids = {}; for id in pairs(A.SpellIDs) do ids[#ids+1] = id end; table.sort(ids)
    local index = 1
    local function batch()
        if InCombatLockdown and InCombatLockdown() then C_Timer.After(3, batch); return end
        for _=1,12 do
            local id=ids[index]; if not id then return end
            readSpell(id, true); index=index+1
        end
        C_Timer.After(0.1,batch)
    end
    batch()
end
function A.Report()
    local read, translated, missing = 0,0,{}
    for id, r in pairs(A.DB.clientSpells) do
        read = read + 1
        if r.cs then translated=translated+1 else missing[#missing+1]=id.." "..r.name end
    end
    table.sort(missing)
    return read, translated, missing
end
local function export()
    local data = {"ForeverCestina "..A.Version, "Build: "..(A.DB.client and A.DB.client.version or "?")}
    local keys={}; for id in pairs(A.DB.clientSpells)do keys[#keys+1]=id end;table.sort(keys)
    for _,id in ipairs(keys)do local r=A.DB.clientSpells[id];data[#data+1]="ID "..id.." | "..r.name.."\nEN: "..r.en.."\nCZ: "..(r.cs or "[CHYBI]") end
    local sk={};for k in pairs(A.DB.samples)do sk[#sk+1]=k end;table.sort(sk)
    for _,k in ipairs(sk)do local r=A.DB.samples[k];if not r.cs then data[#data+1]="TOOLTIP "..r.name.."\nEN: "..r.en end end
    if not A.ExportFrame then
        local f=CreateFrame("Frame","ForeverCestinaExport",UIParent,"BasicFrameTemplateWithInset")
        f:SetSize(720,500);f:SetPoint("CENTER");f:SetMovable(true);f:EnableMouse(true);f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart",f.StartMoving);f:SetScript("OnDragStop",f.StopMovingOrSizing)
        f.TitleText:SetText("ForeverCestina – data z tvé hry (Ctrl+A, Ctrl+C)")
        local scroll=CreateFrame("ScrollFrame",nil,f,"UIPanelScrollFrameTemplate");scroll:SetPoint("TOPLEFT",16,-40);scroll:SetPoint("BOTTOMRIGHT",-32,16)
        local edit=CreateFrame("EditBox",nil,scroll);edit:SetMultiLine(true);edit:SetFontObject(ChatFontNormal);edit:SetWidth(650);edit:SetAutoFocus(false);edit:SetScript("OnEscapePressed",function()f:Hide()end);scroll:SetScrollChild(edit)
        A.ExportFrame,A.ExportEdit=f,edit
    end
    A.ExportEdit:SetText(table.concat(data,"\n\n"));A.ExportFrame:Show();A.ExportEdit:SetFocus();A.ExportEdit:HighlightText()
end
local function diagnostic()
    local d=A.Diagnostics or {}
    local modes={translated="čeština, původní schválené rozložení",text_only="překlad dostupných řádků, nativní rozložení",original="originál"}
    local reasons={ok="v pořádku",geometry="nedostupná geometrie",restricted_text="nedostupný text",shift="podržený Shift",disabled="čeština vypnutá",unknown="neznámý tooltip",unmatched="chybějící shoda překladu",error="zachycená chyba"}
    print("ForeverCestina "..A.Version.." | čeština: "..(A.DB.enabled==false and "vypnutá" or "zapnutá"))
    local t=d.tooltip
    if t then print("Tooltip: "..(modes[t.mode] or t.mode).." | "..(reasons[t.reason] or t.reason))
    else print("Tooltip: zatím nebyl zpracován.") end
    if d.lastLimited then print("Poslední omezení: "..(reasons[d.lastLimited.reason] or d.lastLimited.reason)) end
    local log=A.DB.tooltipAudit
    if log and log.lastCombatProblem then
        local row=log.lastCombatProblem
        print("Poslední bojový stav: "..(row.title or "název nedostupný").." | "..(reasons[row.reason] or row.reason or "?").." | "..(row.detail or "bez doplňujícího důvodu"))
    end
    if t and t.detail then print("Podrobnost: "..t.detail) end
    print("Zachycené chyby od načtení: "..(d.totalErrors or 0))
    if d.lastError then print(d.lastError) end
end
SLASH_FOREVERCESTINA1="/fcz"
SlashCmdList.FOREVERCESTINA=function(msg)
    if not A.DB then init() end
    msg=(msg or ""):lower():match("^%s*(.-)%s*$")
    if msg=="off" then A.DB.enabled=false; print("ForeverCestina: vypnuto.")
    elseif msg=="on" then A.DB.enabled=true; print("ForeverCestina: zapnuto.")
    elseif msg=="stav" or msg=="status" then diagnostic()
    elseif msg=="scan" then A.Scan(); print("ForeverCestina: načítám popisy z této instalace hry.")
    elseif msg=="export" then export()
    else local n,t,m=A.Report();print("ForeverCestina: načteno z klienta "..n..", přeloženo "..t..", zbývá "..#m..". Shift = originál. /fcz on | off | stav | scan | export") end
    if A.RefreshUI then A.RefreshUI() end
    if (msg=="on" or msg=="off") and A.RefreshTooltips then A.RefreshTooltips() end
end
local f=CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED");f:RegisterEvent("PLAYER_LOGIN");f:RegisterEvent("SPELL_DATA_LOAD_RESULT")
f:SetScript("OnEvent",function(_,event,arg,success)
    if event=="ADDON_LOADED" and arg=="ForeverCestina" then init()
    elseif event=="PLAYER_LOGIN" then if not A.DB then init() end;C_Timer.After(2,A.Scan)
    elseif event=="SPELL_DATA_LOAD_RESULT" and A.Accessible(arg) and pending[arg] then
        if success then readSpell(arg,false) else pending[arg]=nil end
    end
end)
