-- NPC greetings/options and available/active quest titles. Only rendered text changes.
-- Native Setup/Resize/extent calculator remain responsible for all layout and clicks.
local _, A = ...
local font="Interface\\AddOns\\ForeverCestina\\Fonts\\ForeverSerif-Medium.ttf"
local watched=setmetatable({},{__mode="k"})
local hooked=setmetatable({},{__mode="k"})
local refreshing=false
local function enabled()
 return (not A.DB or A.DB.enabled~=false) and not (IsShiftKeyDown and IsShiftKeyDown())
end
local function npcName()
 local name=UnitName and UnitName("npc")
 if A.Accessible(name) and type(name)=="string" then return name end
end
function A.TranslateGossip(npc,text)
 local clean=A.Normalize(text)
 if not clean or not A.Accessible(npc) then return end
 for _,entry in ipairs(A.GossipEntries or {}) do
  if entry.npc==npc and A.Normalize(entry.en)==clean then return entry.cs end
 end
end
local function apply(object,state)
 if state.busy then return end
 state.busy=true
 local ok,err=pcall(function()
  local text=object:GetText()
  if not A.Accessible(text) or type(text)~="string" then return end
  local cs
  if enabled() then
   if state.kind=="quest" then cs=A.TranslateQuestTitle(object:GetID(),text)
   elseif state.kind=="goodbye" then if text=="Goodbye" then cs="Na shledanou" end
   else cs=A.TranslateGossip(npcName(),text) end
  end
  if cs then
   state.base=state.base or A.CaptureFont(state.fs)
   A.SetLocalizedFont(state.fs,state.base,font,state.kind=="goodbye" and 0 or 1)
   state.changed=true
   object:SetText(cs)
  elseif state.changed then
   A.RestoreFont(state.fs,state.base);state.changed=false
  end
 end)
 state.busy=false
 if not ok then A.NoteError("NPC text",err) end
end
local function watch(object,kind)
 if not object or not object.SetText or not object.GetText or watched[object] then return false end
 local fs=object.GetFontString and object:GetFontString() or object
 if not fs or not fs.GetFont then return false end
 local state={kind=kind,fs=fs};watched[object]=state
 hooksecurefunc(object,"SetText",function() apply(object,state) end)
 if object.SetFormattedText then hooksecurefunc(object,"SetFormattedText",function() apply(object,state) end) end
 -- The parchment theme can assign a font object after text has been measured.
 if fs.SetFontObject then hooksecurefunc(fs,"SetFontObject",function()
  if state.changed and not state.busy then
   state.busy=true
   A.SafeCall("NPC theme font",A.SetLocalizedFont,fs,state.base,font,kind=="goodbye" and 0 or 1)
   state.busy=false
  end
 end) end
 return true
end
local function watchFrame(frame)
 if not frame then return false end
 if frame.GreetingText then return watch(frame.GreetingText,"greeting") end
 if frame.GetFontString and frame.Setup then
  return watch(frame,frame.UpdateTitleForQuest and "quest" or "option")
 end
 return false
end
local function attach(frame)
 if not frame or hooked[frame] or not frame.Update or not frame.RegisterFontString then return end
 hooked[frame]=true
 -- Called before native Setup on each newly acquired/recycled visible row.
 hooksecurefunc(frame,"RegisterFontString",function(_,fs)
  if fs and fs.GetParent then A.SafeCall("NPC row hooks",watchFrame,fs:GetParent()) end
 end)
 hooksecurefunc(frame,"Update",function()
  if refreshing then return end
  refreshing=true
  A.SafeCall("NPC window",function()
   local added=false
   -- The four hidden measurement widgets are direct children of GossipFrame.
   -- Install the same text hooks on them so scrolling uses Czech text extents.
   if frame.GetChildren then for _,child in ipairs({frame:GetChildren()}) do
    added=watchFrame(child) or added
   end end
   local panel=frame.GreetingPanel
   if panel then
    local button=panel.GoodbyeButton
    if button then
     watch(button,"goodbye")
     button:SetText("Goodbye")
    end
   end
   -- One native rebuild on first discovery, never a layout/geometry replacement.
   if added and not (InCombatLockdown and InCombatLockdown()) then frame:Update() end
  end)
  refreshing=false
 end)
end
local function capture()
 if not A.DB or not C_GossipInfo then return end
 local npc=npcName();if not npc or #npc>200 then return end
 local function record(kind,text)
  if not A.Accessible(text) or type(text)~="string" or #text<2 or #text>8000
      or A.TranslateGossip(npc,text) then return end
  local samples=A.DB.gossipSamples
  if type(samples)~="table" then samples={};A.DB.gossipSamples=samples end
  for _,v in ipairs(samples) do if v.npc==npc and v.kind==kind and v.en==text then return end end
  if #samples>=200 then return end
  samples[#samples+1]={npc=npc,kind=kind,en=text}
 end
 if C_GossipInfo.GetText then record("greeting",C_GossipInfo.GetText()) end
 local options=C_GossipInfo.GetOptions and C_GossipInfo.GetOptions()
 if A.Accessible(options) and type(options)=="table" then
  for _,option in ipairs(options) do
   if A.Accessible(option) and type(option)=="table" then record("option",option.name) end
  end
 end
end
local events=CreateFrame("Frame")
for _,e in ipairs({"ADDON_LOADED","PLAYER_LOGIN","GOSSIP_SHOW","MODIFIER_STATE_CHANGED"}) do events:RegisterEvent(e) end
events:SetScript("OnEvent",function(_,event,key)
 A.SafeCall("NPC install",attach,_G.GossipFrame)
 if event=="GOSSIP_SHOW" then A.SafeCall("NPC capture",capture) end
 if event=="MODIFIER_STATE_CHANGED" and (key=="LSHIFT" or key=="RSHIFT")
     and GossipFrame and GossipFrame:IsShown() and not (InCombatLockdown and InCombatLockdown()) then
  A.SafeCall("NPC original",GossipFrame.Update,GossipFrame)
 end
end)
A.SafeCall("NPC install",attach,_G.GossipFrame)
