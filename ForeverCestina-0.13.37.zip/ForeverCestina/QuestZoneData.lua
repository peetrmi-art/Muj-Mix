-- Zephras Isle: exact source match, no invented completion dialogue.
local _, A = ...
A.QuestEntries[93459]={title="More Al'Aketh Ears",
 objectives={"Collect 10 Al'Aketh Cultist's Ears from the Al'Aketh in Shadowgale Forest, the Shine of Akir, or Gustberry Lowlands and return them to Vayn Moonclaw in Shadowgale Forest.","Nasbírej 10 uší kultistů Al'Aketh od členů kultu v Shadowgale Forest, Shine of Akir nebo Gustberry Lowlands a dones je Vaynovi Moonclawovi v Shadowgale Forest."},
 description={"The Al'Aketh cult normally gives this forest a wide berth, fearing the rumors that it is haunted... rumors we are happy to maintain. The Druids of my order wish only to live quiet, peaceful lives here in Shadowgale and they threaten that. \n\nMany among us are afraid.\n\nI come with an offer. Fight the cultists for us, and bring us the ears of those you kill. We will reward you for each that you return with in both coin and, in time, access to our secrets should you prove yourself to be a true friend.","Kult Al'Aketh se tomuto lesu obvykle obloukem vyhýbá. Bojí se pověstí, že tu straší… a my ty pověsti rádi přiživujeme. Druidové mého řádu chtějí jen žít tady v Shadowgale v klidu a míru, ale kultisté tento klid ohrožují.\n\nMnozí z nás mají strach.\n\nMám pro tebe nabídku. Bojuj s kultisty za nás a přinášej nám uši těch, které zabiješ. Za každou tě odměníme penězi. A pokud se osvědčíš jako skutečný přítel, časem ti dovolíme nahlédnout i do našich tajemství."},
}
A.QuestTitleTranslations["More Al'Aketh Ears"]="Další uši kultistů Al'Aketh"
A.QuestTargetTranslations["al'alketh cultist's ear"]="ucho kultisty Al'Aketh"
A.QuestTargetTranslations["al'aketh cultist's ear"]="ucho kultisty Al'Aketh"
A.QuestTargetTranslations["vulgara's head"]="hlava Vulgary"
