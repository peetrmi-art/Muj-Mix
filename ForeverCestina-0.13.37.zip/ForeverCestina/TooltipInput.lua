local _, A = ...
-- Read CURRENT public input, then localize FontStrings in the native line-post
-- callback, before Show measures the tooltip. All engine data stays read-only.
-- In particular, do not taint source fields before a later secret-color row.
local function weak() return setmetatable({}, {__mode='k'}) end
local contexts, active, rebuilding = weak(), weak(), weak()
local hooked=false
local footerEN='Press F6 to submit an issue for this Spell'
local footerCS='|cff40ccffF6: nahlásit problém s tímto kouzlem|r'
local measure
local widths=weak()
local function field(t,k)
    if not A.Accessible(t) or type(t)~='table' then return nil,false end
    local ok,v=pcall(function() return t[k] end)
    if not ok or not A.Accessible(v) then return nil,false end
    return v,true
end
local function text(t,k)
    local v,ok=field(t,k)
    return v,ok and (v==nil or type(v)=='string')
end
local function call(obj,method,...)
    if not obj or type(obj[method])~='function' then return nil,false end
    local ok,v=pcall(obj[method],obj,...)
    return v,ok and A.Accessible(v)
end
local function enabled()
    if A.DB and A.DB.enabled==false then return false end
    if type(IsShiftKeyDown)=='function' then
        local ok,v=pcall(IsShiftKeyDown)
        if not ok or not A.Accessible(v) then return false end
        if v then return false end
    end
    return true
end
local function undo(row) row.edits=nil end
local function release(ctx)
    for _,row in ipairs(ctx.rows or {}) do undo(row) end
end
local function set(row,key,value)
    local old,ok=field(row.data,key)
    if not ok then return false end
    row.edits=row.edits or {}
    if not row.edits[key] then row.edits[key]={old=old,out=value} else row.edits[key].out=value end
    -- Candidate output only; never modify the native row, including on rollback.
    return true
end
local function named(title)
    local s=A.Normalize(title)
    if s and A.Names[s] then return s end
    if s then s=s:gsub(' %(Rank %d+%)$','');if A.Names[s] then return s end end
end
local function rgba(color)
    if color==nil then return '|cffffff00' end -- native NORMAL_FONT_COLOR
    if not A.Accessible(color) then return nil end
    local ok,r,g,b,a=pcall(function() return color:GetRGBA() end)
    if not ok or not A.PublicNumber(r) or not A.PublicNumber(g) or not A.PublicNumber(b)
        or not A.PublicNumber(a) then return nil end
    local function byte(v)return math.floor(math.max(0,math.min(1,v))*255+0.5)end
    return string.format('|c%02x%02x%02x%02x',byte(a),byte(r),byte(g),byte(b))
end
local function width(s,font)
    if not A.Accessible(s) or type(s)~='string' or not font then return nil end
    local ok,value=pcall(function()
        if not measure then
            local f=CreateFrame('Frame')
            if not f.CreateFontString then return nil end
            measure=f:CreateFontString(nil,'ARTWORK')
            f:Hide()
        end
        local path,size,flags=font:GetFont()
        if not A.Accessible(path) or type(path)~='string' or not A.PublicNumber(size) or not A.Accessible(flags) then return nil end
        if measure:SetFont(path,size,flags)==false then return nil end
        measure:SetText(s)
        return measure:GetUnboundedStringWidth()
    end)
    if ok and A.PublicNumber(value) and value>=0 then return value end
end
local function fontAt(ctx,index,right)
    local f=_G[ctx.globalName..(right and 'TextRight' or 'TextLeft')..index]
    if f then return f end
    local value,ok=call(ctx.tip,right and 'GetRightLine' or 'GetLeftLine',index)
    if ok then return value end
end
local function restoreWidth(tip)
    local saved=widths[tip]
    if not saved or type(tip.GetMinimumWidth)~='function' then return end
    local ok,w,force=pcall(tip.GetMinimumWidth,tip)
    if not ok or not A.PublicNumber(w) or not A.Accessible(force) then return end
    if w==saved.out and force==true then
        local success=A.SafeCall('Tooltip native width restore',tip.SetMinimumWidth,tip,saved.width,saved.force)
        if not success then return end
    end
    widths[tip]=nil
end
local function nativeWidth(ctx)
    local tip=ctx.tip
    restoreWidth(tip)
    if widths[tip] or type(tip.GetMinimumWidth)~='function' or type(tip.SetMinimumWidth)~='function' then return end
    local ok,w,force=pcall(tip.GetMinimumWidth,tip)
    if not ok or not A.PublicNumber(w) or not A.Accessible(force) or type(force)~='boolean' then return end
    local target=#ctx.rows>3 and 350 or 240
    if UIParent and UIParent.GetWidth then
        local sw,good=call(UIParent,'GetWidth')
        if not good or not A.PublicNumber(sw) or sw<=24 then return end
        target=math.min(target,sw-24)
    end
    widths[tip]={width=w,force=force,out=target}
    local applied=A.SafeCall('Tooltip native width',tip.SetMinimumWidth,tip,target,true)
    if applied then ctx.inner=math.max(1,target-24) end
end
-- Only use an after-render fallback when the complete candidate fits the
-- existing readable rectangle. Never enlarge text in an unmeasurable box.
function A.TooltipTextFits(font,cs,base,path)
    local ok,fits=pcall(function()
        if not font or not base or type(cs)~='string' then return false end
        local w,h=font:GetWidth(),font:GetHeight()
        local wrap=font.CanWordWrap and font:CanWordWrap()
        if not A.PublicNumber(w) or w<=0 or not A.PublicNumber(h) or h<=0 or not A.Accessible(wrap) then return false end
        if not measure then
            local parent=CreateFrame('Frame')
            if not parent.CreateFontString then return false end
            measure=parent:CreateFontString(nil,'ARTWORK');parent:Hide()
        end
        if measure:SetFont(path,A.TooltipFontSize,base.flags)==false then return false end
        measure:SetSpacing((base.spacing or 0)+A.TooltipLineSpacingDelta)
        measure:SetWidth(w);measure:SetHeight(0);measure:SetWordWrap(wrap==true);measure:SetText(cs)
        local needed=measure:GetStringHeight()
        local unbounded=measure:GetUnboundedStringWidth()
        return A.PublicNumber(needed) and (needed>0 or A.Normalize(cs)=='') and needed<=h and A.PublicNumber(unbounded)
            and (wrap==true or unbounded<=w)
    end)
    return ok and fits==true
end
local function changeFont(ctx,fs)
    if not fs or not A.PrepareTooltipInputFont then ctx.fontMissing=(ctx.fontMissing or 0)+1;return false end
    local ok,value=A.SafeCall('Tooltip input font',A.PrepareTooltipInputFont,ctx.tip,fs)
    if not ok or value~=true then ctx.writeFailures=ctx.writeFailures+1 end
    return ok and value==true
end
function A.TooltipInputReady() return hooked end
function A.TooltipInputBuilding(tip) return active[tip]~=nil end
function A.TooltipInputWriting(tip) return active[tip]~=nil or rebuilding[tip]~=nil end
function A.ForgetTooltipInput(tip)
    local ctx=contexts[tip]
    if ctx then release(ctx) end
    contexts[tip]=nil;active[tip]=nil
    restoreWidth(tip)
end
function A.TooltipInputChanged(tip)
    if active[tip] or rebuilding[tip] then return end
    A.ForgetTooltipInput(tip)
end
local function begin(tip,data)
    if not tip or not A.Accessible(data) or type(data)~='table' then return end
    local forbidden,valid=call(tip,'IsForbidden')
    if not valid or forbidden then return end
    local globalName,ok=call(tip,'GetName')
    if not ok or type(globalName)~='string' then return end
    local lines,linesOK=field(data,'lines')
    if not linesOK or type(lines)~='table' then return end
    -- Talents use a public title followed by AppendInfo(GetTraitEntry), rather
    -- than a standalone spell tooltip. Other append handlers stay untouched.
    local info,infoOK=call(tip,'GetProcessingTooltipInfo')
    if not infoOK or type(info)~='table' then return end
    local current,currentOK=field(info,'tooltipData')
    local append,appendOK=field(info,'append')
    if not currentOK or current~=data or not appendOK then return end
    local getter,getterOK=field(info,'getterName')
    local talentAppend=append==true and getterOK and getter=='GetTraitEntry'
    if append and not talentAppend then return end
    local first,firstOK=field(lines,1)
    if not firstOK then return end
    local title,titleOK=text(first,'leftText')
    if talentAppend then title,titleOK=call(_G[globalName..'TextLeft1'],'GetText') end
    local name=titleOK and named(title) or nil
    if not name and (not titleOK or title==nil or title=='') then
        local kind,kindOK=field(data,'type');local id,idOK=field(data,'id')
        if kindOK and Enum and Enum.TooltipDataType and kind==Enum.TooltipDataType.Spell
            and idOK and A.PublicNumber(id) then name=A.SpellIDs[id] end
    end
    local ui=tip==_G.SettingsTooltip
    if A.IsSettingsTooltip then
        local contextOK,value=pcall(A.IsSettingsTooltip,tip)
        if contextOK and A.Accessible(value) and value==true then ui=true end
    end
    -- Settings retain the existing dedicated formatting/priority.
    if not name or ui then return end
    local ctx=talentAppend and contexts[tip]
    if not ctx or not ctx.talentAppend or ctx.name~=name then
        A.ForgetTooltipInput(tip)
        ctx={tip=tip,globalName=globalName,name=name,rows={},lookup=weak(),translated=0,
            publicFields=0,restrictedFields=0,localize=enabled(),writeFailures=0}
    end
    ctx.data=data;ctx.finished=false;ctx.talentAppend=talentAppend
    contexts[tip]=ctx;active[tip]=ctx
    if A.RegisterTooltipInput then A.RegisterTooltipInput(tip) end
    local function addRow(row,prefix)
        if #ctx.rows>=500 then return end
        local l,lOK=text(row,'leftText');local r,rOK=text(row,'rightText')
        local entry={data=row,index=#ctx.rows+1,left=l,right=r,leftOK=lOK,rightOK=rOK,prefix=prefix}
        if lOK and l~=nil then ctx.publicFields=ctx.publicFields+1 elseif not lOK then ctx.restrictedFields=ctx.restrictedFields+1 end
        if rOK and r~=nil then ctx.publicFields=ctx.publicFields+1 elseif not rOK then ctx.restrictedFields=ctx.restrictedFields+1 end
        ctx.rows[#ctx.rows+1]=entry;ctx.lookup[row]=entry
    end
    if talentAppend then
        local count,good=call(tip,'NumLines')
        if not good or not A.PublicNumber(count) or count<1 or count>500 or count%1~=0 then
            A.ForgetTooltipInput(tip);return
        end
        local covered={}
        for _,row in ipairs(ctx.rows) do
            local index,indexOK=field(row.data,'lineIndex')
            if indexOK and A.PublicNumber(index) then covered[index]=true end
        end
        for i=1,count do
            local fs=fontAt(ctx,i)
            if not covered[i] and not (ctx.extras and ctx.extras[fs]) then
                local l,lOK=call(fs,'GetText');local rf=fontAt(ctx,i,true)
                local r,rOK=call(rf,'GetText');if not rf then rOK=true end
                if lOK and rOK then
                    -- This is our output snapshot, never an engine-owned table.
                    addRow({leftText=l,rightText=r,lineIndex=i},true)
                end
            end
        end
    end
    for i=1,500 do
        local row,rowOK=field(lines,i)
        if not rowOK then ctx.restrictedFields=ctx.restrictedFields+1;break end
        if row==nil then break end
        if type(row)~='table' then break end
        addRow(row)
    end
    if ctx.localize then nativeWidth(ctx) end
    local footerSeen=false
    for i,row in ipairs(ctx.rows) do
        if i>1 and row.leftOK and row.left then
            if A.Normalize(row.left)==footerEN then
                row.csLeft=footerSeen and '' or footerCS;row.footer=true;footerSeen=true
            else row.csLeft=A.Translate(name,row.left) end
        end
        if row.rightOK and row.right then row.csRight=A.Translate(name,row.right,true) end
    end
    -- Only merge complete public multi-line descriptions. A private or double
    -- row is a hard boundary; unknown fragments are never guessed.
    for i,row in ipairs(ctx.rows) do
        if i>1 and row.leftOK and row.left and row.left~='' and not row.csLeft and not row.consumed and not row.footer then
            local combined=row.left
            for j=i+1,math.min(#ctx.rows,i+(name=='Metamorphosis' and 32 or 12)) do
                local nextRow=ctx.rows[j]
                if not nextRow.leftOK or not nextRow.rightOK or nextRow.left==nil or nextRow.footer
                    or (nextRow.right and nextRow.right~='') then break end
                combined=combined..' '..nextRow.left
                local cs=A.Translate(name,combined)
                if cs then
                    row.combined=combined;row.csLeft=cs;row.group={row}
                    for k=i+1,j do
                        ctx.rows[k].csLeft='';ctx.rows[k].consumed=row
                        row.group[#row.group+1]=ctx.rows[k]
                    end
                    break
                end
            end
        end
    end
    -- Keep the existing bounded collector, including newly observed public
    -- descriptions. This is never a source for rendering a later tooltip.
    for i,row in ipairs(ctx.rows) do
        if i>1 and row.leftOK and row.left and not row.consumed and not row.footer then
            A.SafeCall('Tooltip input sample',A.Record,name,row.combined or row.left,row.csLeft,'tooltip_input')
        end
    end
    -- A build aborted by the engine/another callback must not retain a busy
    -- flag or temporary source edits. This is ONE watchdog, not polling.
    if C_Timer and C_Timer.After then C_Timer.After(0,function()
        if active[tip]~=ctx then return end
        release(ctx);active[tip]=nil;ctx.finished=true;ctx.aborted=true
        if A.ProcessTooltip then A.ProcessTooltip(tip) end
    end) end
end
local function planLine(tip,data)
    local ctx=active[tip];if not ctx or not ctx.localize then return end
    if not A.Accessible(data) or type(data)~='table' then return end
    local row=ctx.lookup[data];if not row then return end
    undo(row)
    local l,lOK=text(data,'leftText');local r,rOK=text(data,'rightText')
    -- Source altered by a native/other pre-handler: use no saved older value.
    if not lOK or l~=row.left then row.csLeft=nil;row.group=nil end
    if not rOK or r~=row.right then row.csRight=nil end
    if row.consumed then
        -- A joined description was already rendered by its head. Blank only
        -- its unchanged public output fragment; the native row stays intact.
        if row.consumed.groupApplied and row.consumed.rendered and lOK and l==row.left
            and rOK and (r==nil or r=='') then row.csLeft='' else row.csLeft=nil end
    end
    if row.footer and row.csLeft=='' then
        if not (ctx.footerRendered and lOK and l==row.left and rOK and (r==nil or r=='')) then
            row.csLeft=footerCS -- The earlier footer may have failed its font write.
        end
    end
    local index,indexOK=field(data,'lineIndex')
    if not indexOK or not A.PublicNumber(index) or index<1 or index>500 or index%1~=0 then return end
    row.renderIndex=index
    local count=index-1
    local left,right=fontAt(ctx,index),fontAt(ctx,index,true)
    -- Native AddLine has now created these FontStrings. The private color was
    -- processed by the engine before this addon callback.
    local cl=row.csLeft~=nil and changeFont(ctx,left)
    local cr=row.csRight~=nil and changeFont(ctx,right)
    if row.group and cl then
        -- Require all affected line objects to exist before consuming fragments.
        for k=2,#row.group do
            if not changeFont(ctx,fontAt(ctx,count+k)) then cl=false;break end
            local part=row.group[k];local now,good=text(part.data,'leftText')
            if not good or now~=part.left then cl=false;break end
        end
    end
    if cl then set(row,'leftText',row.csLeft);row.changedLeft=true;row.groupApplied=row.group~=nil end
    if cr then set(row,'rightText',row.csRight);row.changedRight=true end
    if not cl and not cr then
        if row.index==1 and lOK and type(l)=='string' then
            changeFont(ctx,left) -- Preserve the approved title font; the name stays English.
            local _,wrapOK=field(data,'wrapText');if wrapOK then set(row,'wrapText',true) end
        end
        return
    end
    -- Long double lines become a single wrapped native text block. This lets
    -- the engine reserve the complete height before subsequent rows are added.
    local leftOut=cl and row.csLeft or l
    local rightOut=cr and row.csRight or r
    if lOK and rOK and type(leftOut)=='string' and type(rightOut)=='string' and rightOut~='' then
        local lw,rw=width(leftOut,left),width(rightOut,right)
        local split=leftOut:find('\n',1,true) or rightOut:find('\n',1,true) or not lw or not rw or not ctx.inner or lw+rw+14>ctx.inner
        if split and row.index>1 then
            local lc,lcOK=field(data,'leftColor');local rc,rcOK=field(data,'rightColor')
            local lp=lcOK and rgba(lc);local rp=rcOK and rgba(rc)
            if lp and rp and (cl or changeFont(ctx,left)) then
                set(row,'leftText',lp..leftOut..'|r\n'..rp..rightOut..'|r')
                set(row,'rightText',nil);row.changedLeft=true;row.split=true
            else
                -- No trustworthy space/color information: keep the original
                -- right side instead of crowding a long replacement into it.
                if cr then set(row,'rightText',r);row.changedRight=nil end
            end
        end
    end
    local wrap,wrapOK=field(data,'wrapText')
    if wrapOK then set(row,'wrapText',true) end
end
local function postLine(tip,data)
    local ctx=active[tip];if not ctx or not ctx.localize or not A.Accessible(data) then return end
    local row=ctx.lookup[data];if not row then return end
    planLine(tip,data)
    if not row.renderIndex then return end
    local saved={}
    local ok,err=pcall(function()
        for _,side in ipairs({'leftText','rightText'}) do
            local edit=row.edits and row.edits[side]
            if edit then
                local fs=fontAt(ctx,row.renderIndex,side=='rightText')
                local record=A.WriteTooltipRowText(tip,fs,edit.old,edit.out or '',side=='rightText')
                if not record then error('Aktuální řádek není dostupný pro bezpečný překlad.') end
                saved[#saved+1]=record
            end
        end
        -- Title remains English, but shares the approved font and Shift reset.
        if row.index==1 and not (row.edits and row.edits.leftText) and row.leftOK and type(row.left)=='string' then
            local record=A.WriteTooltipRowText(tip,fontAt(ctx,row.renderIndex),row.left,row.left,false)
            if record then saved[#saved+1]=record end
        end
    end)
    if not ok then
        for _,record in ipairs(saved) do
            A.SafeCall('Tooltip output rollback',A.ToggleTooltipRowText,tip,record,false)
        end
        ctx.writeFailures=ctx.writeFailures+1;row.groupApplied=nil
        A.NoteError('Tooltip output',err)
    else
        row.renderedFields=saved;row.rendered=#saved>0
        if row.rendered then
            ctx.translated=ctx.translated+#saved
            if row.footer and row.csLeft~='' then ctx.footerRendered=true end
            if row.changedLeft and not row.footer then A.Stats.translated=A.Stats.translated+1 end
        else row.groupApplied=nil end
    end
    undo(row)
end
-- Some native/post handlers append F6 or the action-bar hint outside data.lines.
-- Translate current public hints before a native Show reflow. A verified
-- bound and an auto-height row allow long hints to wrap instead of staying EN.
local function supplements(ctx)
    if not ctx.localize or not ctx.inner then return false end
    local count,good=call(ctx.tip,'NumLines')
    if not good or not A.PublicNumber(count) or count<1 or count>500 then return false end
    local covered={}
    for _,row in ipairs(ctx.rows) do if row.renderIndex then covered[row.renderIndex]=true end end
    ctx.extras=ctx.extras or weak()
    local changed=false
    local previous=active[ctx.tip];active[ctx.tip]=ctx
    for i=2,count do
        if not covered[i] then
            local fs,rf=fontAt(ctx,i),fontAt(ctx,i,true)
            local raw,ok=call(fs,'GetText');local right,rok=call(rf,'GetText')
            if ok and type(raw)=='string' and rok and (right==nil or right=='') and (not ctx.extras[fs] or raw~=ctx.extras[fs].cs) then
                local normal=A.Normalize(raw)
                local isFooter=normal==footerEN
                local cs=isFooter and (ctx.footerRendered and '' or footerCS) or A.Translate(ctx.name,raw,true)
                local h,hok=call(fs,'GetHeight',true);local w,wok=call(fs,'GetWidth',true)
                if cs and (ctx.talentAppend or not cs:find('\n',1,true)) and hok and A.PublicNumber(h) and h==0
                    and wok and A.PublicNumber(w) and changeFont(ctx,fs) then
                    local needed=width(cs,fs);local available=w>0 and math.min(w,ctx.inner) or ctx.inner
                    if needed and available>0 then
                        local wrote,record=A.SafeCall('Tooltip input extra',A.WriteTooltipRowText,ctx.tip,fs,raw,cs,false)
                        if wrote and record then
                            ctx.extras[fs]=record;ctx.translated=ctx.translated+1;changed=true
                            if isFooter and cs~='' then ctx.footerRendered=true end
                        end
                    elseif A.ReleaseTooltipInputFont then
                        A.SafeCall('Tooltip input extra font restore',A.ReleaseTooltipInputFont,fs)
                    end
                end
            end
        end
    end
    active[ctx.tip]=previous
    return changed
end
local function finish(tip,data)
    local ctx=contexts[tip];if not ctx or not A.Accessible(data) or ctx.data~=data then return end
    -- A new pooled tooltip may create the later fragment FontStrings only
    -- after the head row. Finish those public groups before native Show.
    if ctx.localize then
        for _,row in ipairs(ctx.rows) do
            if row.prefix and not row.rendered then postLine(tip,row.data) end
        end
        for _,row in ipairs(ctx.rows) do
            if row.group and not row.groupApplied then
                postLine(tip,row.data)
                if row.groupApplied then
                    for k=2,#row.group do postLine(tip,row.group[k].data) end
                end
            end
        end
    end
    release(ctx);active[tip]=nil;ctx.finished=true
end
function A.ProcessTooltipInput(tip,trace)
    local ctx=contexts[tip]
    if not ctx or not ctx.finished then return false end
    local ok,changed=pcall(supplements,ctx)
    if not ok then active[tip]=nil;A.NoteError('Tooltip extra native input',changed) end
    if ok and changed and tip.Show then A.SafeCall('Tooltip extra native reflow',tip.Show,tip) end
    -- Context is a current render transaction, not a saved spell description.
    -- Any external text write invalidates it in Tooltip.lua.
    trace.source='current_input';trace.sourceReadable=ctx.publicFields
    trace.sourceRestricted=ctx.restrictedFields;trace.sourceTranslated=ctx.translated
    trace.layout='native';trace.sourceHook=true;trace.sourceRows=#ctx.rows
    trace.fontMissing=ctx.fontMissing;trace.nativeBounded=ctx.inner~=nil
    trace.tooltip=ctx.globalName;trace.title=ctx.name
    trace.phase='native_input';trace.translated=ctx.localize and ctx.translated or 0
    trace.mode=ctx.localize and ctx.translated>0 and 'native_input' or 'original'
    trace.reason=ctx.aborted and 'error' or (not ctx.localize and (A.DB and A.DB.enabled==false and 'disabled' or 'shift')
        or (ctx.restrictedFields>0 and 'restricted_input' or (ctx.translated>0 and 'ok' or 'unmatched')))
    if ctx.writeFailures>0 then trace.reason='error';trace.detail='input_write_rejected' end
    return true
end
function A.RebuildTooltipInput(tip)
    local ctx=contexts[tip]
    if not ctx or not ctx.finished or active[tip] or rebuilding[tip] then return false end
    local localize=enabled()
    if ctx.localize==localize then return true end
    rebuilding[tip]=true
    local ok,err=pcall(function()
        ctx.localize=localize
        if localize then
            nativeWidth(ctx);ctx.translated=0;ctx.footerRendered=nil
            active[tip]=ctx
            for _,row in ipairs(ctx.rows) do
                row.rendered=nil;row.groupApplied=nil;row.edits=nil
                postLine(tip,row.data)
            end
            active[tip]=nil
        else
            for _,row in ipairs(ctx.rows) do
                for _,saved in ipairs(row.renderedFields or {}) do A.ToggleTooltipRowText(tip,saved,false) end
            end
            restoreWidth(tip)
        end
        for _,saved in pairs(ctx.extras or {}) do A.ToggleTooltipRowText(tip,saved,localize) end
        -- Do not call RebuildFromTooltipInfo: it writes native info tables from
        -- addon execution and can taint subsequent action/cooldown refreshes.
        if tip.Show then tip:Show() end
    end)
    rebuilding[tip]=nil;active[tip]=nil
    if not ok then A.NoteError('Tooltip output refresh',err) end
    return true
end
local registrations={}
function A.HookTooltipInput()
    if hooked or not TooltipDataProcessor then return end
    local p=TooltipDataProcessor
    if not A.Accessible(p.AllTypes) or p.AllTypes==nil then return end
    for _,key in ipairs({'AddTooltipPreCall','AddLinePreCall','AddLinePostCall','AddTooltipPostCall'}) do
        if type(p[key])~='function' then return end
    end
    local function safe(scope,fn)
        return function(tip,data)
            if not hooked then return end
            local ok,err=pcall(fn,tip,data)
            if not ok then
                A.NoteError(scope,err)
                local ctx=contexts[tip]
                if ctx then ctx.writeFailures=ctx.writeFailures+1;release(ctx) end
            end
            -- Observers only: never consume native lines or modify their data.
        end
    end
    for _,entry in ipairs({
        {'AddTooltipPreCall','Tooltip input begin',begin},
        {'AddLinePostCall','Tooltip input end row',postLine},
        {'AddTooltipPostCall','Tooltip input finish',finish},
    }) do
        if not registrations[entry[1]] then
            local ok=A.SafeCall('Tooltip input registration',p[entry[1]],p.AllTypes,safe(entry[2],entry[3]))
            if not ok then return end
            registrations[entry[1]]=true
        end
    end
    hooked=true
end
