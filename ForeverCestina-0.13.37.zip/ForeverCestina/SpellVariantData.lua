-- Captured client variants, build 69977. Do not replace unresolved source values.
local _, A = ...
local rules = {
  {name=[=[Metamorphosis]=], en=[=[Transform into a Demon, increasing Armor by {1}%, reducing the chance you will be critically hit by {2}%, increasing your threat by {3}%, increasing mana gained from Life Tap by {4}%, and transforming the functionality of some of your abilities: Searing Pain: Now instant. Shadow Bolt: Becomes Shadow Cleave, a Shadow melee attack that hits up to {5} nearby enemies. Curse of Recklessness: Now also taunts your target to attack you for until canceled. Howl of Terror: Now also forces all nearby enemies to attack you for until canceled, but cooldown increased to {6} minutes.]=], cs=[=[Promění tě v démona. Zbroj se zvýší o {1} %, šance utrpět kritický zásah klesne o {2} %, hrozba vzroste o {3} % a mana získaná z Life Tap o {4} %. Mění tyto schopnosti:

Searing Pain: sesílá se okamžitě.

Shadow Bolt: změní se na Shadow Cleave, útok na blízko se stínovým poškozením, který zasáhne až {5} okolních nepřátel.

Curse of Recklessness: navíc vyprovokuje cíl, aby na tebe útočil až do zrušení účinku.

Howl of Terror: navíc donutí všechny okolní nepřátele útočit na tebe až do zrušení účinku, ale doba obnovy se prodlouží na {6} min.]=]},
  {name=[=[Starfall]=], en=[=[You summon a flurry of stars from the sky on all targets within {1} yards of the caster, each dealing {2} to {3} Arcane damage. Also causes {4} to {5} Arcane damage to all other enemies within {6} yards of the enemy target. Maximum {7} stars. Lasts until canceled.]=], cs=[=[Přivolává hvězdy na všechny cíle do {1} yardů od tebe. Každá způsobí svému cíli {2} až {3} arkánového poškození a všem ostatním nepřátelům do {6} yardů od něj {4} až {5} arkánového poškození. Nejvýše {7} hvězd. Trvá do zrušení.]=]},
  {name=[=[Prayer of Mending]=], en=[=[Places a spell on the target that heals them the next time they take damage. When the heal occurs, Prayer of Mending jumps to a party or raid member within {1} yards. Jumps up to {2} times and lasts until canceled after each jump. This spell can only be placed on one target at a time.]=], cs=[=[Umístí na cíl Prayer of Mending, který ho vyléčí, až příště utrpí poškození. Pak přeskočí na člena skupiny nebo raidu do {1} yardů. Může přeskočit až {2}krát; po každém přeskočení vydrží do zrušení. Současně může být jen na jednom cíli.]=]},
  {name=[=[Living Bomb]=], en=[=[The target becomes a Living Bomb, taking {1} Fire damage over until canceled. After until canceled or when the spell is dispelled, the target explodes dealing {2} Fire damage to all enemies within {3} yards.]=], cs=[=[Z cíle udělá Living Bomb, který mu během svého působení způsobí celkem {1} ohnivého poškození. Účinek trvá do zrušení. Po skončení nebo při rozptýlení kouzla cíl vybuchne a způsobí {2} ohnivého poškození všem nepřátelům do {3} yardů.]=]},
  {name=[=[Regeneration]=], en=[=[Heals the target for {1} health over until canceled and applies Temporal Beacon for {2} sec. Temporal Beacon Records the subject's space-time position. {3}% of all Arcane damage done by the caster will be converted to chronomantic healing on each of the caster's current Temporal Beacon targets. This healing is reduced by {4}% on self, and also reduced by {5}% when damage is done by Arcane spells that damage multiple targets.]=], cs=[=[Obnovuje cíli celkem {1} zdraví během účinku trvajícího do zrušení a na {2} s na něj umístí Temporal Beacon.

Temporal Beacon
Zaznamenává polohu cíle v časoprostoru. {3} % veškerého arkánového poškození, které způsobíš, se převede na časové léčení každého tvého současného cíle s Temporal Beacon. Léčení sebe sama je sníženo o {4} %. Léčení z arkánových kouzel zasahujících více cílů je navíc sníženo o {5} %.]=]},
  {name=[=[Mind Sear]=], en=[=[Causes an explosion of shadow magic around the enemy target, causing {1} to {2} Shadow damage every {3} sec for until canceled to all enemies within {4} yards around the target.]=], cs=[=[Vyvolá kolem cílového nepřítele stínový výbuch. Až do zrušení způsobuje všem nepřátelům do {4} yardů od něj {1} až {2} stínového poškození každých {3} s.]=]},
}
for _, rule in ipairs(rules) do A.Rules[#A.Rules+1] = rule end
