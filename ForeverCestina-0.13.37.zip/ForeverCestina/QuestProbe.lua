local _, A = ...
-- Opt-in, bounded read-only cache probe. No quest selection, acceptance or travel.
local ids={8,14,19,20,23,24,25,30,46,48,49,50}
local active
local function capture(run,id,success)
    local row=run.results[id]
    if not row then return end
    row.success=success
    if C_QuestLog.GetTitleForQuestID then
        local ok,title=pcall(C_QuestLog.GetTitleForQuestID,id)
        if ok and A.Accessible(title) and type(title)=="string" then row.title=title end
    end
    if C_QuestLog.GetQuestObjectives then
        local ok,objectives=pcall(C_QuestLog.GetQuestObjectives,id)
        if ok and A.Accessible(objectives) and type(objectives)=="table" then
            row.objectives={}
            for _,objective in ipairs(objectives) do
                if A.Accessible(objective.text) and type(objective.text)=="string" then
                    row.objectives[#row.objectives+1]=objective.text
                end
            end
        end
    end
end
local event=CreateFrame("Frame")
event:RegisterEvent("QUEST_DATA_LOAD_RESULT")
event:SetScript("OnEvent",function(_,_,id,success)
    if active and A.Accessible(id) and A.Accessible(success) then capture(active,id,success) end
end)
SLASH_FOREVERQUESTPROBE1="/fczquestprobe"
SlashCmdList.FOREVERQUESTPROBE=function()
    if active then print("ForeverCestina: test už probíhá.");return end
    if not A.DB or not C_QuestLog or not C_QuestLog.RequestLoadQuestByID then
        print("ForeverCestina: klient neposkytuje potřebné načítání questů.");return
    end
    local run={version=A.Version,results={},finished=false}
    A.DB.questProbe=run;active=run
    local index=1
    local function nextQuest()
        local id=ids[index]
        if not id then
            C_Timer.After(5,function()
                local successful=0
                for questID,row in pairs(run.results) do
                    capture(run,questID,row.success)
                    if row.success then successful=successful+1 end
                end
                run.finished=true;active=nil
                print("ForeverCestina: test hotov, potvrzené odpovědi "..successful.."/"..#ids..". Pro uložení cache normálně ukonči hru. Úplnost textů ověříme na disku.")
            end)
            return
        end
        run.results[id]={}
        local ok=pcall(C_QuestLog.RequestLoadQuestByID,id)
        if not ok then run.results[id].requestFailed=true end
        index=index+1;C_Timer.After(1,nextQuest)
    end
    print("ForeverCestina: vyžádám 12 questů podle ID, bez návštěvy NPC. Test trvá asi 17 sekund.")
    nextQuest()
end
