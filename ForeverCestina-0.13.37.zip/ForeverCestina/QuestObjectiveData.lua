-- Short objective variants use existing verified quest identity and exact wording.
local _, A = ...
local professions = {
 alchemy="alchymii", blacksmithing="kovářství", cooking="vaření", enchanting="očarování",
 engineering="inženýrství", ["first aid"]="první pomoci", fishing="rybaření",
 herbalism="bylinkářství", leatherworking="kožedělnictví", mining="těžbě",
 skinning="stahování kůží", tailoring="krejčovství",
}
local rules={}
for en,cs in pairs(professions) do
 rules[#rules+1]=A.Compile("Raise your "..en.." skill to {1}", "Zvyš svou dovednost v "..cs.." na {1}")
end
local short={}
for id,entry in pairs(A.QuestEntries) do
 if entry.title=="Camping 101: Cooking" and entry.objectives then
  local npc,place=entry.objectives[1]:match("^Speak with (.-) in (.-) to learn to become a cook%.$")
  if npc and place then
   short[id]={en="Learn cooking from "..npc.." in "..place,cs="Nauč se vaření u "..npc.." v "..place}
  end
 end
end
function A.TranslateExtraQuestObjective(id,text)
 local row=short[id]
 if row and text==row.en then return row.cs end
 for _,rule in ipairs(rules) do local cs=A.Apply(rule,text);if cs then return cs end end
end
