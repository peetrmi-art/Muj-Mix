local _, A = ...
-- Text availability is independent of geometry. All captures are atomic;
-- inaccessible current geometry is never replaced with a cached measurement.
local layouts = setmetatable({}, {__mode="k"})
local unpackValues = unpack or table.unpack
local function snapshot(tip,fonts)
    if not tip.GetWidth or not tip.GetHeight or not tip.SetWidth or not tip.SetHeight then return nil end
    if tip.IsForbidden and tip:IsForbidden() then return nil end
    local width,height=tip:GetWidth(),tip:GetHeight()
    if not A.PublicNumber(width) or not A.PublicNumber(height) then return nil end
    local result={width=width,height=height,fonts={}}
    for _,font in ipairs(fonts) do
        if not font.GetNumPoints or not font.GetStringHeight or not font.SetWidth then return nil end
        if font.IsForbidden and font:IsForbidden() then return nil end
        local text=font.GetText and font:GetText()
        if not A.Accessible(text) then return nil end
        -- A measured rectangle is NOT a size constraint. In particular,
        -- auto-height 0 must remain 0 when this FontString is reused later.
        -- ignoreRect is part of SimpleScriptRegion API in build 1.60.1.69913.
        local measuredWidth,measuredHeight=font:GetWidth(),font:GetHeight()
        if not A.PublicNumber(measuredWidth) or not A.PublicNumber(measuredHeight) then return nil end
        local saved={points={},width=font:GetWidth(true),height=font:GetHeight(true),justify=font:GetJustifyH(),wrap=font.CanWordWrap and font:CanWordWrap()}
        local count=font:GetNumPoints()
        if not A.PublicNumber(count) or count<0 or count%1~=0 or count>64 then return nil end
        if not A.PublicNumber(saved.width) or not A.PublicNumber(saved.height)
            or not A.Accessible(saved.justify) or type(saved.justify)~="string"
            or not A.Accessible(saved.wrap) then return nil end
        for i=1,count do
            local point,relative,relativePoint,x,y=font:GetPoint(i)
            if not A.Accessible(point) or type(point)~="string" or not A.Accessible(relative)
                or not A.Accessible(relativePoint) or type(relativePoint)~="string"
                or not A.PublicNumber(x) or not A.PublicNumber(y) then return nil end
            saved.points[i]={point,relative,relativePoint,x,y}
        end
        if font.GetTextColor then
            saved.color={font:GetTextColor()}
            for _,value in ipairs(saved.color) do if not A.PublicNumber(value) then return nil end end
        end
        -- Measurement may itself be protected, independently of frame dimensions.
        if not A.PublicNumber(font:GetStringHeight()) then return nil end
        if font.GetUnboundedStringWidth and not A.PublicNumber(font:GetUnboundedStringWidth()) then return nil end
        result.fonts[font]=saved
    end
    return result
end
local function save(tip,fonts)
    local current=snapshot(tip,fonts);if not current then return false end
    local old=layouts[tip]
    -- A new capture is valid only after our previous mutations were released.
    -- Do not retain the first tooltip's dimensions across native rebuilds.
    if old and old.applied then return false end
    layouts[tip]=current
    return true
end
function A.SaveTooltipGeometry(tip,fonts)
    local ok,result=A.SafeCall('Geometry capture',save,tip,fonts)
    return ok and result==true
end
local function sameNumber(a,b)
    -- Native UI coordinates/colors can round to single precision on write.
    return math.abs(a-b)<=math.max(1,math.abs(a),math.abs(b))*0.000001
end
local function sameValues(first,second)
    if not first or not second or #first~=#second then return false end
    for i,value in ipairs(first) do if not sameNumber(value,second[i]) then return false end end
    return true
end
local function samePoints(first,second)
    if #first~=#second then return false end
    for i,point in ipairs(first) do
        -- Relative frames are compared by identity, never traversed as tables.
        local other=second[i]
        for k=1,3 do if point[k]~=other[k] then return false end end
        for k=4,5 do if not sameNumber(point[k],other[k]) then return false end end
    end
    return true
end
local function restore(tip,old)
    local applied=old.applied
    if not applied then return true end
    local fonts={};for font in pairs(applied.fonts) do fonts[#fonts+1]=font end
    local current=snapshot(tip,fonts);if not current then return false end
    for font,ours in pairs(applied.fonts) do
        local saved,now=old.fonts[font],current.fonts[font]
        -- Restore only properties that are still ours. A native refresh or
        -- another addon may already have supplied different anchors/dimensions.
        if ours.points and samePoints(now.points,ours.points) then
            font:ClearAllPoints()
            for _,point in ipairs(saved.points) do font:SetPoint(unpackValues(point,1,5)) end
        end
        if ours.width~=nil and sameNumber(now.width,ours.width) then font:SetWidth(saved.width) end
        if ours.height~=nil and sameNumber(now.height,ours.height) then font:SetHeight(saved.height) end
        if ours.justify~=nil and now.justify==ours.justify then font:SetJustifyH(saved.justify) end
        if ours.wrap~=nil and now.wrap==ours.wrap and saved.wrap~=nil then font:SetWordWrap(saved.wrap) end
        if ours.color and now.color and sameValues(now.color,ours.color) and saved.color then
            font:SetTextColor(unpackValues(saved.color))
        end
    end
    if applied.width~=nil and sameNumber(current.width,applied.width) then tip:SetWidth(old.width) end
    if applied.height~=nil and sameNumber(current.height,applied.height) then tip:SetHeight(old.height) end
    old.applied=nil
    return true
end
function A.RestoreTooltipGeometry(tip,forget)
    local old=layouts[tip]
    -- Clearing invalidates the snapshot even when a native setter fails.
    if forget then layouts[tip]=nil end
    if not old then return true end
    local ok,result=A.SafeCall('Geometry restore',restore,tip,old)
    return ok and result==true
end
local function layout(tip,left,right,state,count,preferredWidth)
    local old=layouts[tip]; if not old then return false end
    -- Never feed the native frame's previous width back into our layout.
    -- Native tooltip measurement can include widths assigned to reused rows.
    -- A content-independent width prevents growth while hovering between spells.
    local fonts={}
    for fs in pairs(old.fonts) do fonts[#fonts+1]=fs end
    if not snapshot(tip,fonts) then return false end
    local width=preferredWidth or (count>3 and 350 or 240)
    if UIParent and UIParent.GetWidth then
        local screenWidth=UIParent:GetWidth()
        if not A.PublicNumber(screenWidth) or screenWidth<=24 then return false end
        width=math.min(width,screenWidth-24)
    end
    local inner=math.max(100,width-24)
    local applied={fonts={}};old.applied=applied
    local function marker(font)
        local row=applied.fonts[font]
        if not row then row={};applied.fonts[font]=row end
        return row
    end
    -- Mark each write before invoking it: a later hook may throw after mutation.
    applied.width=width;tip:SetWidth(width)
    local y=10
    local function content(font)
        local text=font and font:GetText()
        if not A.Accessible(text) then error("Text tooltipu již není dostupný.") end
        return type(text)=="string" and text~="" and text or nil
    end
    local function place(font,x,top,w,justify)
        local ours=marker(font)
        ours.points={};font:ClearAllPoints()
        ours.points={{"TOPLEFT",tip,"TOPLEFT",x,-top}};font:SetPoint("TOPLEFT",tip,"TOPLEFT",x,-top)
        ours.width=w;font:SetWidth(w)
        ours.height=0;font:SetHeight(0)
        ours.justify=justify;font:SetJustifyH(justify)
        ours.wrap=true;font:SetWordWrap(true)
        local height=font:GetStringHeight()
        if not A.PublicNumber(height) then error("Výška řádku již není dostupná.") end
        return math.max(1,height)
    end
    for i=1,count do
        local l,r=left[i],right[i]
        local lt,rt=content(l),content(r)
        if (lt and not old.fonts[l]) or (rt and not old.fonts[r]) then error("Unsupported tooltip font geometry") end
        -- Settings explanations/options are distinct blocks, not one dense paragraph.
        if preferredWidth and i>1 and (lt or rt) then y=y+(i==2 and 3 or 7) end
        local lh,rh=0,0
        if lt and state[l] and state[l].footer then
            y=y+7
            if l.SetTextColor then
                marker(l).color={0.25,0.8,1,1};l:SetTextColor(0.25,0.8,1,1)
            end
        end
        if lt and rt then
            -- Measure both sides before deciding whether a double row fits.
            local lw=l.GetUnboundedStringWidth and l:GetUnboundedStringWidth() or inner
            local rw=r.GetUnboundedStringWidth and r:GetUnboundedStringWidth() or inner
            if not A.PublicNumber(lw) or not A.PublicNumber(rw) then error("Šířka textu není dostupná.") end
            if lt:find("\n",1,true) or rt:find("\n",1,true) or lw+rw+14>inner then
                lh=place(l,12,y,inner,"LEFT")
                rh=place(r,12,y+lh+3,inner,"LEFT")
                y=y+lh+3+rh+3
            else
                local rightWidth=math.min(inner-20,rw+2)
                lh=place(l,12,y,inner-rightWidth-12,"LEFT")
                rh=place(r,12+inner-rightWidth,y,rightWidth,"RIGHT")
                y=y+math.max(lh,rh)+3
            end
        elseif lt then y=y+place(l,12,y,inner,"LEFT")+3
        elseif rt then y=y+place(r,12,y,inner,"LEFT")+3
        else
            -- Preserve native separators, but not rows consumed by a joined description.
            local suppressed=(l and state[l] and state[l].cs=="") or (r and state[r] and state[r].cs=="")
            if not suppressed then y=y+6 end
        end
    end
    -- FontString changes can trigger native measurement; apply the bound last.
    applied.width=width;tip:SetWidth(width)
    applied.height=y+9;tip:SetHeight(y+9)
    return true
end

function A.LayoutTooltip(tip,left,right,state,count,preferredWidth)
    local ok,result=A.SafeCall('Geometry layout',layout,tip,left,right,state,count,preferredWidth)
    if not ok then A.RestoreTooltipGeometry(tip) end
    return ok and result==true
end
