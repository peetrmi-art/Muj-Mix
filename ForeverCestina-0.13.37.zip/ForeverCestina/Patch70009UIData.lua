-- UI labels introduced/confirmed by WoW Forever build 70009.
local _, A = ...
local E = A.UIEntries

table.insert(E, {"Use Compact Action Bar", "Použít kompaktní akční lištu"})
table.insert(E, {"Fixed Party Targeting", "Pevné zaměřování členů skupiny"})
table.insert(E, {"Swap Target Modifier Sides", "Prohodit strany modifikátorů cílení"})
table.insert(E, {"Swap Friendly Target Action Sides", "Prohodit strany akcí pro přátelský cíl"})
table.insert(E, {"Swap Hostile Target Action Sides", "Prohodit strany akcí pro nepřátelský cíl"})
