-- Only named quest buttons/headers; prose, item names and quest titles have separate handling.
local _, A = ...
local function label(value)
 if not value then return end
 if value.GetFontString then value=value:GetFontString() end
 if value and A.RegisterUILabel then A.SafeCall("Quest UI label",A.RegisterUILabel,value) end
end
local function install()
 for _,name in ipairs({
  "QuestFrameAcceptButton","QuestFrameDeclineButton","QuestFrameCompleteButton",
  "QuestFrameCompleteQuestButton","QuestFrameGoodbyeButton",
  "QuestInfoDescriptionHeader","QuestInfoObjectivesHeader","QuestProgressRequiredItemsText",
  "QuestInfoSpellObjectiveLearnLabel","QuestInfoGroupSize",
 }) do label(_G[name]) end
 for _,frameName in ipairs({"QuestInfoRewardsFrame","MapQuestInfoRewardsFrame"}) do
 local rewards=_G[frameName]
 if rewards then
  for _,key in ipairs({"Header","ItemChooseText","ItemReceiveText","PlayerTitleText","QuestSessionBonusReward"}) do label(rewards[key]) end
  if rewards.XPFrame then label(rewards.XPFrame.ReceiveText) end
 end
 end
 for _,frameName in ipairs({"ObjectiveTrackerFrame","QuestObjectiveTracker"}) do
  local tracker=_G[frameName]
  if tracker and tracker.Header then label(tracker.Header.Text) end
 end
end
local frame=CreateFrame("Frame")
for _,event in ipairs({"ADDON_LOADED","PLAYER_LOGIN","QUEST_DETAIL","QUEST_PROGRESS","QUEST_COMPLETE","QUEST_LOG_UPDATE"}) do frame:RegisterEvent(event) end
frame:SetScript("OnEvent",install)
install()
