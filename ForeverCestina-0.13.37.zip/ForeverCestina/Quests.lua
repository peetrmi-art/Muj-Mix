local _, A = ...
-- Quest prose only. Native layout measures the translated text after SetText
-- returns. No tooltip hooks, width changes, frame polling, or global strings.
local font = "Interface\\AddOns\\ForeverCestina\\Fonts\\ForeverSerif-Medium.ttf"
local compiled, watched, busy = {}, setmetatable({}, {__mode="k"}), setmetatable({}, {__mode="k"})
local function normalize(text)
    if not A.Accessible(text) or type(text)~="string" then return nil end
    return A.Normalize((text:gsub("%$[Bb]", "\n")))
end
local function escape(text)
    return (text:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1"))
end
local function variants(text)
    local first,last,male,female=text:find("%$[Gg]([^:;]*):([^;]*);")
    if not first then return {text} end
    local result={}
    for _,branch in ipairs({male,female}) do
        for _,value in ipairs(variants(text:sub(1,first-1)..branch..text:sub(last+1))) do
            result[#result+1]=value
        end
    end
    return result
end
local function compile(row,csOverride)
    local result={}
    for _,en in ipairs(variants(row[1])) do
        en=normalize(en)
        local parts, keys, pos={"^"},{},1
        while true do
            local first,last,key=en:find("%$(%d+oa)",pos)
            local f,l,k=en:find("%$([NnCcRr])",pos)
            if f and (not first or f<first) then first,last,key=f,l,k end
            if not first then break end
            keys[#keys+1]=key:lower()
            parts[#parts+1]=escape(en:sub(pos,first-1))
            parts[#parts+1]=key:match("^%d") and "(%d+)" or "(.-)"
            pos=last+1
        end
        parts[#parts+1]=escape(en:sub(pos)).."$"
        result[#result+1]={pattern=table.concat(parts), keys=keys, cs=csOverride or row[2]}
    end
    return result
end
function A.TranslateQuest(id, field, text)
    if not A.Accessible(id) or type(id)~="number" then return nil end
    local entry=A.QuestEntries[id]
    local row=entry and entry[field]
    local en=normalize(text)
    if not row or not en or en=="" then return nil end
    compiled[id]=compiled[id] or {}
    compiled[id][field]=compiled[id][field] or compile(row,A.QuestTextOverrides and A.QuestTextOverrides[id] and A.QuestTextOverrides[id][field])
    for _,rule in ipairs(compiled[id][field]) do
        local captures={en:match(rule.pattern)}
        if (#rule.keys==0 and en:match(rule.pattern)) or (#rule.keys>0 and #captures==#rule.keys) then
            local values,valid={},true
            for i,key in ipairs(rule.keys) do
                local value=captures[i]
                if value=="" or #value>120 or value:find("%$") or (values[key] and values[key]~=value) then valid=false end
                values[key]=value
            end
            if valid then
                local cs=rule.cs:gsub("%$[Bb]", "\n")
                cs=cs:gsub("%$(%d+oa)",function(key)return values[key] or "$"..key end)
                cs=cs:gsub("%$([NnCcRr])",function(key)return values[key:lower()] or "$"..key end)
                if not cs:find("%$[%w]") then return cs end
            end
        end
    end
end
local function questID(field)
    local getter
    if field~="progress" and field~="completion" and QuestInfoFrame and QuestInfoFrame.questLog then
        getter=C_QuestLog and C_QuestLog.GetSelectedQuest or GetQuestLogSelectedID
    else getter=GetQuestID end
    if type(getter)~="function" then return end
    local ok,id=pcall(getter)
    if ok and A.Accessible(id) and type(id)=="number" and id>0 then return id end
end
local function record(id,field,text,translated)
    if translated or not A.DB or not text or text=="" or #text>16000 then return end
    A.DB.questSamples=type(A.DB.questSamples)=="table" and A.DB.questSamples or {}
    local row=A.DB.questSamples[id]
    if type(row)~="table" then row={}; A.DB.questSamples[id]=row end
    row[field]=text
    row.build=A.DB.client and A.DB.client.build
end
local function watch(name,field)
    local fs=_G[name]
    if not fs or watched[fs] then return end
    local state={};watched[fs]=state
    hooksecurefunc(fs,"SetText",function(self,text)
        if busy[self] then return end
        busy[self]=true
        local ok,err=pcall(function()
            text=self:GetText()
            if not A.Accessible(text) or type(text)~="string" then return end
            local id=questID(field)
            local cs=id and A.TranslateQuest(id,field,text)
            if id then record(id,field,text,cs) end
            if A.DB and A.DB.enabled==false then cs=nil end
            if cs then
                if not state.originalFont then state.originalFont=A.CaptureFont(self) end
                A.SetLocalizedFont(self,state.originalFont,font,1) -- +1 from the saved native size; never from our previous output.
                state.changed=true
                -- The unobtrusive footer contains only the original quest title.
                if field=="description" or field=="progress" or field=="completion" then
                    local entry=A.QuestEntries[id]
                    if entry and A.QuestTitleTranslations and A.QuestTitleTranslations[entry.title] then
                        cs=cs.."\n\n|cff706050EN: "..entry.title.."|r"
                    end
                end
                self:SetText(cs)
            elseif state.changed then
                A.RestoreFont(self,state.originalFont);state.changed=false
            end
        end)
        busy[self]=nil -- Release even when the engine or another hook throws.
        if not ok then A.NoteError('Quests',err) end
    end)
end
local function install()
    watch("QuestInfoDescriptionText","description")
    watch("QuestInfoObjectivesText","objectives")
    watch("QuestProgressText","progress")
    watch("QuestInfoRewardText","completion")
end
local frame=CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent",install)
install()
