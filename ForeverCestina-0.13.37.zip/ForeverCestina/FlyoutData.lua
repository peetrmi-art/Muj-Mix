-- SpellFlyout from local build 1.60.1.69913. English titles are preserved.
local _, A = ...
A.Rules[#A.Rules+1] = {name=[=[Portal]=],en=[=[Creates a portal, teleporting group members who use it to a major city.]=],cs=[=[Vytvoří portál, který přenese členy skupiny, kteří ho použijí, do velkého města.]=]}
A.Rules[#A.Rules+1] = {name=[=[Teleport]=],en=[=[Teleports you to a major city.]=],cs=[=[Přenese tě do velkého města.]=]}
A.Rules[#A.Rules+1] = {name=[=[Spell Resistances]=],en=[=[Your resistances to spells.]=],cs=[=[Tvé odolnosti vůči kouzlům.]=]}
A.Rules[#A.Rules+1] = {name=[=[Aspect]=],en=[=[Take on aspects of nature.]=],cs=[=[Převezmeš vlastnosti přírody pomocí aspektu.]=]}
A.Rules[#A.Rules+1] = {name=[=[Weapon Proficiencies]=],en=[=[Your weapon skill determines your effectiveness in combat, affecting your chance to hit, critically hit, and avoid being dodged or parried, as well as the damage reduction of your Glancing Blows.]=],cs=[=[Dovednost se zbraní ovlivňuje tvou účinnost v boji: šanci zasáhnout, kriticky zasáhnout a vyhnout se úhybu či odražení útoku nepřítelem. Ovlivňuje také snížení poškození tvých letmých zásahů (Glancing Blows).]=]}
A.Rules[#A.Rules+1] = {name=[=[Summon Demon]=],en=[=[Summons a Demon under the command of the Warlock]=],cs=[=[Přivolá démona pod velení warlocka.]=]}
A.Rules[#A.Rules+1] = {name=[=[Imp Spells]=],en=[=[[PH] Commands the Imp to cast spells]=],cs=[=[[PH] Přikáže Impovi sesílat kouzla.]=]}
A.Rules[#A.Rules+1] = {name=[=[Shapeshift]=],en=[=[Shapeshift into a different form.]=],cs=[=[Promění tě do jiné formy.]=]}
A.Rules[#A.Rules+1] = {name=[=[Retribution Blessings]=],en=[=[Places Retribution Blessings on friendly targets.]=],cs=[=[Sesílá požehnání typu Retribution na spojence.]=]}
A.Rules[#A.Rules+1] = {name=[=[Blessings]=],en=[=[Places a Blessing on friendly targets.]=],cs=[=[Sesílá požehnání na spojence.]=]}
A.Rules[#A.Rules+1] = {name=[=[Protection Blessings]=],en=[=[Places Protection Blessings on friendly targets.]=],cs=[=[Sesílá požehnání typu Protection na spojence.]=]}
A.Rules[#A.Rules+1] = {name=[=[Pet Utilities]=],en=[=[Manage your pets.]=],cs=[=[Správa tvých petů.]=]}
A.Rules[#A.Rules+1] = {name=[=[Tracking]=],en=[=[Track your quarry.]=],cs=[=[Sledování tvé kořisti.]=]}
A.Rules[#A.Rules+1] = {name=[=[Stances]=],en=[=[Activate a combat stance.]=],cs=[=[Aktivuje bojový postoj.]=]}
A.Rules[#A.Rules+1] = {name=[=[Auras]=],en=[=[Activate a protective aura for your group.]=],cs=[=[Aktivuje ochrannou auru pro tvou skupinu.]=]}
A.Rules[#A.Rules+1] = {name=[=[Greater Blessings]=],en=[=[Blessings that target all members of your group that share the same class.]=],cs=[=[Požehnání, která působí na všechny členy tvé skupiny stejného povolání.]=]}
A.Rules[#A.Rules+1] = {name=[=[Utility Blessings]=],en=[=[Short duration Blessings used to save a single target.]=],cs=[=[Krátkodobá požehnání používaná k záchraně jednoho cíle.]=]}
