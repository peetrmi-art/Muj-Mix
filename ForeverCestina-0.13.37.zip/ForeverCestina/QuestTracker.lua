local _, A = ...
-- Presentation-only hooks on quest objective FontStrings, before native height
-- measurement. Never replace quest APIs, counters, or tracker geometry.
local font="Interface\\AddOns\\ForeverCestina\\Fonts\\ForeverSerif-Medium.ttf"
local watched,hooked=setmetatable({},{__mode="k"}),setmetatable({},{__mode="k"})
local busy=setmetatable({},{__mode="k"})
local labels={
    ["Ready for turn-in"]="|cffc4df78HOTOVO – odevzdej úkol|r",
    ["Quest Complete!"]="|cffc4df78HOTOVO – úkol splněn!|r",
    ["Quest Complete"]="|cffc4df78HOTOVO – úkol splněn|r",
    ["Click to complete quest."]="Kliknutím odevzdej úkol.",
    ["Complete"]="Hotovo",["Failed"]="Nesplněno",
}
local short={
    [62]={["Scout through the Fargodeep Mine"]="Prozkoumej Fargodeep Mine"},
    [76]={["Scout through the Jasperlode Mine"]="Prozkoumej Jasperlode Mine"},
    [2561]={["Release Oben Rageclaw's spirit"]="Osvoboď ducha Oben Rageclaw"},
}
function A.TranslateQuestObjective(id,text,objectiveType)
    local en=A.Normalize(text)
    if not en or en=="" then return end
    local suffix=""
    if en:sub(-11)==" (Complete)" then en=en:sub(1,-12);suffix=" (Hotovo)" end
    if labels[en] then return labels[en]..suffix end
    if not A.Accessible(id) or type(id)~="number" or id<=0 then return end
    local result=A.TranslateQuest(id,"objectives",en) or (short[id] and short[id][en])
        or (A.TranslateExtraQuestObjective and A.TranslateExtraQuestObjective(id,en))
    if result then return result..suffix end
    local current,total,name=en:match("^(%d+)/(%d+) (.+) slain$")
    if not current then name,current,total=en:match("^(.+) slain: (%d+)/(%d+)$") end
    if current then
        name=(A.TranslateQuestTarget and A.TranslateQuestTarget(id,name)) or name
        return "Zabito: "..current.."/"..total.." "..name..suffix
    end
    current,total,name=en:match("^(%d+)/(%d+) (.+)$")
    if not current then name,current,total=en:match("^(.+): (%d+)/(%d+)$") end
    if current then
        name=(A.TranslateQuestTarget and A.TranslateQuestTarget(id,name)) or name
        local prefix=objectiveType=="item" and "Získáno: " or "Postup: "
        return prefix..current.."/"..total.." "..name..suffix
    end
    local target=A.TranslateQuestTarget and A.TranslateQuestTarget(id,en)
    if target then return target..suffix end
    -- A completed unknown objective retains its English wording.
    if suffix~="" then return en..suffix end
end
local function kind(id,text)
    if not C_QuestLog or not C_QuestLog.GetQuestObjectives then return end
    local ok,rows=pcall(C_QuestLog.GetQuestObjectives,id)
    if not ok or not A.Accessible(rows) or type(rows)~="table" then return end
    local en=A.Normalize(text)
    for _,row in ipairs(rows) do
        if A.Normalize(row.text)==en and A.Accessible(row.type) then return row.type end
    end
end
local function record(id,text)
    if not A.DB or not id or type(id)~="number" or id<=0 or #text>2000 then return end
    A.DB.questSamples=A.DB.questSamples or {}
    local row=A.DB.questSamples[id] or {};A.DB.questSamples[id]=row
    row.tracker=type(row.tracker)=="table" and row.tracker or {}
    local key=text:gsub("%d+","#")
    local count=0;for _ in pairs(row.tracker) do count=count+1 end
    if row.tracker[key] or count<40 then row.tracker[key]=text end
end
local function watch(fs,getID)
    if not fs or watched[fs] then return end
    local state={};watched[fs]=state
    hooksecurefunc(fs,"SetText",function(self,text)
        if busy[self] then return end
        busy[self]=true
        local ok,err=pcall(function()
            text=self:GetText()
            if not A.Accessible(text) or type(text)~="string" then return end
            local id=getID()
            if not A.Accessible(id) then return end
            local cs
            if type(id)=="number" and id>0 then cs=A.TranslateQuestObjective(id,text,kind(id,text)) end
            if not cs then record(id,text) end
            if A.DB and A.DB.enabled==false then cs=nil end
            if cs then
                if not state.original then state.original=A.CaptureFont(self) end
                A.SetLocalizedFont(self,state.original,font,1) -- +1 from the saved native size; never from our previous output.
                state.changed=true
                self:SetText(cs)
            elseif state.changed then
                A.RestoreFont(self,state.original);state.changed=false
            end
        end)
        busy[self]=nil
        if not ok then A.NoteError('QuestTracker',err) end
    end)
end
local function watchBlock(block)
    if hooked[block] then return end
    hooked[block]=true
    if A.WatchQuestTitle then
        A.WatchQuestTitle(block.HeaderText,function()
            if block.parentModule==QuestObjectiveTracker then return block.id end
        end)
    end
    local function lines()
        for _,line in pairs(block.usedLines or {}) do
            watch(line.Text,function()
                local owner=line.parentBlock
                if owner and owner.parentModule==QuestObjectiveTracker then return owner.id end
            end)
        end
    end
    hooksecurefunc(block,"GetLine",lines)
    lines()
end
local function selectedID()
    if QuestInfoFrame and QuestInfoFrame.questLog then
        if C_QuestLog and C_QuestLog.GetSelectedQuest then return C_QuestLog.GetSelectedQuest() end
        if GetQuestLogSelectedID then return GetQuestLogSelectedID() end
    elseif GetQuestID then return GetQuestID() end
end
local function install()
    local tracker=QuestObjectiveTracker
    if tracker and tracker.GetBlock and not hooked[tracker] then
        hooked[tracker]=true
        local function blocks()
            for _,group in pairs(tracker.usedBlocks or {}) do
                for _,block in pairs(group) do watchBlock(block) end
            end
        end
        hooksecurefunc(tracker,"GetBlock",blocks);blocks()
    end
    local pool=QuestScrollFrame and QuestScrollFrame.objectiveFramePool
    if pool and not hooked[pool] then
        hooked[pool]=true
        local function rows()
            for row in pool:EnumerateActive() do
                watch(row.Text,function()return row.questID end)
            end
        end
        hooksecurefunc(pool,"Acquire",rows);rows()
    end
    local info=QuestInfoObjectivesFrame
    if info and not hooked[info] then
        hooked[info]=true
        for _,fs in ipairs(info.Objectives or {}) do watch(fs,selectedID) end
        hooksecurefunc(info,"CreateFontString",function(_,name)
            if type(name)=="string" and name:match("^QuestInfoObjective%d+$") then watch(_G[name],selectedID) end
        end)
    end
end
local frame=CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED");frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent",install)
install()
