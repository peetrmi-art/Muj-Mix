local _, A = ...
-- UI localization is presentation-only: no global string replacement, CVar writes,
-- setting values, bindings, callbacks or spell-name data are modified.
local dictionary, patterns = {}, {}
local function normalize(text)
    if not A.Accessible(text) or type(text)~="string" then return nil end
    return A.Normalize(text:gsub('\\n',' '):gsub('\\"','"'):gsub('|cn[%w_]+:', ''))
end
local function escape(s) return (s:gsub('([%(%)%.%%%+%-%*%?%[%]%^%$])','%%%1')) end
local function template(en,cs)
    -- A plural marker with identical branches has one rendered spelling.
    en=en:gsub('|4([^:;]+):([^;]+);',function(one,many)
        if one==many then return one end
        return '|4'..one..':'..many..';'
    end)
    if en=='%s' then return end -- A bare wildcard must not match unknown prose.
    -- Only printf formats actually present in the extracted UI dictionary.
    local parts,pos,n={"^"},1,0
    for first,token,last in en:gmatch('()(%%[%d%.]*[sdfiu])()') do
        -- A %% literal is not a placeholder.
        if first==1 or en:sub(first-1,first-1)~='%' then
            n=n+1; parts[#parts+1]=escape(en:sub(pos,first-1):gsub('%%%%','%%'))
            parts[#parts+1]=token:sub(-1)=='s' and '(.-)' or '([%+%-]?%d[%d%.,]*)';pos=last
        end
    end
    if n==0 then return end
    parts[#parts+1]=escape(en:sub(pos):gsub('%%%%','%%'))..'$'
    local index=0
    cs=cs:gsub('%%[%d%.]*[sdfiu]',function()index=index+1;return '{'..index..'}'end):gsub('%%%%','%%')
    local generic=en:find('%s',1,true) and not en:gsub('%%[%d%.]*[sdfiu]',''):find('%a')
    patterns[#patterns+1]={pattern=table.concat(parts),cs=cs,n=n,weight=#en-n*2,generic=generic}
end
for _,row in ipairs(A.UIEntries or {}) do
    local en=normalize(row[1]);dictionary[en]=row[2]
    template(en,row[2]:gsub('\\n','\n'):gsub('\\"','"'))
end
table.sort(patterns,function(a,b)return a.weight>b.weight end)
function A.TranslateUI(text, nested)
    local key=normalize(text);if not key or key=='' then return nil end
    local result=dictionary[key]
    if not result then
        for _,rule in ipairs(patterns) do
            local captures={key:match(rule.pattern)}
            if #captures==rule.n and (not rule.generic or dictionary[captures[1]]) then
                result=rule.cs:gsub('{(%d+)}',function(i)
                    local value=captures[tonumber(i)]
                    return (not nested and dictionary[value]) or value
                end)
                break
            end
        end
    end
    -- Graphics dropdown tooltips concatenate known option labels and explanations.
    -- Translate only verified segments, never individual words in unknown prose.
    if not result and not nested then
        local label,body=key:match('^([^:]+):%s*(.*)$')
        if label and dictionary[label] then
            local translated=body=='' and '' or A.TranslateUI(body,true)
            if translated then result=dictionary[label]..':'..(body~='' and ' '..translated or '') end
        end
    end
    if result then
        result=result:gsub('\\n','\n'):gsub('\\"','"')
        local color=text:match('^(|c%x%x%x%x%x%x%x%x)') or text:match('^(|cn[%w_]+:)')
        if color and text:sub(-2)=='|r' and not result:match('^|c') then result=color..result..'|r' end
    end
    return result
end
-- Presentation only: separate known option names from their explanations.
function A.FormatSettingsExplanation(cs, source)
    local original=A.Normalize(source)
    local label=original and original:match('^([^:]+):%s*')
    local translatedLabel=label and A.TranslateUI(label)
    local clean=A.Normalize(cs)
    if translatedLabel and clean then
        translatedLabel=A.Normalize(translatedLabel)
        local prefix=translatedLabel..':'
        if #translatedLabel<=90 and clean:sub(1,#prefix)==prefix then
            local body=clean:sub(#prefix+1):match('^%s*(.-)%s*$')
            if #body>20 then return '|cffffffff'..translatedLabel..'|r\n'..body end
        end
    end
    -- Long introductory paragraphs: retain every sentence and all numbers.
    -- Decimal points do not match this sentence boundary.
    if #cs>180 and not cs:find('|H',1,true) and not cs:find('\n',1,true) then
        return (cs:gsub('%. (%u)','.\n\n%1'))
    end
    return cs
end
local roots=setmetatable({}, {__mode='k'})
local frames=setmetatable({}, {__mode='k'})
local fonts=setmetatable({}, {__mode='k'})
local fixedRegions=setmetatable({}, {__mode='k'})
local busy=setmetatable({}, {__mode='k'})
local scrolls=setmetatable({}, {__mode='k'})
local dropdownMenus=setmetatable({}, {__mode='k'})
local dropdownFonts,dropdownFontCount={},0
local dialogs={GAME_SETTINGS_APPLY_DEFAULTS=true,GAME_SETTINGS_CONFIRM_DISCARD=true,GAME_SETTINGS_TIMED_CONFIRMATION=true,CONFIRM_RESET_TO_DEFAULT_KEYBINDINGS=true}
-- Static serif with Czech coverage, only for menu/settings labels.
local fontPath='Interface\\AddOns\\ForeverCestina\\Fonts\\ForeverSerif-Medium.ttf'
local function spellBook()
    return _G.PlayerSpellsFrame and PlayerSpellsFrame.SpellBookFrame or _G.SpellBookFrame
end
local function inBook(frame)
    local root=spellBook()
    for _=1,40 do
        if not frame then return false end
        if frame==root then return true end
        frame=frame.GetParent and frame:GetParent()
    end
    return false
end
local function allowed(frame, settingsOnly)
    local seen={}
    for _=1,40 do
        if not frame or seen[frame] then return false end;seen[frame]=true
        if frame==_G.SettingsPanel or frame==_G.GameMenuFrame then return true end
        if frame==spellBook() then return not settingsOnly end
        if roots[frame] then
            local scope=roots[frame]
            if scope==true then return true end
            return allowed(scope,settingsOnly)
        end
        if frame.GetParent then frame=frame:GetParent() else return false end
    end
    return false
end
function A.IsSettingsTooltip(tip)
    return tip==_G.SettingsTooltip or (tip.GetOwner and allowed(tip:GetOwner(),true))
end
-- Compositor menu FontStrings disallow SetFont; use addon-owned FontObjects.
-- Never change Blizzard's shared FontObjects or bypass compositor restrictions.
local function inDropdown(frame)
    for _=1,40 do
        if not frame then return false end
        if dropdownMenus[frame] then return true end
        frame=frame.GetParent and frame:GetParent()
    end
    return false
end
local function assignDropdownFont(font,object)
    local color=font.GetTextColor and {font:GetTextColor()}
    if color then
        for i=1,4 do
            if not A.PublicNumber(color[i]) then error("Barva položky nabídky není dostupná.") end
        end
    end
    font:SetFontObject(object)
    -- Selected/disabled/hover colors belong to the native menu item.
    if color then font:SetTextColor(unpack(color)) end
end
local function applyUIFont(font,old,delta)
    if not inDropdown(font) then return A.SetLocalizedFont(font,old.base,fontPath,delta) end
    if not old.menuBase then
        local original=font:GetFontObject()
        if not A.Accessible(original) or not original then error("Písmo položky nabídky není dostupné.") end
        old.menuBase=original
    end
    local variants=dropdownFonts[old.menuBase]
    if not variants then variants={};dropdownFonts[old.menuBase]=variants end
    local key=tostring(old.base.size+delta)..":"..(old.base.flags or "")
    local object=variants[key]
    if not object then
        dropdownFontCount=dropdownFontCount+1
        object=CreateFont("ForeverCestinaDropdownFont"..dropdownFontCount)
        object:CopyFontObject(old.menuBase)
        if object:SetFont(fontPath,old.base.size+delta,old.base.flags)==false then
            error("Schválené písmo nabídky nelze načíst.")
        end
        if old.base.spacing~=nil then object:SetSpacing(old.base.spacing) end
        variants[key]=object
    end
    assignDropdownFont(font,object)
    old.menuChanged=true
end
local function restoreUIFont(font,old)
    if old.menuChanged then
        assignDropdownFont(font,old.menuBase);old.menuChanged=nil
    else A.RestoreFont(font,old.base) end
end
local function updateFont(font)
    if busy[font] then return end
    busy[font]=true
    local ok,err=pcall(function()
        if not allowed(font) or (font.IsForbidden and font:IsForbidden()) then return end
        local old=fonts[font];if not old then return end
        local text=font:GetText()
        if not A.Accessible(text) or type(text)~='string' then old.en=nil;old.cs=nil;return end
        local parent=font.GetParent and font:GetParent()
        if inBook(font) and ((parent and parent.Name==font) or A.Names[A.Normalize(text)]) then return end
        if text~=old.cs and text~=old.en then old.en=text end
        local cs=(not A.DB or A.DB.enabled~=false) and A.TranslateUI(old.en) or nil
        local titleScope=roots[font]
        if titleScope==spellBook() and titleScope and titleScope.IsShown and not titleScope:IsShown() then cs=nil end
        if cs then
            if not old.base then old.base=A.CaptureFont(font) end
            applyUIFont(font,old,(inBook(font) or fixedRegions[font]) and 0 or 1)
            old.changed=true
            old.cs=cs -- A later post-hook may throw after the text was changed.
            if text~=cs then font:SetText(cs) end
        else
            if old.cs and text==old.cs then font:SetText(old.en) end
            if old.changed then restoreUIFont(font,old);old.changed=nil end
            old.cs=nil
        end
    end)
    busy[font]=nil
    if not ok then A.NoteError('UI',err) end
end
local function watchFont(font,oneShot)
    if not font.GetText or not font.SetText then return end
    local state=fonts[font]
    if not state then state={};fonts[font]=state end
    -- Menu rows are pooled and may later be reused by unrelated or protected UI.
    -- Translate them only for the current Settings menu; never leave addon hooks
    -- attached to their FontStrings. A hook that survives pool reuse can turn a
    -- later Blizzard update into addon execution around secret values.
    if not oneShot then
        for _,method in ipairs({'SetText','SetFormattedText','SetFontObject'}) do
            local current=font[method]
            if current and state[method]~=current then
                hooksecurefunc(font,method,function()updateFont(font)end)
                state[method]=font[method]
            end
        end
    end
    updateFont(font)
end
function A.RegisterUILabel(font)
    roots[font]=true;fixedRegions[font]=true;watchFont(font)
end
local function namePlatePreview(frame)
    if not frame then return false end
    -- NamePlatePreviewTemplate embeds a real Blizzard nameplate UnitFrame. That
    -- frame can come from the same native pool used by world nameplates. Never
    -- attach localization hooks anywhere in this subtree; after the preview is
    -- hidden a reused frame may process secret health/aura values.
    if frame.GetPreviewText and frame.SetExplicitValues and frame.OnNamePlateInfoChanged then return true end
    local plate=frame.NamePlate
    if plate and plate.GetPreviewText and plate.SetExplicitValues and plate.OnNamePlateInfoChanged then return true end
    return false
end
local walk
walk=function(frame,depth)
    depth=depth or 0
    if not frame or depth>24 or (frame.IsForbidden and frame:IsForbidden()) then return end
    if namePlatePreview(frame) then return end
    -- Never edit user input (search fields, key capture or numeric input).
    if frame.GetObjectType and frame:GetObjectType()=='EditBox' then return end
    local dropdown=inDropdown(frame)
    -- Pooled dropdown frames must stay hook-free. A one-shot scan on menu open
    -- is enough and cannot follow the row into a later unrelated menu.
    if not dropdown and not frames[frame] then
        frames[frame]=true
        if frame.HookScript and (not frame.HasScript or frame:HasScript('OnShow')) then
            frame:HookScript('OnShow',function(self)if allowed(self) then walk(self) end end)
        end
        if frame.OpenMenu then
            hooksecurefunc(frame,'OpenMenu',function(self)
                if allowed(self) and self.menu then roots[self.menu]=self;dropdownMenus[self.menu]=true;walk(self.menu) end
            end)
        end
    end
    if frame.GetRegions then
        for _,region in ipairs({frame:GetRegions()}) do
            if region.GetObjectType and region:GetObjectType()=='FontString' then watchFont(region,dropdown) end
        end
    end
    if frame.GetFontString then local font=frame:GetFontString();if font then watchFont(font,dropdown) end end
    -- First initialization and reused/virtualized rows are handled synchronously.
    if not dropdown and frame.RegisterCallback and frame.GetView and not scrolls[frame] and ScrollBoxListMixin and ScrollBoxListMixin.Event then
        scrolls[frame]=true
        frame:RegisterCallback(ScrollBoxListMixin.Event.OnInitializedFrame,function(_,child)
            if allowed(frame) then walk(child) end
        end,A)
    end
    if frame.GetChildren then for _,child in ipairs({frame:GetChildren()}) do walk(child,depth+1) end end
end
A.RefreshUI=function()
    -- Names are dense even when the lazily loaded SettingsPanel is absent.
    for _,name in ipairs({'SettingsPanel','GameMenuFrame'}) do
        local root=_G[name];if root then A.SafeCall('UI refresh',walk,root) end
    end
    local book=spellBook()
    if book then
        A.SafeCall('Spellbook UI',walk,book)
        local instructions=book.SearchBox and book.SearchBox.Instructions
        if instructions then A.SafeCall('Spellbook search',watchFont,instructions) end
        local container=_G.PlayerSpellsFrame and PlayerSpellsFrame.TitleContainer
        local title=container and container.TitleText
        if title then roots[title]=book;fixedRegions[title]=true;A.SafeCall('Spellbook title',watchFont,title) end
    end
    for font in pairs(fixedRegions) do A.SafeCall('Quest UI refresh',updateFont,font) end
end
local searchTagged=setmetatable({}, {__mode='k'})
local function addSearchTags(panel)
    if not panel.GetAllCategories or not panel.GetLayout then return end
    local function category(cat)
        local layout=panel:GetLayout(cat)
        if layout and layout.IsVerticalLayout and layout:IsVerticalLayout() then
            for _,initializer in layout:EnumerateInitializers() do
                if not searchTagged[initializer] and initializer.GetName and initializer.AddSearchTags then
                    local cs=A.TranslateUI(initializer:GetName())
                    if cs then initializer:AddSearchTags(cs) end
                    searchTagged[initializer]=true
                end
            end
        end
    end
    for _,cat in ipairs(panel:GetAllCategories()) do
        category(cat)
        if cat.GetSubcategories then for _,sub in pairs(cat:GetSubcategories()) do category(sub) end end
    end
end
local searchHooked,menuHooked,popupHooked
function A.HookUI()
    A.RefreshUI()
    if _G.SettingsPanel and not searchHooked then
        searchHooked=true
        SettingsPanel:HookScript('OnShow',function(self)addSearchTags(self) end)
    end
    if EventRegistry and not menuHooked then
        menuHooked=true
        EventRegistry:RegisterCallback('MenuProxy.OnShow',function(_,menu)
            local owner=menu.GetOwnerRegion and menu:GetOwnerRegion()
            roots[menu]=nil;dropdownMenus[menu]=nil -- Pooled menus must not retain an old settings scope.
            if allowed(owner) then
                roots[menu]=owner;dropdownMenus[menu]=true;walk(menu)
                -- Some compositor rows receive their final text after MenuProxy.OnShow.
                -- Rescan once without installing hooks; never poll.
                if C_Timer and C_Timer.After then C_Timer.After(0,function()
                    if roots[menu]==owner and dropdownMenus[menu] and allowed(owner) then walk(menu) end
                end) end
            end
        end,A)
    end
    if StaticPopup_Show and not popupHooked then
        popupHooked=true
        hooksecurefunc('StaticPopup_Show',function(which)
            for i=1,4 do
                local frame=_G['StaticPopup'..i]
                if frame then
                    roots[frame]=nil
                    if dialogs[frame.which] then roots[frame]=true;walk(frame) end
                end
            end
        end)
    end
end
local events=CreateFrame('Frame')
events:RegisterEvent('PLAYER_LOGIN');events:RegisterEvent('ADDON_LOADED')
events:SetScript('OnEvent',function()A.HookUI()end)
A.HookUI()


