local _, A = ...
-- Opt-in read-only catalog scan. SavedVariables persist on reload/normal exit.
-- API success is NOT a promise that full descriptions or hand-in dialog exist.
local running, generation, state, queue, cursor, pending = false,0,nil,{},1,{}
local timeoutStreak,delay=0,1
local function now() return GetTime() end
local function getState()
    if not A.DB then return end
    A.DB.questBulk=type(A.DB.questBulk)=="table" and A.DB.questBulk or {}
    local key=A.QuestCatalogBuild
    local s=A.DB.questBulk[key]
    if type(s)~="table" then s={results={},running=false};A.DB.questBulk[key]=s end
    s.build=key;s.total=#A.QuestCatalogIDs
    return s
end
local function counts(s)
    local done,ok,unavailable,failed=0,0,0,0
    for _,row in pairs(s.results) do
        if row.status=="ok" then ok=ok+1;done=done+1
        elseif row.status=="unavailable" then unavailable=unavailable+1;done=done+1
        elseif (row.status=="timeout" or row.status=="error") and row.attempts>=2 then failed=failed+1;done=done+1 end
    end
    return done,ok,unavailable,failed
end
local function report(s)
    local done,ok,unavailable,failed=counts(s)
    print("ForeverCestina: prověřeno "..done.."/"..s.total..", odpověď OK "..ok..", nedostupné "..unavailable..", bez odpovědi/chyba "..failed..". "..(running and "Sběr běží." or s.finished and "Průchod dokončen." or "Sběr stojí."))
end
local function capture(id,row)
    if C_QuestLog.GetTitleForQuestID then
        local ok,title=pcall(C_QuestLog.GetTitleForQuestID,id)
        if ok and A.Accessible(title) and type(title)=="string" then row.title=title end
    end
    if C_QuestLog.GetQuestObjectives then
        local ok,objectives=pcall(C_QuestLog.GetQuestObjectives,id)
        if ok and A.Accessible(objectives) and type(objectives)=="table" then
            row.objectives={}
            for _,objective in ipairs(objectives) do
                if A.Accessible(objective.text) and type(objective.text)=="string" then row.objectives[#row.objectives+1]=objective.text end
            end
        end
    end
end
local function stop(reason)
    running=false;generation=generation+1
    if state then state.running=false;state.reason=reason end
end
local function start()
    if running then report(state);return end
    if not C_QuestLog or not C_QuestLog.RequestLoadQuestByID then print("ForeverCestina: klient neumí načítat questy podle ID.");return end
    if GetBuildInfo then
        local version,build=GetBuildInfo()
        if version.."."..build~=A.QuestCatalogBuild then print("ForeverCestina: katalog questů je pro jiný build. Nejdříve je třeba aktualizovat katalog.");return end
    end
    state=getState();if not state then return end
    queue={};cursor=1;pending={};timeoutStreak=0;delay=1
    for _,id in ipairs(A.QuestCatalogIDs) do
        local row=state.results[id]
        -- A request interrupted by reload is still owed a response.
        if row and row.status=="pending" then row.status="interrupted";row.attempts=math.max(0,(row.attempts or 1)-1) end
        if not row or (row.status~="ok" and row.status~="unavailable" and (row.attempts or 0)<2) then queue[#queue+1]=id end
    end
    if #queue==0 then state.finished=true;state.running=false;report(state);return end
    running=true;state.running=true;state.finished=false;state.reason=nil
    generation=generation+1;local run=generation
    print("ForeverCestina: automatický sběr spuštěn. Zbývá "..#queue.." ID. /fczscan status = stav, /fczscan pause = pozastavit. Průběh se zapíše na disk při /reload nebo běžném ukončení hry.")
    local function tick()
        if not running or generation~=run then return end
        local current=now()
        for id,deadline in pairs(pending) do
            if current>=deadline then
                pending[id]=nil;local row=state.results[id];row.status="timeout"
                if row.attempts<2 then queue[#queue+1]=id end
                timeoutStreak=timeoutStreak+1;delay=math.min(5,1+math.floor(timeoutStreak/4))
            end
        end
        if timeoutStreak>=20 then
            stop("no-responses");print("ForeverCestina: server opakovaně neodpovídá, sběr pozastaven. Dosavadní výsledky zůstávají zachované. Pokračování: /fczscan.");return
        end
        local outstanding=0;for _ in pairs(pending) do outstanding=outstanding+1 end
        if cursor>#queue and outstanding==0 then
            state.finished=true;stop("complete");report(state)
            print("ForeverCestina: hromadný průchod hotov. Normálně ukonči hru, aby se uložila cache; z ní vyexportujeme skutečné popisy. Počet OK není počet úplných překladových podkladů.");return
        end
        if outstanding<4 and cursor<=#queue and not (InCombatLockdown and InCombatLockdown()) then
            local id=queue[cursor];cursor=cursor+1
            local row=state.results[id] or {attempts=0};state.results[id]=row
            row.attempts=row.attempts+1;row.status="pending";pending[id]=current+8
            local ok=pcall(C_QuestLog.RequestLoadQuestByID,id)
            if not ok then
                pending[id]=nil;row.status="error"
                if row.attempts<2 then queue[#queue+1]=id end
                timeoutStreak=timeoutStreak+1;delay=math.min(5,1+math.floor(timeoutStreak/4))
            end
        end
        C_Timer.After(delay,tick)
    end
    tick()
end
SLASH_FOREVERQUESTSCAN1="/fczscan"
SlashCmdList.FOREVERQUESTSCAN=function(message)
    message=(message or ""):lower():match("^%s*(.-)%s*$")
    if message=="pause" or message=="stop" then
        state=state or getState();stop("user");print("ForeverCestina: sběr pozastaven. /fczscan pokračuje ze zachovaného postupu.")
    elseif message=="status" then local s=getState();if s then report(s) end
    elseif message=="" or message=="start" or message=="resume" then start()
    else print("ForeverCestina: /fczscan | /fczscan status | /fczscan pause") end
end
local frame=CreateFrame("Frame")
frame:RegisterEvent("QUEST_DATA_LOAD_RESULT");frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent",function(_,event,id,success)
    if event=="PLAYER_LOGIN" then
        local s=getState()
        if s and s.running then C_Timer.After(2,function()if s.running then start() end end) end
    elseif running and A.Accessible(id) and A.Accessible(success) and pending[id] then
        local row=state.results[id];pending[id]=nil
        row.status=success and "ok" or "unavailable"
        if success then capture(id,row) end
        timeoutStreak=0;delay=1
    end
end)
