-- Quest labels only: native quest IDs, APIs and secure data are never rewritten.
local _, A = ...
local font="Interface\\AddOns\\ForeverCestina\\Fonts\\ForeverSerif-Medium.ttf"
local watched, busy, hooked=setmetatable({},{__mode="k"}),setmetatable({},{__mode="k"}),setmetatable({},{__mode="k"})
function A.TranslateQuestTarget(id,text)
    if not A.PublicNumber(id) or not A.QuestEntries[id] then return end
    local clean=A.Normalize(text)
    if clean then return A.QuestTargetTranslations[clean:lower()] end
end
function A.TranslateQuestTitle(id,text)
    if not A.PublicNumber(id) or not A.Accessible(text) or type(text)~="string" then return end
    local entry=A.QuestEntries[id]
    local en=entry and entry.title
    local cs=en and A.QuestTitleTranslations[en]
    if not cs or cs==en then return end
    local clean=A.Normalize(text)
    if not clean or clean:sub(-#en)~=en then return end
    -- Permit only native level/party-count prefixes and decoration markup.
    local prefix=clean:sub(1,#clean-#en)
    if prefix:gsub("%[%d+%+?%]%s*",""):match("%S") then return end
    local pos=1
    while true do
        local first,last=text:find(en,pos,true)
        if not first then return end
        if A.Normalize(text:sub(last+1))=="" then
            return text:sub(1,first-1)..cs..text:sub(last+1)
        end
        pos=last+1
    end
end
function A.WatchQuestTitle(fs,getID)
    if not fs or watched[fs] then return end
    local state={};watched[fs]=state
    local function update()
        if busy[fs] then return end
        busy[fs]=true
        local ok,err=pcall(function()
            local text=fs:GetText()
            if not A.Accessible(text) or type(text)~="string" then return end
            local cs=(not A.DB or A.DB.enabled~=false) and A.TranslateQuestTitle(getID(),text)
            if cs then
                state.original=state.original or A.CaptureFont(fs)
                A.SetLocalizedFont(fs,state.original,font,1) -- +1 from the saved native size; never from our previous output.
                state.changed=true
                fs:SetText(cs)
            elseif state.changed then
                A.RestoreFont(fs,state.original);state.changed=false
            end
        end)
        busy[fs]=nil
        if not ok then A.NoteError("Quest title",err) end
    end
    hooksecurefunc(fs,"SetText",update)
    update()
end
local function selectedID()
    if QuestInfoFrame and QuestInfoFrame.questLog then
        if C_QuestLog and C_QuestLog.GetSelectedQuest then return C_QuestLog.GetSelectedQuest() end
        if GetQuestLogSelectedID then return GetQuestLogSelectedID() end
    elseif GetQuestID then return GetQuestID() end
end
local function install()
    A.WatchQuestTitle(_G.QuestInfoTitleHeader,selectedID)
    A.WatchQuestTitle(_G.QuestProgressTitleText,function() if GetQuestID then return GetQuestID() end end)
    local pool=QuestScrollFrame and QuestScrollFrame.titleFramePool
    if pool and not hooked[pool] then
        hooked[pool]=true
        local function rows()
            for row in pool:EnumerateActive() do A.WatchQuestTitle(row.Text,function()return row.questID end) end
        end
        hooksecurefunc(pool,"Acquire",rows);rows()
    end
end
local frame=CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED");frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent",function() A.SafeCall("Quest title hooks",install) end)
install()
