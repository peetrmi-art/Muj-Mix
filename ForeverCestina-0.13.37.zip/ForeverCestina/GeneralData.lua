-- General spellbook abilities; English DB2 1.60.1.69977 and supplied Shoot screenshot.
local _, A = ...
local rows = {
 {"Shoot", "Attack with an equipped wand.", "Útočí vybavenou hůlkou."},
 {"Shoot", "Shoots at an enemy, inflicting Physical damage.", "Vystřelí na nepřítele a způsobí fyzické poškození."},
 {"Shoot", "Fire at the target with a ranged weapon.", "Vystřelí na cíl vybavenou zbraní na dálku."},
 {"Shoot", "Requires Wands", "Vyžaduje hůlku"},
 {"Shoot", "Requires Guns", "Vyžaduje pušku"},
 {"Shoot", "Requires Bows", "Vyžaduje luk"},
 {"Shoot", "Requires Crossbows", "Vyžaduje kuši"},
 {"Auto Shot", "Automatically shoots the target until cancelled.", "Automaticky střílí na cíl až do zrušení."},
 {"Auto Shot", "Automatically shoots the target with your bow until cancelled.", "Automaticky střílí z luku na cíl až do zrušení."},
 {"Dodge", "Gives a chance to dodge enemy melee attacks.", "Umožňuje uhnout nepřátelským útokům na blízko."},
 {"Parry", "Gives a chance to parry enemy melee attacks.", "Umožňuje odrazit nepřátelské útoky na blízko."},
 {"Block", "Gives a chance to block enemy melee and ranged attacks.", "Umožňuje zablokovat nepřátelské útoky na blízko i na dálku."},
 {"Dual Wield", "Allows one-hand and off-hand weapons to be equipped in the off-hand.", "Umožňuje vybavit vedlejší ruku jednoruční zbraní nebo zbraní určenou do vedlejší ruky."},
}
for _, row in ipairs(rows) do
 local exists
 for _, old in ipairs(A.Rules) do if old.name==row[1] and old.en==row[2] then exists=true;break end end
 if not exists then A.Rules[#A.Rules+1]={name=row[1],en=row[2],cs=row[3]} end
end
for id,name in pairs({[5019]="Shoot",[75]="Auto Shot",[413446]="Auto Shot",[81]="Dodge",[107]="Block",[3127]="Parry",[674]="Dual Wield",[1300344]="Dual Wield"}) do
 if not A.SpellIDs[id] then A.SpellIDs[id]=name end
end
