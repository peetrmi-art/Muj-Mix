local _, A = ...
local function weak() return setmetatable({}, {__mode="k"}) end
local states,busy,pending,hooked=weak(),weak(),weak(),weak()
local watched,dirty=weak(),weak()
local textLayout=weak()
local schedule -- Forward declaration for native FontString mutation hooks.
-- Font metrics survive a failed cleanup, but text never survives invalidation.
local bases,owned,identities=weak(),weak(),weak()
local methods={"SetSpellByID","SetSpellBookItem","SetTrainerService","SetAction","SetUnitAura","SetUnitBuff","SetUnitDebuff","SetHyperlink","SetTalent","RefreshData","RebuildFromTooltipInfo"}
A.TooltipFont="Interface\\AddOns\\ForeverCestina\\Fonts\\ForeverSerif-Medium.ttf"
A.SettingsTooltipFont="Interface\\AddOns\\ForeverCestina\\Fonts\\ForeverSerif-Medium.ttf"
A.TooltipFontSize=13
A.TooltipLineSpacingDelta=2
-- Keep a bounded history of public decisions, not spell text or hidden values.
-- The last combat failure survives a later successful out-of-combat refresh.
local auditDB,auditSession
local function publicFlag(fn)
    if type(fn)~="function" then return "unknown" end
    local ok,value=pcall(fn)
    if ok and A.Accessible(value) and type(value)=="boolean" then return value end
    return "unknown"
end
local function saveAudit(trace)
    if not A.DB then return end
    if auditDB~=A.DB then
        auditDB=A.DB
        local old=type(A.DB.tooltipAudit)=="table" and A.DB.tooltipAudit or {}
        auditSession=A.PublicNumber(old.session) and math.min(old.session+1,1000000) or 1
        -- Preserve one previous-session combat result for a normal reload.
        A.DB.tooltipAudit={session=auditSession,history={},previousCombat=old.lastCombatProblem or old.previousCombat}
    end
    local log=A.DB.tooltipAudit
    local row={version=A.Version,session=auditSession}
    local fields={"tooltip","title","mode","reason","detail","phase","combat","shift","lineCount",
        "titleReadable","unreadableLeft","unreadableRight","readErrors","writeFailures","translated","geometryAllowed",
        "source","sourceReadable","sourceRestricted","sourceTranslated","sourceHook","layout","layoutSkipped","sourceRows","fontMissing","nativeBounded"}
    local parts={}
    for _,key in ipairs(fields) do
        local value=trace[key]
        if A.Accessible(value) and (type(value)=="string" or type(value)=="boolean" or A.PublicNumber(value)) then
            if type(value)=="string" then value=value:sub(1,160) end
            row[key]=value;parts[#parts+1]=key.."="..tostring(value)
        end
    end
    local signature=table.concat(parts,"|")
    local previous=log.last
    if previous and log.signature==signature then
        previous.repeats=math.min((previous.repeats or 1)+1,1000000)
        row=previous
    else
        row.repeats=1
        if GetTime then
            local ok,time=pcall(GetTime)
            if ok and A.PublicNumber(time) then row.time=time end
        end
        log.history[#log.history+1]=row
        if #log.history>32 then table.remove(log.history,1) end
        log.last=row;log.signature=signature
    end
    if row.combat==true then
        log.lastCombat=row
        if row.reason~="ok" and row.reason~="unknown" then log.lastCombatProblem=row end
    end
    -- A fully restricted tooltip is itself useful evidence, even without a title.
    if row.reason~="ok" and row.reason~="unknown" then log.lastProblem=row end
end
local function status(trace,mode,reason,translated,detail)
    trace.mode,trace.reason,trace.translated=mode,reason,translated or 0
    if detail then trace.detail=detail end
    A.Diagnostics.tooltip=trace
    if reason=="restricted_text" or reason=="geometry" or reason=="error" then A.Diagnostics.lastLimited=trace end
end
local function readText(font)
    if not font or not font.GetText then return nil,true end
    local ok,text=pcall(font.GetText,font)
    if not ok then A.NoteError('Tooltip read',text);return nil,false,'error' end
    if not A.Accessible(text) then return nil,false,'secret' end
    if text~=nil and type(text)~="string" then return nil,false,'invalid' end
    return text,true
end
local function geometry(method,...)
    if not A[method] then return false end
    local ok,result=A.SafeCall(method,A[method],...)
    return ok and result~=false
end
local function restoreBase(font)
    local base=bases[font];if not base then return end
    -- Font metrics are public independently of the displayed text. A secret
    -- text must not prevent releasing our font when the pooled row is cleared.
    local now=A.CaptureFont(font)
    local ours=(now.path==A.TooltipFont or now.path==A.SettingsTooltipFont)
        and now.size==A.TooltipFontSize
    if ours or (now.path==base.path and now.size==base.size) then A.RestoreFont(font,base) end
    bases[font]=nil
end
local function original(font,state,trace,side)
    if not font or not font.GetText then return nil,true end
    local text,ok,why=readText(font)
    if not ok then
        state[font]=nil -- No cached text is a substitute for the current value.
        if trace then
            local key=side=="right" and "unreadableRight" or "unreadableLeft"
            trace[key]=(trace[key] or 0)+1
            if why=="error" then trace.readErrors=(trace.readErrors or 0)+1 end
            trace.detail=trace.detail or ((side or "row").."_"..why)
        end
        return nil,false
    end
    if text==nil then state[font]=nil;return nil,true end -- Native empty row, not protected data.
    if type(text)~="string" then state[font]=nil;return nil,false end
    local saved=state[font]
    if saved and (text==saved.cs or text==saved.en) then return saved.en,true end
    state[font]={en=text}
    return text,true
end
local function restoreRow(font,saved)
    local text=font:GetText()
    if not A.Accessible(text) then return end
    -- Never replace a new/unknown native value using a cached original.
    if saved and saved.cs~=nil and text==saved.cs then
        font:SetText(saved.en);saved.cs=nil;saved.joined=nil
    end
    restoreBase(font)
end
local function restoreText(state)
    for font,saved in pairs(state) do A.SafeCall('Tooltip text restore',restoreRow,font,saved) end
end
local function restoreFonts(tip)
    for font in pairs(owned[tip] or {}) do A.SafeCall('Tooltip font restore',restoreBase,font) end
end
local function put(tip,font,cs,state,fontPath,joined)
    local saved=font and state[font]
    if states[tip]~=state or not saved or cs==nil then error("Tooltip byl mezitím obnoven.") end
    local text=font:GetText()
    if not A.Accessible(text) or (text~=saved.en and text~=saved.cs) then
        state[font]=nil;error("Aktuální řádek tooltipu již není dostupný.")
    end
    if not bases[font] then bases[font]=A.CaptureFont(font) end
    owned[tip]=owned[tip] or weak();owned[tip][font]=true
    A.SetLocalizedFont(font,bases[font],fontPath,A.TooltipFontSize-bases[font].size,A.TooltipLineSpacingDelta)
    -- Set the ownership marker first: another post-hook can throw after SetText.
    saved.cs=cs;saved.joined=joined or nil
    if text~=cs then font:SetText(cs) end
    -- Wrapping/anchors belong exclusively to the optional geometry phase.
end
local function applyGroup(tip,fonts,values,state,fontPath,trace)
    if textLayout[tip]==false then
        for i,font in ipairs(fonts) do
            local base=bases[font]
            if not base then
                local ok,v=pcall(A.CaptureFont,font);if ok then base=v end
            end
            if not A.TooltipTextFits or not A.TooltipTextFits(font,values[i],base,fontPath) then
                if trace then trace.layoutSkipped=(trace.layoutSkipped or 0)+1 end
                for _,f in ipairs(fonts) do A.SafeCall('Tooltip unsafe row restore',restoreRow,f,state[f]) end
                return false
            end
        end
    end
    local ok,err=pcall(function()
        for i,font in ipairs(fonts) do put(tip,font,values[i],state,fontPath,#fonts>1) end
    end)
    if not ok then
        A.NoteError('Tooltip text',err)
        if trace then trace.writeFailures=(trace.writeFailures or 0)+1;trace.detail='write_rejected' end
        for _,font in ipairs(fonts) do A.SafeCall('Tooltip rollback',restoreRow,font,state[font]) end
    end
    return ok
end
local function undoJoined(state)
    for font,saved in pairs(state) do
        if saved.joined then A.SafeCall('Tooltip joined restore',restoreRow,font,saved) end
    end
end
local function watchFont(tip,font)
    if not font or watched[font] then return end
    if font.IsForbidden then
        local ok,value=pcall(font.IsForbidden,font)
        if not ok or not A.Accessible(value) or value then return end
    end
    watched[font]=true
    for _,method in ipairs({"SetText","SetFormattedText"}) do
        if type(font[method])=="function" then
            A.SafeCall('Tooltip text hook',hooksecurefunc,font,method,function()
                -- A Lua/native writer can replace a visible line without Show,
                -- a spell setter or TooltipDataProcessor post-call. Coalesce
                -- until the writer has finished; never translate half a write.
                if not busy[tip] and not (A.TooltipInputWriting and A.TooltipInputWriting(tip)) then
                    if A.TooltipInputChanged then A.TooltipInputChanged(tip) end
                    dirty[tip]=true;schedule(tip)
                end
            end)
        end
    end
end
-- Input translation and legacy rendering share immutable baseline font metrics.
function A.RegisterTooltipInput(tip) states[tip]=states[tip] or {} end
A.ReleaseTooltipInputFont=restoreBase
function A.PrepareTooltipInputFont(tip,font)
    if not bases[font] then bases[font]=A.CaptureFont(font) end
    owned[tip]=owned[tip] or weak();owned[tip][font]=true
    A.SetLocalizedFont(font,bases[font],A.TooltipFont,A.TooltipFontSize-bases[font].size,A.TooltipLineSpacingDelta)
    watchFont(tip,font)
    return true
end
local function process(tip,trace)
    trace.phase='identity'
    if not tip.GetName or not tip.NumLines then status(trace,'original','unknown',0,'unsupported_tooltip');return end
    if tip.IsForbidden then
        local ok,value=pcall(tip.IsForbidden,tip)
        if not ok or not A.Accessible(value) or value then status(trace,'original','restricted_text',0,'forbidden_tooltip');return end
    end
    local globalName=tip:GetName()
    if not A.Accessible(globalName) or type(globalName)~="string" then status(trace,'original','restricted_text',0,'tooltip_name');return end
    trace.tooltip=globalName
    local restored=geometry('RestoreTooltipGeometry',tip)
    local countOK,count=pcall(tip.NumLines,tip)
    if not countOK then
        A.NoteError('Tooltip line count',count);status(trace,'original','error',0,'line_count_error');return
    end
    if not A.Accessible(count) then status(trace,'original','restricted_text',0,'line_count_secret');return end
    if not A.PublicNumber(count) or count<1 or count>500 or count%1~=0 then status(trace,'original','unknown',0,'line_count_invalid');return end
    trace.lineCount=count
    local state=states[tip] or {};states[tip]=state
    local titleFont=_G[globalName.."TextLeft1"]
    local title,titleOK,titleWhy=readText(titleFont)
    trace.titleReadable=titleOK and type(title)=="string"
    if titleOK and type(title)=="string" then
        local saved=titleFont and state[titleFont]
        if saved and title==saved.cs then title=saved.en end
        title=A.Normalize(title);trace.title=title
    else trace.detail='title_'..(titleWhy or 'empty');title=nil end
    if identities[tip]~=nil and identities[tip]~=title then
        -- No text cache crosses a title change, even without OnTooltipCleared.
        restoreFonts(tip);state={};states[tip]=state
    end
    identities[tip]=title
    local left,right,texts,rightTexts={},{},{},{}
    local readable=true
    trace.phase='read_rows'
    for i=1,count do
        left[i],right[i]=_G[globalName.."TextLeft"..i],_G[globalName.."TextRight"..i]
        watchFont(tip,left[i]);watchFont(tip,right[i])
        local leftOK,rightOK
        texts[i],leftOK=original(left[i],state,trace,"left");rightTexts[i],rightOK=original(right[i],state,trace,"right")
        if not leftOK or not rightOK then readable=false end
    end
    -- This optional reporter scan must never veto the numbered spell rows.
    if tip.GetRegions then
        local seen={}
        for i=1,count do if left[i] then seen[left[i]]=true end;if right[i] then seen[right[i]]=true end end
        local ok,regions=pcall(function() return {tip:GetRegions()} end)
        if not ok then
            A.NoteError('Tooltip optional regions',regions)
            trace.readErrors=(trace.readErrors or 0)+1;trace.detail=trace.detail or 'regions_error'
            readable=false
        else
            for _,region in ipairs(regions) do
                if not seen[region] and region.GetObjectType and region.GetText then
                    local typeOK,kind=pcall(region.GetObjectType,region)
                    if typeOK and A.Accessible(kind) and kind=="FontString" then
                        local raw,readOK,why=readText(region)
                        local previous=state[region]
                        if readOK and previous and raw==previous.cs then raw=previous.en end
                        if readOK and A.Normalize(raw)=="Press F6 to submit an issue for this Spell" then
                            watchFont(tip,region)
                            count=count+1;left[count]=region;texts[count]=original(region,state,trace,"extra")
                        elseif not readOK then
                            state[region]=nil;readable=false
                            if why=='error' then trace.readErrors=(trace.readErrors or 0)+1 end
                            trace.detail=trace.detail or ('extra_'..why)
                        end
                    end
                end
            end
        end
    end
    local name=title and A.Names[title] and title or nil
    if not name and title then
        local stripped=title:gsub(" %(Rank %d+%)$","")
        if A.Names[stripped] then name=stripped end
    end
    -- A failed Settings owner query cannot veto a recognized spell.
    -- Preserve UI precedence for a public Settings tooltip with a spell-like title.
    local uiContext=tip==_G.SettingsTooltip
    if not uiContext and A.IsSettingsTooltip then
        local ok,value=pcall(A.IsSettingsTooltip,tip)
        if ok and A.Accessible(value) then uiContext=value==true
        else
            if not ok then A.NoteError('Tooltip UI context',value) end
            trace.detail=trace.detail or 'ui_context_unavailable'
        end
    end
    if not name and not uiContext then
        restoreText(state);restoreFonts(tip);geometry('RestoreTooltipGeometry',tip,true)
        status(trace,'original',title and 'unknown' or 'restricted_text');return
    end
    local enabled=not A.DB or A.DB.enabled~=false
    local showEnglish=trace.shift==true
    if not enabled or showEnglish then
        restoreText(state);restoreFonts(tip)
        status(trace,'original',not enabled and 'disabled' or 'shift');return
    end
    local fonts={}
    for i=1,count do if left[i] then fonts[#fonts+1]=left[i] end;if right[i] then fonts[#fonts+1]=right[i] end end
    trace.phase='translate'
    -- Data-driven spell tooltips keep native anchors and auto-height rows.
    -- Manual fallback geometry can otherwise survive a restricted combat clear.
    local nativeSpell=not uiContext and A.TooltipInputReady and A.TooltipInputReady()
    local layoutOK=not nativeSpell and restored and readable and geometry('SaveTooltipGeometry',tip,fonts)
    textLayout[tip]=not not layoutOK
    if not layoutOK then undoJoined(state) end
    local fontPath=uiContext and A.SettingsTooltipFont or A.TooltipFont
    local function translate(input,commonOnly)
        if uiContext then return A.TranslateUI(input) end
        return A.Translate(name,input,commonOnly)
    end
    local translated,footerSeen=0,false
    local footerRows={}
    for k=2,count do
        if left[k] and state[left[k]] then state[left[k]].footer=nil end
        if A.Normalize(texts[k])=="Press F6 to submit an issue for this Spell" then
            footerRows[k]=true
            local cs=footerSeen and "" or (layoutOK and "F6: nahlásit problém s tímto kouzlem" or "|cff40ccffF6: nahlásit problém s tímto kouzlem|r")
            if applyGroup(tip,{left[k]},{cs},state,fontPath,trace) then
                state[left[k]].footer=not footerSeen or nil;footerSeen=true
            end
            texts[k]="" -- Never join the reporter hint into a spell description.
        end
    end
    local i=uiContext and 1 or 2
    while i<=count do
        local input=texts[i]
        if input and input~="" then
            local result,last=translate(input),i
            -- Joining consumes native rows; only do it with a safe full layout.
            if not result and layoutOK then
                local combined=input
                for j=i+1,math.min(count,i+(name=="Metamorphosis" and 32 or 12)) do
                    if not texts[j] or footerRows[j] or (rightTexts[j] and rightTexts[j]~="") then break end
                    combined=combined.." "..texts[j]
                    local joined=translate(combined)
                    if joined then result,input,last=joined,combined,j;break end
                end
            end
            if not uiContext then A.Record(name,input,result) end
            if result then
                if uiContext and i>1 and A.FormatSettingsExplanation then result=A.FormatSettingsExplanation(result,input) end
                local group,values={left[i]},{result}
                for j=i+1,last do group[#group+1]=left[j];values[#values+1]="" end
                if applyGroup(tip,group,values,state,fontPath,trace) then
                    translated=translated+1;A.Stats.translated=A.Stats.translated+1;i=last
                end
            elseif #input>30 then A.Stats.unmatched=A.Stats.unmatched+1 end
        end
        i=i+1
    end
    for k=1,count do
        local input=rightTexts[k] -- Only the current, explicitly readable value.
        local result=input and translate(input,true)
        if result and applyGroup(tip,{right[k]},{result},state,fontPath,trace) then translated=translated+1 end
    end
    if tip.Show then A.SafeCall('Tooltip show',tip.Show,tip) end
    if layoutOK then
        layoutOK=geometry('LayoutTooltip',tip,left,right,state,count,uiContext and 420 or nil)
        if not layoutOK then
            -- A late layout rejection must not leave bigger Czech text inside
            -- the old fixed boxes. Roll back every still-owned readable row.
            restoreText(state);restoreFonts(tip);translated=0
            textLayout[tip]=false
            if tip.Show then A.SafeCall('Tooltip native show',tip.Show,tip) end
        end
    end
    trace.phase='complete';trace.geometryAllowed=not not layoutOK
    status(trace,translated>0 and (layoutOK and 'translated' or 'text_only') or 'original',
        (trace.writeFailures or 0)>0 and 'error' or ((trace.readErrors or 0)>0 and 'error' or
        (not readable and 'restricted_text' or (not layoutOK and 'geometry' or (translated>0 and 'ok' or 'unmatched')))),translated)
end
function A.ProcessTooltip(tip,data)
    if tip and A.HandleQuestTooltip then
        local ok,handled=A.SafeCall('Quest tooltip route',A.HandleQuestTooltip,tip)
        if ok and handled then return end
    end
    if not tip or busy[tip] or (A.TooltipInputBuilding and A.TooltipInputBuilding(tip)) then return end
    busy[tip]=true;dirty[tip]=nil
    local trace={combat=publicFlag(InCombatLockdown),shift=publicFlag(IsShiftKeyDown),sourceHook=A.TooltipInputReady and A.TooltipInputReady() or false}
    local ok,err=pcall(function()
        if A.ProcessTooltipInput and A.ProcessTooltipInput(tip,trace) then
            A.Diagnostics.tooltip=trace
            return
        end
        process(tip,trace)
    end)
    if not ok then
        A.NoteError('Tooltip process',err)
        restoreText(states[tip] or {})
        status(trace,'original','error',0,'unexpected_exception')
    end
    busy[tip]=nil
    -- Diagnostics are optional; their failure must not roll back translated text.
    A.SafeCall('Tooltip audit',saveAudit,trace)
end
local function clear(tip)
    pending[tip]=nil;dirty[tip]=nil
    if A.ForgetTooltipInput then A.ForgetTooltipInput(tip) end
    local wasBusy=busy[tip];busy[tip]=true
    states[tip]=nil;identities[tip]=nil
    -- Forget the source first; a rejected restoration cannot keep a stale text.
    geometry('RestoreTooltipGeometry',tip,true)
    restoreFonts(tip)
    owned[tip]=nil
    busy[tip]=wasBusy
end
local function refreshShown(tip,phase)
    if not tip.IsShown then return end
    local ok,shown=pcall(tip.IsShown,tip)
    if not ok or not A.Accessible(shown) then
        if not ok then A.NoteError('Tooltip visibility',shown) end
        local trace={phase=phase,combat=publicFlag(InCombatLockdown),shift=publicFlag(IsShiftKeyDown)}
        status(trace,'original',ok and 'restricted_text' or 'error',0,ok and 'visibility_secret' or 'visibility_error')
        A.SafeCall('Tooltip audit',saveAudit,trace)
        return
    end
    if shown==true then
        if phase=='refresh' and A.RebuildTooltipInput and A.RebuildTooltipInput(tip) then return end
        A.ProcessTooltip(tip)
    end
end
schedule=function(tip)
    if busy[tip] or pending[tip] or not C_Timer or not C_Timer.After then return end
    local token={};pending[tip]=token
    C_Timer.After(0,function()
        if pending[tip]~=token then return end
        pending[tip]=nil
        A.SafeCall('Tooltip deferred',function()
            refreshShown(tip,'deferred')
        end)
    end)
end
function A.RefreshTooltips()
    for tip in pairs(states) do
        A.SafeCall('Tooltip refresh',function()
            refreshShown(tip,'refresh')
        end)
    end
end
function A.HookTooltips()
    if A.HookTooltipInput then A.HookTooltipInput() end
    if TooltipDataProcessor and not A.processorHooked then
        TooltipDataProcessor.AddTooltipPostCall(TooltipDataProcessor.AllTypes,function(tip,data) A.ProcessTooltip(tip,data);schedule(tip) end)
        A.processorHooked=true
    end
    for _,key in ipairs({"GameTooltip","SettingsTooltip","ItemRefTooltip","ShoppingTooltip1","ShoppingTooltip2"}) do
        local tip=_G[key]
        if tip and not hooked[tip] then
            hooked[tip]=true
            for _,method in ipairs(methods) do
                if type(tip[method])=="function" then hooksecurefunc(tip,method,function() A.ProcessTooltip(tip);schedule(tip) end) end
            end
            -- ClearLines is the start of a new native content generation, not
            -- a reason to replay the previous tooltip's text or fixed heights.
            if type(tip.ClearLines)=="function" then
                hooksecurefunc(tip,'ClearLines',function() A.SafeCall('Tooltip clear lines',clear,tip) end)
            end
            for _,method in ipairs({"SetText","AddLine","AddDoubleLine"}) do
                if type(tip[method])=="function" then hooksecurefunc(tip,method,function() schedule(tip) end) end
            end
            -- Preserve synchronous completion: the native Show can resize again.
            if type(tip.Show)=="function" then hooksecurefunc(tip,'Show',function() A.ProcessTooltip(tip) end) end
            if tip.HookScript and (not tip.HasScript or tip:HasScript('OnUpdate')) then
                tip:HookScript('OnUpdate',function()
                    -- Constant-time dirty check, NOT a periodic tooltip scan.
                    -- Runs after the native update; the queued callback is a
                    -- fallback for writers outside the tooltip's OnUpdate.
                    if dirty[tip] and not busy[tip] then A.ProcessTooltip(tip) end
                end)
            end
            if tip.HookScript and (not tip.HasScript or tip:HasScript('OnTooltipCleared')) then
                tip:HookScript('OnTooltipCleared',function() A.SafeCall('Tooltip clear',clear,tip) end)
            end
        end
    end
end
local frame=CreateFrame('Frame')
for _,event in ipairs({'PLAYER_LOGIN','ADDON_LOADED','MODIFIER_STATE_CHANGED','PLAYER_REGEN_ENABLED','PLAYER_ENTERING_WORLD'}) do frame:RegisterEvent(event) end
frame:SetScript('OnEvent',function(_,event)
    if event=='PLAYER_LOGIN' or event=='ADDON_LOADED' then A.SafeCall('Tooltip hooks',A.HookTooltips)
    else A.RefreshTooltips() end
end)
A.HookTooltips()
