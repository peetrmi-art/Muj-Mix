-- Compatibility data for WoW Forever 1.60.1 build 70009 (25 Sep 2026).
-- Only exact, verified text variants are added here. Names stay English.
local _, A = ...

local function R(name, en, cs)
    table.insert(A.Rules, {name=name, en=en, cs=cs})
end

-- Druid: Mangle -> Primal Bite, Primal Fury -> Blood Frenzy.
R("Primal Bite",
  "Bite the target for {1}% normal damage plus {2}.",
  "Kousne cíl za {1} % běžného poškození plus {2}.")
R("Ferocity",
  "Reduces the cost of your Maul, Primal Bite, Swipe, Claw, and Rake abilities by {1} Rage or Energy.",
  "Snižuje cenu Maul, Primal Bite, Swipe, Claw a Rake o {1} zuřivosti nebo energie.")
R("Blood Frenzy",
  "Gives you a {1}% chance to gain an additional {2} Rage any time you get a critical strike while in Bear Form or Dire Bear Form. In addition, your non-periodic critical strikes from Cat Form abilities that generate Combo Points have a {3}% chance to add an additional Combo Point.",
  "Kritický zásah v Bear Form nebo Dire Bear Form má {1}% šanci přidat {2} zuřivosti. Neperiodický kritický zásah schopností v Cat Form, která vytváří kombinované body, má {3}% šanci přidat další kombinovaný bod.")
R("Berserk",
  "Causes your Primal Bite ability to strike up to {1} targets, removes its cooldown, and increases the critical strike chance of your Combo Point-generating abilities by {2}%. Clears and grants immunity to Fear effects for the duration. Lasts {3} sec.",
  "Primal Bite zasáhne až {1} cílů a nemá dobu obnovy. Šance na kritický zásah schopností vytvářejících kombinované body se zvýší o {2} %. Odstraní strach a po dobu účinku poskytuje imunitu vůči strachu. Trvá {3} s.")
R("Berserk",
  "Combo Point generating abilities gain {1}% increased critical strike chance. Primal Bite hits up to {2} targets and has no cooldown. Immune to Fear effects.",
  "Zvyšuje šanci na kritický zásah schopností vytvářejících kombinované body o {1} %. Primal Bite zasáhne až {2} cílů a nemá dobu obnovy. Imunita vůči strachu.")
A.SpellIDs[16958] = "Blood Frenzy"
A.SpellIDs[16959] = "Blood Frenzy"
A.SpellIDs[1238069] = "Primal Bite"
A.SpellIDs[1238070] = "Primal Bite"
A.SpellIDs[1238073] = "Primal Bite"
A.SpellIDs[407995] = "Primal Bite"

-- Hunter: Strider Kick gained a movement-speed component.
R("Strider Kick",
  "A powerful kick that deals {1}% melee weapon damage and increases movement speed by {2}% for {3} sec.",
  "Silný kop, který způsobí {1} % poškození zbraně na blízko a na {3} s zvýší rychlost pohybu o {2} %.")

-- Paladin: changed talent wording and reorganized Light's Vigil tooltip.
R("Light's Vigil",
  "Applies Light's Vigil to the target for {1} sec. Your next Holy Shock cast on them triggers no cooldown and causes enemy targets to suffer {2} Holy damage and refund {3}% of Light's Vigil's Mana cost, or allied targets to heal their party for {4}. The Paladin may only have one Light's Vigil active per party.",
  "Na {1} s označí cíl účinkem Light's Vigil. Tvůj příští Holy Shock seslaný na tento cíl nespustí dobu obnovy. Je-li cílem nepřítel, utrpí {2} svatého poškození a vrátí se ti {3} % ceny many Light's Vigil; je-li cílem spojenec, obnoví jeho skupině {4} zdraví. Paladin může mít v jedné skupině aktivní pouze jeden Light's Vigil.")
R("Holy Power",
  "Increases the critical strike chance of your Holy Shock and Holy Strike spells by {1}%, and all other spells by {2}%.",
  "Zvyšuje šanci na kritický účinek Holy Shock a Holy Strike o {1} % a všech ostatních kouzel o {2} %.")
R("Holy Power",
  "Increases the critical strike chance of your Holy Shock spell and Holy Strike spells by {1}%, and all other spells by {2}%.",
  "Zvyšuje šanci na kritický účinek Holy Shock a Holy Strike o {1} % a všech ostatních kouzel o {2} %.")
R("Twist of Light",
  "Reduces the Mana cost of your Seal spells by {1}%, and when you replace your Seal of Command, Seal of Righteousness, Seal of Fury, or Seal of Justice with a different Seal, gain an Echo of that Seal. Your next melee attack applies the replaced Seal's effects, consuming the Echo.",
  "Snižuje cenu many tvých Seal kouzel o {1} %. Když vyměníš Seal of Command, Seal of Righteousness, Seal of Fury nebo Seal of Justice za jinou pečeť, získáš Echo této pečeti. Tvůj příští útok na blízko použije i účinek nahrazené pečeti a Echo spotřebuje.")
R("Vengeance",
  "Increases your Physical and Holy damage dealt by {1}% for {2} sec after landing a non-periodic critical strike. Stacks up to {3} times.",
  "Po neperiodickém kritickém zásahu zvyšuje tvé fyzické a svaté poškození o {1} % na {2} s. Účinek se může nasčítat až {3}krát.")

-- Priest: Dark Sacrifice Mana now explicitly scales with Spirit.
R("Dark Sacrifice",
  "Cannibalize {1} of your own Health over {2} sec to gain ({1} + Spirit) Mana.",
  "Během {2} s obětuješ celkem {1} vlastního zdraví a získáš ({1} + Spirit) many.")

-- Shaman: buff-name changes and revised Rage of the Farseer wording.
R("Flametongue Totem",
  "Main hand attacks deal an additional {1} to {2} Fire damage.",
  "Zásahy zbraní v hlavní ruce způsobují navíc {1} až {2} ohnivého poškození.")
R("Flametongue Totem",
  "Summons a Flametongue Totem with {1} health at the feet of the caster. The totem enchants all party members' main-hand weapons with fire if they are within {2} yards. Each hit causes {3} to {4} additional Fire damage, based on the speed of the weapon. Slower weapons cause more fire damage per swing.",
  "U tvých nohou vyvolá Flametongue Totem s {1} zdraví. Posílí zbraně v hlavní ruce členů skupiny v okruhu {2} yardů: každý zásah způsobí navíc {3} až {4} ohnivého poškození podle rychlosti zbraně. Pomalejší zbraně způsobují více dodatečného poškození na zásah.")
R("Flametongue Totem",
  "Summons a Flametongue Totem with {1} health at the feet of the caster. The totem enhances the melee attacks of all party members within {2} yards. Each main hand hit causes {3} to {4} additional Fire damage, based on the speed of the weapon. Slower weapons cause more fire damage per swing.",
  "U tvých nohou vyvolá Flametongue Totem s {1} zdraví. Posílí útoky na blízko členů skupiny v okruhu {2} yardů: zásahy hlavní rukou způsobují navíc {3} až {4} ohnivého poškození podle rychlosti zbraně. Pomalejší zbraně způsobují více dodatečného poškození na zásah.")
R("Rage of the Farseer",
  "Increases your melee attack speed by {1}% for {2} sec.",
  "Na {2} s zvýší rychlost tvých útoků na blízko o {1} %.")
R("Rage of the Farseer",
  "Increases your attack speed by {1}% for {2} sec.",
  "Na {2} s zvýší rychlost tvých útoků o {1} %.")
R("Rage of the Farseer",
  "Melee attack speed increased by {1}%.",
  "Rychlost útoků na blízko zvýšena o {1} %.")
R("Rage of the Farseer",
  "Attack speed increased by {1}%.",
  "Rychlost útoků zvýšena o {1} %.")
A.SpellIDs[8230] = "Flametongue Totem"
A.SpellIDs[8250] = "Flametongue Totem"
A.SpellIDs[10521] = "Flametongue Totem"
A.SpellIDs[15036] = "Flametongue Totem"
A.SpellIDs[8515] = "Windfury Totem"

-- Warlock: Life Tap tooltip was rewritten in build 70009. Keep exact safe variants.
R("Life Tap",
  "Converts {1} Health into {2} Mana for you. Spirit increases the amount converted.",
  "Přemění {1} zdraví na {2} many. Množství se zvyšuje podle tvého Spiritu.")
R("Life Tap",
  "Converts {1} health into {2} Mana for you. Spirit increases the amount converted.",
  "Přemění {1} zdraví na {2} many. Množství se zvyšuje podle tvého Spiritu.")
R("Life Tap",
  "Converts {1} Health into {2} Mana for you. Spirit increases the amount of Mana converted.",
  "Přemění {1} zdraví na {2} many. Spirit zvyšuje množství získané many.")
R("Life Tap",
  "Converts {1} health into {2} Mana for you. Spirit increases the amount of Mana converted.",
  "Přemění {1} zdraví na {2} many. Spirit zvyšuje množství získané many.")

-- Warrior: Bloodthrill and Improved Slam wording changed.
R("Bloodthrill",
  "Your Main Hand melee attacks against enemies afflicted by your Rend have a {1}% chance to allow the use of your Overpower ability on the target. Lasts {2} sec.",
  "Tvé útoky hlavní rukou na blízko proti nepřátelům zasaženým tvým Rend mají {1}% šanci zpřístupnit Overpower na daný cíl. Možnost trvá {2} s.")
R("Improved Slam",
  "Reduces the global cooldown and cast time of your Slam ability by {1} sec. In addition, Slam no longer interrupts or delays your melee swing time and Slam's cooldown is reduced by {2} sec.",
  "Zkracuje globální dobu obnovy i sesílání Slam o {1} s. Slam navíc už nepřerušuje ani neoddaluje časování běžných útoků na blízko a jeho doba obnovy se zkrátí o {2} s.")
R("Improved Slam",
  "Reduces the global cooldown and cast time of your Slam ability by {1} sec. In addition, Slam no longer interrupts or delays your melee swing time. Slam's cooldown is reduced by {2} sec.",
  "Zkracuje globální dobu obnovy i sesílání Slam o {1} s. Slam navíc už nepřerušuje ani neoddaluje časování běžných útoků na blízko a jeho doba obnovy se zkrátí o {2} s.")
