-- Original dialogue supplied in the user's screenshots, 2026-09-23.
local _, A = ...
A.GossipEntries = {
 {npc="Ailee Farheart",en="Hello, mage.",cs="Zdravím tě, mágu."},
 {npc="Windshaper Boro",en="The spirits of the wind may have left us, but the power of the elements is not entirely out of reach for those with the patience to seek them out.\n\nIf you are initiated in the ways of the shaman, I can help you grasp them.",cs="Duchové větru nás možná opustili, ale moc živlů není zcela mimo dosah těch, kteří mají dost trpělivosti ji hledat.\n\nPokud už znáš základy šamanského umění, mohu ti pomoci tuto moc ovládnout."},
 {npc="Falorne Fallwind",en="Greetings to you, fellow High Order initiate.",cs="Buď zdráv, nový členu Vysokého řádu."},
 {npc="Falorne Fallwind",en="May you tell me more about the state of Zephras Isle and the High Order?",cs="Můžeš mi říct více o situaci na ostrově Zephras a o Vysokém řádu?"},
 {npc="Falorne Fallwind",en="Zephras is in great danger. The elemental wind spirits that brought us here to Skywall so many thousands of years ago have abandoned us, leaving us vulnerable in this unstable realm. Our once-robust society spanned multiple island sanctuaries in our corner of Skywall, but now we are not even sure if any other shen'dorei remain outside of this small island.\n\nThings are dire, but the High Order is committed to rising to this challenge.",cs="Zephras je ve velkém nebezpečí. Živelní duchové větru, kteří nás před mnoha tisíci lety přivedli sem do Skywallu, nás opustili. V této nestálé říši jsme tak zůstali bez ochrany. Naše kdysi vzkvétající společnost obývala několik ostrovních útočišť v této části Skywallu. Dnes už ani nevíme, jestli mimo tento malý ostrov ještě nějací shen'dorei přežívají.\n\nSituace je zoufalá, ale Vysoký řád je odhodlán této hrozbě čelit."},
 {npc="Falorne Fallwind",en="What can you tell me about the status of the High Order?",cs="Co mi můžeš říct o současném stavu Vysokého řádu?"},
}
