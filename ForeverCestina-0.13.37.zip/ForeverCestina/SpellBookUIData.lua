-- Exact interface labels; spell names and editable search text stay original.
local _, A = ...
local rows = {
 {"Spellbook", "Kniha kouzel"}, {"Spell Book", "Kniha kouzel"},
 {"General", "Obecné"}, {"Search abilities, keywords", "Hledat schopnosti, klíčová slova"},
 {"Passive", "Pasivní"}, {"Racial", "Rasová schopnost"},
 {"Racial Passive", "Pasivní rasová"}, {"Page %d/%d", "Strana %d/%d"},
 {"Hide Passives", "Skrýt pasivní schopnosti"}, {"Show All Ranks", "Zobrazit všechny stupně"},
 {"Use Flyouts", "Seskupit schopnosti"}, {"Show Passive Abilities", "Zobrazit pasivní schopnosti"},
 {"Not On Action Bar", "Nejsou na lištách"}, {"Not on Action Bar", "Nejsou na lištách"},
 {"No Results", "Žádné výsledky"}, {"No results found", "Nic nenalezeno"},
 {"Rank %d", "Stupeň %d"}, {"Level %d", "Úroveň %d"},
 {"Requires Level %d", "Vyžaduje úroveň %d"},
}
for _,row in ipairs(rows) do A.UIEntries[#A.UIEntries+1]=row end
local questLabels={
 {"Accept","Přijmout"}, {"Decline","Odmítnout"}, {"Continue","Pokračovat"},
 {"Complete Quest","Odevzdat úkol"}, {"Goodbye","Na shledanou"},
 {"Description","Popis"}, {"Objectives","Cíle úkolu"}, {"Quest Objectives","Cíle úkolu"},
 {"Required Items","Požadované předměty"}, {"Required items:","Požadované předměty:"},
 {"You will receive:","Obdržíš:"}, {"You will also receive:","Dále obdržíš:"},
 {"Choose one of these rewards:","Vyber si jednu z odměn:"},
 {"You will be able to choose one of these rewards:","Budeš si moci vybrat jednu z odměn:"},
 {"You will learn:","Naučíš se:"}, {"Learn Spell","Naučit se kouzlo"},
 {"Suggested Players: %d","Doporučený počet hráčů: %d"},
}
for _,row in ipairs(questLabels) do A.UIEntries[#A.UIEntries+1]=row end
