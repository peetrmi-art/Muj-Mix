local _, A = ...
_G.ForeverCestina = A
A.Version = "0.13.36"
A.Names, A.ByName = {}, {}
A.Stats = { translated = 0, unmatched = 0 }
function A.Accessible(value)
    if issecretvalue and issecretvalue(value) then return false end
    return true
end
-- Diagnostics contain only ordinary error strings, never protected game values.
A.Diagnostics = {errors={}, totalErrors=0}
function A.NoteError(scope, err)
    local d=A.Diagnostics
    d.totalErrors=math.min(d.totalErrors+1,1000000)
    d.errors[scope]=math.min((d.errors[scope] or 0)+1,1000000)
    local message="Operace byla odmítnuta."
    if A.Accessible(err) and type(err)=="string" then message=err:sub(1,600) end
    d.lastError=scope..": "..message
    if A.DB then A.DB.lastError=d.lastError end
end
function A.SafeCall(scope, fn, ...)
    local ok, result=pcall(fn,...)
    if not ok then A.NoteError(scope,result) end
    return ok,result
end
function A.PublicNumber(value)
    return A.Accessible(value) and type(value)=="number" and value==value
        and value>-math.huge and value<math.huge
end
function A.CaptureFont(fs)
    if not fs.GetFont then error("Chybí čitelné údaje o písmu.") end
    local path,size,flags=fs:GetFont()
    local spacing=fs.GetSpacing and fs:GetSpacing()
    if not A.Accessible(path) or type(path)~="string" or not A.PublicNumber(size) or size<=0
        or not A.Accessible(flags) or (flags~=nil and type(flags)~="string")
        or not A.Accessible(spacing) or (spacing~=nil and not A.PublicNumber(spacing)) then
        error("Údaje o písmu nejsou dostupné.")
    end
    return {path=path,size=size,flags=flags,spacing=spacing}
end
function A.SetLocalizedFont(fs, base, path, sizeDelta, spacingDelta)
    if not base then error("Chybí původní metriky písma.") end
    if fs:SetFont(path,base.size+(sizeDelta or 0),base.flags)==false then
        error("Schválené písmo nelze načíst; původní text zůstává zachován.")
    end
    if spacingDelta and base.spacing~=nil and fs.SetSpacing then fs:SetSpacing(base.spacing+spacingDelta) end
end
function A.RestoreFont(fs, base)
    if not base then return end
    if fs:SetFont(base.path,base.size,base.flags)==false then error("Původní písmo nelze obnovit.") end
    if base.spacing~=nil and fs.SetSpacing then fs:SetSpacing(base.spacing) end
end
function A.Normalize(s)
    if not A.Accessible(s) or type(s) ~= "string" then return nil end
    -- The description API can retain plural-control markup that the tooltip renders.
    s = s:gsub("(%d[%d,%.]*) ([Cc]ombo) |4([^:;]+):([^;]+);", function(n, label, one, many)
        local value = tonumber((n:gsub(",", "")))
        return n.." "..label.." "..(value == 1 and one or many)
    end)
    s = s:gsub("(%d[%d,%.]*)%s+|4([^:;]+):([^;]+);", function(n, one, many)
        local value = tonumber((n:gsub(",", "")))
        return n.." "..(value == 1 and one or many)
    end)
    return (s:gsub("|n", " "):gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", ""):gsub("|H.-|h(.-)|h", "%1")
        :gsub("|T.-|t", ""):gsub("|A.-|a", ""):gsub("\194\160", " ")
        :gsub("\r", " "):gsub("\n", " "):gsub("%s+", " "):match("^%s*(.-)%s*$"))
end
local function escape(s) return (s:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1")) end
local units = {sec="s", secs="s", second="s", seconds="s", min="min", mins="min", minute="min", minutes="min", hr="h", hrs="h", hour="h", hours="h"}
function A.Compile(en, cs)
    en = A.Normalize(en)
    en = en:gsub("(%{(%d+)%}) (%a+)", function(token, index, unit)
        if units[unit] then
            local marker = "{u"..index.."}"
            local changed
            cs, changed = cs:gsub("%{"..index.."%} "..units[unit].."%f[%A]", token.." "..marker)
            if changed > 0 then return token.." "..marker end
        end
        return token.." "..unit
    end)
    local parts, order, pos = {"^"}, {}, 1
    for startAt, index, endAt in en:gmatch("()%{([u%d]+)%}()") do
        parts[#parts+1] = escape(en:sub(pos, startAt-1))
        parts[#parts+1] = "(.-)"
        order[#order+1] = tonumber(index) or index
        pos = endAt
    end
    parts[#parts+1] = escape(en:sub(pos)) .. "$"
    return {pattern=table.concat(parts), order=order, cs=cs, en=en}
end
local function numeric(s)
    local n = "[%+%-]?%d[%d,%.]*"
    return s:match("^"..n.."$") or s:match("^"..n.." to "..n.."$")
        or s:match("^"..n.." ?%- ?"..n.."$") or s:match("^"..n.." ?– ?"..n.."$")
end
function A.Apply(rule, input)
    local captures = {input:match(rule.pattern)}
    if #captures == 0 then return nil end
    if #rule.order == 0 then return rule.cs end
    local values = {}
    for i, index in ipairs(rule.order) do
        local v = captures[i]
        if not v then return nil end
        if type(index) == "string" then
            v = units[v]
            if not v then return nil end
        else
            if not numeric(v) then return nil end
            v = v:gsub(" to ", "–"):gsub(",", " "):gsub("%.", ",")
        end
        if values[index] and values[index] ~= v then return nil end
        values[index] = v
    end
    return (rule.cs:gsub("%{([u%d]+)%}", function(i) return values[tonumber(i) or i] end))
end
for _, r in ipairs(A.Rules) do
    A.Names[r.name] = true
    A.ByName[r.name] = A.ByName[r.name] or {}
    table.insert(A.ByName[r.name], A.Compile(r.en, r.cs))
end
for _, name in pairs(A.SpellIDs) do A.Names[name] = true end
A.Common = {}
local function C(en, cs) table.insert(A.Common, A.Compile(en, cs)) end
C("Instant", "Okamžité seslání")
C("Instant cast", "Okamžité seslání")
C("Passive", "Pasivní schopnost")
C("Talent", "Talent")
C("Racial", "Rasová schopnost")
C("Racial Passive", "Pasivní rasová schopnost")
C("Passive Specialization", "Pasivní specializace")
C("You haven't added this to your action bars", "Tuto schopnost zatím nemáš na liště")
-- Observed verbatim in the user's Fireball screenshot; only public current values.
C("Cooldown remaining: {1} sec", "Zbývající doba obnovy: {1} s")
C("Reagents: Symbol of Divinity", "Vyžaduje: Symbol of Divinity")
C("Reagents: Symbol of Kings", "Vyžaduje: Symbol of Kings")
C("Magic", "Magie")
C("Next rank:", "Další stupeň:")
C("Rank {1}", "Stupeň {1}")
C("Rank {1}/{2}", "Stupeň {1}/{2}")
C("{1} Mana", "{1} many")
C("All Mana", "Veškerá mana")
C("{1} Rage", "{1} zuřivosti")
C("{1} Energy", "{1} energie")
C("{1} Focus", "{1} soustředění (Focus)")
C("Requires Hunter", "Vyžaduje huntera")
C("Requires Mage", "Vyžaduje mága")
C("Requires Priest", "Vyžaduje priesta")
C("Requires Warlock", "Vyžaduje warlocka")
C("Requires Shaman", "Vyžaduje shamana")
C("Requires Druid", "Vyžaduje druida")
C("Requires {1} points in Balance Talents", "Vyžaduje {1} talentových bodů ve stromu Balance")
C("Requires {1} points in Feral Combat Talents", "Vyžaduje {1} talentových bodů ve stromu Feral Combat")
for _, form in ipairs({"Cat Form", "Bear Form", "Dire Bear Form", "Moonkin Form", "Bear Form, Dire Bear Form", "Cat Form, Bear Form, Dire Bear Form"}) do
    C("Requires "..form, "Vyžaduje "..form:gsub(", ", " nebo "))
end
C("Reuires Cat Form, Bear Form, Dire Bear Form", "Vyžaduje Cat Form nebo Bear Form nebo Dire Bear Form")
C("Reagents: Ankh", "Vyžaduje: Ankh")
C("Reagents: Fish Oil", "Vyžaduje: Fish Oil")
C("Reagents: Shiny Fish Scales", "Vyžaduje: Shiny Fish Scales")
C("Requires {1} points in Elemental Talents", "Vyžaduje {1} talentových bodů ve stromu Elemental")
C("Requires {1} points in Enhancement Talents", "Vyžaduje {1} talentových bodů ve stromu Enhancement")
C("Requires {1} points in Restoration Talents", "Vyžaduje {1} talentových bodů ve stromu Restoration")
C("{1} Health", "{1} zdraví")
C("Reagents: Soul Shard", "Vyžaduje: Soul Shard (střep duše)")
C("Reagents: Infernal Stone", "Vyžaduje: Infernal Stone")
C("Reagents: Demonic Figurine", "Vyžaduje: Demonic Figurine")
C("Requires {1} points in Affliction Talents", "Vyžaduje {1} talentových bodů ve stromu Affliction")
C("Requires {1} points in Demonology Talents", "Vyžaduje {1} talentových bodů ve stromu Demonology")
C("Requires {1} points in Destruction Talents", "Vyžaduje {1} talentových bodů ve stromu Destruction")
C("Reagents: Holy Candle", "Vyžaduje: Holy Candle")
C("Reagents: Sacred Candle", "Vyžaduje: Sacred Candle")
C("Requires {1} points in Discipline Talents", "Vyžaduje {1} talentových bodů ve stromu Discipline")
C("Requires {1} points in Shadow Talents", "Vyžaduje {1} talentových bodů ve stromu Shadow")
C("Reagents: Light Feather", "Vyžaduje: Light Feather")
C("Reagents: Rune of Teleportation", "Vyžaduje: Rune of Teleportation")
C("Reagents: Rune of Portals", "Vyžaduje: Rune of Portals")
C("Requires {1} points in Arcane Talents", "Vyžaduje {1} talentových bodů ve stromu Arcane")
C("Requires {1} points in Fire Talents", "Vyžaduje {1} talentových bodů ve stromu Fire")
C("Requires {1} points in Frost Talents", "Vyžaduje {1} talentových bodů ve stromu Frost")
C("Requires Ranged Weapon", "Vyžaduje zbraň na dálku")
C("Requires Pet", "Vyžaduje peta")
C("Channeled", "Usměrňované sesílání")
C("Requires {1} points in Beast Mastery Talents", "Vyžaduje {1} talentových bodů ve stromu Beast Mastery")
C("Requires {1} points in Marksmanship Talents", "Vyžaduje {1} talentových bodů ve stromu Marksmanship")
C("Requires {1} points in Survival Talents", "Vyžaduje {1} talentových bodů ve stromu Survival")
C("Requires Rogue", "Vyžaduje roguea")
C("Requires Stealth", "Vyžaduje skrytí (Stealth)")
C("Requires Dagger", "Vyžaduje dýku")
C("Requires Daggers", "Vyžaduje dýky")
C("Requires Combo Points", "Vyžaduje kombinované body")
C("Requires {1} Combo Points", "Vyžaduje kombinované body: {1}")
C("{1} Combo Point", "Kombinované body: {1}")
C("{1} Combo Points", "Kombinované body: {1}")
C("{1} combo point", "Kombinované body: {1}")
C("{1} combo points", "Kombinované body: {1}")
C("Requires {1} points in Assassination Talents", "Vyžaduje {1} talentových bodů ve stromu Assassination")
C("Requires {1} points in Combat Talents", "Vyžaduje {1} talentových bodů ve stromu Combat")
C("Requires {1} points in Subtlety Talents", "Vyžaduje {1} talentových bodů ve stromu Subtlety")
C("Next melee", "Příští útok na blízko")
C("Next Melee", "Příští útok na blízko")
C("Requires Warrior", "Vyžaduje warriora")
C("Requires {1} points in Arms Talents", "Vyžaduje {1} talentových bodů ve stromu Arms")
C("Requires {1} points in Fury Talents", "Vyžaduje {1} talentových bodů ve stromu Fury")
C("Requires Two-Handed Melee Weapon", "Vyžaduje obouruční zbraň na blízko")
C("Requires One-Handed Melee Weapon", "Vyžaduje jednoruční zbraň na blízko")
for _, stance in ipairs({"Battle Stance", "Defensive Stance", "Berserker Stance", "Battle Stance, Defensive Stance", "Battle Stance, Berserker Stance", "Defensive Stance, Berserker Stance"}) do
    C("Requires "..stance, "Vyžaduje postoj: "..stance:gsub(", ", " nebo "))
end
C("{1}% of base mana", "{1} % základní many")
C("{1}% of Base Mana", "{1} % základní many")
C("{1} - {2} yd range", "Dosah: {1}–{2} yardů")
C("{1} yd range", "Dosah: {1} yardů")
C("Enemy: {1} yd range", "Dosah na nepřítele: {1} yardů")
C("Friendly: {1} yd range", "Dosah na spojence: {1} yardů")
C("Enemy: {1} yd range Friendly: {2} yd range", "Dosah na nepřítele: {1} yardů\nDosah na spojence: {2} yardů")
C("Friendly: {1} yd range Enemy: {2} yd range", "Dosah na spojence: {1} yardů\nDosah na nepřítele: {2} yardů")
for _, tree in ipairs({"Holy", "Protection", "Retribution", "Arms", "Fury", "Assassination", "Combat", "Subtlety", "Beast Mastery", "Marksmanship", "Survival", "Arcane", "Fire", "Frost", "Discipline", "Shadow", "Affliction", "Demonology", "Destruction", "Elemental", "Enhancement", "Restoration", "Balance", "Feral Combat"}) do
    C("Spend {1} more points in "..tree.." Talents", "Nejprve rozděl dalších {1} talentových bodů ve stromu "..tree)
    C("Spend {1} more point in "..tree.." Talents", "Nejprve rozděl další {1} talentový bod ve stromu "..tree)
end
C("Melee Range", "Dosah na blízko")
C("Melee range", "Dosah na blízko")
C("Unlimited range", "Neomezený dosah")
C("{1} sec cast", "Sesílání: {1} s")
C("{1} sec cooldown", "Doba obnovy: {1} s")
C("{1} min cooldown", "Doba obnovy: {1} min")
C("{1} hour cooldown", "Doba obnovy: {1} h")
C("{1} sec remaining", "Zbývá {1} s")
C("{1} seconds remaining", "Zbývá {1} s")
C("{1} minutes remaining", "Zbývá {1} min")
C("{1} minute remaining", "Zbývá {1} min")
C("{1} hours remaining", "Zbývá {1} h")
C("{1} hour remaining", "Zbývá {1} h")
C("Requires Level {1}", "Vyžaduje úroveň {1}")
C("Requires level {1}", "Vyžaduje úroveň {1}")
C("Requires Paladin", "Vyžaduje paladina")
C("Requires Shields", "Vyžaduje vybavený štít")
C("Requires Shield", "Vyžaduje vybavený štít")
C("Requires Melee Weapon", "Vyžaduje zbraň na blízko")
C("Requires {1} points in Holy Talents", "Vyžaduje {1} talentových bodů ve stromu Holy")
C("Requires {1} points in Protection Talents", "Vyžaduje {1} talentových bodů ve stromu Protection")
C("Requires {1} points in Retribution Talents", "Vyžaduje {1} talentových bodů ve stromu Retribution")
C("Click to learn", "Kliknutím se naučíš")
C("Click to learn talent", "Kliknutím se naučíš talent")
C("Right-click to unlearn", "Pravým tlačítkem odebereš")
C("Press F6 to submit an issue for this Spell", "F6: nahlásit problém s tímto kouzlem")
C("{1} charges.", "Počet použití: {1}.")
local function translateList(name, input)
    local list = A.DynamicLists and A.DynamicLists[name]
    if not list or input:sub(1, #list.en) ~= list.en then return nil end
    local rest = input:sub(#list.en + 1):match("^%s*(.-)%s*$")
    local items, used = {}, {}
    while rest ~= "" do
        local found
        for _, item in ipairs(list.items) do
            if rest == item or rest:sub(1, #item + 1) == item.." " then
                if used[item] then return nil end
                used[item] = true
                items[#items+1] = item
                rest = rest:sub(#item + 1):match("^%s*(.-)%s*$")
                found = true
                break
            end
        end
        if not found then return nil end -- A changed/unknown list stays in English.
    end
    return list.cs .. (#items > 0 and "\n"..table.concat(items, "\n") or "")
end
function A.Translate(name, text, commonOnly)
    local s = A.Normalize(text)
    if not s or s == "" or not A.Names[name] then return nil end
    local prefix = ""
    if not commonOnly and s:sub(1, 5) == "Use: " then
        s, prefix = s:sub(6), "Použití: "
    end
    if not commonOnly then
        -- Astral Recall alone has a nonnumeric home-location placeholder.
        -- Require the entire known sentence; never relax numeric spell rules.
        if name == "Astral Recall" and A.HomeRecall then
            local h = A.HomeRecall
            if s:sub(1, #h.prefix) == h.prefix and s:sub(-#h.suffix) == h.suffix then
                local place = s:sub(#h.prefix + 1, -#h.suffix - 1)
                if #place > 0 and #place <= 200 and not place:find("[%c%$|{}]") and place:match("^%S.*%S$") then
                    return prefix..h.csPrefix..place..h.csSuffix
                end
            end
        end
        local listText = translateList(name, s)
        if listText then return prefix..listText end
        for _, rule in ipairs(A.ByName[name] or {}) do
            local result = A.Apply(rule, s)
            if result then return prefix..result end
        end
    end
    for _, rule in ipairs(A.Common) do
        local result = A.Apply(rule, s)
        if result then return prefix..result end
    end
    return nil
end
function A.Record(name, text, translated, origin)
    if not A.DB then return end
    local s = A.Normalize(text)
    if not s or #s < 30 or #s > 6000 or not A.Names[name] then return end
    local key = name .. ":" .. s:gsub("%d[%d,%.]*", "#")
    if not A.DB.samples[key] and A.DB.count >= 600 then return end
    if not A.DB.samples[key] then A.DB.count = A.DB.count + 1 end
    A.DB.samples[key] = {name=name, en=s, cs=translated, origin=origin or "tooltip"}
end


