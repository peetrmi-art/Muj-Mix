# Forever Quest Map

Minimalist world-map helper for WoW Forever 1.60.1.

## Filters
- Quest starts: bundled ATT-derived Forever quest database, filtered against character state where the client exposes it.
- Flight points: native WoW taxi API.
- Dungeon / raid entrances: native Encounter Journal API when available plus a bundled fallback list. The fallback includes verified beta entrances for the new Forever dungeons The Hall of Thanes and Ruins of Lordaeron; other new Forever dungeons are not given guessed coordinates and will appear automatically if the client API exposes them.
- Selected rare enemies: curated outdoor rare selection from ATT Forever data. It is intentionally NOT a complete rare database and uses one representative spawn per rare to reduce map clutter.

All extra filters are off by default, except quest starts. The rare button tooltip explicitly says `Nektere rare`.

Toolbar buttons are in the upper-right of the map. `- / +` changes all addon icon sizes from 40% to 130% (default 80%).

## Zone level hint
For outdoor questing zones, a small `Oblast LVL: X-Y` line appears directly below the toolbar. Classic-zone ranges use the original Classic recommended brackets, while Forever-specific ranges use published Forever 1.60.1 information. Cities, continents and zones without a confirmed useful range show no label. The hint is informational only and does not change quest filtering.

## Commands
`/fqm status`, `/fqm refresh`, `/fqm on`, `/fqm off`, `/fqm reset`

## Install
Delete the old `ForeverQuestMap` folder, then place this `ForeverQuestMap` folder in `Interface\AddOns\`. Restart WoW or `/reload`.

## Data attribution
See `THIRD_PARTY_NOTICES.txt`.

## Safety
v2.3.4 uses plain child frames over the map. It does not use WorldMapFrame:AcquirePin, RemoveAllPinsByTemplate or MapCanvasPinMixin. Native APIs are capability-checked and called through protected calls where applicable.

## 2.2.0
- Expanded the `Nektere rare` filter from only world bosses to a curated outdoor selection across many Classic/Forever zones.
- Added verified beta entrance points for The Hall of Thanes and Ruins of Lordaeron.
- Kept the native dungeon entrance API fallback so future/new Forever entrances can appear automatically when the client exposes them.
- Did not add guessed coordinates for unreleased/unverified new Forever dungeon entrances.
- Quest, flight and icon-size behavior is otherwise unchanged.

## 2.3.0
- Added a small `Oblast LVL: X-Y` hint below the toolbar for outdoor questing zones.
- City maps such as Stormwind, Ironforge, Orgrimmar, Thunder Bluff, Darnassus and Undercity intentionally show no zone-level range.
- Added published Forever ranges for Zephras Isle (1-12), Riverglades (35-45) and Mount Hyjal (60).
- No quest, flight, dungeon/raid, rare, icon-size or minimap logic was changed.


## 2.3.1
- Changed only the `Oblast LVL` text color from gold to neutral gray for better contrast over parchment maps.
- No quest, flight, dungeon/raid, rare, icon-size or minimap logic was changed.

## 2.3.2
- Restored the original gold `Oblast LVL` text color and strengthened its black drop shadow for better readability over parchment maps.
- No quest, flight, dungeon/raid, rare, icon-size or minimap logic was changed.


## 2.3.3
- Kept the gold `Oblast LVL` text and added a black font outline on top of the existing 100% black drop shadow for much stronger readability.
- No quest, flight, dungeon/raid, rare, icon-size or minimap logic was changed.
