local ADDON_NAME, ns = ...

-- Supplemental POI data for ForeverQuestMap.
-- Classic instance and rare coordinates are derived from the All The Things (ATT) Forever database
-- under the MIT license. See THIRD_PARTY_NOTICES.txt.
-- ATT source audited through commit cea7f798464860934d4438d9df5d2612ec2c79ca.
-- The Hall of Thanes (43.5, 52.0 Ironforge) and Ruins of Lordaeron (71.6, 11.4 Tirisfal)
-- use public 2026-09 beta entrance reports; no guessed coordinates are used for the other new Forever dungeons.

ns.InstanceByMap = {
    [33] = {
        { x=54.18, y=83.25, name="Molten Core", kind="Raid" },
        { x=64.2, y=71.0, name="Blackwing Lair", kind="Raid" },
    },
    [35] = {
        { x=39.06, y=18.12, name="Blackrock Depths", kind="Dungeon" },
    },
    [1413] = {
        { x=45.9, y=35.7, name="Wailing Caverns", kind="Dungeon" },
        { x=40.94, y=94.55, name="Razorfen Kraul", kind="Dungeon" },
        { x=50.0, y=92.0, name="Razorfen Downs", kind="Dungeon" },
    },
    [1418] = {
        { x=64.0, y=44.0, name="Uldaman", kind="Dungeon" },
    },
    [1420] = {
        { x=82.6, y=32.4, name="Scarlet Monastery", kind="Dungeon" },
        { x=71.6, y=11.4, name="Ruins of Lordaeron", kind="Forever Dungeon" },
    },
    [1421] = {
        { x=36.6, y=65.6, name="Shadowfang Keep", kind="Dungeon" },
    },
    [1422] = {
        { x=69.07, y=72.96, name="Scholomance", kind="Dungeon" },
    },
    [1423] = {
        { x=30.9, y=16.6, name="Stratholme - Main Gate", kind="Dungeon" },
        { x=48.18, y=21.9, name="Stratholme - Service Entrance", kind="Dungeon" },
        { x=81.8, y=58.1, name="Naxxramas", kind="Raid" },
    },
    [1426] = {
        { x=18.4, y=38.6, name="Gnomeregan", kind="Dungeon" },
    },
    [1435] = {
        { x=69.2, y=54.8, name="The Temple of Atal'Hakkar", kind="Dungeon" },
    },
    [1436] = {
        { x=42.2, y=82.6, name="Deadmines", kind="Dungeon" },
    },
    [1440] = {
        { x=16.5, y=11.0, name="Blackfathom Deeps", kind="Dungeon" },
    },
    [1443] = {
        { x=35.7, y=55.5, name="Maraudon", kind="Dungeon" },
    },
    [1444] = {
        { x=64.83, y=30.24, name="Dire Maul - East", kind="Dungeon" },
        { x=62.48, y=24.48, name="Dire Maul - North", kind="Dungeon" },
        { x=60.32, y=30.17, name="Dire Maul - West", kind="Dungeon" },
    },
    [1445] = {
        { x=52.3, y=76.2, name="Onyxia's Lair", kind="Raid" },
    },
    [1446] = {
        { x=39.0, y=19.0, name="Zul'Farrak", kind="Dungeon" },
    },
    [1453] = {
        { x=51.6, y=69.4, name="The Stockade", kind="Dungeon" },
    },
    [1454] = {
        { x=50.6, y=51.6, name="Ragefire Chasm", kind="Dungeon" },
    },
    [1455] = {
        { x=43.5, y=52.0, name="The Hall of Thanes", kind="Forever Dungeon" },
    },
}

-- Curated rare selection: one representative spawn point per rare to keep maps readable.
-- This is intentionally not a complete rare database. The filter tooltip says "Nektere rare".
ns.RareByMap = {
    [35] = {
        { x=36.2, y=36.2, name="Overmaster Pyron", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=9026 },
        { x=37.8, y=61.3, name="The Behemoth", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=8924 },
    },
    [1411] = {
        { x=38.8, y=46.2, name="Death Flayer", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5823 },
        { x=51.6, y=9.6, name="Felweaver Scornn", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5822 },
        { x=43.6, y=40.8, name="Geolord Mottle", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5826 },
        { x=46.6, y=79.8, name="Warlord Kolkanis", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5808 },
        { x=59.6, y=59.0, name="Watch Commander Zalaphil", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5809 },
    },
    [1412] = {
        { x=50.6, y=15.0, name="Ghost Howl", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=3056 },
        { x=34.8, y=42.2, name="Mazzranache", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=3068 },
        { x=50.6, y=26.6, name="The Rake", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5807 },
        { x=48.2, y=68.0, name="Snagglespear", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5786 },
    },
    [1413] = {
        { x=62.0, y=33.6, name="Humar the Pridelord", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5828 },
        { x=58.2, y=7.6, name="Takk the Leaper", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5842 },
        { x=60.6, y=30.4, name="Swiftmane", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5831 },
        { x=49.6, y=15.8, name="Dishu", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5865 },
        { x=41.8, y=20.4, name="Snort the Heckler", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5829 },
        { x=49.6, y=58.0, name="Brontus", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5827 },
        { x=52.0, y=54.0, name="Trigore the Lasher", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=3652 },
        { x=44.6, y=62.2, name="Azzere the Skyblade", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5834 },
        { x=58.6, y=26.8, name="Elder Mystic Razorsnout", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=3270 },
        { x=46.6, y=39.6, name="Gesharahan", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=3398 },
    },
    [1416] = {
        { x=31.2, y=71.0, name="Araga", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14222 },
        { x=14.2, y=54.2, name="Cranky Benj", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14223 },
        { x=48.0, y=34.2, name="Lo'Grosh", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=2453 },
        { x=79.2, y=47.0, name="Narillasanz", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=2447 },
        { x=30.6, y=59.4, name="Skhowl", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=2452 },
    },
    [1417] = {
        { x=29.8, y=60.2, name="Darbel Montrose", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=2598 },
        { x=19.4, y=64.0, name="Foulbelly", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=2601 },
        { x=21.6, y=82.8, name="Prince Nazjak", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=2779 },
        { x=66.0, y=60.2, name="Nimar the Slayer", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=2606 },
        { x=54.6, y=79.0, name="Molok the Crusher", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=2604 },
    },
    [1419] = {
        { x=36.6, y=75.8, name="Lord Kazzak", note="World boss", npcID=12397 },
    },
    [1425] = {
        { x=63.3, y=27.8, name="Dragons of Nightmare", note="World boss spawn" },
    },
    [1426] = {
        { x=52.8, y=58.4, name="Bjarn", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=1130 },
        { x=27.2, y=36.6, name="Gibblewilt", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=8503 },
        { x=71.8, y=51.4, name="Hammerspine", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=1119 },
        { x=38.4, y=54.0, name="Old Icebeard", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=1271 },
        { x=23.8, y=53.4, name="Great Father Arctikus", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=1260 },
    },
    [1429] = {
        { x=68.0, y=40.6, name="Fedfennel", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=472 },
        { x=61.8, y=47.8, name="Mother Fang", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=471 },
        { x=41.2, y=78.8, name="Narg the Taskmaster", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=79 },
        { x=31.8, y=65.6, name="Morgaine the Sly", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=99 },
    },
    [1431] = {
        { x=18.0, y=38.0, name="Commander Felstrom", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=771 },
        { x=59.8, y=26.8, name="Fenros", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=507 },
        { x=25.6, y=30.2, name="Lord Malathrom", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=503 },
        { x=20.0, y=25.4, name="Lupos", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=521 },
        { x=86.6, y=49.6, name="Naraxis", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=574 },
        { x=63.6, y=82.4, name="Nefaru", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=534 },
        { x=45.4, y=39.6, name="Dragons of Nightmare", note="World boss spawn" },
    },
    [1432] = {
        { x=68.4, y=66.0, name="Boss Galgosh", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=1398 },
        { x=65.0, y=21.0, name="Emogg the Crusher", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14267 },
        { x=62.8, y=78.2, name="Lord Condar", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14268 },
        { x=77.8, y=53.6, name="Shanda the Spinner", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14266 },
        { x=35.4, y=27.8, name="Grizlak", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=1425 },
    },
    [1433] = {
        { x=88.8, y=67.0, name="Boulderheart", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14273 },
        { x=51.2, y=37.2, name="Chatter", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=616 },
        { x=33.0, y=6.6, name="Kazon", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=584 },
        { x=16.2, y=60.6, name="Ribchaser", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14271 },
        { x=36.4, y=66.8, name="Snarlflare", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14272 },
    },
    [1434] = {
        { x=51.4, y=16.6, name="High Priestess Hai'watna", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=11383 },
        { x=31.8, y=68.2, name="Kurmokk", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14491 },
        { x=28.6, y=62.2, name="Lord Sakrasis", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=2541 },
        { x=24.2, y=58.0, name="Rippa", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14490 },
        { x=44.0, y=48.2, name="Scale Belly", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=1552 },
        { x=36.8, y=56.0, name="Verifonix", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14492 },
    },
    [1436] = {
        { x=26.2, y=65.6, name="Brack", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=520 },
        { x=38.6, y=51.6, name="Foe Reaper 4000", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=573 },
        { x=42.4, y=30.8, name="Leprithus", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=572 },
        { x=46.2, y=18.6, name="Master Digger", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=1424 },
        { x=37.6, y=32.8, name="Sergeant Brashclaw", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=506 },
        { x=56.0, y=9.8, name="Slark", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=519 },
        { x=51.8, y=24.6, name="Vultros", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=462 },
    },
    [1437] = {
        { x=42.8, y=43.8, name="Dragonmaw Battlemaster", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=1037 },
        { x=46.8, y=61.4, name="Leech Widow", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=1112 },
        { x=70.8, y=30.4, name="Razormaw Matriarch", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=1140 },
        { x=39.0, y=30.6, name="Gnawbone", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14425 },
        { x=18.6, y=28.4, name="Mirelow", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14424 },
        { x=47.8, y=76.8, name="Ma'ruk Wyrmscale", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=2090 },
    },
    [1438] = {
        { x=42.8, y=25.8, name="Blackmoss the Fetid", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=3535 },
        { x=51.2, y=77.8, name="Duskstalker", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14430 },
        { x=34.8, y=34.4, name="Fury Shelda", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14431 },
        { x=63.8, y=57.2, name="Uruson", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=14428 },
    },
    [1439] = {
        { x=39.6, y=54.0, name="Carnivous the Breaker", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=2186 },
        { x=39.2, y=35.4, name="Shadowclaw", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=2175 },
        { x=59.8, y=15.6, name="Lady Vespira", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=7016 },
        { x=55.0, y=35.4, name="Lord Sinslayer", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=7017 },
        { x=35.0, y=86.0, name="Strider Clutchmother", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=2172 },
    },
    [1440] = {
        { x=94.2, y=35.7, name="Dragons of Nightmare", note="World boss spawn" },
    },
    [1442] = {
        { x=28.2, y=12.8, name="Brother Ravenoak", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5915 },
        { x=45.2, y=39.2, name="Pridewing Patriarch", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=4015 },
        { x=64.8, y=49.2, name="Taskmaster Whipfang", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5932 },
        { x=36.8, y=68.8, name="Sister Riven", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5930 },
        { x=33.4, y=63.0, name="Vengeful Ancient", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=4030 },
    },
    [1444] = {
        { x=53.6, y=69.2, name="Antilus the Soarer", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5347 },
        { x=52.6, y=60.6, name="Bloodroar the Stalker", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5346 },
        { x=26.6, y=65.8, name="Lady Szallah", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5343 },
        { x=57.4, y=56.8, name="Old Grizzlegut", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5352 },
        { x=75.0, y=36.2, name="Snarler", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5356 },
        { x=71.8, y=63.4, name="Qirot", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=5350 },
        { x=51.2, y=10.9, name="Dragons of Nightmare", note="World boss spawn" },
    },
    [1447] = {
        { x=16.8, y=51.8, name="Antilos", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=6648 },
        { x=41.6, y=51.8, name="General Fangferror", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=6650 },
        { x=40.6, y=45.6, name="Lady Sesspira", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=6649 },
        { x=55.0, y=49.8, name="Scalebeard", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=13896 },
        { x=17.6, y=54.0, name="The Evalcharr", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=8660 },
        { x=13.4, y=74.8, name="Varo'then's Ghost", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=6118 },
        { x=82.0, y=18.6, name="Monnos the Elder", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=6646 },
        { x=53.3, y=80.4, name="Azuregos", note="World boss", npcID=6109 },
    },
    [1453] = {
        { x=49.8, y=22.6, name="Sewer Beast", note="Vybrany spawn; nekteri rare maji vice moznych lokaci.", npcID=3581 },
    },
}

local instanceCount, rareCount = 0, 0
for _, t in pairs(ns.InstanceByMap) do instanceCount = instanceCount + #t end
for _, t in pairs(ns.RareByMap) do rareCount = rareCount + #t end
ns.PoiDataMeta = {
    source = "ATTWoWAddon/AllTheThings + verified beta entrance reports",
    attCommit = "cea7f798464860934d4438d9df5d2612ec2c79ca",
    instanceFallbackCount = instanceCount,
    rarePointCount = rareCount,
}
