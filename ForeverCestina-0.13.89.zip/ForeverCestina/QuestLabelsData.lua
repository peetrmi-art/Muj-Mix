local _, A = ...
for _,row in ipairs({
 {"All Objectives","Všechny cíle"},
 {"You will receive:","Dostaneš:"},
 {"You will receive","Dostaneš"},
 {"You will be able to choose one of these rewards:","Vyber si jednu z těchto odměn:"},
 {"Required items:","Požadované předměty:"},
}) do A.UIEntries[#A.UIEntries+1]=row end

-- QUEST_GREETING headings and the already-watched reward XP label.
for _,row in ipairs({
 {"Current Quests","Aktuální úkoly"},
 {"Available Quests","Dostupné úkoly"},
 {"Experience:","Zkušenosti:"},
}) do A.UIEntries[#A.UIEntries+1]=row end
