# Forever Quest Map

Minimalist world-map helper for WoW Forever 1.60.1.

## Filters
- Quest starts: bundled ATT-derived Forever quest database, filtered against character state where the client exposes it.
- Flight points: native WoW taxi API.
- Dungeon / raid entrances: native Encounter Journal API when available plus a bundled fallback list. The fallback includes verified beta entrances for the new Forever dungeons The Hall of Thanes and Ruins of Lordaeron; other new Forever dungeons are not given guessed coordinates and will appear automatically if the client API exposes them.
- Selected rare enemies: curated outdoor rare selection from ATT Forever data. It is intentionally NOT a complete rare database and uses one representative spawn per rare to reduce map clutter.

All extra filters are off by default, except quest starts. The rare button tooltip explicitly says `Nektere rare`.

Toolbar buttons are in the upper-right of the map. `- / +` changes all addon icon sizes from 40% to 130% (default 80%).

## Commands
`/fqm status`, `/fqm refresh`, `/fqm on`, `/fqm off`, `/fqm reset`

## Install
Delete the old `ForeverQuestMap` folder, then place this `ForeverQuestMap` folder in `Interface\AddOns\`. Restart WoW or `/reload`.

## Data attribution
See `THIRD_PARTY_NOTICES.txt`.

## Safety
v2.2.0 uses plain child frames over the map. It does not use WorldMapFrame:AcquirePin, RemoveAllPinsByTemplate or MapCanvasPinMixin. Native APIs are capability-checked and called through protected calls where applicable.

## 2.2.0
- Expanded the `Nektere rare` filter from only world bosses to a curated outdoor selection across many Classic/Forever zones.
- Added verified beta entrance points for The Hall of Thanes and Ruins of Lordaeron.
- Kept the native dungeon entrance API fallback so future/new Forever entrances can appear automatically when the client exposes them.
- Did not add guessed coordinates for unreleased/unverified new Forever dungeon entrances.
- Quest, flight and icon-size behavior is otherwise unchanged.
