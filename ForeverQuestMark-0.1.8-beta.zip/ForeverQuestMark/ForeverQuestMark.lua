-- Forever Quest Mark, WoW Forever 1.60.1 (Interface 16001).
-- Uses public quest/tooltip APIs. No name/color guessing or quest database.
local ADDON = ...
local VERSION = "0.1.8-beta"
local POSITION_REVISION = 7
local driver = CreateFrame("Frame")
local defaults = { enabled = true, size = 20, x = -10, y = 0 }
local db, ready, dirty = nil, false, false
local elapsed, lastError = 0, nil
local marks = {} -- keyed by the nameplate base; Blizzard unit frames are pooled
local active = {} -- unit token -> mark, cleared on NAME_PLATE_UNIT_REMOVED

local function Readable(value)
    return not (issecretvalue and issecretvalue(value))
end

local function ReadBool(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, value = pcall(fn, ...)
    if ok and Readable(value) and type(value) == "boolean" then return value end
    return nil
end

local function Say(text)
    print("|cffffd34eForever Quest Mark:|r " .. text)
end

local function CleanText(text)
    if not Readable(text) or type(text) ~= "string" then return nil end
    return (text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):match("^%s*(.-)%s*$"))
end

local function IsOwnPlayerLine(line)
    local text = CleanText(line.leftText)
    if not text then return false end
    local name, realm = UnitName("player")
    if not Readable(name) or type(name) ~= "string" then return false end
    if text == name then return true end
    if Readable(realm) and type(realm) == "string" and realm ~= "" then
        return text == name .. "-" .. realm
    end
    return false
end

-- Returns true/false only if the tooltip supplies a readable objective state.
-- nil means unavailable: the native quest relationship remains the fallback.
-- 'completed' is Blizzard's field used by TooltipDataRules.QuestObjective.
local function TooltipNeed(unit)
    local kinds = Enum and Enum.TooltipDataLineType
    if not kinds or not C_TooltipInfo or not C_TooltipInfo.GetUnit then return nil end
    local ok, data = pcall(C_TooltipInfo.GetUnit, unit)
    if not ok or not Readable(data) or type(data) ~= "table" then return nil end
    local lines = data.lines
    if not Readable(lines) or type(lines) ~= "table" then return nil end

    local sawOwn, sawParty, unknown = false, false, false
    local first, count = 1, #lines
    while first <= count do
        -- Each quest has its own player sections. A solo block has no
        -- QuestPlayer lines and its objectives belong to the local player.
        local last = first
        while last < count do
            local nextLine = lines[last + 1]
            if not Readable(nextLine) or type(nextLine) ~= "table" then return nil end
            if not Readable(nextLine.type) then return nil end
            if nextLine.type == kinds.QuestTitle then break end
            last = last + 1
        end
        local hasPlayers = false
        for i = first, last do
            local line = lines[i]
            if not Readable(line) or type(line) ~= "table" or not Readable(line.type) then return nil end
            if line.type == kinds.QuestPlayer then hasPlayers = true end
        end
        local own = not hasPlayers
        for i = first, last do
            local line = lines[i]
            if line.type == kinds.QuestPlayer then
                own = IsOwnPlayerLine(line)
                sawParty = true
            elseif line.type == kinds.QuestObjective and own then
                if Readable(line.completed) and type(line.completed) == "boolean" then
                    sawOwn = true
                    if not line.completed then return true end
                else
                    unknown = true
                end
            end
        end
        first = last + 1
    end
    if unknown then return nil end
    if sawOwn or sawParty then return false end
    return nil
end

local function NeedMark(unit)
    if ReadBool(UnitExists, unit) ~= true then return false end
    -- This marker is for attackable quest mobs, not players or quest givers.
    if ReadBool(UnitIsPlayer, unit) ~= false then return false end
    if ReadBool(UnitIsDeadOrGhost, unit) ~= false then return false end
    if ReadBool(UnitCanAttack, "player", unit) ~= true then return false end
    local related = ReadBool(C_QuestLog and C_QuestLog.UnitIsRelatedToActiveQuest, unit)
    if related ~= true then return false end
    local needed = TooltipNeed(unit)
    if needed ~= nil then return needed end
    return true
end

local function Allowed(frame)
    if not frame then return false end
    if frame.IsForbidden and frame:IsForbidden() then return false end
    return true
end

local function HideAll()
    for _, mark in pairs(marks) do mark.texture:Hide() end
    for unit in pairs(active) do active[unit] = nil end
end

local function ApplyPosition(mark)
    if mark.size == db.size and mark.x == db.x and mark.y == db.y
        and mark.positionedEdge == mark.edge then return end
    mark.holder:SetSize(db.size, db.size)
    mark.holder:ClearAllPoints()
    mark.holder:SetPoint("LEFT", mark.edge, "RIGHT", db.x, db.y)
    mark.size, mark.x, mark.y = db.size, db.x, db.y
    mark.positionedEdge = mark.edge
end

local function GetMark(plate)
    if not Allowed(plate) then return nil end
    local frame = plate.UnitFrame
    if not Allowed(frame) then return nil end

    -- Anchor to the full Blizzard UnitFrame, not to HealthBarsContainer, healthBar
    -- or a ClassicUI border. The Forever client reserves the right side of the
    -- UnitFrame for the level frame and resizes that whole frame when the
    -- nameplate-size option changes. This keeps the marker outside the complete
    -- plate at every size without reading/comparing protected geometry values.
    local mark = marks[plate]
    if not mark then
        local holder = CreateFrame("Frame", nil, plate)
        holder:SetFrameLevel(1000)
        holder:EnableMouse(false)
        local texture = holder:CreateTexture(nil, "OVERLAY", nil, 7)
        texture:SetAllPoints(holder)
        texture:SetTexture("Interface\\GossipFrame\\ActiveQuestIcon")
        texture:Hide()
        mark = { holder = holder, texture = texture }
        marks[plate] = mark
    end
    mark.edge = frame
    ApplyPosition(mark)
    return mark
end

local function UpdatePlate(plate)
    if not Allowed(plate) then return end
    local frame = plate.UnitFrame
    if not Allowed(frame) then return end
    -- Do not branch directly on a possibly secret unit token. Read each candidate
    -- only after issecretvalue says it is public.
    local unit = plate.unitToken
    if not Readable(unit) or type(unit) ~= "string" then unit = frame.unit end
    if not Readable(unit) or type(unit) ~= "string" then unit = frame.displayedUnit end
    if not Readable(unit) or type(unit) ~= "string" or not unit:match("^nameplate%d+$") then return end
    local mark = GetMark(plate)
    if not mark then return end
    mark.seen = true
    active[unit] = mark
    mark.texture:SetShown(NeedMark(unit))
end

local function Refresh()
    if not ready then return end
    if not db.enabled then HideAll(); return end
    for _, mark in pairs(marks) do mark.seen = false end
    for unit in pairs(active) do active[unit] = nil end
    local ok, plates = pcall(C_NamePlate.GetNamePlates)
    if not ok or not Readable(plates) or type(plates) ~= "table" then HideAll(); return end
    for _, plate in ipairs(plates) do
        local success, err = pcall(UpdatePlate, plate)
        if not success then
            -- If the beta changes its frame/API structure, hide stale marks.
            lastError = Readable(err) and tostring(err) or "Nedostupna data klienta."
            HideAll()
            return
        end
    end
    for _, mark in pairs(marks) do
        if not mark.seen then mark.texture:Hide() end
    end
end

local function Number(value, fallback, low, high)
    value = tonumber(value)
    if not value or value ~= value then return fallback end
    return math.max(low, math.min(high, value))
end

local function Status()
    local version, build, _, toc = GetBuildInfo()
    Say(VERSION .. " | WoW " .. tostring(version) .. " / " .. tostring(build)
        .. " | Interface " .. tostring(toc) .. " | " .. (db.enabled and "ZAP" or "VYP"))
    local count, shown = 0, 0
    for _, mark in pairs(active) do
        count = count + 1
        if mark.texture:IsShown() then shown = shown + 1 end
    end
    Say("Nameplaty: " .. count .. ", otazniky: " .. shown .. ". Velikost " .. db.size
        .. ", posun " .. db.x .. " / " .. db.y .. ".")
    if ReadBool(UnitExists, "target") then
        local related = ReadBool(C_QuestLog and C_QuestLog.UnitIsRelatedToActiveQuest, "target")
        local ok, needed = pcall(TooltipNeed, "target")
        Say("Cil: vztah k ukolu = " .. tostring(related) .. "; nesplneny cil = "
            .. (ok and tostring(needed) or "nedostupne") .. ".")
    end
    if lastError then Say("Posledni chyba: " .. lastError) end
end

local function Command(message)
    if not db then return end
    local command, rest = message:match("^%s*(%S*)%s*(.-)%s*$")
    command = command:lower()
    if command == "on" or command == "zap" then
        db.enabled = true; Say("Zapnuto.")
    elseif command == "off" or command == "vyp" then
        db.enabled = false; Say("Vypnuto.")
    elseif command == "size" then
        if not tonumber(rest) then Say("Priklad: /fqm size 24 (12 az 48)."); return end
        db.size = Number(rest, 20, 12, 48); Say("Velikost: " .. db.size)
    elseif command == "offset" then
        local x, y = rest:match("^(%-?[%d%.]+)%s+(%-?[%d%.]+)$")
        if not tonumber(x) or not tonumber(y) then Say("Priklad: /fqm offset 12 2"); return end
        db.x, db.y = Number(x, defaults.x, -100, 100), Number(y, defaults.y, -100, 100)
        Say("Posun: " .. db.x .. " / " .. db.y)
    elseif command == "reset" then
        for key, value in pairs(defaults) do db[key] = value end
        Say("Vychozi nastaveni obnoveno.")
    elseif command == "status" or command == "stav" then
        Status(); return
    else
        Say("/fqm on | off | size 24 | offset 12 2 | reset | stav")
        return
    end
    Refresh()
end

local function Initialize()
    if type(ForeverQuestMarkDB) ~= "table" then ForeverQuestMarkDB = {} end
    db = ForeverQuestMarkDB
    if type(db.enabled) ~= "boolean" then db.enabled = true end
    db.size = Number(db.size, 20, 12, 48)
    -- Keep the safe full-UnitFrame anchoring, but pull the icon closer and a bit lower.
    -- Preserve manual user offsets; migrate only untouched defaults from older builds.
    if db.positionRevision ~= POSITION_REVISION then
        if db.positionRevision == 6 and db.x == -6 and db.y == 2 then
            db.x, db.y = defaults.x, defaults.y
        elseif db.positionRevision == 5 and db.x == 0 and db.y == 2 then
            db.x, db.y = defaults.x, defaults.y
        elseif db.positionRevision == 4 and db.x == 6 and db.y == 2 then
            db.x, db.y = defaults.x, defaults.y
        elseif db.positionRevision == 3 and db.x == 10 and db.y == 2 then
            db.x, db.y = defaults.x, defaults.y
        elseif db.positionRevision == 2 and db.x == 16 and db.y == 2 then
            db.x, db.y = defaults.x, defaults.y
        elseif db.positionRevision == 1 and db.x == 12 and db.y == 2 then
            db.x, db.y = defaults.x, defaults.y
        elseif db.positionRevision == nil and db.x == nil and db.y == nil then
            db.x, db.y = defaults.x, defaults.y
        end
        db.positionRevision = POSITION_REVISION
    end
    db.x = Number(db.x, defaults.x, -100, 100)
    db.y = Number(db.y, defaults.y, -100, 100)
    SLASH_FOREVERQUESTMARK1 = "/fqm"
    SlashCmdList.FOREVERQUESTMARK = Command
    if not (C_NamePlate and C_NamePlate.GetNamePlates and C_QuestLog
        and C_QuestLog.UnitIsRelatedToActiveQuest) then
        Say("Klient nema potrebne API. Posli prosim vystup /fqm stav.")
        return
    end
    ready, dirty = true, true
    Say("Nacteno. Zlaty otaznik u ukolovych mobu. Nastaveni: /fqm")
end

driver:SetScript("OnEvent", function(_, event, unit)
    if event == "ADDON_LOADED" then
        if unit == ADDON then Initialize() end
    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        if Readable(unit) and type(unit) == "string" then
            local mark = active[unit]
            if mark then mark.texture:Hide(); active[unit] = nil end
        end
        dirty = true
    elseif event == "PLAYER_LEAVING_WORLD" then
        HideAll()
    else
        dirty = true
    end
end)

-- Coalesce quest events; never scan all tooltips every rendered frame.
driver:SetScript("OnUpdate", function(_, delta)
    if not ready or not db.enabled then return end
    elapsed = elapsed + delta
    if elapsed >= 0.5 or (dirty and elapsed >= 0.1) then
        elapsed, dirty = 0, false
        Refresh()
    end
end)

for _, event in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "PLAYER_ENTERING_WORLD",
    "PLAYER_LEAVING_WORLD", "NAME_PLATE_UNIT_ADDED", "NAME_PLATE_UNIT_REMOVED",
    "QUEST_LOG_UPDATE", "QUEST_WATCH_UPDATE", "QUEST_ACCEPTED", "QUEST_REMOVED",
    "QUEST_TURNED_IN", "PLAYER_REGEN_ENABLED", "PLAYER_REGEN_DISABLED",
    "GROUP_ROSTER_UPDATE", "CVAR_UPDATE" }) do
    driver:RegisterEvent(event)
end
