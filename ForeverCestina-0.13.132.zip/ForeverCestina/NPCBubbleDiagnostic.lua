-- Temporary, bounded, READ-ONLY observation. No native setters or hooks.
-- Does not translate bubbles. Remove from TOC after evidence is collected.
local _, A = ...
local limit, accepted, queued = 8, 0, false
local seen = {}
local fields = {"unit", "unitToken", "guid", "unitGUID", "senderGUID", "lineID", "chatLineID", "messageID"}
local frame = CreateFrame("Frame") -- addon-owned event receiver only
local report
local function public(v) return A.Accessible(v) end
local function scalar(v)
    if not public(v) then return nil end
    if type(v)=="string" then return v:sub(1,160) end
    if type(v)=="boolean" or A.PublicNumber(v) then return v end
end
local function call(o,k,...)
    if not public(o) or o==nil then return nil end
    local f=o[k]
    if not public(f) or type(f)~="function" then return nil end
    local ok,v=pcall(f,o,...)
    if ok and public(v) then return v end
end
local function readable(o)
    return public(o) and o~=nil and call(o,"IsForbidden")==false and call(o,"IsProtected")==false
end
local function list(o,method)
    local result={}
    local function fetch() result={o[method](o)} end
    if public(o[method]) and type(o[method])=="function" and pcall(fetch) then return result end
    return {}
end
local function stopped()
    local combat=InCombatLockdown and InCombatLockdown()
    if not public(combat) or combat~=false then return true end
    if C_ChatInfo and type(C_ChatInfo.InChatMessagingLockdown)=="function" then
        local locked=C_ChatInfo.InChatMessagingLockdown()
        if not public(locked) or locked~=false then return true end
    end
    return false
end
local function inspect(o,message)
    if not readable(o) then return {skipped="restricted_or_unknown"} end
    local out={name=scalar(call(o,"GetName")),id=scalar(call(o,"GetID")),kind=scalar(call(o,"GetObjectType")),fields={},attributes={}}
    -- These are observations, NOT assumed public ownership contracts.
    for _,k in ipairs(fields) do
        if type(o)=="table" then out.fields[k]=scalar(rawget(o,k)) end
        out.attributes[k]=scalar(call(o,"GetAttribute",k))
    end
    local function textInfo(fs)
        if not readable(fs) then return nil end
        local s=call(fs,"GetText")
        if not public(s) or type(s)~="string" then return nil end
        -- Do not persist unrelated player chat. The NPC message is already recorded.
        return {bytes=#s,exactNPCText=(s==message)}
    end
    out.text=textInfo(o)
    if type(o)=="table" then out.string=textInfo(rawget(o,"String")) end
    out.regions={}
    local n=call(o,"GetNumRegions")
    if A.PublicNumber(n) and n>=0 and n<=12 and n%1==0 then
        for _,reg in ipairs(list(o,"GetRegions")) do
            if readable(reg) and call(reg,"GetObjectType")=="FontString" then
                local info=textInfo(reg)
                if info then out.regions[#out.regions+1]=info end
            end
        end
    end
    return out
end
local function sample(record,phase)
    if not report or stopped() then return end
    if not C_ChatBubbles or type(C_ChatBubbles.GetAllChatBubbles)~="function" then report.apiAvailable=false;return end
    report.apiAvailable=true
    local all=C_ChatBubbles.GetAllChatBubbles(false)
    if not public(all) or type(all)~="table" then return end
    local snap={phase=phase,bubbles={}}
    -- Maximum 8 frames and 4 children; no WorldFrame or nameplate scan.
    for i=1,8 do
        local bubble=all[i]
        if not public(bubble) then break end
        if bubble==nil then break end
        local row=inspect(bubble,record.text)
        if readable(bubble) then
            row.children={}
            local n=call(bubble,"GetNumChildren")
            if A.PublicNumber(n) and n>=0 and n<=4 and n%1==0 then
                for _,child in ipairs(list(bubble,"GetChildren")) do row.children[#row.children+1]=inspect(child,record.text) end
            end
        end
        snap.bubbles[#snap.bubbles+1]=row
    end
    record.snapshots[#record.snapshots+1]=snap
end
local function safeSample(record,phase)
    if not pcall(sample,record,phase) and report then report.readFailures=(report.readFailures or 0)+1 end
end
local function init()
    if not A.DB then return end
    local old=A.DB.npcBubbleDiagnostic
    -- One bounded capture per diagnostic schema, across reloads. Preserve completed evidence.
    if type(old)=="table" and old.schema==1 then
        report=old
        if type(report.samples)~="table" then return end
        accepted=#report.samples
    else
        report={schema=1,version=A.Version,samples={},limit=limit,readOnly=true}
        A.DB.npcBubbleDiagnostic=report
    end
    report.status=accepted>=limit and "complete" or "waiting_for_npc_speech"
    if accepted<limit then frame:RegisterEvent("CHAT_MSG_MONSTER_SAY");frame:RegisterEvent("CHAT_MSG_MONSTER_YELL") end
end
local function receive(event,message,sender,_,_,recipient,_,_,_,_,_,lineID,guid)
    if event=="PLAYER_LOGIN" then init();return end
    if event~="CHAT_MSG_MONSTER_SAY" and event~="CHAT_MSG_MONSTER_YELL" then return end
    if not report or accepted>=limit or queued or stopped() then return end
    if not public(message) or type(message)~="string" or #message==0 or #message>1200 then return end
    local name=scalar(sender)
    if not name then return end
    local key=event.."\n"..name.."\n"..message
    if seen[key] then return end
    seen[key]=true;accepted=accepted+1
    local record={event=event,text=message,sender=name,recipient=scalar(recipient),lineID=scalar(lineID),guid=scalar(guid),snapshots={}}
    report.samples[#report.samples+1]=record
    safeSample(record,"event")
    if C_Timer and type(C_Timer.After)=="function" then
        queued=true
        local ok=pcall(C_Timer.After,0.15,function() queued=false;safeSample(record,"after_0.15s") end)
        if not ok then queued=false end
    end
    report.status=accepted>=limit and "complete" or "collecting"
    if accepted>=limit then frame:UnregisterEvent("CHAT_MSG_MONSTER_SAY");frame:UnregisterEvent("CHAT_MSG_MONSTER_YELL") end
end
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent",function(_,event,...)
    local ok=pcall(receive,event,...)
    if not ok and report then report.readFailures=(report.readFailures or 0)+1 end
end)
