local _, A = ...
-- Only the native reading-page SimpleHTML. No action/event-handler replacements,
-- tooltip tables, global strings, WorldFrame scanning, or page-navigation hooks.
local font = "Interface\\AddOns\\ForeverCestina\\Fonts\\ForeverSerif-Medium.ttf"
local tags = {"P", "H1", "H2", "H3"}
local index, state, widget, hooked, busy = {}, nil, nil, false, false
local bases, localized = {}, false
local events = CreateFrame("Frame")
local elapsed = 0

local function key(text)
    if not A.Accessible(text) or type(text) ~= "string" or #text > 40000 then return end
    -- Preserve paragraphs, markup, names, punctuation and internal whitespace.
    return (text:gsub("\r\n", "\n"):gsub("\n\r", "\n"):gsub("\r", "\n"):gsub("[ \t\n]+$", ""))
end
for _, row in ipairs(A.ReadingPageEntries or {}) do
    for _, title in ipairs(row.titles) do
        index[title] = index[title] or {}
        local k = key(row.en)
        local old = index[title][k]
        if old ~= nil and old ~= row.cs then index[title][k] = false
        else index[title][k] = row.cs end
    end
end
function A.TranslateReadingPage(title, text)
    if not A.Accessible(title) or type(title) ~= "string" then return end
    local k = key(text)
    local cs = k and index[title] and index[title][k]
    if type(cs) == "string" then return cs end
end
local function read(fn, ...)
    if type(fn) ~= "function" then return end
    local ok, value = pcall(fn, ...)
    if ok and A.Accessible(value) then return value end
end
local function writable(frame)
    if not frame or type(frame.IsForbidden) ~= "function" or type(frame.IsProtected) ~= "function" then return false end
    return read(frame.IsForbidden, frame) == false and read(frame.IsProtected, frame) == false
end
local function allowed()
    return read(InCombatLockdown) == false and writable(widget) and writable(ItemTextFrame)
        and writable(ItemTextScrollFrame) and writable(ItemTextPageScrollChild)
end
local function fontBase(tag)
    local path, size, flags = widget:GetFont(tag)
    if not A.Accessible(path) or type(path) ~= "string" or not A.PublicNumber(size) or size <= 0
        or not A.Accessible(flags) or (flags ~= nil and type(flags) ~= "string") then
        error("Čtecí písmo není veřejně dostupné.")
    end
    return {path, size, flags}
end
local function restoreFonts()
    if not localized then return end
    for _, tag in ipairs(tags) do
        local b = bases[tag]
        if b and widget:SetFont(tag, b[1], b[2], b[3]) == false then error("Obnova čtecího písma selhala.") end
    end
    localized = false
end
local function useFonts()
    if localized then return end
    for _, tag in ipairs(tags) do bases[tag] = fontBase(tag) end
    localized = true -- Allow recovery if a later tag is rejected.
    for _, tag in ipairs(tags) do
        local b = bases[tag]
        if widget:SetFont(tag, font, b[2] + 1, b[3]) == false then error("České čtecí písmo nelze načíst.") end
    end
end
local function enabled()
    return (not A.DB or A.DB.enabled ~= false) and read(IsShiftKeyDown) == false
end
local function apply()
    if enabled() then useFonts(); widget:SetText(state.cs); state.csShown = true
    else restoreFonts(); widget:SetText(state.en); state.csShown = false end
end
local function reflow()
    -- For Shift/enable changes only. Same public text-content measurement as
    -- native ITEM_TEXT_READY; never resize the panel, SimpleHTML or controls.
    -- The native SetText callback does NOT call this: native layout follows it.
    local scroll, child = ItemTextScrollFrame, ItemTextPageScrollChild
    local oldHeight = child:GetHeight()
    if not A.PublicNumber(oldHeight) or oldHeight < 0 then error("Nečitelná výška stránky.") end
    local ok, err = pcall(function()
        child:SetHeight(1)
        scroll:UpdateScrollChildRect()
        local range, height = scroll:GetVerticalScrollRange(), scroll:GetHeight()
        if not A.PublicNumber(range) or not A.PublicNumber(height) or range < 0 or range > 100000 or height <= 0 then
            error("Nečitelný rozsah posouvání stránky.")
        end
        if math.floor(range) > 0 then child:SetHeight(height + range + 30) end
        scroll:UpdateScrollChildRect()
    end)
    if not ok then pcall(child.SetHeight, child, oldHeight); error(err) end
end
local function run(fn)
    if busy then return end
    busy = true
    local ok, err = pcall(fn)
    if not ok and allowed() then
        -- A font/render failure may not leave Czech glyphs in the native font.
        pcall(restoreFonts)
        if state then pcall(widget.SetText, widget, state.en); state.csShown = false end
    end
    if not ok then state = nil; events:SetScript("OnUpdate", nil) end
    busy = false
    if not ok then A.NoteError("ReadingPages", err) end
end
local function refresh()
    if not state or not allowed() or read(ItemTextFrame.IsShown, ItemTextFrame) ~= true then return end
    if enabled() == state.csShown then return end
    run(function() apply(); reflow() end)
end
local function tick(_, delta)
    elapsed = elapsed + delta
    if elapsed < 0.2 then return end
    elapsed = 0
    if not state or read(ItemTextFrame.IsShown, ItemTextFrame) ~= true then events:SetScript("OnUpdate", nil); return end
    refresh()
end
local function install()
    if hooked or not ItemTextPageText or type(hooksecurefunc) ~= "function" then return end
    widget = ItemTextPageText
    if not widget.SetText or not widget.GetFont or not widget.SetFont or not widget.SetFontObject then return end
    -- Native BEGIN resets each tag. Keep those newly supplied fonts as the base.
    hooksecurefunc(widget, "SetFontObject", function(_, tag)
        if busy or not A.Accessible(tag) then return end
        if bases[tag] and allowed() then run(function() bases[tag] = fontBase(tag) end) end
    end)
    hooksecurefunc(widget, "SetText", function(_, text, ignoreMarkup)
        if busy then return end
        state = nil; events:SetScript("OnUpdate", nil)
        if not allowed() then return end
        run(function()
            restoreFonts()
            if not A.Accessible(ignoreMarkup) or (ignoreMarkup ~= nil and ignoreMarkup ~= false) then return end
            local title = read(ItemTextGetItem)
            -- Player-authored mail/creator suffixes are outside this dictionary.
            if type(ItemTextGetCreator) ~= "function" then return end
            local creatorOK, creator = pcall(ItemTextGetCreator)
            if not creatorOK or not A.Accessible(creator) then return end
            if creator ~= nil and creator ~= "" then return end
            local cs = A.TranslateReadingPage(title, text)
            if not cs then return end
            state = {en = text, cs = cs, csShown = false}
            apply()
            elapsed = 0; events:SetScript("OnUpdate", tick)
        end)
    end)
    hooked = true
end
for _, event in ipairs({"ADDON_LOADED", "PLAYER_LOGIN", "ITEM_TEXT_BEGIN", "ITEM_TEXT_TRANSLATION", "ITEM_TEXT_CLOSED", "MODIFIER_STATE_CHANGED", "PLAYER_REGEN_ENABLED"}) do events:RegisterEvent(event) end
events:SetScript("OnEvent", function(_, event)
    if event == "ADDON_LOADED" or event == "PLAYER_LOGIN" then install()
    elseif event == "ITEM_TEXT_BEGIN" or event == "ITEM_TEXT_TRANSLATION" or event == "ITEM_TEXT_CLOSED" then
        state = nil; events:SetScript("OnUpdate", nil)
        if allowed() then run(restoreFonts) end
    else refresh() end
end)
install()
