-- Exact local NPC/text pairs; sources in prace/0.13.84/gossip-additions.json.
local _, A = ...
local entries={
 {npc="Terunne Bearshaper",en="Care to learn how to gather leather from slain beasts? Or do you need some new tools?",cs="Chceš se naučit stahovat kůži ze zabitých zvířat? Nebo potřebuješ nové nástroje?"},
 {npc="Terunne Bearshaper",en="Train me.",cs="Chci se něco naučit."},
 {npc="Terunne Bearshaper",en="I would like to buy from you.",cs="Chci u tebe nakoupit."},
 {npc="Fanorran Stilloak",en="How can I help you?",cs="Jak ti mohu pomoci?"},
 {npc="Fanorran Stilloak",en="Train me.",cs="Chci se něco naučit."},
 {npc="Fanorran Stilloak",en="I would like to buy from you.",cs="Chci u tebe nakoupit."},
 {npc="Jannok Breezesong",en="Like a cat dragged in from the rain, you scratch and claw, then do it all over again... I'll be back for more...\n\nOh, I didn't see you enter, $n! What can I do for you?",cs="Jako kočka zmoklá v dešti škrábeš, drápy zatínáš, pak začínáš zas od začátku... Ještě si přijdu pro přídavek...$B$BAch, nevšiml jsem si, že přicházíš, $n! Co pro tebe mohu udělat?"},
 {npc="Jannok Breezesong",en="Hello! I am a Rogue in need of training.",cs="Zdravím! Jsem tulák a potřebuji výcvik."},
 {npc="Dolanaar Sentinel",en="There are many places that you might visit in Teldrassil.  Tell me what you seek.",cs="V Teldrassilu je mnoho míst, která můžeš navštívit. Pověz mi, co hledáš."},
 {npc="Dolanaar Sentinel",en="Profession Trainer",cs="Učitel povolání"},
 {npc="Dolanaar Sentinel",en="Class Trainer",cs="Trenér třídy"},
 {npc="Dolanaar Sentinel",en="Stable Master",cs="Správce stájí"},
 {npc="Dolanaar Sentinel",en="The Inn\r\n",cs="Hostinec"},
 {npc="Dolanaar Sentinel",en="The Guild Master.",cs="Cechovní mistr."},
 {npc="Dolanaar Sentinel",en="Rut'theran Ferry",cs="Přívoz do Rut'theranu"},
 {npc="Dolanaar Sentinel",en="The Bank",cs="Banka"},
 {npc="Aldia",en="I would like to see your wares.",cs="Chci si prohlédnout tvé zboží."},
 {npc="Darnassus Sentinel",en="The Inn",cs="Hostinec"},
 {npc="Darnassus Sentinel",en="The Bank",cs="Banka"},
 {npc="Stormwind City Guard",en="Mailbox",cs="Poštovní schránka"},
 {npc="Stormwind City Guard",en="The Inn",cs="Hostinec"},
 {npc="Stormwind City Guard",en="Stormwind Harbor",cs="Přístav Stormwind"},
 {npc="Stormwind City Guard",en="Barbershop",cs="Holičství"},
 {npc="Stormwind City Guard",en="Transmogrifier",cs="Transmogrifikátor"},
 {npc="Keryn Sylvius",en="Well, well... look what the cat brung in... and how can I help you, rogue?",cs="Ale, ale... koho nám to sem čerti nesou... Jak ti mohu pomoci, tuláku?"},
 {npc="Keryn Sylvius",en="I am in need of training, Keryn.",cs="Potřebuji výcvik, Keryn."},
 {npc="Servant of Azora",en="Greetings, adventurer.",cs="Zdravím tě, dobrodruhu."},
 {npc="Lee Brown",en="Train me.",cs="Chci se něco naučit."},
}
for _,entry in ipairs(entries) do A.GossipEntries[#A.GossipEntries+1]=entry end
A.QuestTargetTranslations["elune's light cast"]="Seslání kouzla Elune's Light"
A.QuestTargetTranslations["shadowmeld cast"]="Seslání kouzla Shadowmeld"

-- 2026-09-28: exact known menu labels; use existing data, no runtime replacement.
-- Class/profession names remain English for recognition; prose is not rewritten.
local menuTerms={
 ["Class Trainer"]="Trenér povolání",
 ["A class trainer"]="Trenér povolání",
 ["Profession Trainer"]="Trenér profesí",
 ["A profession trainer"]="Trenér profesí",
 ["Which class trainer are you looking for?"]="Trenéra kterého povolání hledáš?",
 ["Which class trainer might ye be looking for?"]="Trenéra kterého povolání hledáš?",
 ["Which profession trainer are you looking for?"]="Trenéra které profese hledáš?",
 ["Which profession trainer would ye be looking for?"]="Trenéra které profese hledáš?",
 ["I can not train you. You need to talk to your class trainer."]="Nemohu tě vycvičit. Musíš si promluvit s trenérem svého povolání.",
 ["Druid"]="Druid",
 ["Hunter"]="Hunter",
 ["Mage"]="Mage",
 ["Paladin"]="Paladin",
 ["Priest"]="Priest",
 ["Rogue"]="Rogue",
 ["Shaman"]="Shaman",
 ["Warlock"]="Warlock",
 ["Warrior"]="Warrior",
 ["Alchemy"]="Alchemy",
 ["Blacksmithing"]="Blacksmithing",
 ["Cooking"]="Cooking",
 ["Enchanting"]="Enchanting",
 ["Engineering"]="Engineering",
 ["First Aid"]="First Aid",
 ["Fishing"]="Fishing",
 ["Herbalism"]="Herbalism",
 ["Leatherworking"]="Leatherworking",
 ["Mining"]="Mining",
 ["Skinning"]="Skinning",
 ["Tailoring"]="Tailoring",
}
for _,entry in ipairs(A.GossipEntries) do
 local translation=menuTerms[entry.en]
 if translation then entry.cs=translation end
end
-- Exact current NPC/text observations, including the preceding Legacy menu.
A.GossipEntries[#A.GossipEntries+1]={npc="Ironforge Mountaineer",en="The Inn",cs="Hostinec"}
A.GossipEntries[#A.GossipEntries+1]={npc="Ironforge Guard",en="The Inn",cs="Hostinec"}
A.GossipEntries[#A.GossipEntries+1]={npc="Ironforge Mountaineer",en="Shaman",cs="Shaman"}
A.GossipEntries[#A.GossipEntries+1]={npc="Ironforge Guard",en="Shaman",cs="Shaman"}
A.GossipEntries[#A.GossipEntries+1]={npc="Courier Hammerfall",en="I would like to rewrite my legacy.",cs="Chci změnit svůj odkaz (Legacy)."}
A.GossipEntries[#A.GossipEntries+1]={npc="Courier Hammerfall",en="Your legacy precedes you, rogue. If you wish, I can allow you to rewrite that legacy into something new.",cs="Tvůj odkaz je známý, rogue. Pokud chceš, mohu ti umožnit změnit jej v něco nového."}
A.GossipEntries[#A.GossipEntries+1]={npc="Courier Hammerfall",en="Yes. I would like to unlearn my legacy talents.",cs="Ano, chci zrušit své Legacy talenty."}
