-- ForeverCestina 0.13.74 — historical quest Progress exact-source batch 1.
-- 300 audited Progress fields from QUEST_DIALOG_SOURCE_POOL_70009.json.
-- Data-only: exact English source is retained; existing quest fields are never overwritten.
local _, A = ...
local entries = {
 [117]={
  progress={[=[Hurry, my friend, move with haste $BIn order for our rich lager to taste $BMore like beer and less like stew, $BHops are needed to make the brew.]=],[=[Pospěš si, příteli, není času nazbyt!$BAby náš výtečný ležák chutnal$Bvíc jako pivo a míň jako guláš,$Bpotřebujeme do něj chmel.]=]},
 },
 [128]={
  progress={[=[Return once you have slain 15 Blackrock Champions.]=],[=[Vrať se, až zabiješ 15 Blackrock Champions.]=]},
 },
 [155]={
  progress={[=[What business do you have with me? I am a very busy man...]=],[=[Co ode mě potřebuješ? Jsem velmi zaneprázdněný muž...]=]},
 },
 [245]={
  progress={[=[You'd best be careful when dealing with the spiders, I've lost a few of my men to them, and trust me, it isn't a pleasant sight to see a man hanging upside down in their webs after the venom has started to soften them up.$B$BI wouldn't want to see one of the bugs having you for lunch.]=],[=[Při boji s pavouky buď raději opatrný. Už jsem kvůli nim přišel o několik mužů a věř mi, není to pěkný pohled, když člověk visí hlavou dolů v jejich pavučinách a jed mu začíná rozkládat tělo.$B$BNerad bych viděl, jak si některý z těch brouků dává k obědu tebe.]=]},
 },
 [434]={
  progress={[=[Yes, $N? Are things going well with Tyrion? He apprised me of the situation and I've helped him trick Marzon into going to the castle.$B$BMarzon has been a thorn in the side of many people in Stormwind; many of which are close friends of mine. No one messes with my friends... not if they know what's healthy for them.$B$BIt's just a shame I'm indirectly doing a favor for Shaw and SI:7 in the meantime. Oh well, not every plan is perfect.]=],[=[Ano, $N? Daří se věci s Tyrionem? Seznámil mě se situací a pomohl jsem mu přimět Marzona, aby šel na hrad.$B$BMarzon je už dlouho trnem v oku mnoha lidem ve Stormwindu, a řada z nich jsou moji blízcí přátelé. S mými přáteli si nikdo zahrávat nebude... pokud ví, co je pro něj dobré.$B$BJen je škoda, že tím zároveň nepřímo prokazuji laskavost Shawovi a SI:7. No, žádný plán není dokonalý.]=]},
 },
 [455]={
  progress={[=[You're coming from Loch Modan? How is the orc situation at Algaz Gate?]=],[=[Přicházíš z Loch Modan? Jaká je situace s orky u Algaz Gate?]=]},
 },
 [516]={
  progress={[=[Have you located their base yet, $n? Time is of the essence!]=],[=[Už jsi našel jejich základnu, $n? Čas nás tlačí!]=]},
 },
 [709]={
  progress={[=[Did you find the tablet? It must hold secrets! Secrets to save us!]=],[=[Našel jsi tu tabulku? Musí skrývat tajemství! Tajemství, která nás zachrání!]=]},
 },
 [710]={
  progress={[=[This area's perfect for-- Could you hold these in place for a moment? Yes, just like that, along the vector normal. Now, what was I... Right. Perfect for testing my latest project. The raw materials, the open space... what more could an intelligent and enlightened practitioner of the arts ask for?]=],[=[Tahle oblast je ideální pro-- Mohl bys mi to na chvíli podržet? Ano, přesně tak, podél normály vektoru. Kde jsem to... Ano. Ideální místo pro testování mého nejnovějšího projektu. Suroviny, otevřený prostor... co víc by si mohl inteligentní a osvícený praktik umění přát?]=]},
 },
 [711]={
  progress={[=[I'm most pleased, $N. My spells affected the smaller pieces just as I predicted. If this experiment is as successful as I foresee, then the elementals I'll be able to control will put anything summoned prior to this to shame.]=],[=[Jsem velmi spokojený, $N. Má kouzla působila na menší kusy přesně podle předpovědi. Pokud bude tento experiment tak úspěšný, jak očekávám, elementálové, které budu schopen ovládat, zastíní vše, co kdy bylo předtím přivoláno.]=]},
 },
 [712]={
  progress={[=[The stone slabs you found were ideal, $N. Lucien will be taking the extra ones back to Kharanos when we're done here. After all, they could prove useful again.$B$BFor instance, they'd be a nice basis for a handy little shelter once I start looking into a multidisciplinary approach to high-yield explosives...]=],[=[Kamenné desky, které jsi našel, byly ideální, $N. Až tady skončíme, Lucien vezme ty přebytečné zpět do Kharanos. Koneckonců by se mohly znovu hodit.$B$BTřeba by z nich byl pěkný základ pro praktický malý úkryt, až začnu zkoumat multidisciplinární přístup k výbušninám s vysokou účinností...]=]},
 },
 [713]={
  progress={[=[Have you found the oil I need? It would be so helpful if you were able to find some.]=],[=[Našel jsi olej, který potřebuji? Velmi by mi pomohlo, kdybys nějaký sehnal.]=]},
 },
 [714]={
  progress={[=[Yes, yes, yes. Just a moment.$B$B]=],[=[Ano, ano, ano. Jen okamžik.$B$B]=]},
 },
 [715]={
  progress={[=[He's getting closer to finishing. How are things going on your end?]=],[=[Blíží se k dokončení. Jak to jde na tvé straně?]=]},
 },
 [716]={
  progress={[=[I wouldn't wait too long to get that bracer, $N.$B$BWho knows what's going to happen next?]=],[=[S tím získáním náramku bych příliš neotálel, $N.$B$BKdo ví, co se stane dál?]=]},
 },
 [717]={
  progress={[=[Strong magics and powers held the drakes' prison for so long, but we cannot allow any possibility that Blacklash and Hematus may be released.]=],[=[Silná magie a moc držely vězení draků tak dlouho, ale nesmíme připustit ani možnost, že by Blacklash a Hematus mohli být osvobozeni.]=]},
 },
 [718]={
  progress={[=[The desert's a bad place to be hungry, my friend, let me tell you that.$B$BHey... what's that over there...]=],[=[Poušť není dobré místo, kde mít hlad, příteli, to mi věř.$B$BHej... co je to támhle...]=]},
 },
 [719]={
  progress={[=[Not sure what the Shadowforge were lookin' for, but they definitely had a purpose.]=],[=[Nevím, co Shadowforge hledali, ale rozhodně měli nějaký cíl.]=]},
 },
 [722]={
  progress={[=[The Shadowforge clan... <cough> is dangerous. Be careful. <cough> You must find the amulet.]=],[=[Klan Shadowforge... <kašel> je nebezpečný. Buď opatrný. <kašel> Musíš najít amulet.]=]},
 },
 [723]={
  progress={[=[I'd say it was a bad day, but this is the Badlands: every day's a bad day.]=],[=[Řekl bych, že to byl špatný den, ale tohle je Badlands: tady je špatný každý den.]=]},
 },
 [724]={
  progress={[=[Ah, yes. Another traveler seeking something from the dwarves.$B$BMa'am, I'm truly sorry, but I've no time to answer meaningless questions right now.]=],[=[Ach, ano. Další cestovatel, který něco potřebuje od trpaslíků.$B$BMadam, opravdu mě to mrzí, ale teď nemám čas odpovídat na bezvýznamné otázky.]=]},
 },
 [725]={
  progress={[=[Hmm? Yes, $C.]=],[=[Hm? Ano, $C.]=]},
 },
 [727]={
  progress={[=[Hello. Welcome to my shop, but watch what you touch.$B$BKnowledge can be deadly.]=],[=[Zdravím. Vítej v mém obchodě, ale dávej pozor, čeho se dotýkáš.$B$BVědomosti mohou být smrtící.]=]},
 },
 [728]={
  progress={[=[Ah, we have an eager $C, I see. Are you here to learn from my collection? Good!$B$BBut be warned: just as knowledge gives power to the strong...it will drive the weak mad.]=],[=[Ach, vidím, že tu máme nedočkavého $C. Přišel ses učit z mé sbírky? Dobře!$B$BAle varuji tě: tak jako vědomosti dávají silným moc... slabé mohou dohnat k šílenství.]=]},
 },
 [731]={
  progress={[=[Is the prospector alive?]=],[=[Je prospektor naživu?]=]},
 },
 [732]={
  progress={[=[The nomadic band of ogres travels between their camps across the Badlands; heat rising from the dry earth and the swirling winds will make it difficult to track their progress. I have heard that sometimes they travel through Camp Boff. If you are lost, you might try your search there.]=],[=[Kočovná skupina ogrů putuje mezi svými tábory napříč Badlands; horký vzduch stoupající ze suché země a vířící vítr ztěžují sledování jejich pohybu. Slyšel jsem, že někdy procházejí přes Camp Boff. Pokud nevíš, kam dál, zkus hledat tam.]=]},
 },
 [733]={
  progress={[=[Well, I've made do with what I could, but... it's not much. Have you found any more supplies?]=],[=[Vystačil jsem si s tím, co jsem měl, ale... není toho mnoho. Našel jsi další zásoby?]=]},
 },
 [735]={
  progress={[=[Do you have the relics for which I asked?]=],[=[Máš relikvie, o které jsem tě žádal?]=]},
 },
 [736]={
  progress={[=[How goes your mission, $c.]=],[=[Jak pokračuje tvá mise, $c?]=]},
 },
 [737]={
  progress={[=[Ho! You were gone a long time. Did you get the digest?]=],[=[Ho! Byl jsi pryč dlouho. Získal jsi ten digest?]=]},
 },
 [739]={
  progress={[=[Do you have news of Agmond's fate? Did you find him?]=],[=[Máš nějaké zprávy o Agmondově osudu? Našel jsi ho?]=]},
 },
 [745]={
  progress={[=[If the Palemanes had respected the land and its inhabitants more, this conflict would have never occurred.]=],[=[Kdyby Palemanes měli větší úctu k zemi a jejím obyvatelům, k tomuto konfliktu by nikdy nedošlo.]=]},
 },
 [762]={
  progress={[=[Time is of the essence, $N. Ragnaros will not wait for us to prepare.]=],[=[Čas nás tlačí, $N. Ragnaros nebude čekat, až se připravíme.]=]},
 },
 [777]={
  progress={[=[<Without looking up from the shackles, Lotwil holds out a hand and waggles his fingers impatiently.>$B$BThe cog, $N, the cog!]=],[=[<Lotwil ani nezvedne oči od pout, natáhne ruku a netrpělivě zakmitá prsty.>$B$BOzubené kolečko, $N, to kolečko!]=]},
 },
 [778]={
  progress={[=[Not quite the outcome I was expecting. Could you get my shackles back?]=],[=[Tohle není zrovna výsledek, který jsem čekal. Mohl bys mi přinést zpět moje pouta?]=]},
 },
 [782]={
  progress={[=[Tho'grun's betrayal... is there any wonder why the ogres are part of the Horde no longer? I will be glad to see him dead, and the Sign of the Earth returned.$B$BIf you've not dispatched him yet, then waste no time going to Camp Boff.  It is to the southeast of Kargath.]=],[=[Tho'grunova zrada... divíš se ještě, proč už ogři nejsou součástí Hordy? Rád ho uvidím mrtvého a Sign of the Earth navrácený.$B$BPokud jsi ho ještě nezabil, neztrácej čas a vydej se do Camp Boff. Je jihovýchodně od Kargath.]=]},
 },
 [793]={
  progress={[=[There are few enemies more deadly than dragonkind, and there were few dragons that fought as ferociously as Blacklash and Hematus.]=],[=[Jen málo nepřátel je smrtelnějších než draci a jen málo draků bojovalo tak zuřivě jako Blacklash a Hematus.]=]},
 },
 [813]={
  progress={[=[Remember, no matter what creature you hunt, you would do well to study it and understand its behavior. That knowledge could save your life.]=],[=[Pamatuj, ať lovíš jakéhokoli tvora, vždy se vyplatí ho studovat a pochopit jeho chování. Tyto znalosti ti mohou zachránit život.]=]},
 },
 [822]={
  progress={[=[You working hard at finding those ingredients, $N?]=],[=[Pilně hledáš ty přísady, $N?]=]},
 },
 [824]={
  progress={[=[Ah, hello there. I spend a great deal of time studying the water - all the elements really - so much so that sometimes I don't even notice people around me.$B$BIs there something I can help you with?]=],[=[Ach, zdravím. Trávím spoustu času studiem vody — vlastně všech živlů — natolik, že si někdy ani nevšimnu lidí kolem sebe.$B$BMohu ti s něčím pomoci?]=]},
 },
 [841]={
  progress={[=[Well, have you got the ten water pouches?]=],[=[Tak co, máš těch deset vaků s vodou?]=]},
 },
 [857]={
  progress={[=[Where is the Tear of the Moons? I need it now! Need I say!]=],[=[Kde je Tear of the Moons? Potřebuji ji hned! Musím to snad opakovat?]=]},
 },
 [864]={
  progress={[=[Welcome back. At least, welcome back if you have returned with a sealed testing kit. Otherwise, I will pretend not to notice your utter incompetence and spare my wrath from you until you do as you have been tasked and accomplish my task.]=],[=[Vítej zpět. Tedy pokud ses vrátil se zapečetěnou testovací sadou. Jinak budu předstírat, že jsem si tvé naprosté neschopnosti nevšiml, a ušetřím tě svého hněvu, dokud nesplníš úkol, který ti byl uložen.]=]},
 },
 [910]={
  progress={[=[Are we there yet?]=],[=[Už tam budeme?]=]},
 },
 [911]={
  progress={[=[Are we there yet?]=],[=[Už tam budeme?]=]},
 },
 [915]={
  progress={[=[I wish they'd make more flavors of ice cream other than strawberry, but I guess I'm lucky that strawberry is my favorite!]=],[=[Kéž by dělali víc příchutí zmrzliny než jen jahodovou, ale asi mám štěstí, že právě jahodová je moje nejoblíbenější!]=]},
 },
 [925]={
  progress={[=[When the orcs were alone and without friends, the tauren welcomed them to a strange land and shared with them without asking anything in return. That's honor, $N.]=],[=[Když byli orkové sami a bez přátel, taureni je přivítali v cizí zemi a podělili se s nimi, aniž by za to něco žádali. To je čest, $N.]=]},
 },
 [939]={
  progress={[=[What is it, $C? You look concerned.]=],[=[Co se děje, $C? Vypadáš ustaraně.]=]},
 },
 [964]={
  progress={[=[Kill many and kill often, $C - we'll need a decent supply of suitable skeletal fragments to make up the outer layer of the key. They don't call it a Skeleton Key for nothing, you know.]=],[=[Zabíjej hodně a často, $C — budeme potřebovat slušnou zásobu vhodných kosterních úlomků na vnější vrstvu klíče. Neříká se mu Skeleton Key jen tak pro nic za nic.]=]},
 },
 [969]={
  progress={[=[Bring back da shards, and I be tellin' you more!]=],[=[Přines střepy a já ti povím víc!]=]},
 },
 [974]={
  progress={[=[I'd go there myself, but... I'm a little scared of the fire elementals there!]=],[=[Šel bych tam sám, ale... z těch ohnivých elementálů mám trochu strach!]=]},
 },
 [977]={
  progress={[=[I've just about finished attaching the fur, $N. Please, hurry back with those horns!]=],[=[Už jsem skoro hotový s připevňováním kožešiny, $N. Prosím, pospěš si zpět s těmi rohy!]=]},
 },
 [978]={
  progress={[=[Where could these powers have originated from? I think we are on the right track to find the answer, $N.]=],[=[Odkud se tyto síly mohly vzít? Myslím, že jsme na správné cestě k odpovědi, $N.]=]},
 },
 [985]={
  progress={[=[Do not stay your hand from what must be done, child. I know how repulsive the idea of killing the creatures of the forest must be, but in this case it is necessary. No cure has been discovered for the corruption let loose upon the forest, and we must do what we can to halt its progress until one is found.]=],[=[Neváhej udělat to, co je nutné, dítě. Vím, jak odpudivá ti musí připadat představa zabíjení tvorů lesa, ale v tomto případě je to nezbytné. Na zkázu, která se v lese rozšířila, zatím nebyl nalezen lék, a dokud ho nenajdeme, musíme udělat vše, co můžeme, abychom její šíření zastavili.]=]},
 },
 [992]={
  progress={[=[Welcome back, Junior Surveyor $n!  Have you completed your assignment yet?]=],[=[Vítej zpět, Junior Surveyor $n! Už jsi splnil svůj úkol?]=]},
 },
 [995]={
  progress={[=[Yes, $n?]=],[=[Ano, $n?]=]},
 },
 [1011]={
  progress={[=[Did you find the camp, $N? Do you have a bottle of disease?]=],[=[Našel jsi tábor, $N? Máš láhev s nákazou?]=]},
 },
 [1012]={
  progress={[=[The anguish of the Dor'danil druids still haunt my dreams, $N. You must destroy their leaders!]=],[=[Utrpení druidů z Dor'danil mě stále pronásleduje ve snech, $N. Musíš zničit jejich vůdce!]=]},
 },
 [1022]={
  progress={[=[The tome of the shrine is a mysterious object. It is not a book in the traditional sense. The leaves of the tome were blessed by Mel'Thandris herself, and records events of import in its pages.$B$BIt is hard for me to explain. If you go to the shrine, you will understand.]=],[=[Kniha ve svatyni je záhadný předmět. Není to kniha v běžném slova smyslu. Její listy požehnala sama Mel'Thandris a na jejích stránkách se zaznamenávají významné události.$B$BTěžko se to vysvětluje. Až se dostaneš ke svatyni, pochopíš.]=]},
 },
 [1025]={
  progress={[=[The furbolg were not always our enemy, $N. But times change, and it is no longer a time of peace here in these dark woods.]=],[=[Furbolgové nebyli vždy našimi nepřáteli, $N. Časy se ale mění a v těchto temných lesích už není čas míru.]=]},
 },
 [1031]={
  progress={[=[Have you found them? What did Anilia say? Where is she?]=],[=[Našel jsi je? Co řekla Anilia? Kde je?]=]},
 },
 [1032]={
  progress={[=[Please, help me avenge Anilia's death.]=],[=[Prosím, pomoz mi pomstít Aniliinu smrt.]=]},
 },
 [1038]={
  progress={[=[What'd you find out?]=],[=[Co jsi zjistil?]=]},
 },
 [1043]={
  progress={[=[The woods are perilous for the unprepared. Keep your weapons close at hand and your wits even closer, or your next journey into the haunted forest may be your last.]=],[=[Lesy jsou pro nepřipravené smrtelně nebezpečné. Měj zbraně po ruce a rozum ještě blíž, jinak může být tvá příští cesta do strašidelného lesa poslední.]=]},
 },
 [1045]={
  progress={[=[Have you slain Ran yet, my friend?$B$BEven the Night elves do not truly deserve his wrath. His hatred burns even brighter than my own, but his mind is no longer his own. He is a threat to all the natural creatures of this forest.]=],[=[Už jsi Rana zabil, příteli?$B$BAni Night elves si ve skutečnosti nezaslouží jeho hněv. Jeho nenávist plane ještě silněji než ta má, ale jeho mysl už mu nepatří. Je hrozbou pro všechny přirozené tvory tohoto lesa.]=]},
 },
 [1048]={
  progress={[=[Perhaps I was not explicit in my orders, $c. I want High Inquisitor Whitemane killed once and for all. And while you're at it, take out her top brass as well.$B$BKill that zealot, Scarlet Commander Mograine. Lay waste to Herod, the Scarlet Champion. And slaughter Houndmaster Loksey and his filthy mutts too.$B$BNow begone!]=],[=[Možná jsem své rozkazy neřekl dost jasně, $c. Chci, aby High Inquisitor Whitemane zemřela jednou provždy. A když už tam budeš, zbav se i jejího nejvyššího velení.$B$BZabij toho fanatika Scarlet Commander Mograina. Znič Heroda, Scarlet Championa. A zmasakruj i Houndmaster Lokseyho a jeho špinavé čokly.$B$BA teď zmiz!]=]},
 },
 [1049]={
  progress={[=[Cairne is a brave and noble leader and I would trust him with my own life. But it is others that I do not trust in this political climate.$B$BOnce I have a chance to gather all the knowledge available I can provide sound council to the Chieftain.$B$BHave you had a chance to travel to Tirisfal Glades? To the Scarlet Monastery? The Compendium of the Fallen is just one piece in this complicated puzzle...]=],[=[Cairne je statečný a ušlechtilý vůdce a svěřil bych mu vlastní život. V tomto politickém ovzduší ale nevěřím ostatním.$B$BAž budu mít možnost shromáždit všechny dostupné poznatky, budu moci dát náčelníkovi rozumnou radu.$B$BUž ses dostal do Tirisfal Glades? Do Scarlet Monastery? Compendium of the Fallen je jen jeden dílek této složité skládačky...]=]},
 },
 [1050]={
  progress={[=[The Monastery was a seminary for Paladins-in-training. Once a stronghold of the Light, it fell into the hands of the crazed zealots of the Scarlet Crusade.$B$BThe Crusade believed their goal a noble one: to purify the land of the undead plague. But insanity tainted their plight and now they stand enemies to all.$B$BBring Mythology of the Titans to me so I can study it and house it here in Ironforge.$B$BThe corrupt halls of the Monastery are no place for such a historical treasure.]=],[=[Scarlet Monastery býval seminářem pro budoucí paladiny. Kdysi byl baštou Světla, ale padl do rukou šílených fanatiků Scarlet Crusade.$B$BCrusade věřila, že její cíl je ušlechtilý: očistit zemi od moru nemrtvých. Jejich úsilí ale otrávilo šílenství a nyní jsou nepřáteli všech.$B$BPřines mi Mythology of the Titans, abych ji mohl prostudovat a uložit zde v Ironforge.$B$BZkažené síně Monastery nejsou místem pro takový historický poklad.]=]},
 },
 [1051]={
  progress={[=[What do you want, stranger?]=],[=[Co chceš, cizinče?]=]},
 },
 [1052]={
  progress={[=[Who goes there? What do you want from me?]=],[=[Kdo je tam? Co ode mě chceš?]=]},
 },
 [1053]={
  progress={[=[The corruption in the Monastery will not end until the highest ranking officials have been removed.$B$BIn the name of the Light, slay High Inquisitor Whitemane, Scarlet Commander Mograine,  Herod, the Scarlet Champion and Houndmaster Loksey. Once they have fallen, perhaps the true cause can be rekindled. Until then, anyone who crosses the path of the Crusade lies in peril.$B$BVenture forth from Southshore and make it so!]=],[=[Zkaženost v Monastery neskončí, dokud nebudou odstraněni její nejvyšší představitelé.$B$BVe jménu Světla zabij High Inquisitor Whitemane, Scarlet Commander Mograina, Heroda, Scarlet Championa, a Houndmaster Lokseyho. Až padnou, možná bude možné obnovit skutečný smysl celé věci. Do té doby je každý, kdo zkříží cestu Crusade, v nebezpečí.$B$BVydej se ze Southshore a postarej se o to!]=]},
 },
 [1083]={
  progress={[=[The first time I saw the Charred Vale I almost wept, $N.]=],[=[Když jsem poprvé spatřil Charred Vale, málem jsem se rozplakal, $N.]=]},
 },
 [1084]={
  progress={[=[I have a feeling Gaxim will find a use for the shrapnel regardless of how the Venture Co. has used it in the past.]=],[=[Mám pocit, že Gaxim najde pro ty střepiny využití bez ohledu na to, jak je Venture Co. používala dříve.]=]},
 },
 [1089]={
  progress={[=[Three keyholes are carved into the stone.]=],[=[Do kamene jsou vytesány tři klíčové dírky.]=]},
 },
 [1091]={
  progress={[=[Yes, $N? What can I do for you?]=],[=[Ano, $N? Co pro tebe mohu udělat?]=]},
 },
 [1100]={
  progress={[=[From your look of concern, I can tell that something is amiss....]=],[=[Podle tvého ustaraného výrazu poznám, že něco není v pořádku...]=]},
 },
 [1101]={
  progress={[=[So long as Charlga Razorflank is mustering a force in Razorfen Kraul, these lands are in great danger.]=],[=[Dokud Charlga Razorflank shromažďuje síly v Razorfen Kraul, je tato země ve velkém nebezpečí.]=]},
 },
 [1102]={
  progress={[=[Once I know the foul beasts of Razorfen Kraul have been driven from their foul lair, I will be able to rest in peace, knowing that revenge has been served.$B$BHave you the driven the quilboar from the Kraul? Do you bring to me good news in the form of Razorflank's heart?]=],[=[Dokud nebudu vědět, že odporní tvorové z Razorfen Kraul byli vyhnáni ze svého doupěte, nenajdu klid. Teprve pak budu vědět, že pomsta byla vykonána.$B$BVyhnal jsi quilboary z Kraulu? Přinášíš mi dobrou zprávu v podobě Razorflankina srdce?]=]},
 },
 [1103]={
  progress={[=[Ya have the sapta, brotha?$B$BI know another that had trouble after defeating da corrupt water spirit--seems he waited too long and he came out of the spirit world too quick fer his taste. Hate to see dat happen to another, so I'll just wait here fer a bit to make sure no one else be needin' me help.]=],[=[Máš saptu, bratře?$B$BZnám jednoho, co měl po porážce zkaženého vodního ducha potíže — čekal příliš dlouho a ze světa duchů se vrátil rychleji, než se mu líbilo. Nerad bych, aby se to stalo někomu dalšímu, tak tady chvíli počkám, kdyby ještě někdo potřeboval mou pomoc.]=]},
 },
 [1104]={
  progress={[=[Hi hi hi! Did you get that venom??]=],[=[Ahoj, ahoj, ahoj! Sehnal jsi ten jed??]=]},
 },
 [1105]={
  progress={[=[My brother is making progress with his new fuel design, and that has me worried. I need to start work on a tortoise shell fuel tank as soon as possible!]=],[=[Můj bratr dělá pokroky s novou konstrukcí paliva a to mě znepokojuje. Musím co nejdřív začít pracovat na palivové nádrži z krunýře želvy!]=]},
 },
 [1106]={
  progress={[=[Well, you found me. Good for you.$B$BAre you here about that axe I made for Gath'Ilzogg? Or are you here to reclaim Duchess Pamay's honor?$B$BActually, I don't care which it is. If you're here to fight, then let's get it over with...]=],[=[Takže jsi mě našel. Výborně.$B$BJsi tady kvůli té sekeře, kterou jsem vyrobil pro Gath'Ilzogga? Nebo jsi přišel obnovit čest Duchess Pamay?$B$BVlastně je mi jedno, proč jsi přišel. Pokud se chceš prát, tak to vyřiďme...]=]},
 },
 [1107]={
  progress={[=[Do you have the tail fins?  If I can't protect our car from its own speed, then it won't last long in these races.]=],[=[Máš ocasní ploutve? Pokud neochráním náš vůz před jeho vlastní rychlostí, dlouho v těch závodech nevydrží.]=]},
 },
 [1108]={
  progress={[=[Did you find any indurium flakes, $N. I have my forge heated up and ready to test them.]=],[=[Našel jsi nějaké indurium flakes, $N? Mám výheň rozpálenou a jsem připraven je vyzkoušet.]=]},
 },
 [1109]={
  progress={[=[Ah, I see you have returned. Were you able to procure any Kraul Guano?]=],[=[Ach, vidím, že ses vrátil. Podařilo se ti získat nějaké Kraul Guano?]=]},
 },
 [1110]={
  progress={[=[$N, have you been out into the Flats? Did you bring back that load of parts I wanted?]=],[=[$N, byl jsi už ve Flats? Přinesl jsi tu hromadu součástek, kterou jsem chtěl?]=]},
 },
 [1111]={
  progress={[=[Speak up! Tell me, are you dropping off or picking up?]=],[=[Mluv nahlas! Tak co, něco přinášíš, nebo si něco vyzvedáváš?]=]},
 },
 [1112]={
  progress={[=[Did you make it to Ratchet and get those parts?]=],[=[Dostal ses do Ratchet a sehnal ty součástky?]=]},
 },
 [1113]={
  progress={[=[Have you returned from the Scarlet Monastery? I'll need many hearts for this delightful experiment!$B$BNo doubt, Varimathras and the Dark Lady will be pleased to be rid of the Scarlet Scum as well...]=],[=[Vrátil ses ze Scarlet Monastery? Na tenhle půvabný experiment budu potřebovat spoustu srdcí!$B$BVarimathras i Dark Lady budou bezpochyby rádi, že se zároveň zbaví té Scarlet chátry...]=]},
 },
 [1114]={
  progress={[=[You have something for me? That's great! let's see it!]=],[=[Něco pro mě máš? Skvělé! Tak se na to podíváme!]=]},
 },
 [1116]={
  progress={[=[Back so soon? Do you have my dream dust?]=],[=[Tak brzy zpátky? Máš můj dream dust?]=]},
 },
 [1117]={
  progress={[=[Did you get anything on Nazz Steamboil? Anything he might want to keep a secret??]=],[=[Zjistil jsi něco na Nazz Steamboil? Něco, co by chtěl udržet v tajnosti??]=]},
 },
 [1118]={
  progress={[=[Hello hello. And what brings a noble $R such as you down to Booty Bay?]=],[=[Zdravím, zdravím. Co přivádí tak urozeného $R, jako jsi ty, až do Booty Bay?]=]},
 },
 [1119]={
  progress={[=[Hello, $N. Was Fizzlebub able to help us?]=],[=[Zdravím, $N. Dokázal nám Fizzlebub pomoci?]=]},
 },
 [1120]={
  progress={[=[Hi! You have something for me?]=],[=[Ahoj! Něco pro mě máš?]=]},
 },
 [1121]={
  progress={[=[What are you looking at?]=],[=[Na co zíráš?]=]},
 },
 [1122]={
  progress={[=[Hello $N. How'd that stout work out? It's strong stuff, isn't it?]=],[=[Zdravím, $N. Jak zabral ten stout? Je to síla, co?]=]},
 },
 [1124]={
  progress={[=[This is a dangerous land to be so casual, $C. What brings you to the wastes of Silithus?]=],[=[Tohle je příliš nebezpečná země na tak bezstarostné chování, $C. Co tě přivádí do pustin Silithusu?]=]},
 },
 [1125]={
  progress={[=[Alliance or Horde, it doesn't matter - no being deserves to be trapped on this world as a tortured spirit.  The freeing of these souls will make things right, $N.]=],[=[Alliance nebo Horde, na tom nezáleží — žádná bytost si nezaslouží být uvězněna na tomto světě jako mučený duch. Osvobozením těchto duší napravíš, co je třeba, $N.]=]},
 },
 [1126]={
  progress={[=[Well, did it work? You're still in one piece, which is good news. Did you find anything?]=],[=[Tak co, fungovalo to? Jsi pořád v jednom kuse, což je dobrá zpráva. Našel jsi něco?]=]},
 },
 [1127]={
  progress={[=[Do you have those Zanzil mixtures yet, $N?]=],[=[Máš už ty Zanzil mixtures, $N?]=]},
 },
 [1135]={
  progress={[=[Did you find Highperch, $N? Any luck with the wyverns there?]=],[=[Našel jsi Highperch, $N? Měl jsi tam štěstí s wyverny?]=]},
 },
 [1136]={
  progress={[=[Have you been to the Alterac Mountains, $N? Did you face the elusive Frostmaw?]=],[=[Byl jsi v Alterac Mountains, $N? Postavil ses nepolapitelnému Frostmawovi?]=]},
 },
 [1139]={
  progress={[=[Hammertoe's quest must be actualized, $N. I owe him that much.$B$BYour return to Uldaman is imperative not only to that goal, but also to the safety of all dwarven kind. With the tablet in the hands of the Dark Irons who knows how powerful their army of golems would become.]=],[=[Hammertoeův úkol musí být naplněn, $N. Tolik mu dlužím.$B$BTvůj návrat do Uldaman je nezbytný nejen kvůli tomu, ale i pro bezpečí všech trpaslíků. Kdo ví, jak mocná by byla armáda golemů Dark Ironů, kdyby tabulka zůstala v jejich rukou.]=]},
 },
 [1142]={
  progress={[=[What brings you to my home, $R?]=],[=[Co tě přivádí do mého domova, $R?]=]},
 },
 [1145]={
  progress={[=[I envy you, $C. You have the look of someone who's been outside the walls of Orgrimmar for a while.$B$BI myself would travel in the name of the Warchief if Thrall didn't have need of my skills here in the city. But he leads us well, and I trust his judgement - I remain here for as long as he needs me.]=],[=[Závidím ti, $C. Vypadáš jako někdo, kdo už nějakou dobu pobývá za hradbami Orgrimmaru.$B$BSám bych cestoval ve jménu Warchiefa, kdyby Thrall nepotřeboval mé schopnosti zde ve městě. Vede nás však dobře a já jeho úsudku věřím — zůstanu tady tak dlouho, jak mě bude potřebovat.]=]},
 },
 [1146]={
  progress={[=[War brings my group and I to the Shimmering Flats, $C. What brings you here?]=],[=[Válka přivedla mě i mou skupinu do Shimmering Flats, $C. Co sem přivádí tebe?]=]},
 },
 [1147]={
  progress={[=[With the amount of travelers heading out to the Flats for those races, I'm sure we can convince enough adventure seekers to help push back those insects. My party and I won't be able to leave until we do.]=],[=[Při množství cestovatelů, kteří míří do Flats na ty závody, určitě přesvědčíme dost dobrodruhů, aby nám pomohli zatlačit ten hmyz zpět. Má skupina a já odsud nemůžeme odejít, dokud to neuděláme.]=]},
 },
 [1148]={
  progress={[=[Ah, it been a long time since you've come to see me, $N. What can I do for you today? You be looking like you've seen the face of battle recently. Good... good for the Horde and good for you. The more battle you've seen, the more helpful you'll be; stronger, too.]=],[=[Ach, už je to dlouho, cos mě naposledy navštívil, $N. Co pro tebe dnes mohu udělat? Vypadáš, že jsi nedávno viděl boj. Dobře... dobře pro Hordu i pro tebe. Čím víc bitev zažiješ, tím užitečnější budeš — a také silnější.]=]},
 },
 [1149]={
  progress={[=[Faith. It is far more important than some realize.$B$BIt does not matter what you believe sometimes. It is just important that you believe in something.]=],[=[Víra. Je mnohem důležitější, než si někteří uvědomují.$B$BNěkdy ani nezáleží na tom, čemu věříš. Důležité je, že věříš v něco.]=]},
 },
 [1150]={
  progress={[=[You must be prepared spiritually, physically and mentally for the challenges that lie ahead of you.$B$BToo often do we rush forward before we are ready. I consider it my duty to the youth, no matter which tribe they belong to, to prepare them for the dangers they may face after they leave the sanctity of their home.]=],[=[Na výzvy, které tě čekají, musíš být připraven duchovně, fyzicky i duševně.$B$BPříliš často se vrháme vpřed dřív, než jsme připraveni. Považuji za svou povinnost připravit mladé na nebezpečí, kterému mohou čelit po opuštění bezpečí domova, bez ohledu na to, ke kterému kmeni patří.]=]},
 },
 [1151]={
  progress={[=[Rok'Alim is also called the Pounder by the centaur tribes in Thousand Needles because of the thundering his fists make as he pummels the creatures brave, or stupid, enough to stand in his path.]=],[=[Rok'Alimovi říkají centauří kmeny v Thousand Needles také Pounder kvůli hromovému dunění jeho pěstí, když drtí tvory dost statečné — nebo hloupé — na to, aby se mu postavili do cesty.]=]},
 },
 [1153]={
  progress={[=[I saw the travelers again - the ones that would not sell me a sample of the ore. I spit at them for not helping the warchief.$B$BMay they die in battle like cowards and not like warriors as should be the right of all people who ally themselves with the Horde.]=],[=[Znovu jsem viděl ty cestovatele — ty, kteří mi odmítli prodat vzorek rudy. Plivu na ně, že nepomohli Warchiefovi.$B$BKéž zemřou v boji jako zbabělci, a ne jako válečníci, jak by mělo být právem všech, kdo se spojili s Hordou.]=]},
 },
 [1154]={
  progress={[=[Bring me the book after you've studied it. I will not ask you your question until after you have given me the book.]=],[=[Až knihu prostuduješ, přines mi ji. Tvou otázku ti nepoložím dřív, než mi knihu odevzdáš.]=]},
 },
 [1160]={
  progress={[=[I hope you made the Scarlet Crusade suffer some before stealing the book from them.$B$BMy views of their kind are not unwarranted. The Crusade may have been followers of the Light at one time, but now, they seek to destroy any creatures that have not sided with their religion. They believe all undead, Forsaken or otherwise, must be cleansed, and those traveling in their lands must either be insane, or subject to the undead's powerful magics. Idiots. Idiots and fools; all of them.]=],[=[Doufám, že jsi Scarlet Crusade před krádeží té knihy trochu pocuchal.$B$BMůj názor na jejich druh není bezdůvodný. Crusade možná kdysi následovala Světlo, ale teď chce zničit všechny tvory, kteří nepřijali její víru. Věří, že všichni nemrtví, Forsaken i ostatní, musí být očištěni a že každý, kdo cestuje jejich zemí, je buď šílený, nebo pod vlivem mocné magie nemrtvých. Idioti. Idioti a hlupáci, všichni do jednoho.]=]},
 },
 [1164]={
  progress={[=[Kill them all and bring me their heads!]=],[=[Zabij je všechny a přines mi jejich hlavy!]=]},
 },
 [1166]={
  progress={[=[Me thirsty for grog. Me miss snuff too. Where is strongbox? You go get for Overlord Mok'Morokk.$B$BGo find south in old home. Me too busy leading ogres to get.]=],[=[Já žízeň na grog. Já taky chybí šňupací tabák. Kde strongbox? Ty jít přinést pro Overlord Mok'Morokk.$B$BJít hledat na jih ve starý domov. Já moc zaneprázdněný vedením ogrů.]=]},
 },
 [1168]={
  progress={[=[Mok'Morokk tell all ogres to stay and keep this place safe. Me think ogres need to kill black dragon army and get old home back.$B$BYou help ogres get home back. Help ogres get revenge.]=],[=[Mok'Morokk řekl všem ogrům zůstat a držet místo v bezpečí. Já myslím ogři musí zabít armádu černých draků a získat starý domov zpět.$B$BTy pomoct ogrům získat domov zpět. Pomoct ogrům pomstít se.]=]},
 },
 [1169]={
  progress={[=[With the hearts and tongues of scorched offspring of the black dragon army, I can decipher what wretched beast introduced her spawn into our home. Perhaps with a greater knowledge of our aggressors, we can seek to destroy them once and for all and reclaim Stonemaul Village from ruin.$B$BOf course, convincing Mok'Morokk to move his lethargic, fat mass out of this muck hole is going to be an epic quest in and of itself...]=],[=[Se srdci a jazyky spálených potomků armády černých draků dokážu zjistit, která odporná bestie zavedla své potomstvo do našeho domova. Když budeme o útočnících vědět víc, možná je dokážeme jednou provždy zničit a získat zpět Stonemaul Village.$B$BSamozřejmě přesvědčit Mok'Morokka, aby pohnul svou línou tlustou hmotou z téhle bahnité díry, bude epický úkol sám o sobě...]=]},
 },
 [1172]={
  progress={[=[You must hurry to the Dragonmurk, $n. With Onyxia's eggs riddled around the Wyrmbog, we face overwhelming numbers unless something is done quickly.$B$BDestroy her eggs! Don't let the black dragon plague spread across our homeland!]=],[=[Musíš si pospíšit do Dragonmurk, $n. Onyxia má po celém Wyrmbogu rozesetá vejce a pokud rychle něco neuděláme, budeme čelit zdrcující přesile.$B$BZnič její vejce! Nedovol, aby se nákaza černých draků rozšířila po naší domovině!]=]},
 },
 [1173]={
  progress={[=[I thought you were going to attempt to drive Mok'Morokk out of the village. Instead you have come to me to chat?]=],[=[Myslel jsem, že se pokusíš vyhnat Mok'Morokka z vesnice. A místo toho sis se mnou přišel popovídat?]=]},
 },
 [1175]={
  progress={[=[It's bad enough having to clear out the wreckage of the racers without having to pick them out of burnt animal parts.]=],[=[Už tak je dost zlé odklízet trosky závodních strojů, natož je ještě vytahovat ze spálených zvířecích ostatků.]=]},
 },
 [1176]={
  progress={[=[Do you have those bones for me? I was just about to start working on lightening the steering rig, but I don't want to open her up without all the parts I need.]=],[=[Máš pro mě ty kosti? Právě jsem chtěl začít odlehčovat řízení, ale nechci ho rozebírat, dokud nemám všechny potřebné součástky.]=]},
 },
 [1177]={
  progress={[=[Gimme food or me eat you.]=],[=[Dej mi jídlo, nebo tě sním.]=]},
 },
 [1179]={
  progress={[=[Watch where you're stepping! Watch watch watch!! This is delicate stuff you see here, and if we're to win then it must all work perfectly!]=],[=[Dávej pozor, kam šlapeš! Pozor, pozor, pozor!! Tohle je jemná práce a jestli máme vyhrát, musí všechno fungovat dokonale!]=]},
 },
 [1182]={
  progress={[=[Much as I hate to admit it, that gnome team they have out there is pretty good. Our boys need every edge they can get.]=],[=[Ačkoli to nerad přiznávám, ten gnomí tým venku je docela dobrý. Naši kluci potřebují každou výhodu, kterou mohou získat.]=]},
 },
 [1183]={
  progress={[=[$N! Did you manage to track down the fuel regulator?]=],[=[$N! Podařilo se ti vystopovat fuel regulator?]=]},
 },
 [1187]={
  progress={[=[How'm I supposed to show my face around the track without a little extra kick to get me going? It's a travesty, I tell you.]=],[=[Jak se mám ukázat u závodní dráhy bez trochy výkonu navíc, který mě rozjede? Je to ostuda, říkám ti.]=]},
 },
 [1188]={
  progress={[=[As I'm sure you know, the Gizmorium can service all of your tinkering needs! How can I help you?]=],[=[Jak jistě víš, Gizmorium se postará o všechny tvé kutilské potřeby! Jak ti mohu pomoci?]=]},
 },
 [1189]={
  progress={[=[Can you believe Pozzik put a bucket of sand on the racer? How am I supposed to hit my maximum speed with a bucket of sand under the seat?]=],[=[Věříš tomu, že Pozzik dal na závodní stroj kýbl písku? Jak mám dosáhnout maximální rychlosti s kýblem písku pod sedadlem?]=]},
 },
 [1201]={
  progress={[=[Did you find the infiltrators, $N?]=],[=[Našel jsi ty infiltrátory, $N?]=]},
 },
 [1202]={
  progress={[=[Did you find the documents, $N?  They hold information vital to the stability of the Alliance and, hence, vital to the security of the Horde.]=],[=[Našel jsi dokumenty, $N? Obsahují informace zásadní pro stabilitu Alliance, a tedy i pro bezpečnost Hordy.]=]},
 },
 [1203]={
  progress={[=[You have my blade??]=],[=[Máš můj meč??]=]},
 },
 [1204]={
  progress={[=[Did you get the forked tongues?]=],[=[Získal jsi ty rozeklané jazyky?]=]},
 },
 [1205]={
  progress={[=[Do you have the tooth of Deadmire, $N?  Have you ended the creature's suffering?]=],[=[Máš Deadmireův zub, $N? Ukončil jsi utrpení toho tvora?]=]},
 },
 [1206]={
  progress={[=[Where are those eyes?]=],[=[Kde jsou ty oči?]=]},
 },
 [1218]={
  progress={[=[Spice. We could all use some spice in our life. You agree?]=],[=[Koření. Trochu koření by se hodilo do života každému. Souhlasíš?]=]},
 },
 [1219]={
  progress={[=[Do you have a report to make?]=],[=[Máš co hlásit?]=]},
 },
 [1220]={
  progress={[=[You have something for me?]=],[=[Něco pro mě máš?]=]},
 },
 [1222]={
  progress={[=[Have you seen Mr. Ignatz? I sent him into the swamp some time ago and he hasn't returned!]=],[=[Viděl jsi pana Ignatze? Poslal jsem ho před nějakou dobou do bažiny a stále se nevrátil!]=]},
 },
 [1238]={
  progress={[=[You have something for me?]=],[=[Něco pro mě máš?]=]},
 },
 [1239]={
  progress={[=[You have another matter to report, $N?]=],[=[Máš další hlášení, $N?]=]},
 },
 [1240]={
  progress={[=[There is an angry spirit about you, $gbrother:sister;. What brings you to Kin'weelay?]=],[=[Je kolem tebe cítit hněvivý duch, $gbrother:sister;. Co tě přivádí ke Kin'weelayovi?]=]},
 },
 [1241]={
  progress={[=[Hmph, you better have good reason to interrupt a man and his fishin'. I don't take kindly to peddlers, let alone beggars.]=],[=[Hmph, raději měj dobrý důvod, proč vyrušuješ chlapa při rybaření. Nemám rád podomní prodejce, natož žebráky.]=]},
 },
 [1242]={
  progress={[=[Hello, $N. Is there something I can do for you? Perhaps you'd like to try some of our special Trias cheddar? Or a block of Darnassian bleu?]=],[=[Zdravím, $N. Mohu pro tebe něco udělat? Třeba bys chtěl ochutnat náš speciální Trias cheddar? Nebo kus Darnassian bleu?]=]},
 },
 [1243]={
  progress={[=[Not too safe to be traveling about in the woods, $N. Be careful, and if you see anything suspicious or dangerous, contact the Watchers immediately. Don't try and take anything on yourself. We're not responsible for anything terrible that might happen to you.$B$BBut we both know you're gonna ignore me and fight whatever comes out of the darkness anyway, don't we? Haha, yeah, you adventurer types... all the same.]=],[=[Není moc bezpečné toulat se po lese, $N. Buď opatrný a pokud uvidíš něco podezřelého nebo nebezpečného, okamžitě kontaktuj Watchers. Nesnaž se s ničím bojovat sám. Nejsme zodpovědní za nic hrozného, co by se ti mohlo stát.$B$BAle oba víme, že mě stejně neposlechneš a pustíš se do všeho, co vyleze ze tmy, že? Haha, jo, vy dobrodruzi... všichni stejní.]=]},
 },
 [1244]={
  progress={[=[Be careful out there, $N. I know Trias was the one to send you here, but that doesn't mean there isn't anything lurking out in the woods that couldn't cause you some trouble... especially with you investigating the Defias.]=],[=[Dávej tam venku pozor, $N. Vím, že tě sem poslal Trias, ale to neznamená, že v lese nečíhá něco, co by ti mohlo pořádně zavařit... zvlášť když vyšetřuješ Defias.]=]},
 },
 [1245]={
  progress={[=[I see you're back, and in one piece. We both know you're not here for cheese, so let's cut out the pleasantries. Was Backus any help, or have you even left for Duskwood yet?]=],[=[Vidím, že ses vrátil, a dokonce v jednom kuse. Oba víme, že tu nejsi kvůli sýru, tak vynechme zdvořilosti. Pomohl ti Backus, nebo ses ještě ani nevydal do Duskwoodu?]=]},
 },
 [1249]={
  progress={[=[Did he slip away? He looked a little shady the way he was watching us.]=],[=[Uklouzl ti? Vypadal trochu podezřele, jak nás pozoroval.]=]},
 },
 [1251]={
  progress={[=[What's that you have there, $n? Evidence from the remains of the Shady Rest Inn?]=],[=[Copak to máš, $n? Důkaz z trosek Shady Rest Inn?]=]},
 },
 [1252]={
  progress={[=[Have you found anything of interest at the Shady Rest Inn?]=],[=[Našel jsi u Shady Rest Inn něco zajímavého?]=]},
 },
 [1253]={
  progress={[=[Have you found evidence from the site of the Shady Rest Inn?]=],[=[Našel jsi na místě Shady Rest Inn nějaké důkazy?]=]},
 },
 [1258]={
  progress={[=[My research with the Mudrock tongues is progressing nicely. I trust your crab hunt goes well?]=],[=[Můj výzkum jazyků Mudrocků pěkně pokračuje. Předpokládám, že tvůj lov krabů jde dobře?]=]},
 },
 [1261]={
  progress={[=[$N, did you discover Marg's fate?]=],[=[$N, zjistil jsi, co se stalo Margovi?]=]},
 },
 [1262]={
  progress={[=[You traveled from Brackenwall Village in Dustwallow? How fares Nazeer, and how fare his efforts in the marsh?]=],[=[Přicestoval jsi z Brackenwall Village v Dustwallow? Jak se daří Nazeerovi a jeho úsilí v bažinách?]=]},
 },
 [1265]={
  progress={[=[Yes, $N?]=],[=[Ano, $N?]=]},
 },
 [1269]={
  progress={[=[Have you found any leads on what happened at the Shady Rest Inn?]=],[=[Našel jsi nějakou stopu k tomu, co se stalo v Shady Rest Inn?]=]},
 },
 [1273]={
  progress={[=[Did you find Reethe?]=],[=[Našel jsi Reetha?]=]},
 },
 [1276]={
  progress={[=[Hello there, $c. Something I can help you with?]=],[=[Zdravím, $c. Mohu ti s něčím pomoci?]=]},
 },
 [1319]={
  progress={[=[Something for me to look at?]=],[=[Něco, na co se mám podívat?]=]},
 },
 [1321]={
  progress={[=[Something for me, $c?]=],[=[Něco pro mě, $c?]=]},
 },
 [1322]={
  progress={[=[Did you get them sacs from the spiders?]=],[=[Získal jsi ty vaky od pavouků?]=]},
 },
 [1324]={
  progress={[=[Hello again, $N. I hope you don't mind the assistance, but we couldn't have Hendel escaping, or worse, wind up dead.]=],[=[Zdravím znovu, $N. Doufám, že ti ta pomoc nevadila, ale nemohli jsme Hendela nechat uniknout — nebo ještě hůř, nechat ho zabít.]=]},
 },
 [1360]={
  progress={[=[Well now, we're you able to get slap around those troggs long enough to get into my chest and nab my treasure?]=],[=[Tak co, podařilo se ti ty troggy pořádně zmalovat, dostat se k mé truhle a vzít můj poklad?]=]},
 },
 [1364]={
  progress={[=[What brings you to Nethergarde Keep, $R?]=],[=[Co tě přivádí do Nethergarde Keep, $R?]=]},
 },
 [1365]={
  progress={[=[$N, have you defeated Khan Dez'hepah?]=],[=[$N, porazil jsi Khan Dez'hepaha?]=]},
 },
 [1366]={
  progress={[=[How is your collection of ears, $N? Large?]=],[=[Jak pokračuje tvá sbírka uší, $N? Už je velká?]=]},
 },
 [1367]={
  progress={[=[Leave! The Magram do not speak with the weak. We kill them!$B$BIf you want to speak with me, then show me you are strong. Return after you slay many Gelkis.]=],[=[Odejdi! Magram nemluví se slabými. Zabíjíme je!$B$BChceš-li se mnou mluvit, ukaž, že jsi silný. Vrať se, až zabiješ mnoho Gelkis.]=]},
 },
 [1368]={
  progress={[=[Your two feet step on Gelkis earth. You are not welcome here!$B$BProve you seek friendship with the Gelkis. Kill Magram centaur. Return when the ground is wet with Magram blood.]=],[=[Tvé dvě nohy stojí na zemi Gelkis. Nejsi tu vítán!$B$BDokaž, že hledáš přátelství s Gelkis. Zabíjej centaury Magram. Vrať se, až bude zem mokrá krví Magram.]=]},
 },
 [1369]={
  progress={[=[If you are not our enemy, then you will do what I ask!]=],[=[Jestli nejsi náš nepřítel, uděláš, co žádám!]=]},
 },
 [1370]={
  progress={[=[Return after you further prove your worth to the Gelkis!]=],[=[Vrať se, až Gelkis ještě více prokážeš svou hodnotu!]=]},
 },
 [1374]={
  progress={[=[Show me you are a friend of the Gelkis, $N.]=],[=[Ukaž mi, že jsi přítel Gelkis, $N.]=]},
 },
 [1375]={
  progress={[=[Do tasks for the Magram, and I will help you.]=],[=[Plň úkoly pro Magram a já ti pomohu.]=]},
 },
 [1384]={
  progress={[=[You have the charms? You showed the Kolkar they are weak?]=],[=[Máš ty amulety? Ukázal jsi Kolkarům, že jsou slabí?]=]},
 },
 [1386]={
  progress={[=[Are you afraid of the Kolkar? Why do you not kill them? Maybe you forgot how to kill. Hurry and kill Kolkar before they are dead!]=],[=[Bojíš se Kolkarů? Proč je nezabíjíš? Možná jsi zapomněl, jak se zabíjí. Pospěš si a zabíjej Kolkary, než budou mrtví!]=]},
 },
 [1388]={
  progress={[=[I hope you have proven yourself of use to our dear friend, Apothecary Faustin.]=],[=[Doufám, že ses našemu drahému příteli Apothecary Faustinovi ukázal jako užitečný.]=]},
 },
 [1392]={
  progress={[=[Greetings. And welcome to the Harborage.]=],[=[Buď zdráv. A vítej v Harborage.]=]},
 },
 [1396]={
  progress={[=[The swamp creatures press close, $N. Please, you must defend the camp!]=],[=[Tvorové z bažiny se tlačí stále blíž, $N. Prosím, musíš bránit tábor!]=]},
 },
 [1420]={
  progress={[=[You returned. You have a report?]=],[=[Vrátil ses. Máš hlášení?]=]},
 },
 [1423]={
  progress={[=[You have something for me?]=],[=[Něco pro mě máš?]=]},
 },
 [1428]={
  progress={[=[Not until the sea and all her children are silenced will I be pleased... especially those disgusting fish men.]=],[=[Nebudu spokojený, dokud nebude umlčeno moře i všechny jeho děti... zvlášť ti odporní rybí lidé.]=]},
 },
 [1447]={
  progress={[=[I didn't mean anything by the comment 'bout you being a stupid $C. We're friends, right? No hard feelings?]=],[=[Nemyslel jsem nic zlého tím, že jsem tě nazval hloupým $C. Jsme přátelé, ne? Bez urážky?]=]},
 },
 [1467]={
  progress={[=[Well met, $N. Business is booming, the sounds of anvils being struck rings throughout Ironforge, the bellows blow the fires hot, and me wife's making me a pie for dessert after tonight's dinner. Could life be any grander?]=],[=[Buď zdráv, $N. Obchody kvetou, po celém Ironforge zní údery kovadlin, měchy rozdmýchávají žhavé ohně a má žena mi po dnešní večeři upeče koláč. Může být život ještě lepší?]=]},
 },
 [1560]={
  progress={[=[Where is Tooga?]=],[=[Kde je Tooga?]=]},
 },
 [1700]={
  progress={[=[Hello, and well met. How might I be of service to you?]=],[=[Zdravím tě. Jak ti mohu posloužit?]=]},
 },
 [1703]={
  progress={[=[I bid you greetings, $C.]=],[=[Zdravím tě, $C.]=]},
 },
 [1704]={
  progress={[=[Good day, or morning or evening. I can't tell from way down here. So do you have business for me?]=],[=[Dobrý den, ráno nebo večer. Odtud zespodu to nepoznám. Tak co, máš pro mě nějakou práci?]=]},
 },
 [1713]={
  progress={[=[$N, I must have the whirlwind heart!]=],[=[$N, musím mít whirlwind heart!]=]},
 },
 [1846]={
  progress={[=[I'm waiting for those shinbones, $N. They'll make a nice frame for your leg guards.]=],[=[Čekám na ty holenní kosti, $N. Budou z nich pěkné výztuhy pro tvé chrániče nohou.]=]},
 },
 [2602]={
  progress={[=[Have you returned with the requested organs?]=],[=[Vrátil ses s požadovanými orgány?]=]},
 },
 [2661]={
  progress={[=[Oh, $N, you're finally back.  What have you brought?]=],[=[Ach, $N, konečně jsi zpátky. Co jsi přinesl?]=]},
 },
 [2784]={
  progress={[=[Listen to what I have to say.]=],[=[Poslouchej, co ti chci říct.]=]},
 },
 [2801]={
  progress={[=[Listen to what I have to say, $N.]=],[=[Poslouchej, co ti chci říct, $N.]=]},
 },
 [2843]={
  progress={[=[It's ready!]=],[=[Je to připravené!]=]},
 },
 [2873]={
  progress={[=[Did you find my shipment of rum, $N?]=],[=[Našel jsi mou zásilku rumu, $N?]=]},
 },
 [2874]={
  progress={[=[Did Stoley cough up my booze?]=],[=[Vydal ze sebe Stoley můj chlast?]=]},
 },
 [2876]={
  progress={[=[You look out of breath.  You have something to tell me?]=],[=[Vypadáš zadýchaně. Máš mi něco říct?]=]},
 },
 [2882]={
  progress={[=[This chest is locked!]=],[=[Tahle truhla je zamčená!]=]},
 },
 [2903]={
  progress={[=[Welcome back $N - were you able to find some tangible evidence as to the plans of the gnolls?]=],[=[Vítej zpět, $N — podařilo se ti najít nějaký hmatatelný důkaz o plánech gnollů?]=]},
 },
 [2933]={
  progress={[=[Hello, gentle $C. The day has been long and not a single experiment successful...I hope you bring good news to me.]=],[=[Zdravím, laskavý $C. Den byl dlouhý a ani jeden experiment se nepovedl... doufám, že mi přinášíš dobré zprávy.]=]},
 },
 [2937]={
  progress={[=[Did you get the venom?]=],[=[Získal jsi ten jed?]=]},
 },
 [2942]={
  progress={[=[I am glad you have returned, $N. I am eager to hear of your findings.]=],[=[Jsem rád, že ses vrátil, $N. Už se nemohu dočkat, co jsi zjistil.]=]},
 },
 [2943]={
  progress={[=[Hello, $N. Have you been to Darnassus?]=],[=[Zdravím, $N. Byl jsi v Darnassusu?]=]},
 },
 [2967]={
  progress={[=[Welcome back $N.  Were you able to use the discs to your advantage, or was it for naught?]=],[=[Vítej zpět, $N. Podařilo se ti využít ty disky ve svůj prospěch, nebo to bylo k ničemu?]=]},
 },
 [2977]={
  progress={[=[Welcome back $N.  Were you able to use the discs to your advantage, or did it end up being a wild goose chase?]=],[=[Vítej zpět, $N. Podařilo se ti využít ty disky ve svůj prospěch, nebo z toho nakonec byla jen zbytečná honička?]=]},
 },
 [2978]={
  progress={[=[What is this?]=],[=[Co je tohle?]=]},
 },
 [2988]={
  progress={[=[Have you searched the cages, $N? We must find Sharpbeak!]=],[=[Prohledal jsi klece, $N? Musíme najít Sharpbeaka!]=]},
 },
 [2989]={
  progress={[=[Hurry, $N!  If the Vilebranch trolls have Sharpbeak, then who knows what they might be doing with him!]=],[=[Pospěš si, $N! Jestli mají Sharpbeaka trollové Vilebranch, kdo ví, co mu mohou dělat!]=]},
 },
 [2991]={
  progress={[=[Do you have Nekrum's Medallion, $N?  There are powers hidden within it that I am eager to discover.]=],[=[Máš Nekrum's Medallion, $N? Skrývá se v něm moc, kterou toužím odhalit.]=]},
 },
 [2994]={
  progress={[=[Save Sharpbeak!]=],[=[Zachraň Sharpbeaka!]=]},
 },
 [3002]={
  progress={[=[What have you brought me, $R?]=],[=[Co jsi mi přinesl, $R?]=]},
 },
 [3042]={
  progress={[=[Did you bring me the temper, $N?]=],[=[Přinesl jsi mi temper, $N?]=]},
 },
 [3122]={
  progress={[=[Have you spoken to Neeru?]=],[=[Mluvil jsi s Neeru?]=]},
 },
 [3141]={
  progress={[=[Do not interrupt me, $r.]=],[=[Nevyrušuj mě, $r.]=]},
 },
 [3367]={
  progress={[=[I'm not going to make it...]=],[=[Já to nezvládnu...]=]},
 },
 [3377]={
  progress={[=[Allow me to finish my story.]=],[=[Nech mě dokončit můj příběh.]=]},
 },
 [3441]={
  progress={[=[Allow me to finish mo... $r.]=],[=[Nech mě dokončit můj pří... $r.]=]},
 },
 [3453]={
  progress={[=[Do not interrupt the channeling process.]=],[=[Neruš proces channelingu.]=]},
 },
 [3507]={
  progress={[=[I remember you, $C. I asked you to go to Azshara to destroy that wench that betrayed me! That seems like many moons ago. Don't tell me that Ag'tor and the others are dead also!]=],[=[Pamatuji si tě, $C. Poslal jsem tě do Azshary zničit tu děvku, která mě zradila! Připadá mi to jako před mnoha měsíci. Neříkej mi, že Ag'tor a ostatní jsou také mrtví!]=]},
 },
 [3514]={
  progress={[=[We cannot allow the Alliance on our land, $N. Make this known.]=],[=[Nesmíme dovolit Alliance vstoupit na naši zem, $N. Dej jim to jasně najevo.]=]},
 },
 [3562]={
  progress={[=[Well, what did Magatha say? The old crone... I bet she was less than polite.]=],[=[Tak co řekla Magatha? Ta stará ježibaba... vsadím se, že zrovna zdvořilá nebyla.]=]},
 },
 [3564]={
  progress={[=[Have you met with Andron yet? He rarely leaves Undercity, so I don't think it'd be too hard to find him.]=],[=[Setkal ses už s Andronem? Undercity opouští jen zřídka, takže by nemělo být těžké ho najít.]=]},
 },
 [3565]={
  progress={[=[Well, what did Xylem have to say? He didn't do anything to you, did he? Cast a spell on you? Con you into doing work for him?]=],[=[Tak co říkal Xylem? Nic ti neudělal, že ne? Nesestrčil na tebe kouzlo? Nepřemluvil tě, abys pro něj něco udělal?]=]},
 },
 [3566]={
  progress={[=[I don't believe you! Show me proof!]=],[=[Nevěřím ti! Ukaž mi důkaz!]=]},
 },
 [3569]={
  progress={[=[I've come to Undercity because I heard their alchemists have been studying long and hard on how to find a cure for their own illness. It was suggested that perhaps they could help me too.$B$BAlthough this place makes me feel far from welcome, I had no choice--the sickness that found me is tearing me up inside and I needed their help immediately.]=],[=[Přišel jsem do Undercity, protože jsem slyšel, že zdejší alchymisté dlouho a usilovně hledají lék na vlastní nemoc. Někdo navrhl, že by možná mohli pomoci i mně.$B$BAčkoli se tady necítím ani trochu vítaný, neměl jsem na výběr — nemoc, která mě postihla, mě rozežírá zevnitř a jejich pomoc jsem potřeboval okamžitě.]=]},
 },
 [3702]={
  progress={[=[Allow me to finish telling you the story of Thaurissan.]=],[=[Nech mě dokončit vyprávění příběhu o Thaurissanovi.]=]},
 },
 [3845]={
  progress={[=[Hi there. I've seen you before... Haven't I?]=],[=[Ahoj. Už jsem tě někdy viděl... ne?]=]},
 },
 [3884]={
  progress={[=[Hello there!  I and my companions are happy to see some living beings here other than overgrown savage beasts!  What brings you into the Un'Goro Crater?]=],[=[Zdravím! Já i mí společníci jsme rádi, že tu kromě přerostlých divokých bestií vidíme také nějaké živé bytosti! Co tě přivádí do Un'Goro Crater?]=]},
 },
 [3913]={
  progress={[=[This must be the gravestone that Gaeriyan mentioned...]=],[=[Tohle musí být náhrobek, o kterém mluvil Gaeriyan...]=]},
 },
 [3914]={
  progress={[=[Oh! I remember you! You are... No, don't tell me!]=],[=[Ach! Už si vzpomínám! Ty jsi... Ne, neříkej mi to!]=]},
 },
 [3961]={
  progress={[=[Hi, again, $N!]=],[=[Znovu tě zdravím, $N!]=]},
 },
 [4022]={
  progress={[=[<Cyrus's eyes form two blazing spheres.>]=],[=[<Cyrusovy oči se promění ve dvě planoucí koule.>]=]},
 },
 [4023]={
  progress={[=[<Cyrus's eyes form two blazing spheres.>]=],[=[<Cyrusovy oči se promění ve dvě planoucí koule.>]=]},
 },
 [4186]={
  progress={[=[Any news from Bolvar?]=],[=[Nějaké zprávy od Bolvara?]=]},
 },
 [4245]={
  progress={[=[Have you been able to help A-Me? That mithril casing you mentioned being destroyed was a good guess at what was wrong. I'm sure if you replace that, she'll reactivate and be able to come home.]=],[=[Podařilo se ti pomoci A-Me? To, že byla zničena ta mithril casing, byl dobrý odhad toho, co je špatně. Jsem si jistý, že když ji nahradíš, znovu se aktivuje a bude se moci vrátit domů.]=]},
 },
 [4292]={
  progress={[=[Do not let fear overpower you, $N. Fear is the great betrayer... you must remain strong!$B$BTake the meat, place it in the small valley, and then use the gland on it. Only then will death come for you.]=],[=[Nenech strach, aby tě ovládl, $N. Strach je velký zrádce... musíš zůstat silný!$B$BVezmi maso, polož ho do malého údolí a potom na něj použij žlázu. Teprve pak si pro tebe přijde smrt.]=]},
 },
 [4322]={
  progress={[=[You look exhausted, $n. Perhaps you should have a seat by the fire and relax.]=],[=[Vypadáš vyčerpaně, $n. Možná by sis měl sednout k ohni a odpočinout si.]=]},
 },
 [4342]={
  progress={[=[Allow me to finish telling my story.]=],[=[Nech mě dokončit můj příběh.]=]},
 },
 [4451]={
  progress={[=[*cough*$B$BWho is it? Can't ya see I'm busy?]=],[=[*kašel*$B$BKdo je tam? Nevidíš, že mám práci?]=]},
 },
 [4492]={
  progress={[=[Wha... What?]=],[=[Co... cože?]=]},
 },
 [4581]={
  progress={[=[Do you have something for me?]=],[=[Máš pro mě něco?]=]},
 },
 [4641]={
  progress={[=[The carapace of a scorpid isn't so thick that the strength of a determined $C will be deterred. Strike strongly and without doubt, and the scorpids should prove easy prey.]=],[=[Krunýř scorpida není tak silný, aby odolal síle odhodlaného $C. Udeř pevně a bez zaváhání a scorpidi by pro tebe měli být snadnou kořistí.]=]},
 },
 [4786]={
  progress={[=[A moment, $n...]=],[=[Okamžik, $n...]=]},
 },
 [4809]={
  progress={[=[Do you have the chillwind horns, $N?]=],[=[Máš chillwind horns, $N?]=]},
 },
 [4810]={
  progress={[=[$N! Did you talk to Felnok? Did you bring the components I need?]=],[=[$N! Mluvil jsi s Felnokem? Přinesl jsi součástky, které potřebuji?]=]},
 },
 [4841]={
  progress={[=[Come now $N, I know you haven't killed your share yet. Hunt them down, and I shall give you a reward for my gratitude.]=],[=[No tak, $N, vím, že jsi jich ještě nezabil dost. Lov je a za tvou pomoc tě odměním.]=]},
 },
 [4867]={
  progress={[=[Ah! Do you have my mojo?]=],[=[Ach! Máš moje mojo?]=]},
 },
 [4882]={
  progress={[=[Reporting for another assignment?]=],[=[Hlásíš se pro další úkol?]=]},
 },
 [4970]={
  progress={[=[Discipline and determination are your goals. I may ask you to do a simple task many times; you must perform to the best of your ability each time.]=],[=[Tvými cíli jsou disciplína a odhodlání. Možná tě požádám, abys jednoduchý úkol splnil mnohokrát; pokaždé ho musíš provést, jak nejlépe umíš.]=]},
 },
 [4976]={
  progress={[=[How goes your search for Tabetha and the orb, $N?$B$BTabetha has been more than useful when it comes to matters of the arcane. I'm sure she would have no problem aiding you if you're able to find her.]=],[=[Jak pokračuje hledání Tabethy a orbu, $N?$B$BTabetha byla v otázkách arkánní magie vždy víc než užitečná. Jsem si jistý, že ti ráda pomůže, pokud ji dokážeš najít.]=]},
 },
 [5055]={
  progress={[=[Brumeran calls out to you, $N.]=],[=[Brumeran na tebe volá, $N.]=]},
 },
 [5089]={
  progress={[=[What have you got there, $N?]=],[=[Copak to tam máš, $N?]=]},
 },
 [5123]={
  progress={[=[Now, what's this, $N?]=],[=[Tak co je tohle, $N?]=]},
 },
 [5126]={
  progress={[=[...]=],[=[...]=]},
 },
 [5154]={
  progress={[=[Did you find the book, $N?]=],[=[Našel jsi tu knihu, $N?]=]},
 },
 [5165]={
  progress={[=[The braziers must be extinguished if we are to have any hope of being prepared for a much greater battle. Going in to the dragon's lair without any knowledge is a fool's errand. And this is much worse than a dragon. The Shadow Council are solely responsible for a great number of crimes and atrocities. We'll have to work quickly if we're to stop them.]=],[=[Musíme uhasit braziery, pokud se vůbec chceme připravit na mnohem větší bitvu. Vydat se do dračího doupěte bez jakýchkoli znalostí je bláznovství. A tohle je mnohem horší než drak. Shadow Council je sám zodpovědný za obrovské množství zločinů a zvěrstev. Jestli je chceme zastavit, musíme jednat rychle.]=]},
 },
 [5202]={
  progress={[=[I begin to wonder if I'll ever escape this cage.$B$BIt's only a matter of time before they sacrifice me to whatever demons they worship. The monsters!]=],[=[Začínám pochybovat, že z téhle klece někdy uniknu.$B$BJe jen otázkou času, než mě obětují démonům, které uctívají. Ty zrůdy!]=]},
 },
 [5210]={
  progress={[=[You've come from the west? How fare the rest of Lordaeron? I know that Andorhal is lost, but has the Scourge yet reached fair Tirisfal?]=],[=[Přicházíš ze západu? Jak se daří zbytku Lordaeronu? Vím, že Andorhal je ztracen, ale dosáhl už Scourge i krásného Tirisfalu?]=]},
 },
 [5217]={
  progress={[=[Welcome back to the relative safety of Chillwind Camp, $N.  What progress on the cauldrons do you have to report?]=],[=[Vítej zpět v relativním bezpečí Chillwind Camp, $N. Jaký pokrok u kotlů můžeš hlásit?]=]},
 },
 [5220]={
  progress={[=[We know that each cauldron employs a different mix of reagents to generate its plague-inducing toxin; likewise, we know that we will need to develop a counter agent that is unique for each cauldron. Your sample from Dalson's Tears will be the key to figure out that cauldron's distinct reagent requirement.]=],[=[Víme, že každý kotel používá jinou směs činidel k výrobě toxinu vyvolávajícího mor; stejně tak víme, že pro každý kotel budeme muset vyvinout jedinečnou protilátku. Tvůj vzorek z Dalson's Tears bude klíčem k určení přesných požadavků tohoto kotle na činidla.]=]},
 },
 [5223]={
  progress={[=[Once we successfully analyze the sample drawn from the Writhing Haunt's cauldron, it will provide us with a third avenue to deliver a devastating counter agent onto the Scourge!]=],[=[Jakmile úspěšně zanalyzujeme vzorek odebraný z kotle ve Writhing Haunt, získáme třetí cestu, jak proti Scourge nasadit ničivou protilátku!]=]},
 },
 [5230]={
  progress={[=[Welcome back to the relative safety of the Bulwark, $N. What progress on the cauldrons do you have to report?]=],[=[Vítej zpět v relativním bezpečí Bulwarku, $N. Jaký pokrok u kotlů můžeš hlásit?]=]},
 },
 [5232]={
  progress={[=[We know that each cauldron employs a different mix of reagents to generate its plague-inducing toxin; likewise, we know that we will need to develop a counter agent that is unique for each cauldron. Your sample from Dalson's Tears will be the key to figure out that cauldron's distinct reagent requirement.]=],[=[Víme, že každý kotel používá jinou směs činidel k výrobě toxinu vyvolávajícího mor; stejně tak víme, že pro každý kotel budeme muset vyvinout jedinečnou protilátku. Tvůj vzorek z Dalson's Tears bude klíčem k určení přesných požadavků tohoto kotle na činidla.]=]},
 },
 [5234]={
  progress={[=[Once we successfully analysis the sample drawn from the Writhing Haunt's cauldron, it will provide us with a third avenue to deliver a devastating counter agent against the Scourge!]=],[=[Jakmile úspěšně zanalyzujeme vzorek odebraný z kotle ve Writhing Haunt, získáme třetí cestu, jak proti Scourge nasadit ničivou protilátku!]=]},
 },
 [5236]={
  progress={[=[Gahrron's Withering houses the last cauldron that we need to acquire access to here in the west. Once we have a sample of the plague from that cauldron, we will be able to introduce our reagents into the environment through four separate vessels! The Scourge will be hard pressed to keep us out of all four, even with the power of Kel'Thuzad behind them.]=],[=[V Gahrron's Withering se nachází poslední kotel, ke kterému zde na západě potřebujeme získat přístup. Jakmile budeme mít vzorek moru z tohoto kotle, dokážeme zavést naše činidla do prostředí prostřednictvím čtyř různých nádob! Scourge bude mít velké potíže udržet nás dál od všech čtyř, i s Kel'Thuzadovou mocí za zády.]=]},
 },
 [5242]={
  progress={[=[Without Fel'dan, the Shadow Council will hopefully lose focus and start infighting. They will struggle with one another for control and hoard assets for future plans. That will be an opportune time to devastate them and their demon slaves.]=],[=[Bez Fel'dana snad Shadow Council ztratí soustředění a začne bojovat sám mezi sebou. Budou soupeřit o kontrolu a hromadit prostředky pro budoucí plány. To bude ideální chvíle udeřit na ně i jejich démonické otroky.]=]},
 },
 [5305]={
  progress={[=[His apron! Where is it?]=],[=[Jeho zástěra! Kde je?]=]},
 },
 [5385]={
  progress={[=[How did things go in Jaedenar, $N?]=],[=[Jak to dopadlo v Jaedenaru, $N?]=]},
 },
 [5464]={
  progress={[=[<Leonid shudders.>]=],[=[<Leonid se zachvěje.>]=]},
 },
 [5465]={
  progress={[=[Have you done the impossible?]=],[=[Dokázal jsi nemožné?]=]},
 },
 [5582]={
  progress={[=[$N, do you have something to show me?]=],[=[$N, máš mi něco ukázat?]=]},
 },
 [5742]={
  progress={[=[Please, friend; sit and hear my tale.]=],[=[Prosím, příteli, posaď se a vyslechni můj příběh.]=]},
 },
 [5942]={
  progress={[=[This chest is old and covered in grime.]=],[=[Tahle truhla je stará a pokrytá špínou.]=]},
 },
 [6032]={
  progress={[=[Have you brought the mooncloth, $N?]=],[=[Přinesl jsi mooncloth, $N?]=]},
 },
 [6161]={
  progress={[=[This chest is securely locked.]=],[=[Tahle truhla je bezpečně zamčená.]=]},
 },
 [6389]={
  progress={[=[Have you done it, $N? Have you released the termites? The Light help us if the Scarlet Crusade were able to hold onto both the mill and Hearthglen. They should have neither. They're just capitalizing on the victims of the last war and should be put down like rabid animals!]=],[=[Udělal jsi to, $N? Vypustil jsi termity? Kéž nám Světlo pomůže, kdyby Scarlet Crusade dokázala udržet jak pilu, tak Hearthglen. Neměli by mít ani jedno. Jen využívají oběti poslední války a měli by být utraceni jako vzteklá zvířata!]=]},
 },
 [6390]={
  progress={[=[Have you done it, $N? Have you released the termites in the lumber mill?$B$BIt was bad enough that my family lost their jobs and lives, but then to see the place where my childhood was spent taken over by those disgusting so-called holy men... pfah!!]=],[=[Udělal jsi to, $N? Vypustil jsi termity do pily?$B$BUž tak bylo dost zlé, že má rodina přišla o práci i životy, ale pak ještě vidět místo mého dětství obsazené těmi odpornými samozvanými svatými muži... pfah!!]=]},
 },
 [6482]={
  progress={[=[Have you seen my brother Ruul? He walked into the forest days ago and has not returned...]=],[=[Viděl jsi mého bratra Ruula? Před několika dny odešel do lesa a stále se nevrátil...]=]},
 },
 [6544]={
  progress={[=[Torek was sent on a mission against Silverwing Outpost. Was the attack successful?]=],[=[Torek byl vyslán na misi proti Silverwing Outpost. Byl útok úspěšný?]=]},
 },
 [6566]={
  progress={[=[Patience, $N. Pay attention!]=],[=[Trpělivost, $N. Dávej pozor!]=]},
 },
 [6627]={
  progress={[=[Life is full of questions, $C. You will never be able to answer all of them, but with some time and study, perhaps you will become a little more knowledgeable.]=],[=[Život je plný otázek, $C. Nikdy nebudeš znát odpověď na všechny, ale s trochou času a studia možná budeš o něco moudřejší.]=]},
 },
 [7064]={
  progress={[=[I would prefer to fight this battle on our own, but we are left with no other options--we need those more powerful, and the races of Azeroth have proven without a doubt they can overcome such things when they work together. So it is to you we turn for help.$B$BI only hope it is enough.$B$BZaetar, brother to Remulos, brought many pains to this world, and ultimately it caused his own death. I just hope I have not caused more death by asking you to aid us.]=],[=[Raději bych tuto bitvu vybojoval vlastními silami, ale nezbývá nám jiná možnost — potřebujeme mocnější spojence a rasy Azerothu bezpochyby dokázaly, že když spolupracují, dokážou takovým hrozbám čelit. Proto se obracíme na tebe.$B$BJen doufám, že to bude stačit.$B$BZaetar, Remulosův bratr, přinesl tomuto světu mnoho utrpení a nakonec ho to stálo život. Jen doufám, že jsem tím, že jsem tě požádal o pomoc, nezpůsobil další smrt.]=]},
 },
 [7223]={
  progress={[=[Did you bring any armor scraps, $N?]=],[=[Přinesl jsi nějaké kusy zbroje, $N?]=]},
 },
 [7224]={
  progress={[=[How goes the hunting, $N. Do you have any armor scraps for me?]=],[=[Jak jde lov, $N? Máš pro mě nějaké kusy zbroje?]=]},
 },
 [7490]={
  progress={[=[<Thrall's stoic demeanor changes for a split second when he sees the enormous head of Onyxia. The mighty Doomhammer was nearly unsheathed.>]=],[=[<Thrallův stoický výraz se na okamžik změní, když spatří obrovskou Onyxiinu hlavu. Mocný Doomhammer byl téměř vytažen z pouzdra.>]=]},
 },
 [7495]={
  progress={[=[By Uther's beard!]=],[=[Při Utherových vousech!]=]},
 },
 [7498]={
  progress={[=[You have recovered a tome!]=],[=[Získal jsi svazek!]=]},
 },
 [7499]={
  progress={[=[You have recovered a tome!]=],[=[Získal jsi svazek!]=]},
 },
 [7500]={
  progress={[=[You have recovered a tome!]=],[=[Získal jsi svazek!]=]},
 },
 [7501]={
  progress={[=[You have recovered a tome!]=],[=[Získal jsi svazek!]=]},
 },
 [7502]={
  progress={[=[You have recovered a tome!]=],[=[Získal jsi svazek!]=]},
 },
 [7503]={
  progress={[=[You have recovered a tome!]=],[=[Získal jsi svazek!]=]},
 },
 [7504]={
  progress={[=[You have recovered a tome!]=],[=[Získal jsi svazek!]=]},
 },
 [7505]={
  progress={[=[You have recovered a tome!]=],[=[Získal jsi svazek!]=]},
 },
 [7506]={
  progress={[=[You have recovered a tome!]=],[=[Získal jsi svazek!]=]},
 },
 [7507]={
  progress={[=[Ah, one of our greatest compilations. This one has been missing for ages.]=],[=[Ach, jedna z našich nejvýznamnějších kompilací. Tahle byla ztracená celé věky.]=]},
 },
 [7508]={
  progress={[=[Excellent, let us begin...]=],[=[Výborně, začněme...]=]},
 },
 [7564]={
  progress={[=[You have something for me?  It's not a big, juicy spider, is it?  Or maybe a roach?  I hope it's still alive... I so love chewing on them when they're still alive...]=],[=[Něco pro mě máš? Není to velký šťavnatý pavouk, že ne? Nebo snad šváb? Doufám, že je pořád živý... tak rád je žvýkám, když ještě žijí...]=]},
 },
 [7627]={
  progress={[=[The Wheel of the Black March isn't easy to make, and takes a lot of materials. Have you gathered them yet?]=],[=[Wheel of the Black March není snadné vyrobit a vyžaduje spoustu materiálu. Už jsi všechno shromáždil?]=]},
 },
 [7639]={
  progress={[=[Welcome back, $N. Have you acquired the exorcism censer?]=],[=[Vítej zpět, $N. Získal jsi exorcism censer?]=]},
 },
}
for id,fields in pairs(entries) do
 local entry=A.QuestEntries[id] or {}; A.QuestEntries[id]=entry
 for field,row in pairs(fields) do if not entry[field] then entry[field]=row end end
end
