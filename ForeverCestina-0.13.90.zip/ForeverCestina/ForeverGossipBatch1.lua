-- Forever-only / changed NPC Gossip translations from persistent offline Forever source pool.
-- Data-only batch for ForeverCestina 0.13.71; runtime logic remains unchanged.
local _, A = ...
A.GossipEntries = A.GossipEntries or {}
local E = A.GossipEntries
local function add(npc,en,cs)
 E[#E+1]={npc=npc,en=en,cs=cs}
end
-- source_id 1
add("Alessandro Luca","Yes, I see that. I can't say I'm pleased yet another one of my brilliant concoctions has been wasted.","Ano, vidím to. Nemůžu říct, že mě těší, že další z mých geniálních směsí přišla nazmar.")
-- source_id 2
add("Apothecary Helbrim","The Barrens holds a wealth of substances for which we, the apothecaries or Lordaeron, may find use.","The Barrens ukrývá množství látek, pro které bychom my, lordaeronští lékárníci, mohli najít využití.")
-- source_id 3
add("Apothecary Renferrel","The Dark Lady has put the challenge forth.  Now it is up to the Royal Apothecary Society to develop a new plague.  We shall bring Arthas and his wretched army to their knees.","Temná paní před nás postavila výzvu. Teď je na Královské lékárnické společnosti, aby vyvinula nový mor. Srazíme Arthase i jeho prokletou armádu na kolena.")
-- source_id 4
add("Aramis Hammerhand","Welcome back to the light, friend. Do you require training?","Vítej zpět ve světle, příteli. Potřebuješ výcvik?")
-- source_id 5
add("Archaeologist Hollee","Who would have guessed the excavation would have uncovered such findings!","Kdo by byl řekl, že vykopávky odhalí něco takového!")
-- source_id 6
add("Arnold Leland","Ah, a fellow Fisherman. Are you perhaps in need of a little training? Maybe I can show you a thing or two?","Ach, kolega rybář. Nepotřebuješ trochu výcviku? Možná bych ti mohl ukázat pár triků.")
add("Baelann Swiftcurrent","Ah, a fellow Fisherman. Are you perhaps in need of a little training? Maybe I can show you a thing or two?","Ach, kolega rybář. Nepotřebuješ trochu výcviku? Možná bych ti mohl ukázat pár triků.")
-- source_id 7
add("Borstan","I have the finest meats in Orgrimmar.","Mám to nejlepší maso v Orgrimmaru.")
-- source_id 8
add("Brakk","Greetings, traveler.","Zdravím, poutníku.")
add("Eleanor Shackleton","Greetings, traveler.","Zdravím, poutníku.")
add("Eric Brighthammer","Greetings, traveler.","Zdravím, poutníku.")
add("Lyreena Duskblade","Greetings, traveler.","Zdravím, poutníku.")
add("Raan Wildwind","Greetings, traveler.","Zdravím, poutníku.")
add("Zor Lonetree","Greetings, traveler.","Zdravím, poutníku.")
-- source_id 9
add("Branstock Khalder","Serve the Light well, $c.","Služ Světlu dobře, $c.")
add("Maxan Anvol","Serve the Light well, $c.","Služ Světlu dobře, $c.")
-- source_id 10
add("Daeann Steelwind","Winds tidings. What can I help you with?","Větry nesou zprávy. S čím ti mohu pomoci?")
add("Iaadaria Bitterwind","Winds tidings. What can I help you with?","Větry nesou zprávy. S čím ti mohu pomoci?")
add("Othesia Evengale","Winds tidings. What can I help you with?","Větry nesou zprávy. S čím ti mohu pomoci?")
add("Valiena Swiftgale","Winds tidings. What can I help you with?","Větry nesou zprávy. S čím ti mohu pomoci?")
-- source_id 11
add("Dalar Dawnweaver","The Kirin Tor did not heed my warnings! The Alliance is a sham. Arugal is a reckless fool.","Kirin Tor nedbal mých varování! Aliance je fraška. Arugal je nezodpovědný hlupák.")
-- source_id 12
add("Dane Winslow","Want to make your demons more powerful?  It'll cost you, but you've come to the right place.","Chceš, aby tvoji démoni byli silnější? Něco tě to bude stát, ale jsi na správném místě.")
add("Kitha","Want to make your demons more powerful?  It'll cost you, but you've come to the right place.","Chceš, aby tvoji démoni byli silnější? Něco tě to bude stát, ale jsi na správném místě.")
add("Martha Strain","Want to make your demons more powerful?  It'll cost you, but you've come to the right place.","Chceš, aby tvoji démoni byli silnější? Něco tě to bude stát, ale jsi na správném místě.")
-- source_id 13
add("Daniel","What does Brother Paxton need now?","Co teď Brother Paxton potřebuje?")
-- source_id 14
add("Danitha Morr","Welcome to Bandarion Keep, $c.","Vítej v Bandarion Keep, $c.")
-- source_id 15
add("Deputy Willem","Hello there, $c.  Normally I'd be out on the beat looking after the folk of Stormwind, but a lot of the Stormwind guards are fighting in other lands.  So here I am, deputized and offering bounties when I'd rather be on patrol...","Zdravím, $c. Normálně bych byl venku na obchůzce a dohlížel na obyvatele Stormwindu, jenže spousta stormwindských stráží bojuje v jiných zemích. A tak tu jsem, pověřený službou a vypisuji odměny, i když bych byl raději na hlídce...")
-- source_id 16
add("Dokimi","We've had trouble with shipments going missing across Azeroth. If you find any, I'd appreciate if you could return them to me.","Máme potíže se zásilkami, které mizí po celém Azerothu. Pokud nějakou najdeš, ocenil bych, kdybys mi ji vrátil.")
add("Marcy Baker","We've had trouble with shipments going missing across Azeroth. If you find any, I'd appreciate if you could return them to me.","Máme potíže se zásilkami, které mizí po celém Azerothu. Pokud nějakou najdeš, ocenil bych, kdybys mi ji vrátil.")
-- source_id 17
add("Gar'Thok","Throm'ka, $c. There is little time for talk and much work to be done.","Throm'ka, $c. Na řeči je málo času a práce je před námi víc než dost.")
-- source_id 18
add("High Executor Hadrec","Hello, $C.  If you're here, then you must know that Silverpine is saturated with our enemies.  To survive, the Forsaken must drive them back!","Zdravím, $C. Jestli jsi tady, pak jistě víš, že Silverpine je plný našich nepřátel. Pokud mají Forsaken přežít, musíme je zatlačit zpět!")
-- source_id 19
add("Keeper Bel'dugur","Knowledge is both tool and weapon to those with the will to use it.","Poznání je nástrojem i zbraní pro ty, kteří mají vůli jej využít.")
-- source_id 20
add("Kelsey Fargo","Blast these kobolds. I can't get any work done with them running back and forth, getting in my way. Well, I've got nothing better to do, would you like to learn about mining techniques? Or perhaps you just need some new tools?","Proklatí koboldi. Nemůžu nic udělat, jak pořád pobíhají sem a tam a pletou se mi pod nohy. No, stejně teď nemám nic lepšího na práci. Chceš se něco naučit o těžbě? Nebo jen potřebuješ nové nástroje?")
-- source_id 21
add("Master Apothecary Faranell","The Royal Apothecary Society shall heed The Dark Lady's call to uncover the New Plague and drive Arthas and his heathen Scourge Army from the world once and for all.","Královská lékárnická společnost vyslyší volání Temné paní, odhalí tajemství Nového moru a jednou provždy vyžene Arthase i jeho bezbožnou armádu Pohromy z tohoto světa.")
-- source_id 22
add("Master Gadrin","There is something you wish to discuss, $c... come, sit by me.","Přeješ si něco probrat, $c... pojď, posaď se ke mně.")
-- source_id 23
add("Master Vornal","The sands of Durotar are tough and dry compared to the tropical and lush lands we're from, but we Darkspear persevere. Where chief Vol'jin leads, we will follow.","Písky Durotaru jsou drsné a suché ve srovnání s tropickými, bujnými kraji, odkud pocházíme, ale my Darkspear vytrváme. Kam nás náčelník Vol'jin povede, tam půjdeme.")
-- source_id 24
add("Nazgrel","Mind yourself in the presence of the Warchief, $c. The Kor'kron will suffer no insolence or insult here.","Dávej si v přítomnosti Warchiefa pozor, $c. Kor'kron tu nestrpí žádnou drzost ani urážku.")
-- source_id 25
add("Nyalah Brightfire","I don't get too many cooks in here looking for training, but I guess I could teach you something if you're ready.","Moc kuchařů sem na výcvik nechodí, ale pokud jsi připraven, asi bych tě něco naučit mohl.")
add("Stephen Ryback","I don't get too many cooks in here looking for training, but I guess I could teach you something if you're ready.","Moc kuchařů sem na výcvik nechodí, ale pokud jsi připraven, asi bych tě něco naučit mohl.")
-- source_id 26
add("Orgnil Soulscar","Hail.  Be brief, for we both have much to do.","Buď zdráv. Mluv stručně, oba máme spoustu práce.")
-- source_id 27
add("Pix Xizzix","Impulse purchases are the most fun kind of purchases!","Impulzivní nákupy jsou ze všech nejzábavnější!")
-- source_id 28
add("Rahauro","Please, feel free to speak to me anytime, $N. You have served Magatha well. I am sure she will call upon you in the future.","Kdykoli se mnou klidně promluv, $N. Magatě jsi dobře posloužil. Jsem si jistý, že tě v budoucnu znovu povolá.")
-- source_id 29
add("Rane Yorick","My brother and I are on a vital mission, but we are holed up in this farmhouse.  The Deathstalkers need your help.","Můj bratr a já jsme na důležité misi, ale uvízli jsme v tomto statku. Deathstalkeři potřebují tvou pomoc.")
-- source_id 30
add("Sam Sarsaparilla","Howdy there, traveler!","Nazdar, poutníku!")
-- source_id 31
add("Sergra Darkthorn","The land, the water, and the sky are all as one. It is your eyes that deceive you with such separation. The Earthmother is all those things and more.","Země, voda i nebe jsou jedno. Jen tvé oči tě klamou, když je vidí odděleně. Earthmother je tím vším a ještě mnohem víc.")
-- source_id 32
add("Shadow Priest Allister","Information... With our scouts and agents, we control the flow of information in Lordaeron. Scourge movements, their holdings, all underneath our watchful eyes...","Informace... Díky našim zvědům a agentům řídíme tok informací v Lordaeronu. Pohyb Pohromy, její pozice... nic neunikne našim bdělým očím.")
-- source_id 33
add("Smith Argus","If you'd like to learn how to blacksmith your own weapons and armor, I'd be happy to help.","Pokud se chceš naučit kovat vlastní zbraně a zbroj, rád ti pomohu.")
-- source_id 35
add("Sputtervalve","Director Riddlevox put me in charge of the Union's shredder development program. Few months on the job and I'm already in hot water! I could use your help, $N!","Director Riddlevox mě pověřil vývojovým programem drtičů Unie. Jsem tu pár měsíců a už mám pořádný problém! Tvoje pomoc by se mi hodila, $N!")
-- source_id 36
add("Tabitha Heartweaver","Praise to the Banshee Queen, it isn't often I have visitors out here.","Sláva Banshee Queen, návštěvy tu nemívám často.")
-- source_id 37
add("Talin Keeneye","Greetings, $c! Fine day for hunting, wouldn't you say? I've been having more than a little luck with boars, myself. Perhaps you'd like a shot?","Zdravím, $c! Krásný den na lov, nemyslíš? Mně samotnému se s kanci daří víc než dobře. Nechceš to také zkusit?")
-- source_id 38
add("Tordrin Sternblade","I heard ol' Marshal McBride was sendin' ye' my way.","Slyšel jsem, že tě ke mně posílá starej Marshal McBride.")
-- source_id 39
add("Trevan Rol","In the darkest of nights, trust in the light to protect you. Of course, having a nice, sturdy mace doesn't hurt either.","I v nejtemnější noci důvěřuj světlu, že tě ochrání. Samozřejmě ani pořádný, pevný palcát neuškodí.")
-- source_id 40
add("Unfinished Abomination","<The body looks incomplete and awaiting a head.>","<Tělo vypadá neúplně, jako by mu chyběla hlava.>")
-- source_id 41
add("Vol'jin","I am Vol'jin, of the Darkspear. Do you be friend, or enemy?","Jsem Vol'jin z Darkspear. Jsi přítel, nebo nepřítel?")
-- source_id 42
add("Warcaller Gorlach","Your legacy precedes you, $c. If you wish, I can allow you to rewrite that legacy into something new.","Tvůj odkaz tě předchází, $c. Pokud si přeješ, mohu ti dovolit přepsat jej v něco nového.")
-- source_id 45
add("Alba Fairmoon","I am told the farms of Westfall once supplied a bounty of crops for Stormwind. But now, the soil is barren and most of the farmers have fled.\r\n\r\nOn behalf of Darnassus I would like to offer my aid in replenishing this land. Will you assist me?","Říká se, že farmy ve Westfallu kdysi zásobovaly Stormwind bohatou úrodou. Teď je však půda neúrodná a většina farmářů uprchla.\n\nJménem Darnassu bych chtěl nabídnout pomoc při obnově této země. Pomůžeš mi?")
-- source_id 46
add("Aldia","Greetings.","Zdravím.")
add("Brom Killian","Greetings.","Zdravím.")
add("Morhan Coppertongue","Greetings.","Zdravím.")
-- source_id 47
add("Alessandro Luca","<Alessandro lets out a frustrated sigh and pinches the bridge of his nose with boney fingers.>\r\n\r\nFine. Yes, give it here. At least I can reuse the glass vial.","<Alessandro podrážděně vzdychne a kostnatými prsty si sevře kořen nosu.>\n\nDobře. Ano, dej to sem. Alespoň budu moci znovu použít skleněnou lahvičku.")
-- source_id 48
add("Alynsia","You look like you could use a few enchants. You have come to the right place!","Vypadáš, že by se ti hodilo pár očarování. Jsi na správném místě!")
-- source_id 49
add("Anathamaas Aetherwind","The followers of the old Highborne ways have never been more hungry for knowledge and to reclaim what we've lost. If you would seek to wield the power of the arcane and have the aptitude, I can help you take your next steps.","Stoupenci starých tradic Highborne nikdy netoužili po vědění a znovuzískání toho, co jsme ztratili, více než dnes. Pokud chceš ovládnout sílu arkány a máš pro ni nadání, mohu ti pomoci udělat další kroky.")
add("Dorii Brightwhisper","The followers of the old Highborne ways have never been more hungry for knowledge and to reclaim what we've lost. If you would seek to wield the power of the arcane and have the aptitude, I can help you take your next steps.","Stoupenci starých tradic Highborne nikdy netoužili po vědění a znovuzískání toho, co jsme ztratili, více než dnes. Pokud chceš ovládnout sílu arkány a máš pro ni nadání, mohu ti pomoci udělat další kroky.")
add("Shenaan Spellwind","The followers of the old Highborne ways have never been more hungry for knowledge and to reclaim what we've lost. If you would seek to wield the power of the arcane and have the aptitude, I can help you take your next steps.","Stoupenci starých tradic Highborne nikdy netoužili po vědění a znovuzískání toho, co jsme ztratili, více než dnes. Pokud chceš ovládnout sílu arkány a máš pro ni nadání, mohu ti pomoci udělat další kroky.")
-- source_id 50
add("Ander Solliden","In my previous life, I lived nearby here. I still wander the fields of my childhood farmstead occasionally. It fills me with sadness to see those I knew and loved, shambling around as mindless thralls. It pains me, but its that very pain that gives me strength and purpose.","V předchozím životě jsem bydlel nedaleko odsud. Občas se ještě procházím po polích statku, kde jsem vyrůstal. Naplňuje mě smutkem vidět ty, které jsem znal a miloval, jak se potácejí kolem jako bezduzí otroci. Bolí to, ale právě ta bolest mi dává sílu a smysl.")
-- source_id 51
add("Ander Solliden","Mostly the usual. Murloc attacks, the occasional Scarlet Crusade skirmish. There are even some paladins that can't quite adjust to life as a Forsaken. Far too often we have to put those down that turn their blades upon their brothers. \r\n\r\nBy far the worst is when some mindless thrall wanders too close. I can kill murlocs all day, but some of the scourge I've had to destroy were former friends of mine. Some were even family members.\r\n\r\nI'd rather it be me who puts them down than some random adventurer, but it still stings.","Většinou nic neobvyklého. Útoky murloků, občasná potyčka se Scarlet Crusade. Jsou tu dokonce paladinové, kteří se nedokážou vyrovnat se životem Forsaken. Až příliš často musíme skolit ty, kteří obrátí své čepele proti vlastním bratrům.\n\nNejhorší je, když se příliš přiblíží nějaký bezduchý otrok. Murloky můžu zabíjet celý den, ale někteří příslušníci Pohromy, které jsem musel zničit, bývali mými přáteli. Někteří dokonce členy rodiny.\n\nRaději je ukončím sám, než aby to udělal nějaký náhodný dobrodruh, ale pořád to bolí.")
-- source_id 52
add("Angus Hammerhand","It's my job to get the Paladins of Bandarion Keep set up with proper arms and armor. It's not much, but it's honest work.\r\n\r\nI've got a thing or two for sale as well, should you need gear.","Mým úkolem je zajistit paladinům z Bandarion Keep pořádné zbraně a zbroj. Není to nic velkého, ale je to poctivá práce.\n\nKdybys potřeboval výbavu, mám také pár věcí na prodej.")
-- source_id 53
add("Apothecary Durelle","Please do not touch the vials unless you intend to purchase one.\r\n\r\nFingerprints ruin the value, you see.","Prosím, nedotýkej se lahviček, pokud si některou nechceš koupit.\n\nOtisky prstů snižují jejich hodnotu, víš.")
-- source_id 54
add("Apothecary Johaan","The Dark Lady has put forth the challenge.  It is up to us to meet it.","Temná paní před nás postavila výzvu. Je na nás, abychom ji přijali.")
-- source_id 55
add("Baine Bloodhoof","The land has been good to our people, $c. We must be thankful for our good fortune.","Země byla k našemu lidu štědrá, $c. Musíme být vděční za své štěstí.")
-- source_id 56
add("Baros Alexston","Greetings, I am Baros Alexston, City Architect of Stormwind.","Zdravím, jsem Baros Alexston, městský architekt Stormwindu.")
-- source_id 57
add("Beaten Corpse","The body is that of a female orc warrior.\n\nIt is clear that she died in battle, probably against the quilboar in the area.","Tělo patří orčí válečnici.\n\nJe zřejmé, že zemřela v boji, nejspíš proti quilboarům v okolí.")
-- source_id 58
add("Beaten Corpse","You turn the body over and see the marks from blades and spells upon the deceased orc--her armor all but destroyed, her hair matted to her face.\n\nBased on Mankrik's description of her, there is no doubt in your mind that this was his wife.\n\nHe will be upset by the news, but you are sure he should know the truth.","Obrátíš tělo a spatříš stopy čepelí a kouzel na mrtvé orčici — její zbroj je téměř zničená a vlasy má přilepené k obličeji.\n\nPodle Mankrikova popisu není pochyb, že to byla jeho žena.\n\nTa zpráva ho zdrtí, ale víš, že by měl znát pravdu.")
-- source_id 59
add("Bengus Deepforge","I'm sorry lad but ye just don't have the foundation to learn what I have to teach. But don't fret, go speak with my student Rotgath, he'll help ye out.","Promiň, chlapče, ale zatím nemáš potřebné základy, abys pochopil to, co učím. Ale netrap se. Promluv si s mým žákem Rotgathem, ten ti pomůže.")
-- source_id 60
add("Blademaster Ren","The $c who flinches is the $c who dies. If you would look death in the face as a $c, I will teach you how not to flinch.","$c, který ucukne, je mrtvý $c. Pokud se jako $c dokážeš dívat smrti do tváře, naučím tě, jak necuknout.")
add("Corsan Earthrazer","The $c who flinches is the $c who dies. If you would look death in the face as a $c, I will teach you how not to flinch.","$c, který ucukne, je mrtvý $c. Pokud se jako $c dokážeš dívat smrti do tváře, naučím tě, jak necuknout.")
-- source_id 61
add("Bowen Brisboise","Pleased to make your acquaintance. May I help you?","Těší mě. Mohu ti nějak pomoci?")
-- source_id 62
add("Breton Samuels","If you've come seeking the fellowship of your fellow paladins, you've come to the right place. \r\n\r\nWelcome home.","Pokud hledáš společnost ostatních paladinů, jsi na správném místě.\n\nVítej doma.")
-- source_id 63
add("Brock Stoneseeker","The best miner has a firm grip on his pick, a stout heart in his chest, and thick, black dust in his hair.","Nejlepší horník má pevný stisk krumpáče, odvážné srdce v hrudi a hustý černý prach ve vlasech.")
-- source_id 64
add("Brooke Stonebraid","Don't let the humans in the Bazaar fool ye lad, with the subway those gnomes built it's easier than ye might think to transport goods from Ironforge. If they try to tack on import fees just tell them yer gonna buy yer gear from me.","Nenech se oblbnout lidmi v Bazaru, chlapče. Díky metru, které postavili ti gnómové, je doprava zboží z Ironforge snazší, než si myslíš. Jestli se ti pokusí napařit dovozní poplatek, prostě jim řekni, že si výbavu koupíš ode mě.")
add("Kaita Deepforge","Don't let the humans in the Bazaar fool ye lad, with the subway those gnomes built it's easier than ye might think to transport goods from Ironforge. If they try to tack on import fees just tell them yer gonna buy yer gear from me.","Nenech se oblbnout lidmi v Bazaru, chlapče. Díky metru, které postavili ti gnómové, je doprava zboží z Ironforge snazší, než si myslíš. Jestli se ti pokusí napařit dovozní poplatek, prostě jim řekni, že si výbavu koupíš ode mě.")
add("Kathrum Axehand","Don't let the humans in the Bazaar fool ye lad, with the subway those gnomes built it's easier than ye might think to transport goods from Ironforge. If they try to tack on import fees just tell them yer gonna buy yer gear from me.","Nenech se oblbnout lidmi v Bazaru, chlapče. Díky metru, které postavili ti gnómové, je doprava zboží z Ironforge snazší, než si myslíš. Jestli se ti pokusí napařit dovozní poplatek, prostě jim řekni, že si výbavu koupíš ode mě.")
-- source_id 65
add("Buliwyf Stonehand","Ye want to be trained in the use of a weapon, do ye?  Well don't stand there slack-jawed, speak up laddie!","Chceš výcvik v používání zbraní, co? Tak tam nestůj s otevřenou pusou a mluv, chlapče!")
-- source_id 66
add("Cairne Bloodhoof","Greetings young one, and welcome to Thunder Bluff.  You'll find safe refuge from the burdens of the world here.  All denizens of the Horde are welcome here.\n\nThe spirits of the present and past come alive here in this sacred place, my friend.  Honor them, and in doing so honor yourself.","Zdravím tě, mladý příteli, a vítej v Thunder Bluff. Zde najdeš bezpečné útočiště před tíhou světa. Všichni obyvatelé Hordy jsou zde vítáni.\n\nDuchové přítomnosti i minulosti na tomto posvátném místě ožívají, příteli. Cti je, a tím budeš ctít i sebe.")
-- source_id 67
add("Cairne Bloodhoof","Muln Earthfury has told me much of the Windshapers and I am proud to open the lands--and skies--of Mulgore to your people.\r\n\r\nThe Tauren and the Skyborne are both children of this land. Kalimdor. \r\n\r\nI hope that your people are able to find what they are looking for here and that you are able to save your homeland. In the meantime, it is my hope that you are able to learn more of the land that your ancestors used to call home.\r\n\r\nPlease make yourself at home here in Thunder Bluff, and may the Earth Mother bless your journey.","Muln Earthfury mi o Windshapers mnohé vyprávěl a jsem hrdý, že mohu vašemu lidu otevřít země — i nebe — Mulgore.\n\nTaureni i Skyborne jsou děti této země. Kalimdoru.\n\nDoufám, že zde váš lid nalezne to, co hledá, a že dokážete zachránit svou domovinu. Do té doby doufám, že se dozvíte více o zemi, kterou vaši předkové kdysi nazývali domovem.\n\nV Thunder Bluff se cíť jako doma a nechť Earth Mother požehná tvé cestě.")
-- source_id 68
add("Captured Bandit","Largely, yes. The thing we all have in common is that we have nowhere else to go and that we prefer thieving over enslaving ourselves to some insane cult.","Do značné míry ano. Jediné, co máme všichni společné, je to, že nemáme kam jinam jít a že raději krademe, než abychom se zotročili nějakému šílenému kultu.")
-- source_id 69
add("Captured Bandit","Most of my outfit did. Displaced from the ground falling out from under our feet. Some came from other islands entirely. I came from the city of Shen'dramar, on the big island. Well, what used to be the big island, I suppose.\r\n\r\nMy family and I managed to get on one of the last skycutters out of there before the entire island broke apart. We thought that Zephras would save us. Well, it didn't. They are all long dead and now I'm here, awaiting execution.","Většina mé skupiny ano. Přišli jsme o domov, protože se nám doslova rozpadla země pod nohama. Někteří pocházeli z úplně jiných ostrovů. Já jsem z města Shen'dramar na velkém ostrově. Tedy na tom, co bývalo velkým ostrovem.\n\nMně a mé rodině se podařilo dostat na jeden z posledních skycutterů, než se celý ostrov rozpadl. Mysleli jsme, že nás Zephras zachrání. Nezachránil. Všichni už jsou dávno mrtví a já tu teď čekám na popravu.")
-- source_id 70
add("Chemist Fuely","My brother and I have dedicated ourselves to Sylvanas. She is our beacon of light when times were darkest. We sacrifice ourselves day in and day out to ensure our kind overcome the destiny that's chosen us.\n\nWe will not remain weak. We will take that which is owed to us. We will return tenfold, the pain that was done to us. And we shall do so with smiles on our faces.","Můj bratr a já jsme se zasvětili Sylvanas. Je naším světlem v těch nejtemnějších časech. Den za dnem se obětujeme, aby náš lid překonal osud, který mu byl určen.\n\nNezůstaneme slabí. Vezmeme si to, co nám náleží. Desetinásobně vrátíme bolest, která nám byla způsobena. A uděláme to s úsměvem na tváři.")
-- source_id 71
add("Coleman Farthing","I hope you're well, all things considered.\n\nSit for a spell, and hear my tale.  It's a tragedy, of course, but one I hope will end in revenge!","Doufám, že se ti vzhledem ke všemu daří dobře.\n\nNa chvíli se posaď a vyslechni můj příběh. Je to samozřejmě tragédie, ale doufám, že skončí pomstou!")
-- source_id 72
add("Daniel","Great choice. I have marked that location on your map.","Skvělá volba. Označil jsem ti to místo na mapě.")
-- source_id 73
add("Daniel","Hello, $N! Have you considered taking up a tradeskill?\r\n\r\nI would be happy to answer any questions you might have, or point you toward the local trainers.\r\n\r\nIf this feels overwhelming, that's okay! You can always return here or visit trainers in capital cities to get started on your crafting journey at any time.","Ahoj, $N! Uvažoval jsi někdy o nějakém řemesle?\n\nRád zodpovím všechny tvé otázky nebo tě nasměruji k místním trenérům.\n\nPokud ti to připadá složité, nic se neděje! Kdykoli se sem můžeš vrátit nebo navštívit trenéry v hlavních městech a začít svou řemeslnickou cestu později.")
-- source_id 74
add("Daniel","Of course! Which profession would you like me to guide you towards?\r\n\r\nI will mark your map with the location of a local trainer of your choice. Remember that you can visit trainers in capital cities for more thorough training.","Samozřejmě! Ke kterému povolání tě mám nasměrovat?\n\nNa mapě ti označím polohu místního trenéra, kterého si vybereš. Pamatuj, že v hlavních městech najdeš trenéry s podrobnějším výcvikem.")
-- source_id 75
add("Daniel Stitchsong","Hello there! I've got the finest leathers this side of Stormwind. Interested?","Zdravím! Mám ty nejlepší kůže široko daleko kolem Stormwindu. Máš zájem?")
-- source_id 76
add("Deathguard Billmuth","<Deathguard Billmuth absentmindedly fidgets as he looks around nervously. He is clearly very uncomfortable being here.>","<Deathguard Billmuth se roztržitě ošívá a nervózně se rozhlíží. Je zjevné, že se tu cítí velmi nepříjemně.>")
-- source_id 77
add("Deathguard Dillinger","Take it, then. It seems Zygand is too busy for the agonizing trip here to retrieve it himself.","Tak si to vezmi. Zdá se, že Zygand je příliš zaneprázdněný, než aby podstoupil tu strastiplnou cestu sem a vyzvedl si to sám.")
-- source_id 78
add("Deathguard Kristof","Please do see that he reads it at once. I fear our Scourge problem has only just begun.\r\n\r\nCome see me again in due time. I believe I have nearly uncovered something I could use a willing blade to help with.","Postarej se prosím, aby si to okamžitě přečetl. Obávám se, že naše problémy s Pohromou teprve začaly.\n\nZa nějaký čas za mnou znovu přijď. Myslím, že už jsem téměř odhalil něco, s čím by se mi hodila pomoc ochotné čepele.")
-- source_id 79
add("Deathguard Linnea","Greetings, $C. Be wary as you travel east toward The Bulwark. Recent surveillance reports indicate increased Scourge activity in that area, so exercise caution.","Zdravím, $C. Při cestě na východ k The Bulwark buď opatrný. Nedávné průzkumné zprávy naznačují zvýšenou aktivitu Pohromy v té oblasti, proto postupuj obezřetně.")
-- source_id 80
add("Denalan","The creation of Teldrassil was a grand achievement, but now the world must shift to regain its balance.","Stvoření Teldrassilu bylo velkolepým úspěchem, ale svět se nyní musí změnit, aby znovu získal rovnováhu.")
-- source_id 81
add("Dendrite Starblaze","Greetings, $c.  You are welcome in Nighthaven, as well as all of Moonglade.  The Cenarion Circle welcomes all beings who respect the authority and command of nature.\n\nWhile you are here, please be sure to preserve the balance in all things.  Disturbances are not welcome here, and our wardens are trained to cease all hostilities without question.","Zdravím, $c. V Nighthavenu i v celém Moonglade jsi vítán. Cenarion Circle vítá všechny bytosti, které respektují autoritu a řád přírody.\n\nPo dobu svého pobytu zde dbej na zachování rovnováhy ve všem. Narušování klidu tu není vítáno a naši strážci jsou vycvičeni okamžitě ukončit veškeré nepřátelství.")
-- source_id 82
add("Deputy Feldon","You'll find the town of Lakeshire yonder, across the bridge. But you'll not find it a peaceful place. If you're here for adventure, lass, then mark me--you've found it!","Město Lakeshire najdeš tamhle za mostem. Klidné místo to ale není. Pokud hledáš dobrodružství, děvče, pamatuj má slova — našla jsi ho!")
-- source_id 83
add("Deputy Rainer","I can't believe the officials in Stormwind, sending the bulk of our army abroad... when our home front is under so much pressure!\n\nWith thieves coming from Westfall and gnolls encroaching from from the east and west, it's a wonder Stormwind itself isn't besieged.","Nemůžu uvěřit představitelům Stormwindu, že poslali většinu naší armády do ciziny... když je náš vlastní domov pod takovým tlakem!\n\nZe Westfallu přicházejí zloději a z východu i západu se tlačí gnollové. Je div, že samotný Stormwind ještě není v obležení.")
-- source_id 84
add("Doctor Martin Felben","Have you now? This certainly doesn't look like something I had asked for.\r\n\r\nThis potion is clearly inert, meaning it will no longer create reactions. Hence it is of no use to my studies.\r\n\r\nTake it back to Alessandro. Perhaps next time he sends me a potion he can find someone with faster feet.\r\n\r\n<Doctor Felben waves a dismissive hand.>","Opravdu? Tohle rozhodně nevypadá jako něco, o co jsem žádal.\n\nTenhle lektvar je očividně neúčinný, takže už nebude vyvolávat žádné reakce. Pro mé výzkumy je tedy k ničemu.\n\nVrať ho Alessandrovi. Třeba příště, až mi pošle lektvar, najde někoho s rychlejšíma nohama.\n\n<Doctor Felben odmítavě mávne rukou.>")
-- source_id 85
add("Dungar Longdrink","Where is it ye would like to go lad? For just a few coin my Gryphons can get ye there faster than even the swiftest horse.","Kam by ses chtěl vydat, chlapče? Za pár mincí tě moji gryfové dopraví rychleji než ten nejrychlejší kůň.")
-- source_id 86
add("Earthseer Farsen","On a clear day, you can even see Blackrock Mountain from here. It's both beautiful and terrifying at the same time.","Za jasného dne odsud dokonce uvidíš Blackrock Mountain. Je nádherná a děsivá zároveň.")
-- source_id 87
add("Elaine Compton","Not every order goes according to plan. While we strive to ensure that each delivery arrives intact and efficiently, a recent rise of beasts, bandits, and even Horde attacks, unfortunately cause some unavoidable loss of goods.\r\n\r\nShould you find any lost shipments and are feeling particularly helpful, you can take a look over the label and identify its expected contents. It is not your responsibility to deal with our shortcomings of course, but if you completed the shipment, you will be rewarded in kind.\r\n\r\nMs. Baker near the crates will handle your compensation, and we will take care of the logistics from there.","Ne každá objednávka dopadne podle plánu. Přestože se snažíme zajistit, aby každá zásilka dorazila neporušená a včas, poslední nárůst útoků šelem, banditů a dokonce Hordy bohužel způsobuje nevyhnutelné ztráty zboží.\n\nPokud najdeš některou ze ztracených zásilek a budeš mít chuť pomoci, podívej se na štítek a zjistíš, co měla obsahovat. Naše nedostatky samozřejmě nejsou tvou starostí, ale pokud zásilku doplníš, odměníme tě odpovídajícím způsobem.\n\nMs. Baker u beden se postará o tvou odměnu a my pak vyřešíme zbytek logistiky.")
-- source_id 88
add("Elaine Compton","Oh goodness, you snuck up on me! Glad to see you, $N, the Azeroth Commerce Authority is always in need of new contractors.\r\n\r\nIf you are the sort to enjoy a stroll through the forest gathering useful materials or possess the skills to craft something from scratch, well, you have found yourself right at home!\r\n\r\nPlease let me know if you have any questions.","Proboha, tys mě vylekal! Rád tě vidím, $N. Azeroth Commerce Authority vždycky potřebuje nové smluvní pracovníky.\n\nPokud rád chodíš po lese a sbíráš užitečné materiály nebo umíš něco vyrobit od základů, jsi tu jako doma!\n\nKdybys měl nějaké otázky, dej mi vědět.")
-- source_id 89
add("Elisa Steelhand","How can I help you, friend?","Jak ti mohu pomoci, příteli?")
-- source_id 90
add("Ephram Barbaro","Oi, what do you want?","Hej, co chceš?")
-- source_id 91
add("Executor Zygand","The Scarlet Crusade is encroaching on our homeland. The foolish zealots do not realize that the loyal servants of The Dark Lady shall see to their demise.","Scarlet Crusade proniká do naší domoviny. Ti pošetilí fanatici nechápou, že věrní služebníci Temné paní se postarají o jejich zkázu.")
-- source_id 92
add("Falorne Fallwind","Magic can accomplish almost anything, but stagnation and inaction have caused us to lose so much of ourselves in the thousands of years since we left Kalimdor. The High Order seeks to reclaim the Highborne heritage that we've left behind and become the masters of our own destiny once again.\r\n\r\nThe Windshapers think we are simply reckless and arrogant. Hypocrisy at its finest, if you ask me. The Windshapers will entertain no ideas but their own when it comes to this crisis. Who, I wonder, is truly arrogant?","Magie dokáže téměř cokoli, ale stagnace a nečinnost nás během tisíců let od našeho odchodu z Kalimdoru připravily o příliš velkou část toho, kým jsme byli. High Order usiluje o znovuzískání dědictví Highborne, které jsme opustili, a chce, abychom se znovu stali pány vlastního osudu.\n\nWindshapers si myslí, že jsme jen bezohlední a arogantní. Pokrytectví nejvyššího stupně, jestli se mě ptáš. Windshapers v této krizi nepřipustí žádné myšlenky kromě vlastních. Kdo je tu tedy skutečně arogantní?")
-- source_id 94
add("Farmer Furlbrow","Nothing but trouble in these parts.  I tried to tell that fool Saldean to get out while he still could be he won't hear of it.  But I ain't no fool.  Verna and I are gonna mosey on out as soon as we get this wagon fixed.","V těchto končinách je jen samý problém. Snažil jsem se tomu hlupákovi Saldeanovi říct, ať zmizí, dokud může, ale nechce o tom ani slyšet. Já ale žádný hlupák nejsem. Jakmile spravíme tenhle vůz, s Vernou odsud vypadneme.")
-- source_id 95
add("Father Gavin","Welcome, $c, to the Misty Pine. If you are weary from your travels, feel free to rest and warm yourself inside. And perhaps if you've some spare time, you could assist me in some tasks.","Vítej v Misty Pine, $c. Pokud jsi unavený z cest, klidně si uvnitř odpočiň a ohřej se. A pokud máš trochu času nazbyt, mohl bys mi pomoci s několika úkoly.")
-- source_id 96
add("Frast Dokner","What do yeh' want?","Co chceš?")
-- source_id 97
add("Frightened Paladin","Get away from me, monster!","Jdi ode mě pryč, nestvůro!")
-- source_id 98
add("Frightened Paladin","No! No, no, no! This can't be. I'd rather be dead than Forsaken! \r\n\r\n<The Frightened $C raises her weapon, preparing to attack!>","Ne! Ne, ne, ne! To nemůže být pravda. Raději bych byla mrtvá než Forsaken!\n\n<Vyděšená $C pozvedne zbraň a připraví se k útoku!>")
-- source_id 99
add("Fritz Fizzle","Pleased to meet you! If you like to tinker, you have come to the right place!","Těší mě! Jestli rád kutíš, jsi na správném místě!")
-- source_id 100
add("Gazlowe","Thrall paid me and my boys well for helping out with the construction of Orgrimmar, so I decided to set up a port here. We do most of our business through Booty Bay and Baron Revilgaz.","Thrall mně a mým chlapům dobře zaplatil za pomoc při stavbě Orgrimmaru, tak jsem si tu založil přístav. Většinu obchodu vedeme přes Booty Bay a Barona Revilgaze.")
-- source_id 101
add("Gennia Runetotem","Welcome, my brother.  If you are here to train, then I would be delighted to train you.\n\nWe are the preservers of the balance, now and forever, as Cenarius has taught us.  Never forget this.","Vítej, bratře. Pokud jsi přišel na výcvik, rád tě budu trénovat.\n\nJsme strážci rovnováhy, nyní i navždy, jak nás učil Cenarius. Nikdy na to nezapomeň.")
-- source_id 102
add("Gilshalan Windwalker","The flora and fauna of Shadowglen is a testament to our talents at working with nature.  It is an honor to bear witness to our grand achievement.","Flóra a fauna Shadowglenu je důkazem našeho umění pracovat s přírodou. Je ctí být svědkem našeho velkolepého díla.")
-- source_id 103
add("Glix Xizzix","Yes, I am the renowned trader who magnanimously fed the uh, starving... children...? ...of the Undercity during the recent war with the Scourge. Yes, I am the visionary businessgob and logistical genius who single-handedly armed the resistance and allowed our Dark Lady to found her nation of smelly corpses... um, I mean, \"Forsaken.\"\r\n\r\nYep, I'm him. Glix Xizzix. I'd be happy to sign an autograph. For a small fee, of course.\r\n\r\nWhat am I doing here running a barbershop, you ask? Well I got one word for you, bub--diversification. You've got to keep your revenue streams diversified!","Ano, jsem ten proslulý obchodník, který velkoryse nakrmil, ehm, hladovějící... děti...? ...z Undercity během nedávné války s Pohromou. Ano, jsem ten vizionářský obchodní goblin a logistický génius, který vlastníma rukama vyzbrojil odpor a umožnil naší Temné paní založit její národ smradlavých mrtvol... ehm, chci říct „Forsaken“.\n\nJo, to jsem já. Glix Xizzix. Rád ti dám autogram. Za malý poplatek, samozřejmě.\n\nPtáš se, co tu dělám a proč vedu holičství? No, mám pro tebe jedno slovo, kámo — diverzifikace. Příjmy musíš mít rozložené do více zdrojů!")
-- source_id 104
add("Gordo","Oh yeah. Us gots it right here.","Jo jo. Máme to přímo tady.")
-- source_id 105
add("Gordo","Us is busy with important things!","My máme důležitou práci!")
-- source_id 106
add("Grenhild Darktalon","Great ta meet ya.","Rád tě poznávám.")
-- source_id 107
add("Gretta Ganter","Lookin' to fish? Then you'll need the proper tools.","Chceš rybařit? Pak budeš potřebovat správné náčiní.")
-- source_id 108
add("Grif Wildheart","Before beginning a hunt, it is wise to ask someone what you are looking for before you begin looking for it.","Než se vydáš na lov, je moudré nejprve se někoho zeptat, co vlastně hledáš.")
-- source_id 109
add("Grimand Elmore","If you've come looking for the finest craftsmanship on this or any other continent in the world, then you've come to the right place!\n\nGrimand Elmore, at your service!","Pokud hledáš to nejlepší řemeslné zpracování na tomto nebo jakémkoli jiném kontinentu, jsi na správném místě!\n\nGrimand Elmore, k tvým službám!")
-- source_id 110
add("Gryan Stoutmantle","A foul corruption has crept into Westfall.  While I was upholding my duty on the battlefields of Lordaeron these honest farms were overrun and made into hide-outs for thugs and murderers. The People's Militia needs your help.","Do Westfallu se vkradla odporná zkáza. Zatímco jsem plnil svou povinnost na bojištích Lordaeronu, tyto poctivé farmy obsadili násilníci a vrazi a udělali si z nich skrýše. People's Militia potřebuje tvou pomoc.")
-- source_id 111
add("Gubber Blump","...pan fried, deep fried, and stir fried...","...na pánvi, ve friťáku a ve woku...")
-- source_id 113
add("Harry Burlguard","It takes more than a big arm and a mean look to be a $c.  You also need a clear head and a sharp eye if you want to stay alive.\n\nAnd bad breath doesn't hurt either.","Být $c vyžaduje víc než silnou paži a zlý pohled. Pokud chceš zůstat naživu, potřebuješ také čistou hlavu a bystré oko.\n\nA špatný dech taky neuškodí.")
-- source_id 114
add("Hilda the Breaker","A little bit of a lot of things. Mostly I take the soft and weak and reshape them into hardened fighters once again.\r\n\r\nIt's a tough world out there, and even our own people mistrust us. We need to be tough and self-reliant if we are to fit into this \"horde\" with the rest of our people.","Od všeho trochu. Hlavně beru měkké a slabé a znovu z nich dělám tvrdé bojovníky.\n\nVenku je drsný svět a dokonce i náš vlastní lid nám nedůvěřuje. Pokud máme zapadnout do této „Hordy“ mezi ostatní naše lidi, musíme být tvrdí a soběstační.")
-- source_id 115
add("Hilda the Breaker","Why do they call me \"The Breaker\"?\r\n\r\nTrust me, you don't want to know.","Proč mi říkají „The Breaker“?\n\nVěř mi, nechceš to vědět.")
-- source_id 116
add("Holt Thunderhorn","Remember, all things are connected. If the beasts were gone from the land, our kind would die from a great loneliness of spirit, for whatever happens to the beasts also happens to the Tauren. Whatever befalls Azeroth befalls all those that inhabit it. \r\n","Pamatuj, všechno spolu souvisí. Kdyby ze země zmizela zvířata, náš lid by zahynul velkou samotou ducha, protože cokoli se stane zvířatům, stane se i Taurenům. Cokoli postihne Azeroth, postihne všechny, kdo na něm žijí.\n")
-- source_id 117
add("Idrieth Mossgrove","This dock connects Stormwind to the lands of the kaldorei via Auberdine, the port town of Darkshore. If you wish to travel there, the boat arrives frequently.","Tento přístav spojuje Stormwind se zeměmi kaldorei přes Auberdine, přístavní město v Darkshore. Pokud se tam chceš vydat, loď sem připlouvá často.")
-- source_id 118
add("Illaya Amberwind","The Cult? They are zealots and killers. They believe that we are being punished for some unspecific sin. The reality is that those that lead them are opportunists leftover from a dubious order of so-called \"Priests\" of Al'Akir, the Windlord. \r\n\r\nThey now find themselves in a position to weaponize the fear of our people to consolidate their own power... and they have been quick to do so.","Kult? Jsou to fanatici a vrazi. Věří, že jsme trestáni za jakýsi blíže neurčený hřích. Ve skutečnosti jsou jejich vůdci oportunisté, kteří zbyli z pochybného řádu takzvaných „kněží“ Al'Akira, Windlorda.\n\nNyní mají příležitost využít strach našeho lidu jako zbraň k upevnění vlastní moci... a neváhali toho využít.")
add("Rathiril Sunlance","The Cult? They are zealots and killers. They believe that we are being punished for some unspecific sin. The reality is that those that lead them are opportunists leftover from a dubious order of so-called \"Priests\" of Al'Akir, the Windlord. \r\n\r\nThey now find themselves in a position to weaponize the fear of our people to consolidate their own power... and they have been quick to do so.","Kult? Jsou to fanatici a vrazi. Věří, že jsme trestáni za jakýsi blíže neurčený hřích. Ve skutečnosti jsou jejich vůdci oportunisté, kteří zbyli z pochybného řádu takzvaných „kněží“ Al'Akira, Windlorda.\n\nNyní mají příležitost využít strach našeho lidu jako zbraň k upevnění vlastní moci... a neváhali toho využít.")
-- source_id 119
add("Jorin Croge","I make sure we are provisioned and that the scant resources we do are distributed properly. \r\n\r\nIf this were a proper order, I'd be something of a quartermaster. Such as we are however, I just do my best to make sure we are at least somewhat equipped to deal with the dangers all around us.","Starám se o naše zásoby a o to, aby se těch pár zdrojů, které máme, rozdělilo správně.\n\nKdyby to byl řád se vším všudy, byl bych něco jako quartermaster. V našem současném stavu se prostě snažím zajistit, abychom byli alespoň trochu vybaveni na nebezpečí, která nás obklopují.")
-- source_id 120
add("Jorin Croge","There are many things lurking out there in the dark and the light is needed now more than ever. If only these poor souls could see that just because our world has changed, that doesn't mean we have to be the monsters that the living think we are.","Venku v temnotě číhá mnoho věcí a světlo je nyní potřeba víc než kdy jindy. Kéž by ty ubohé duše pochopily, že jen proto, že se náš svět změnil, se nemusíme stát nestvůrami, za jaké nás živí považují.")
-- source_id 121
add("Josephine Carson","Greetings $c, I can teach you skills and techniques.","Zdravím, $c, mohu tě naučit dovednosti a techniky.")
-- source_id 122
add("Khara Deepwater","There's never an end to the chores around here.","Práce tady nikdy nekončí.")
-- source_id 123
add("Knight of Mourning","My oath binds me to this place. What brings you here, to this light-forsaken place?","Má přísaha mě poutá k tomuto místu. Co tě přivádí sem, na toto místo opuštěné světlem?")
-- source_id 124
add("Kor'geld","Hmm...","Hmm...")
-- source_id 125
add("Lady Sylvanas Windrunner","<Lady Sylvanas Windrunner regards you silently.>","<Lady Sylvanas Windrunner tě mlčky pozoruje.>")
-- source_id 126
add("Lady Sylvanas Windrunner","I've heard of you. Windshapers. Wayward children of ancient Eldre'Thalas.\r\n\r\nI once would have called you kin--albeit distant kin. Now I have no more in common with elfkind than I have with any of the other living races. All I value from any creature that draws breath is how well they may further the goals of the Forsaken. Make yourself useful to my people, and you will be welcome in our lands.\r\n\r\nGo. Explore the Undercity as you like and enjoy its comforts, such as they are. Just remember, nothing escapes my notice within my own domain.","Slyšela jsem o vás. Windshapers. Zbloudilé děti dávného Eldre'Thalasu.\n\nKdysi bych vás nazvala příbuznými — byť vzdálenými. Dnes už nemám s elfy společného nic víc než s kteroukoli jinou živou rasou. U každé bytosti, která dýchá, mě zajímá jen to, jak dobře může posloužit cílům Forsaken. Buď mému lidu užitečný a v našich zemích budeš vítán.\n\nJdi. Prozkoumej Undercity, jak chceš, a užij si jeho pohodlí, pokud se tomu tak dá říkat. Jen pamatuj, že v mém vlastním panství nic neunikne mé pozornosti.")
-- source_id 127
add("Leonid Barthalomew the Revered","They named it Bandarion Keep. I wonder what Garek would make of that?","Pojmenovali to Bandarion Keep. Zajímalo by mě, co by na to řekl Garek.")
-- source_id 128
add("Manifest Clerk Philmor","Harbor work is open to everyone, but your personal safety is your own responsibility.","Práce v přístavu je otevřená všem, ale za svou osobní bezpečnost odpovídáš sám.")
-- source_id 129
add("Mankrik","I came to the Crossroads from the south seeking help, $c, but I find only cowards who turn their backs on me--even the mighty Thork insults me so. He is a good leader, but his dismissal of my plea causes me greater anger.\n\nHe claims my rage makes me hasty--that it clouds my judgement--but I will not rest until I have vengeance!","Přišel jsem do Crossroads z jihu hledat pomoc, $c, ale nacházím tu jen zbabělce, kteří se ke mně obracejí zády — dokonce i mocný Thork mě takto uráží. Je to dobrý vůdce, ale tím, že mou prosbu odmítl, ve mně probudil ještě větší hněv.\n\nTvrdí, že mě můj vztek nutí jednat ukvapeně — že mi zatemňuje úsudek — ale já si nedám pokoj, dokud se nepomstím!")
-- source_id 130
add("Margaret Weaver","Agol ne wirsh ver ne vandar novaedi veld algos nevren? Va se ras uden vrum bor garde?","Agol ne wirsh ver ne vandar novaedi veld algos nevren? Va se ras uden vrum bor garde?")
-- source_id 131
add("Mebok Mizzyrix","Yes yes yes!  You're just the skyborne I'm looking for!\n\nSit!  We have much to discuss!!","Ano ano ano! Právě takového Skyborne hledám!\n\nSedni si! Musíme toho hodně probrat!!")
-- source_id 132
add("Messana Crestwind","You might think that just because we live on a floating island, there would be no need for miners like me. After so many thousands of years however, we still manage to dig up a lot of interesting things. \r\n\r\nIt's almost like there's some invisible force, constantly creating new mineral deposits every so often. That's magic for you though, right?\r\n\r\nRegardless, if you need training as a miner them I'm your shen'dorei.","Možná si myslíš, že když žijeme na plovoucím ostrově, horníci jako já tu nejsou potřeba. Jenže i po tolika tisících let se nám stále daří vykopávat spoustu zajímavých věcí.\n\nSkoro jako by nějaká neviditelná síla čas od času vytvářela nová ložiska nerostů. No jo, magie, že?\n\nKaždopádně, pokud potřebuješ hornický výcvik, jsem tvůj Shen'dorei.")
-- source_id 133
add("Milli Featherwhistle","Salutations, friend! I would be happy to offer you a Mechanostrider, but first you should train with my brother Binjy, over there.\r\n\r\nThey are far more reliable than any beast but can be difficult to pilot for a first time rider, but once you know how to pilot one you will not find a better companion!","Zdravím tě, příteli! Rád bych ti nabídl Mechanostridera, ale nejprve by ses měl vycvičit u mého bratra Binjyho, támhle.\n\nJsou mnohem spolehlivější než jakékoli zvíře, i když pro začínajícího jezdce mohou být zpočátku obtížně ovladatelní. Jakmile se je však naučíš řídit, lepšího společníka nenajdeš!")
-- source_id 134
add("Mirelle Tremayne","If you're looking for plate armor, mail armor or shields, I've got the finest in all of Undercity. Most of these pieces made and repaired here locally, though some is scavenged.\r\n\r\nFeel free to browse.","Pokud hledáš plátovou zbroj, kroužkovou zbroj nebo štíty, mám to nejlepší v celém Undercity. Většina těch kusů se vyrábí a opravuje přímo tady, i když něco je zachráněné ze starších zásob.\n\nKlidně si prohlédni nabídku.")
-- source_id 135
add("Mivin Shadowweave","<Mivin gestures toward his wares and back at you again with a smile, but says nothing.>","<Mivin s úsměvem gestem ukáže na své zboží a pak zpět na tebe, ale nic neřekne.>")
-- source_id 136
add("Morbin Lightbane","We paladins must earn our place amongst our Forsaken kin each day, lest we be judged as fanatics like the Scarlet Crusade. The light is not simply a tool of our foes, but a conduit for our righteous fury! It is in our devotion to the Dark Lady and the love of our home that we may channel the light to bring justice to our enemies.\r\n\r\nThe Banshee Queen keeps a close eye on us. Let her. She will see that our resolve shall never waver. We are Forsaken!","My paladinové si musíme každý den znovu zasloužit své místo mezi ostatními Forsaken, aby nás nepovažovali za fanatiky jako Scarlet Crusade. Světlo není jen nástrojem našich nepřátel, ale také prostředkem našeho spravedlivého hněvu! Díky oddanosti Temné paní a lásce k našemu domovu můžeme skrze světlo přinášet našim nepřátelům spravedlnost.\n\nBanshee Queen nás bedlivě sleduje. Jen ať. Uvidí, že naše odhodlání nikdy nezakolísá. Jsme Forsaken!")
-- source_id 137
add("Morin Cloudstalker","The Outrunners' duty is to ensure the safety of those who travel across the plains of Mulgore. Those that would threaten the safety of the $r homeland risk punishment at our hands.","Povinností Outrunners je zajišťovat bezpečí těch, kdo cestují pláněmi Mulgore. Ti, kdo by ohrožovali bezpečí domoviny $r, riskují trest z našich rukou.")
-- source_id 138
add("Mountaineer Gretchen","Lookin' fer the courier? Just flew off like a wee bird.\r\n\r\nCan't say I blame the poor sod. These wendigos are nasty business.","Hledáš kurýra? Odletěl jako ptáček.\n\nNemůžu říct, že se tomu chudákovi divím. Tihle wendigové jsou pěkně nebezpečná záležitost.")
-- source_id 139
add("Mountaineer Kadrell","Welcome to Thelsamar, your home away from home in Loch Modan!\n\nThelsamar is a nice place, but it's not all beer and salted meat for those who answer the call to duty!  If you're willing to face danger in the name of the Alliance, then read the poster outside the Thelsamar branch of the Explorers' League.","Vítej v Thelsamaru, svém druhém domově v Loch Modan!\n\nThelsamar je pěkné místo, ale pro ty, kdo vyslyší volání povinnosti, to není jen pivo a solené maso! Pokud jsi ochoten čelit nebezpečí ve jménu Aliance, přečti si plakát před thelsamarskou pobočkou Explorers' League.")
-- source_id 140
add("Mountaineer Stormpike","Well, if it isn't a young, bristling $c, no doubt drawn here by talk of my exploits in fields of battle!\n\nNo time for stories now, for there are great, important deeds that need doing!  So if you're looking for glory, then luck shines on you today...","No podívejme, mladý, bojovný $c, bezpochyby přilákaný vyprávěním o mých činech na bojištích!\n\nNa příběhy teď není čas, čekají nás velké a důležité skutky! Takže pokud hledáš slávu, dnes ti štěstí přeje...")
-- source_id 141
add("Naleeia Tattermend","Ah, hello. You look as though you have a question for me.","Ach, zdravím. Vypadáš, jako by ses mě chtěl na něco zeptat.")
-- source_id 142
add("Nazgrel","<Nazgrel grunts as he sizes you up.>\r\n\r\nHigh Elves, here in Orgrimmar. I'd never bet on such a thing happening in my lifetime, but at this point nothing is surprising to me.\r\n\r\nYes, the Warchief instructed me to draft up instructions for you. Take this letter and follow the instructions within. Conduct yourself with honor and show due deference when you meet with our leaders, elf.\r\n\r\nOnce you've finished your journey, return to the Warchief.","<Nazgrel si tě s odfrknutím přeměří.>\n\nHigh Elves tady v Orgrimmaru. Nikdy bych si nevsadil, že něco takového za svého života uvidím, ale teď už mě asi nepřekvapí nic.\n\nAno, Warchief mi nařídil sepsat pro tebe pokyny. Vezmi si tento dopis a řiď se jimi. Jednej čestně a při setkání s našimi vůdci jim prokazuj náležitou úctu, elfe.\n\nAž svou cestu dokončíš, vrať se k Warchiefovi.")
-- source_id 143
add("Neeru Fireblade","Ah, one of our own. It is good to see our numbers are growing so rapidly that I can no longer keep track of the faces of our members.\n\nThat fool Thrall thinks I am working hard to cleanse the image of warlocks and prove we are his servants. Idiot! The Burning Legion will make ash of this entire world after it drains it completely.","Ach, jeden z nás. Je dobré vidět, že naše řady rostou tak rychle, že už ani nedokážu sledovat tváře všech členů.\n\nTen hlupák Thrall si myslí, že tvrdě pracuji na očištění pověsti warlocků a dokazuji, že jsme jeho služebníci. Idiot! Burning Legion udělá z celého tohoto světa popel, až z něj všechno vysaje.")
-- source_id 144
add("Neeru Fireblade","Listen closely to what you are told and do not quickly trust, or distrust.  For even friends serve their own ends, $c.\n\nOur great Warchief knows this, and to prove that there are warlocks within the Horde who do not wish to destroy it from within or gain control over it, I have volunteered to aid our young leader in anyway I can.","Pozorně poslouchej, co ti kdo říká, a nevěř ani nedůvěřuj příliš rychle. I přátelé sledují vlastní cíle, $c.\n\nNáš velký Warchief to ví, a abych dokázal, že mezi warlocky Hordy jsou i tací, kteří ji nechtějí zevnitř zničit ani ovládnout, dobrovolně pomáhám našemu mladému vůdci, jak jen mohu.")
-- source_id 145
add("Neeru Fireblade","Naive fool. The Burning Blade IS the Shadow Council! There are many cults and organizations under the Council's rule, but all of them are just extensions of their will. I may lead the Burning Blade, but I am still just as much a pawn to the Council as you are to me!\n\nLook at the Searing Blade--most of them think they are becoming the next rising group of powerful warlocks that they will replace the Shadow Council.","Naivní hlupáku. Burning Blade JE Shadow Council! Pod vládou Rady působí mnoho kultů a organizací, ale všechny jsou jen prodlouženou rukou její vůle. Možná vedu Burning Blade, ale pro Radu jsem stejnou figurkou jako ty pro mě!\n\nPodívej se na Searing Blade — většina z nich si myslí, že se z nich stává další mocná skupina warlocků, která jednoho dne nahradí Shadow Council.")
-- source_id 146
add("Newton Burnside","Welcome to the Bank of Stormwind. We offer financial accounts and safety deposit boxes for valuable items. Do you already have an account with us sir?","Vítej v Bank of Stormwind. Nabízíme finanční účty a bezpečnostní schránky na cenné předměty. Máte už u nás účet, pane?")
add("Olivia Burnside","Welcome to the Bank of Stormwind. We offer financial accounts and safety deposit boxes for valuable items. Do you already have an account with us sir?","Vítej v Bank of Stormwind. Nabízíme finanční účty a bezpečnostní schránky na cenné předměty. Máte už u nás účet, pane?")
-- source_id 147
add("Nina Surefire","I know what you're thinking, but don't worry, we keep our cooking and alchemy ingredients separate!\r\n\r\nHow can I help you?","Vím, co si myslíš, ale neboj, suroviny na vaření a alchymii držíme odděleně!\n\nJak ti mohu pomoci?")
-- source_id 148
add("Norric Lochthane","Ye've come further than many, $N. Respect the elements around ye and ye shall fare far greater than most.","Došel jsi dál než mnozí, $N. Respektuj živly kolem sebe a povede se ti mnohem lépe než většině ostatních.")
-- source_id 149
add("Novice Warrior","<Novice Warrior gulps.>\r\n\r\nI can do this.","<Novice Warrior polkne.>\n\nZvládnu to.")
-- source_id 150
add("Novice Warrior","Are you here to prove yourself as well?","Jsi tu také proto, abys dokázal svou cenu?")
-- source_id 151
add("Novice Warrior","I am ready.","Jsem připraven.")
-- source_id 152
add("Nyalah Brightfire","It appears the winds have brought you my way! I am happy to train you in the ways of cooking if you have the inclination to learn.","Zdá se, že tě větry zavály přímo ke mně! Pokud máš chuť se učit, rád tě zasvětím do umění vaření.")
-- source_id 153
add("Onu","The wind whispers to those who listen...\n\nDo you hear it?","Vítr šeptá těm, kdo naslouchají...\n\nSlyšíš ho?")
-- source_id 154
add("Peacekeeper","A mailbox can be located just outside of the Inn, near the road leading north out of town.","Poštovní schránku najdeš hned před Inn, poblíž cesty vedoucí na sever z města.")
-- source_id 155
add("Peacekeeper","That trainer can be found in the Crafter's Hall, on the west side of Valanaar.","Tohoto trenéra najdeš v Crafter's Hall na západní straně Valanaaru.")
-- source_id 156
add("Peacekeeper","The $c trainer can be found over in the High Order's lodge, on the southeastern edge of town.","Trenéra $c najdeš v sídle High Order na jihovýchodním okraji města.")
-- source_id 157
add("Rahauro","Well met, $c. You may speak to me unless you have direct business with my mistress Magatha.\n\nI deal with most of her tasks for her so she can concentrate on more important matters. Perhaps there are some things we could discuss before you seek audience with her?","Buď zdráv, $c. Můžeš se mnou mluvit, pokud nemáš přímou záležitost s mou paní Magathou.\n\nVyřizuji za ni většinu úkolů, aby se mohla soustředit na důležitější záležitosti. Možná bychom mohli pár věcí probrat, než ji požádáš o audienci?")
-- source_id 158
add("Rathiril Sunlance","Alas, I have prattled on long enough. Should you find yourself in the port of Valanaar, seek out Elaadrin Evengale. Elaadrin was once my student, but now he serves as the Chief Magister of the High Order. He is headstrong and capable, and it's now up to him and young $R such as yourself to carry the hopes for our people forward.","Běda, mluvím už příliš dlouho. Pokud se ocitneš v přístavu Valanaar, vyhledej Elaadrina Evengalea. Elaadrin byl kdysi mým žákem, ale nyní slouží jako Chief Magister High Order. Je tvrdohlavý a schopný a nyní je na něm a mladých $R, jako jsi ty, aby nesli naděje našeho lidu dál.")
-- source_id 159
add("Rathiril Sunlance","Even the Windshapers would tell you that the spirits never spoke highly of any supreme being amongst them. They acknowledged the existence of a being named Al'Akir, but they avoided invoking his name, almost as if they feared him.\r\n\r\nEven if this Al'Akir is an all-powerful \"Windlord\" or ruler of the wind elementals, relying upon elementals is what got us into this mess. We must now see ourselves out of it.","Dokonce i Windshapers by ti řekli, že duchové nikdy nemluvili s úctou o žádné nejvyšší bytosti mezi sebou. Připouštěli existenci bytosti jménem Al'Akir, ale vyhýbali se vyslovování jeho jména, téměř jako by se ho báli.\n\nI kdyby byl tento Al'Akir všemocným „Windlordem“ či vládcem větrných elementálů, právě závislost na elementálech nás dostala do této situace. Teď se z ní musíme dostat sami.")
-- source_id 160
add("Rathiril Sunlance","Many disagree on this point. The Windshapers would have you believe that joining hands and merely hoping for the spirits' return will be sufficient. Their order's power has waned however, and their path relies on putting us back on the cycle of dependence that got us to this point. The High Order on the other hand... we believe in a more direct approach.","V tomto bodě se mnozí neshodnou. Windshapers by tě přesvědčovali, že stačí spojit ruce a doufat v návrat duchů. Síla jejich řádu však slábne a jejich cesta nás znovu vrací do koloběhu závislosti, který nás do této situace přivedl. High Order naproti tomu... věří v přímější řešení.")
-- source_id 161
add("Rathiril Sunlance","Where to begin? Our home is failing. The wards have fallen and the three provinces have begun to drift apart. There was a time not long ago when the spires of Shen'dramar were visible from the western watchtower. No longer. Day by day the wind pylons that anchor our home to this plane weaken...","Kde začít? Náš domov selhává. Ochranné bariéry padly a tři provincie se začaly od sebe vzdalovat. Ještě nedávno byly věže Shen'dramaru vidět ze západní strážní věže. Už nejsou. Každým dnem slábnou větrné pylony, které poutají náš domov k této rovině...")
-- source_id 162
add("Rathiril Sunlance","Why is this happening? Put simply, the spirits of the wind just... vanished. \r\n\r\nThe petty sprites and lesser elementals you've likely encountered out there are a pale imitation of the true spirits of wind. Non-sentient, aimless, and a far cry from the kindly spirits we lived in harmony alongside for thousands of years.","Proč se to děje? Jednoduše řečeno, duchové větru prostě... zmizeli.\n\nDrobní spritové a nižší elementálové, které jsi venku nejspíš potkal, jsou jen bledou napodobeninou skutečných duchů větru. Bez rozumu, bez cíle a na hony vzdálení laskavým duchům, s nimiž jsme po tisíce let žili v harmonii.")
-- source_id 163
add("Rathiril Sunlance","You must remember that while this realm has been our home for millennia, we will always be somewhat alien to this place. We are not in the terrestrial world that birthed our people. We are in the realm of Skywall, the elemental plane of air. \r\n\r\nWe arrived here as the guests of spirits with whom we found kinship in ages past. Now that we Shen'dorei find ourselves bereft of their presence--and potentially--their protection, there's no telling how the other denizens of this plane may perceive us.","Musíš pamatovat, že ačkoli je tato říše naším domovem už tisíciletí, vždy jí budeme do určité míry cizí. Nejsme v pozemském světě, který zrodil náš lid. Jsme ve Skywallu, elementární rovině vzduchu.\n\nPřišli jsme sem jako hosté duchů, s nimiž jsme kdysi dávno nalezli spříznění. Teď, když jsme my Shen'dorei přišli o jejich přítomnost — a možná i ochranu — nikdo neví, jak nás mohou ostatní obyvatelé této roviny vnímat.")
-- source_id 164
add("Rejold Barleybrew","Curse that Brewers' League!  They have access to all the best ingredients, while we're stuck here grubbing for grain and hops!\n\nI really would like to give them some bitter tasting justice...","Prokletá Brewers' League! Mají přístup ke všem nejlepším surovinám, zatímco my tady musíme shánět obilí a chmel!\n\nMoc rád bych jim naservíroval trochu hořké spravedlnosti...")
-- source_id 165
add("Riley Peltskinner","Care to learn how to gather leather from slain beasts? Or do you need some new tools?","Chceš se naučit stahovat kůži z ulovených zvířat? Nebo potřebuješ nové nástroje?")
-- source_id 166
add("Rudra Amberstill","Welcome to the Amberstill Corral.  If you're interested in purchasing a mount, my husband Veron will be more than happy to help you choose just the right beast.  If you're looking for adventure, well we sure could use some help around here. . .","Vítej v Amberstill Corral. Pokud si chceš koupit mounta, můj manžel Veron ti rád pomůže vybrat přesně to správné zvíře. Pokud hledáš dobrodružství, no, pomoc by se nám tu opravdu hodila...")
-- source_id 167
add("Salma Saldean","Welcome to our humble abode!  It's always nice to see a friendly face.  And what strong arms you have.  My husband and I are always looking for help around the farm.  Now that most the good folk have left, it's hard to find an able body to help out.","Vítej v našem skromném příbytku! Přátelskou tvář vždycky rádi vidíme. A jaké máš silné paže. S manželem pořád hledáme někoho, kdo by nám pomohl na farmě. Teď, když většina slušných lidí odešla, je těžké najít někoho schopného, kdo by přiložil ruku k dílu.")
-- source_id 168
add("Senir Whitebeard","Greetings and salutations to you, good $r. P'rhaps you'd like to share a drink with me, help fight off the chill of the wind? Come, I've more than enough to share.","Zdravím tě, dobrý $r. Nechceš se se mnou napít a zahnat chlad větru? Pojď, mám toho víc než dost pro oba.")
-- source_id 169
add("Sentinel Glynda Nal'Shea","Corruption sneaks into nature's grove.  The forest must be protected at all costs.","Do háje přírody se vkrádá zkáza. Les musí být ochráněn za každou cenu.")
-- source_id 170
add("Shari Stilwell","You may not be a paladin, but you may yet find solace in the light should you seek it.","Možná nejsi paladin, ale pokud budeš hledat útěchu ve světle, můžeš ji přesto najít.")
-- source_id 171
add("Sirocca \"Swimmers\" Starfeather","<The $r before you sways unsteadily, clearly very inebriated.>\r\n\r\nI used to be a sailor you know? Before the trouble started. The skycutters used to run between the islands. Now its unsafe or some such, or so they say.\r\n\r\nI see the High Order and the Windshapers have their skycutters running again, but I'm stuck here, grounded! \r\n\r\nWhat aren't we being told!\r\n\r\n<He turns and yells loudly at the innkeeper.>\r\n\r\nWHAT AREN'T WE BEING TOLD, DONAAL!?","<$r před tebou se nejistě kymácí a je zjevně silně opilý.>\n\nVíš, já býval námořník. Než začaly ty problémy. Skycuttery létaly mezi ostrovy. Teď je to prý nebezpečné nebo tak něco, aspoň to tvrdí.\n\nVidím, že High Order a Windshapers zase zprovoznili své skycuttery, ale já tady trčím na zemi!\n\nCo nám neříkají!\n\n<Otočí se a hlasitě zakřičí na hostinského.>\n\nCO NÁM NEŘÍKÁTE, DONAALE!?")
-- source_id 172
add("Sirocca \"Swimmers\" Starfeather","Shadowgale Forest!\r\n\r\nIt's haunted! Haunted as the sky is blue! Terrible forest spirits, terror birds with talons as big as yer arm! It's... a nightmare!\r\n\r\n<Swimmers turns to Donaal and belches loudly.>\r\n\r\n IT'S NOT CRAZY TALK, DONAAL!","Shadowgale Forest!\n\nStraší tam! Straší, stejně jistě jako je nebe modré! Děsiví lesní duchové, terror birds s pařáty velkými jako tvoje ruka! Je to... noční můra!\n\n<Swimmers se otočí k Donaalovi a hlasitě si říhne.>\n\nTO NEJSOU ŽÁDNÉ BLÁZNIVÉ ŘEČI, DONAALE!")
-- source_id 173
add("Sputtervalve","Interesting, interesting... I know of a druid that lives atop the hill above the Wailing Caverns, $N. She might be able to tell you more about this shard you have found.\n\nNow, I must get back to work!","Zajímavé, zajímavé... Znám jednu druidku, která žije na kopci nad Wailing Caverns, $N. Možná ti dokáže říct víc o tom úlomku, který jsi našel.\n\nTeď se ale musím vrátit k práci!")
-- source_id 174
add("Sputtervalve","See, the Venture Company's new shredder is better than my latest, from the interchangeable hands to the control grips! My boss has given me a pretty strict deadline, but my boys and I couldn't come up with anything.\n\nNothing was working, so we decided to \"borrow\" one of their prototypes. I sent Wizzlecrank to the Sludge Fen to steal one, but he hasn't gotten back yet!","Podívej, nový shredder Venture Company je lepší než můj nejnovější model, od vyměnitelných rukou až po ovládací páky! Šéf mi dal dost přísný termín, ale s kluky jsme na nic nepřišli.\n\nNic nefungovalo, takže jsme se rozhodli jeden jejich prototyp „vypůjčit“. Poslal jsem Wizzlecranka do Sludge Fen, aby jeden ukradl, ale ještě se nevrátil!")
-- source_id 175
add("Stondry Darkhammer","The ingots are for display only!","Ingoty jsou jen na vystavení!")
-- source_id 177
add("Tallonkai Swiftroot","Well met, $N. It is good to see that hunters like yourself are taking an active part in protecting the groves.","Buď zdráv, $N. Je dobré vidět, že hunteři jako ty se aktivně podílejí na ochraně hájů.")
-- source_id 178
add("Tallonkai Swiftroot","Well met, $N. It is good to see that warriors like yourself are taking an active part in protecting the groves.","Buď zdráv, $N. Je dobré vidět, že warrioři jako ty se aktivně podílejí na ochraně hájů.")
-- source_id 179
add("Therum Deepforge","Ye have the look of a Blacksmith to ye. Soot under the nails, steel in yer bones. Aye, very much the blood of a Blacksmith in yer veins. Which means ye've come to me looking to learn a thing or two, well lad grab a hammer. Let's see what I can teach ye.","Vypadáš jako blacksmith. Saze za nehty, ocel v kostech. Jo, v žilách ti koluje krev kováře. To znamená, že jsi za mnou přišel něco se přiučit. Tak popadni kladivo, chlapče. Uvidíme, co tě dokážu naučit.")
-- source_id 180
add("Thork","Welcome to the Crossroads, $c. My name is Thork--I lead the defenses here in the name of the Warchief.\n\nPlease, feel free to make yourself at home. As long as you mind your business, no one should have any problem with you taking up some space.\n\nThere are many threats to our safety here. If you've already become familiar with the lay of the land, speak to the others here--perhaps they have tasks for you to do.","Vítej v Crossroads, $c. Jmenuji se Thork — jménem Warchiefa tu vedu obranu.\n\nKlidně se tu zabydli. Dokud se budeš starat o své věci, nikomu by nemělo vadit, když si zabereš trochu místa.\n\nNaši bezpečnost tu ohrožuje mnoho věcí. Pokud už se v okolí vyznáš, promluv s ostatními — možná pro tebe mají nějaké úkoly.")
-- source_id 181
add("Thrall","All members of the Horde are equal in my eyes, $N. We have all suffered many burdens, and if it were not for wisdom and honor, then we would be no better than the Scourge or my people while our blood was tainted by the demon Mannoroth.\n\nIt is your duty to aid the Horde and to defend our way of life. But it is also your duty to know when quarter and compassion should be given to friend and foe alike.\n\nUnderstand this well. This is the new Horde, not some demon-spawned army who lack freewill.","V mých očích jsou si všichni členové Hordy rovni, $N. Všichni jsme nesli těžká břemena, a nebýt moudrosti a cti, nebyli bychom o nic lepší než Pohroma nebo můj lid v době, kdy naši krev poskvrnil démon Mannoroth.\n\nJe tvou povinností pomáhat Hordě a bránit náš způsob života. Ale je také tvou povinností poznat, kdy je třeba projevit slitování a soucit příteli i nepříteli.\n\nDobře si to zapamatuj. Tohle je nová Horda, ne démony zrozená armáda bez svobodné vůle.")
-- source_id 182
add("Thrall","It would be wise to explain to you the depths at which our enemies will go to to hide themselves under our noses.\n\nKnow this first and foremost: our enemy is the Shadow Council. No matter what task I give you, or who I ask you to act against, know that one simple fact.\n\nMany cults exist within the Council, but only to hide its actions against the foolish.\n\nGroups like the Burning Blade, the Argus Wake, and the Searing Blade are all tools of the Council. Consider them one and the same.","Je moudré vysvětlit ti, jak hluboko jsou naši nepřátelé ochotni zajít, aby se nám ukryli přímo pod nosem.\n\nPředevším věz toto: naším nepřítelem je Shadow Council. Ať ti zadám jakýkoli úkol nebo tě požádám jednat proti komukoli, vždy pamatuj na tento prostý fakt.\n\nUvnitř Rady existuje mnoho kultů, ale jen proto, aby její činy skryly před pošetilci.\n\nSkupiny jako Burning Blade, Argus Wake a Searing Blade jsou všechny nástroji Rady. Považuj je za jedno a totéž.")
-- source_id 183
add("Thundris Windweaver","Dark forces encroach upon our borders, ancient taints resurface, and new evils emerge to topple the delicate balance of the land. In times of such darkness, we all must be vigilant.","Temné síly se tlačí k našim hranicím, prastaré nákazy se znovu vynořují a nová zla povstávají, aby narušila křehkou rovnováhu země. V tak temných časech musíme být všichni ostražití.")
-- source_id 184
add("Tormus Deepforge","Some can't stand the heat of the Great Forge, but I think the heat is just right.  And it's the best place to do some serious smithwork.","Někteří nesnesou žár Great Forge, ale mně připadá přesně akorát. A je to nejlepší místo na pořádnou kovářskou práci.")
-- source_id 185
add("Turak Runetotem","Welcome, my brother.  If you are here to train, then I would be delighted to teach you.\n\nIt never hurts to reaffirm one's place within what I like to call the Great Balance.  As preservers of this balance, we must strive to continually keep our minds clear and our hearts strong.  Training helps us in this regard.","Vítej, bratře. Pokud jsi přišel na výcvik, rád tě budu učit.\n\nNikdy neuškodí znovu si připomenout své místo v tom, čemu rád říkám Velká rovnováha. Jako její strážci musíme neustále usilovat o jasnou mysl a silné srdce. Výcvik nám v tom pomáhá.")
-- source_id 186
add("Varimathras","Do not presume to speak to me as though you are my equal, $c. Sylvanas is my queen, and I will do as she bids.\n\nIf you do not show the proper respect, I assure you, we can find a more than suitable place for you in the Nether.\n\nBut there is no reason we cannot have words if you wish to aid the Dark Lady...","Neopovažuj se se mnou mluvit, jako bychom si byli rovni, $c. Sylvanas je má královna a udělám vše, co mi přikáže.\n\nPokud neprojevíš náležitou úctu, ujišťuji tě, že pro tebe v Netheru najdeme více než vhodné místo.\n\nAle pokud chceš pomoci Temné paní, není důvod, proč bychom si nemohli promluvit...")
-- source_id 187
add("Verna Furlbrow","Sometimes I think there's a big gray cloud in the sky, just raining down bad luck upon us.  First, we're driven off our land, and now we can't even get out of Westfall.  Everything's a mess.  Something needs to be done.","Někdy mám pocit, jako by na obloze visel jeden velký šedý mrak a pršel z něj na nás jen samý pech. Nejdřív nás vyhnali z vlastní země a teď se ani nedokážeme dostat z Westfallu. Všechno je v troskách. Musí se s tím něco udělat.")
-- source_id 188
add("Vol'jin","Ah yes, I heard of the Windshapers. It be good to be meetin' you now.\r\n\r\nYou know, my people been fighting elves for thousands of years. If you be half as fierce as your cousins from Darnassus or Quel'thalas, the Darkspear would be glad to call you friend.\r\n\r\nI be wishin' you well in your travels, $c. We Darkspear know all too well what it's like to have no home, so I hope you be finding what your people need to save yours.","Ach ano, slyšel jsem o Windshapers. Dobré tě konečně potkat.\n\nVíš, můj lid bojuje s elfy tisíce let. Jestli jsi aspoň z poloviny tak zuřivý jako tvoji příbuzní z Darnassu nebo Quel'thalasu, Darkspear tě rádi nazvou přítelem.\n\nPřeji ti na cestách štěstí, $c. My Darkspear moc dobře víme, jaké to je nemít domov, a tak doufám, že váš lid najde to, co potřebuje k záchraně toho svého.")
-- source_id 189
add("Zerril Softbreeze","Ho there, traveler! New to town? Well, once you get settled in come see me if you'd like some work. I've been working overtime preparing for the Festival of Winds and I'll take all the help I can get keeping the larders full!","Hej, poutníku! Jsi ve městě nový? Až se zabydlíš, přijď za mnou, pokud budeš chtít práci. Při přípravách na Festival of Winds dělám přesčasy a každá pomoc s udržením plných zásobáren se mi hodí!")
-- source_id 190
add("Apothecary Lydon","We are but so close to developing the New Plague that our Dark Lady desires with such fervor.","Od vytvoření Nového moru, po kterém naše Temná paní tak vroucně touží, nás dělí už jen krůček.")
-- source_id 191
add("Baelann Favorbreeze","Welcome to the Bank of Valanaar. We can secure your belongings and valuables here should you so desire. Do you wish to access your deposit box?","Vítej v Bank of Valanaar. Pokud si přeješ, můžeme zde bezpečně uložit tvůj majetek a cennosti. Chceš otevřít svou bezpečnostní schránku?")
-- source_id 192
add("Coriella Calmbreeze","Welcome to the Calmbreeze Inn, traveler. Would you like some refreshment?","Vítej v Calmbreeze Inn, poutníku. Dáš si něco na osvěžení?")
add("Donaal Downbreeze","Welcome to the Calmbreeze Inn, traveler. Would you like some refreshment?","Vítej v Calmbreeze Inn, poutníku. Dáš si něco na osvěžení?")
-- source_id 193
add("Ealaane Nimbuswalker","All of the skyborne islands became destabilized and began to move apart a few years ago. If that wasn't bad enough, now large pieces of Zephras are beginning to fall away. It's hard to imagine your home falling into the sky, but that is my reality now.","Před několika lety se všechny ostrovy Skyborne destabilizovaly a začaly se od sebe vzdalovat. Jako by to nestačilo, teď se od Zephrasu začínají odlamovat velké kusy. Je těžké představit si vlastní domov, jak padá do nebe, ale právě taková je dnes moje realita.")
-- source_id 194
add("Elegael Thornpaw","I cannot believe we were taken by surprise by the Al'Aketh. They have never been hostile to us before, but with their ambush they injured many of my kin.I swear I will get revenge for the fallen and wounded druids of my den. Mark my words, they will pay.","Nemůžu uvěřit, že nás Al'Aketh zaskočili. Nikdy předtím vůči nám nebyli nepřátelští, ale při přepadení zranili mnoho mých druhů.Přísahám, že padlé a zraněné druidy z mého doupěte pomstím. Zapamatuj si má slova, zaplatí za to.")
-- source_id 195
add("Garen Largo","Do you require training in the ways of the light?","Potřebuješ výcvik v cestách světla?")
-- source_id 196
add("Godan","You may have what it takes. Let's find out! ","Možná na to máš. Pojďme to zjistit! ")
-- source_id 198
add("Guard Thomas","Hello, citizen.  You look like a woman with a purpose - do you have business with the Stormwind Army?","Zdravím, občanko. Vypadáš jako žena, která ví, co chce — máš nějakou záležitost se Stormwind Army?")
-- source_id 199
add("Helene Peltskinner","How can I help you?","Jak ti mohu pomoci?")
-- source_id 200
add("High Executor Darthalia","In order to serve the Dark Lady and Varimathras we need to advance the front on the Human Infestation.","Abychom mohli sloužit Temné paní a Varimathrasovi, musíme posunout frontu proti lidské nákaze dál.")
-- source_id 201
add("Lotheluum Starbreeze","Our kind are rare these days, but there are those who still dream in emerald amongst the Shen'dorei.","Náš druh je dnes vzácný, ale i mezi Shen'dorei jsou tací, kteří stále sní v smaragdových snech.")
-- source_id 202
add("Lumina Windsinger","There are no words to describe what happened. Banon twisted and contorted horribly. It sounded like every bone in his body was breaking. His mouth filled with razors and his hands became deadly claws. It took twenty gnolls to fell him, and he killed half of them before it was done.","Nedá se popsat slovy, co se stalo. Banon se strašlivě svíjel a kroutil. Znělo to, jako by mu praskala každá kost v těle. Ústa se mu naplnila břitvami a ruce se změnily ve smrtící drápy. Trvalo dvacet gnollů, než ho skolili, a polovinu z nich zabil, než bylo po všem.")
-- source_id 203
add("Lumina Windsinger","Winds blessings, $c.","Požehnání větrů, $c.")
-- source_id 204
add("Maggran Earthbinder","I am afraid that I am no longer gentle or humble. Age and countless battles have hardened my skin and soul. Perhaps that is why Cairne assigned me to Sun Rock Retreat... the gentle winds and warm sun does ease the pain.","Obávám se, že už nejsem jemný ani pokorný. Věk a nesčetné bitvy zocelily mou kůži i duši. Možná proto mě Cairne poslal do Sun Rock Retreat... mírné větry a teplé slunce tu bolest skutečně zmírňují.")
-- source_id 205
add("Marshal Dughan","Ach, it's hard enough keeping order around here without all these new troubles popping up! I hope you have good news, $N...","Ach, už tak je dost těžké udržovat tu pořádek bez všech těch nových problémů, které se pořád objevují! Doufám, že máš dobré zprávy, $N...")
-- source_id 206
add("Naeluna Swiftmend","If you have the aptitude for the druidic arts, I can train you.","Pokud máš nadání pro druidská umění, mohu tě vycvičit.")
add("Xyton Silverwind","If you have the aptitude for the druidic arts, I can train you.","Pokud máš nadání pro druidská umění, mohu tě vycvičit.")
-- source_id 207
add("Pa'zula","What business do you have in the Echo Isles, $c?","Co tě přivádí na Echo Isles, $c?")
-- source_id 208
add("Peacekeeper","Greetings, citizen.","Zdravím, občane.")
add("Valennia Stormfist","Greetings, citizen.","Zdravím, občane.")
-- source_id 209
add("Remy \"Two Times\"","Hey there, friend.  My name's Remy.  I'm from Redridge to the east, and came here looking for business, looking for business.  You got any...got any??","Nazdar, příteli. Jmenuji se Remy. Jsem z Redridge na východě a přišel jsem sem hledat obchod, hledat obchod. Máš něco... máš něco??")
-- source_id 210
add("Strange Hermit","H-Hello. You'll have to excuse me, I'm used to your kind running from me.","A-Ahoj. Musíš mě omluvit, jsem zvyklý, že přede mnou tvůj druh utíká.")
-- source_id 211
add("Strange Hermit","Oh, that's okay. I-I'll be here if you want to learn some other time. T-Thank you for talking to me!","Aha, to je v pořádku. B-budu tady, kdybys se chtěl učit někdy jindy. D-děkuju, že ses se mnou bavil!")
-- source_id 212
add("Tarindrella","Only in Nature do we find purity.","Jen v přírodě nacházíme čistotu.")
-- source_id 213
add("Urs'endris","The spirit of strength does not always allude to physical strength. To face adversity both from within and without is what it means to take my shape.","Duch síly neznamená vždy jen fyzickou sílu. Čelit nepřízni zevnitř i zvenčí — to znamená přijmout mou podobu.")
-- source_id 214
add("Veren Tallstrider","The tauren are sons and daughters of the Earthmother, and we show respect to all her children.  Even the beasts we slay are cherished, as their bodies give nourishment and their skins provide warmth.","Taureni jsou synové a dcery Earthmother a prokazujeme úctu všem jejím dětem. Dokonce i zvířata, která zabíjíme, si vážíme, protože jejich těla nám dávají potravu a jejich kůže teplo.")
-- source_id 216
add("William Pestle","Aha!  Good day, good day, Master $C!  Come, sit down and have a drink.  You have an enterprising look in your eye, and I think you'll find speaking to me worth your time...","Aha! Dobrý den, dobrý den, mistře $C! Pojď, posaď se a dej si něco k pití. V očích máš podnikavý lesk a myslím, že rozhovor se mnou se ti vyplatí...")
-- source_id 217
add("Zephras Citizen","The Windshapers and the High Order are up to something. There are rumors floating around that both groups plan to get the skycutters running again and use them to leave the Skywall. LEAVE SKYWALL? How ridiculous. Where would they even go?","Windshapers a High Order něco chystají. Kolují zvěsti, že obě skupiny plánují znovu zprovoznit skycuttery a použít je k opuštění Skywallu. OPUSTIT SKYWALL? Jak směšné. Kam by vůbec šli?")
-- source_id 218
add("Zerril Softbreeze","If you need training as a cook, I have a few tips and tricks I could pass on! Ho ho! Throw on an apron and let's get started!","Pokud potřebuješ kuchařský výcvik, můžu ti předat pár tipů a triků! Ho ho! Hoď na sebe zástěru a pustíme se do toho!")
-- source_id 219
add("Elayaa Easewind","The hunters and rangers of Zephras have never been more needed. The winds grow ever harsher, and the magic that sustains our island is fading. The wilds have never been more wild and people like me are needed to keep our people safe.\r\n\r\nIf you have the proper aptitude as a $c, I can give you the tools to survive the wilds.","Hunteři a rangeři Zephrasu nikdy nebyli potřebnější. Větry jsou čím dál divočejší a magie, která drží náš ostrov, slábne. Divočina nikdy nebyla divočejší a lidé jako já jsou potřeba, aby náš lid zůstal v bezpečí.\n\nPokud máš jako $c správné nadání, mohu ti dát prostředky k přežití v divočině.")
add("Quel'ana Quickgale","The hunters and rangers of Zephras have never been more needed. The winds grow ever harsher, and the magic that sustains our island is fading. The wilds have never been more wild and people like me are needed to keep our people safe.\r\n\r\nIf you have the proper aptitude as a $c, I can give you the tools to survive the wilds.","Hunteři a rangeři Zephrasu nikdy nebyli potřebnější. Větry jsou čím dál divočejší a magie, která drží náš ostrov, slábne. Divočina nikdy nebyla divočejší a lidé jako já jsou potřeba, aby náš lid zůstal v bezpečí.\n\nPokud máš jako $c správné nadání, mohu ti dát prostředky k přežití v divočině.")
add("Tai'ree Farsight","The hunters and rangers of Zephras have never been more needed. The winds grow ever harsher, and the magic that sustains our island is fading. The wilds have never been more wild and people like me are needed to keep our people safe.\r\n\r\nIf you have the proper aptitude as a $c, I can give you the tools to survive the wilds.","Hunteři a rangeři Zephrasu nikdy nebyli potřebnější. Větry jsou čím dál divočejší a magie, která drží náš ostrov, slábne. Divočina nikdy nebyla divočejší a lidé jako já jsou potřeba, aby náš lid zůstal v bezpečí.\n\nPokud máš jako $c správné nadání, mohu ti dát prostředky k přežití v divočině.")
-- source_id 220
add("Falfaan Halfwind","Greetings, $c. Are you in need of arms?\r\n\r\nI was trained by Antarion of Ban'aethal, using secrets handed down from the ancient master magesmiths of Kalimdor.\r\n\r\nYou'll find no finer weapons on Zephras Isle than mine.","Zdravím, $c. Potřebuješ zbraně?\n\nVycvičil mě Antarion z Ban'aethalu pomocí tajemství předávaných od dávných mistrů mágokovářů Kalimdoru.\n\nNa Zephras Isle nenajdeš lepší zbraně než ty moje.")
-- source_id 221
add("Jorel Windsinger","<Before you lies the corpse Jorel Windsinger.\r\n\r\nDeep lacerations are cut into his legs, and lightning burns scorch his fur.\r\n\r\nIt is clear he put up a fight before succombing to his wounds.>","<Před tebou leží mrtvola Jorela Windsingera.\n\nNa nohách má hluboké tržné rány a srst mu sežehly popáleniny od blesků.\n\nJe zřejmé, že se před podlehnutím svým zraněním bránil.>")
-- source_id 222
add("Lumina Windsinger","As I said, the creature that attacked us fled when I singed its backside with lightning, but not before biting Banon. On our way back to town, the Gnolls surrounded us and took us captive. \r\n\r\nIt wasn't until they started to pull us out of the boat on Fenris Isle that... the change started.","Jak už jsem řekla, tvor, který nás napadl, utekl, když jsem mu bleskem ožehla zadek, ale předtím Banona kousl. Cestou zpět do města nás obklíčili gnollové a zajali nás.\n\nAž když nás na Fenris Isle začali vytahovat z člunu... začala ta proměna.")
-- source_id 223
add("Lumina Windsinger","When it was over I was stunned. He knew what would happen and he threw himself in front of that creature anyway to shield me.\r\n\r\nWe windshapers always pay our debts, and I owe him a debt. We've already avenged his death, but we can still avenge what was done to him by that monster, if you are still willing to lend me aid.","Když bylo po všem, zůstala jsem v šoku. Věděl, co se stane, a přesto se před tu bestii vrhl, aby mě ochránil.\n\nMy Windshapers své dluhy vždy splácíme a já mu dlužím. Jeho smrt jsme už pomstili, ale stále můžeme pomstít to, co mu ta nestvůra udělala, pokud jsi mi stále ochoten pomoci.")
-- source_id 224
add("Ott","My blades don't glisten, glitter, or gleam, and they'll sing no epic songs about my creations when I'm gone. \r\n\r\nOne thing you can be sure of though is that my weapons will cut down all the knights in Stormwind before losing their honed edge.","Mé čepele se nelesknou, netřpytí ani nezáří a až tu nebudu, nikdo o mých výtvorech nebude zpívat epické písně.\n\nJedním si ale můžeš být jistý: moje zbraně pobijí všechny rytíře ve Stormwindu dřív, než ztratí své ostří.")
-- source_id 225
add("Resaan Nimbuswalker","<Before you lies an skyborne; his body is mangled and bruised but still recognizable. It is clear he met a gruesome end while attempting to flee.\r\n\r\nIt appears that all of his belongings are still on his body, and a half filled crate nearby lays spilled on the ground.>","<Před tebou leží Skyborne; jeho tělo je zohavené a potlučené, ale stále rozpoznatelné. Je jasné, že při pokusu o útěk zemřel hrůznou smrtí.\n\nZdá se, že všechny jeho věci zůstaly na těle a nedaleko leží na zemi vysypaná napůl plná bedna.>")
-- source_id 226
add("Rumstag Proudstrider","Hail sister... I'd like a moment of your time, if I may.\n\nWe tauren have endured much in our trials and tribulations in establishing our homeland.  We now find ourselves in a dire shortage of cloth.  If you have the materials to spare, I ask that you please donate them.  You certainly would earn the gratitude of tauren everywhere in helping us out!","Buď zdráva, sestro... rád bych tě na chvíli zdržel, smím-li.\n\nMy Taureni jsme při zkouškách a strastech spojených se založením své domoviny hodně vytrpěli. Nyní máme zoufalý nedostatek látky. Pokud máš materiál nazbyt, prosím, daruj nám jej. Pomocí by sis jistě získala vděčnost Taurenů všude kolem!")
-- source_id 227
add("Strange Hermit","Oh these things? I built them. My little friends helped me. I'm not very good at remembering things, but, um, I do know that at one point I used to build a lot of things. Big things! But then, like I said... I was here. The things I build aren't so big and impressive anymore. Still makes me h-happy, heh.\r\n\r\nB-but... If you want, I can show you how to build things too!","Ach, tyhle věci? Postavil jsem je. Pomohli mi moji malí přátelé. Moc dobře si věci nepamatuju, ale, ehm, vím, že jsem kdysi stavěl spoustu věcí. Velkých věcí! Jenže potom, jak jsem říkal... ocitl jsem se tady. To, co stavím teď, už není tak velké ani působivé. Ale pořád mě to d-dělá šťastným, heh.\n\nA-ale... jestli chceš, můžu ti taky ukázat, jak věci stavět!")
-- source_id 228
add("Strange Hermit","That is... a very good question. I have a hard time remembering things, but I do remember something... \"Engineer\", perhaps? I think that's what, or who, I was.\r\n\r\nOther than that all I can seem to remember is soaring through the sky, then seeing a flash of lightning before things got very bumpy. Then... a crash. \r\n\r\nIt's been... a long time though. A very long time.","To je... velmi dobrá otázka. Věci si pamatuju jen těžko, ale něco přece jen... „Engineer“, možná? Myslím, že to je to, čím — nebo kým — jsem býval.\n\nJinak si dokážu vybavit jen to, že jsem letěl vysoko oblohou, pak jsem zahlédl záblesk blesku a všechno začalo být hodně divoké. Potom... náraz.\n\nAle už je to... dlouho. Velmi dlouho.")
-- source_id 229
add("Sutara Plainstalker","It is my honor to handle supply and provisioning for the Earthen Ring. \r\n\r\nMy stock is limited at present, but check back with me often and I may have new equipment and supplies available for purchase.","Je mi ctí starat se o zásobování Earthen Ring.\n\nMoje zásoby jsou teď omezené, ale vracej se za mnou a možná budu mít k prodeji nové vybavení a zásoby.")
-- source_id 230
add("Trevan Rol","The Son of Argual that attacked Lumina is known as Old Fire-Eye. He's not only well-known for his ferocity, but for his stubborn refusal to die. I've been doing a fair amount of research and I think that we can forge a blade that will do the trick and put him down for good.\r\n\r\nHere, I've prepared a list of materials and information about how to get them for you. When you've gathered what we need, return to me and we'll get started.","Son of Argual, který napadl Luminu, je známý jako Old Fire-Eye. Je proslulý nejen svou zuřivostí, ale i tvrdohlavým odmítáním zemřít. Hodně jsem pátral a myslím, že dokážeme vykovat čepel, která ho konečně pošle k zemi.\n\nTady máš seznam materiálů a informace, kde je získat. Až shromáždíš vše, co potřebujeme, vrať se ke mně a pustíme se do práce.")
-- source_id 231
add("Zephras Citizen","I've seen the skycutters sailing through the sky more and more recently. It's good to know that they are running again. If only the elders would tell us what is going on. They only tell us that nothing has changed and we still have no contact with the other islands.\r\n\r\nI can't help but wonder what this means...","V poslední době vídám skycuttery létat oblohou čím dál častěji. Je dobré vědět, že zase fungují. Kéž by nám starší řekli, co se děje. Tvrdí jen, že se nic nezměnilo a stále nemáme spojení s ostatními ostrovy.\n\nNemůžu si pomoct a přemýšlím, co to znamená...")
-- source_id 232
add("Aamelia Windfield","The Windfield Orchard has seen better days...","Windfield Orchard už zažil lepší časy...")
-- source_id 233
add("Aedi Thriceforged","I can teach you to swing a blacksmith's hammer, if you are willing to learn.","Pokud se chceš učit, mohu tě naučit zacházet s kovářským kladivem.")
-- source_id 234
add("Ailee Farheart","Hello, $c.","Ahoj, $c.")
-- source_id 235
add("Al'Aketh Stormcaller","Do not trouble me, recruit. Submit yourself to Commander Cyclas or Skypriest Aanders if your hands are idle.","Neobtěžuj mě, rekrute. Pokud nemáš co dělat, hlas se u Commandera Cyclase nebo Skypriesta Aanderse.")
-- source_id 236
add("Al'Aketh Stormcaller","Does your heart beat in rhythm with the winds?","Bije tvé srdce v rytmu větrů?")
-- source_id 237
add("Al'Aketh Stormcaller","Soon all Shen'dorei will see the truth... and those that refuse will be swept away in the coming storm!","Brzy všichni Shen'dorei spatří pravdu... a ti, kteří odmítnou, budou smeteni přicházející bouří!")
-- source_id 238
add("Al'Aketh Stormcaller","The non-believers will be purged in our glorious storms! Praise the Windlord!","Nevěřící budou očištěni v našich slavných bouřích! Sláva Windlordovi!")
-- source_id 239
add("Al'Aketh Stormcaller","You'll need to speak with Skypriest Aanders for instruction, there is no guidance I can provide. Be gone with you, recruit.","Pro výcvik musíš promluvit se Skypriestem Aandersem, já ti žádné vedení poskytnout nemohu. Zmiz, rekrute.")
-- source_id 240
add("Alvarion Windfield","It's always great to see you, $N.","Vždy tě rád vidím, $N.")
-- source_id 241
add("Ayessa Dawnsinger","Greetings, I am Ayessa Dawnsinger, the current Grand Skyseer of the Windshapers. What may I do for you?","Zdravím, jsem Ayessa Dawnsinger, současná Grand Skyseer řádu Windshapers. Co pro tebe mohu udělat?")
-- source_id 242
add("Ayessa Dawnsinger","Hmm, I see. Very well then, $c. The Windshapers will provide aid. Please inform Valennia that she can count on us for this fight.","Hmm, chápu. Velmi dobře, $c. Windshapers poskytnou pomoc. Řekni prosím Valennii, že s námi v tomto boji může počítat.")
-- source_id 243
add("Belathaan Brightwish","What are you doing here? Quickly, leave this place now. You are going to ruin everything!","Co tady děláš? Rychle, okamžitě odsud odejdi. Všechno zkazíš!")
-- source_id 244
add("Beneris","Oh! Greetings, friend. Feel free to browse my wares.","Ach! Zdravím, příteli. Klidně si prohlédni mé zboží.")
-- source_id 245
add("Boyle","ssSSLIMES!! Rrraagh...","ssSSLIZY!! Rrraagh...")
-- source_id 246
add("Captured Bandit","Desperation? Hunger? I'm not exactly here doing this because I like robbing and murdering. I lost my home, had no where to go, and I don't much care to shave my head and worship some imaginary wind god, so I became a bandit. The rest is obvious.","Zoufalství? Hlad? Nedělám to proto, že by mě bavilo loupit a vraždit. Přišel jsem o domov, neměl kam jít a rozhodně se mi nechce oholit si hlavu a uctívat nějakého smyšleného boha větru, tak jsem se stal banditou. Zbytek je jasný.")
-- source_id 247
add("Captured Bandit","Killed a peacekeeper and stole some windstones.","Zabil jsem peacekeepera a ukradl pár windstonů.")
-- source_id 248
add("Captured Bandit","What are you looking at?","Na co zíráš?")
-- source_id 249
add("Captured Bandit","Why bother denying it, the constable already passed her judgement. No point lying.","Proč to zapírat? Constable už vynesla rozsudek. Nemá cenu lhát.")
-- source_id 250
add("Damaged Construct","<A faint whirring sound can be heard coming from underneath the constructs metal armor plates. The wind powering this machine is present but is listless and only faintly churning. You don't need to know much about air constructs to know that this unit is clearly not in good repair.>","<Zpod kovových plátů zbroje konstruktu je slyšet slabé bzučení. Vítr, který tento stroj pohání, je přítomný, ale malátný a jen nepatrně víří. Nemusíš se v air constructs moc vyznat, aby ti bylo jasné, že tato jednotka rozhodně není v dobrém stavu.>")
-- source_id 251
add("Eaysaa Brightgust","Gales greetings, friend. Is there something I can help you with?","Pozdravy větrů, příteli. Mohu ti s něčím pomoci?")
add("Naleeia Tattermend","Gales greetings, friend. Is there something I can help you with?","Pozdravy větrů, příteli. Mohu ti s něčím pomoci?")
add("Othesia Evengale","Gales greetings, friend. Is there something I can help you with?","Pozdravy větrů, příteli. Mohu ti s něčím pomoci?")
-- source_id 252
add("Elaadrin Evengale","Greetings, I am Elaadrin Evengale, the current Supreme Magister of the High Order. How can I help you?","Zdravím, jsem Elaadrin Evengale, současný Supreme Magister High Order. Jak ti mohu pomoci?")
-- source_id 253
add("Emerii Tallgust","Do you seek training as a leatherworker?","Hledáš výcvik v leatherworkingu?")
-- source_id 254
add("Faladriaal Featherfall","Welcome to the guild registrar of Valanaar. How may I assist you today?","Vítej u registrátora guild ve Valanaaru. Jak ti dnes mohu pomoci?")
-- source_id 255
add("Fenn Fairweather","Welcome to Shen'dar Village, some of the best fishing this side of the mountain range. If you are looking to catch fish I can teach you, for a price.","Vítej v Shen'dar Village, kde najdeš jedny z nejlepších rybářských míst na této straně pohoří. Pokud chceš chytat ryby, mohu tě to za poplatek naučit.")
-- source_id 256
add("Grelin Whitebeard","Greetings, lad. I'm Grelin Whitebeard. I'm here to examine the threat posed by the growing numbers of trolls in Coldridge Valley. What have I found? It's a bit troubling...","Zdravím, chlapče. Jsem Grelin Whitebeard. Jsem tu, abych prozkoumal hrozbu rostoucího počtu trollů v Coldridge Valley. Co jsem zjistil? Je to trochu znepokojivé...")
-- source_id 257
add("Hadric Harlson","Be careful, $c. There are cultists nearby.","Buď opatrný, $c. Nedaleko jsou kultisté.")
-- source_id 258
add("Illaya Amberwind","Alas, I have prattled on long enough. Seek out my apprentice Ayessa Dawnsinger in the port of Valanaar if you find yourself out that way. She still hears the song--if only faintly.  I am old and much of my power has left me. Ayessa represents the future of our people and the path we must now walk to survive. It's up to her and young skyborne such as yourself to carry the hopes for our people forward.","Běda, už jsem mluvil dost dlouho. Pokud se někdy ocitneš v přístavu Valanaar, vyhledej mou učednici Ayessu Dawnsinger. Stále slyší píseň — byť jen slabě. Jsem starý a velká část mé síly mě opustila. Ayessa představuje budoucnost našeho lidu a cestu, po které teď musíme kráčet, abychom přežili. Je na ní a na mladých Skyborne, jako jsi ty, aby nesli naděje našeho lidu dál.")
-- source_id 259
add("Illaya Amberwind","Where to begin? Our home is failing. The wards have fallen and the three provinces have begun to drift apart. There was a time not long ago when the spires of Shen'dramar were visible from the western watchtower. No longer. The anchor pylons are weakening, and if the chains finally break...","Kde začít? Náš domov selhává. Ochranné bariéry padly a tři provincie se začaly od sebe vzdalovat. Ještě nedávno byly věže Shen'dramaru vidět ze západní strážní věže. Už nejsou. Kotevní pylony slábnou, a pokud se řetězy nakonec přetrhnou...")
-- source_id 260
add("Indari Sunseam","I can teach you to craft fine leather armor, if you have the aptitude.","Pokud máš nadání, mohu tě naučit vyrábět kvalitní koženou zbroj.")
-- source_id 262
add("Lavinia Crowe","Hmm, you scratch my back, I'll scratch yours. If you do what I ask, and do it well, maybe we can discuss your training.","Hmm, ty podrbeš záda mně a já tobě. Když uděláš, co po tobě chci, a uděláš to dobře, možná si potom promluvíme o tvém výcviku.")
-- source_id 263
add("Living Lightning","<The roiling cloud of living lightning before you seems to crackle menacingly as you approach. It might be best to leave. Quickly.>","<Vířící mrak živého blesku před tebou při tvém přiblížení výhružně zapraská. Možná bude nejlepší odejít. Rychle.>")
-- source_id 264
add("Magistrate Sevren","Ah, you there!  I have tasks to give, and I need not waste time explaining their crucial nature.  Listen close.","Hej, ty tam! Mám pro tebe úkoly a nehodlám ztrácet čas vysvětlováním, jak jsou zásadní. Poslouchej pozorně.")
-- source_id 265
add("Malfunctioning Cyclone Construct","<As you approach the enormous cyclone construct, you hear a faint buzzing emanating from beneath its massive armor plates. If you listen carefully you think you might be able to hear a few words being formed but they are too distorted to make out.>","<Když se přiblížíš k obrovskému cyklónovému konstruktu, zaslechneš slabé bzučení vycházející zpod jeho masivních plátů zbroje. Když se zaposloucháš, máš pocit, že rozeznáváš několik tvořících se slov, jsou však příliš zkreslená, než aby jim bylo rozumět.>")
-- source_id 266
add("Melasa Fairmend","Va, y ealdor Gloinador. E majis ko dana ne barad ras thorniss lars majis gol ador endirvis.","Va, y ealdor Gloinador. E majis ko dana ne barad ras thorniss lars majis gol ador endirvis.")
add("Naleeia Tattermend","Va, y ealdor Gloinador. E majis ko dana ne barad ras thorniss lars majis gol ador endirvis.","Va, y ealdor Gloinador. E majis ko dana ne barad ras thorniss lars majis gol ador endirvis.")
-- source_id 267
add("Missionary Jasaan","Do you seek the blessings of the Windlord?","Hledáš požehnání Windlorda?")
-- source_id 268
add("Myriaal Mistwake","It can get boring up here, you know. I can only annoy that stuffy wretch Halaan so much before even that gets old.","Tady nahoře může být nuda, víš. Toho upjatého ubožáka Halaana můžu otravovat jen nějakou dobu, než omrzí i to.")
-- source_id 269
add("Nyalah Brightfire","E borne hir ash nuff garde re ruff vassild lon thorniss, far E regen E majis barad ras aetwinter lo ruftos ergin.","E borne hir ash nuff garde re ruff vassild lon thorniss, far E regen E majis barad ras aetwinter lo ruftos ergin.")
-- source_id 270
add("Peacekeeper","Is there something I can help you find?","Mohu ti pomoci něco najít?")
-- source_id 271
add("Peacekeeper","May I help you locate something, citizen?","Mohu ti pomoci něco najít, občane?")
-- source_id 272
add("Peacekeeper","That trainer can be found in a house near the High Order dock, on the southeastern edge of town.","Toho trenéra najdeš v domě poblíž přístaviště High Order na jihovýchodním okraji města.")
-- source_id 273
add("Peacekeeper","The Inn can be found on the east side of the road leading northward out of town.","Inn najdeš na východní straně cesty vedoucí z města na sever.")
-- source_id 274
add("Peacekeeper","The bank and auction house can be found on the western side of Valanaar, near the Windshapers' skycutter dock.","Banku a auction house najdeš na západní straně Valanaaru, poblíž přístaviště skycutterů Windshapers.")
-- source_id 275
add("Peacekeeper","The town medic can be found inside the tower on the northeast edge of Valanaar.","Městského medika najdeš uvnitř věže na severovýchodním okraji Valanaaru.")
-- source_id 276
add("Peacekeeper","What are you looking for, citizen?","Co hledáš, občane?")
-- source_id 277
add("Peacekeeper","You'll want to head over to the Hall of Arms on the north side of Valanaar.","Vydej se do Hall of Arms na severní straně Valanaaru.")
-- source_id 278
add("Rorian the Dayseeker","What do you need of me, child of Zephras?","Co ode mě potřebuješ, dítě Zephrasu?")
-- source_id 279
add("Sania Silverstream","Greetings, $c. Do you come seeking the blessings of the Windlord?","Zdravím, $c. Přicházíš hledat požehnání Windlorda?")
-- source_id 280
add("Shari Stilwell","The light is a beacon that shines for all. What can I do for you, $c?","Světlo je maják, který září pro všechny. Co pro tebe mohu udělat, $c?")
-- source_id 281
add("Snurk Bucksquick","Hey there cutie, you looking for a ride to Grom'gol? I hear it gets mighty steamy down in those jungles, maybe I could join you for a short vacation, show you a real jungle cat.","Nazdar, kočičko, hledáš odvoz do Grom'gol? Slyšel jsem, že je v těch džunglích pěkně dusno. Možná bych se k tobě mohl přidat na krátkou dovolenou a ukázat ti opravdovou džunglovou kočku.")
-- source_id 282
add("Talaanis Shadowsong","It is vital that we learn more about what the cult is planning, and with the turncoat dead the information may have died with him...","Je životně důležité zjistit víc o tom, co kult plánuje, a se smrtí přeběhlíka mohly informace zemřít spolu s ním...")
-- source_id 283
add("Talaanis Shadowsong","Welcome to Valanaar, $c.","Vítej ve Valanaaru, $c.")
-- source_id 284
add("Vayn Moongaze","The Nightclaw do not take kindly to reckless intruders. Tread carefully while in Shadowgale, $c.","Nightclaw nemají rádi bezhlavé vetřelce. V Shadowgale našlapuj opatrně, $c.")
-- source_id 285
add("Ventaari Brightwish","What may I do for you, fellow windshaper?","Co pro tebe mohu udělat, kolego Windshapere?")
-- source_id 286
add("Wardrobe","<The two cultists nearby are talking. You might be able to learn something if you hide behind this wardrobe and eavesdrop.>","<Dva nedaleké kultisté spolu hovoří. Možná se něco dozvíš, pokud se schováš za tuto skříň a budeš poslouchat.>")
-- source_id 287
add("Windshaper Aeli","The winds favor you, $n.","Větry ti přejí, $n.")
-- source_id 288
add("Xy'aaria Streamrunner","The skycutters and ferries haven't run in years at this point. For all we know, there are no other islands left for us to get imports from. Still though, I'm here... just in case.","Skycuttery ani trajekty už roky nejezdí. Co my víme, možná už žádné jiné ostrovy nezbyly, odkud bychom mohli dovážet zboží. Ale stejně jsem tady... pro jistotu.")
-- source_id 289
add("Yorana Windyreed","Storms curse these Al'Aketh fanatics!","Ať bouře proklejí ty fanatiky Al'Aketh!")
-- source_id 291
add("Akeri Duskblade","Slay your enemies and swoon your paramours with this one weird trick.\r\n\r\nIf you follow the path of the $c, I can teach you... for a cost, of course.","Zabíjej své nepřátele a okouzluj své nápadníky tímto jedním podivným trikem.\n\nPokud kráčíš cestou $c, mohu tě učit... samozřejmě za jistou cenu.")
-- source_id 292
add("Alvarion Windfield","<The man lying before you shifts uncomfortably. He's recovering from some very nasty wounds.>","<Muž ležící před tebou se neklidně zavrtí. Zotavuje se z několika velmi ošklivých zranění.>")
-- source_id 293
add("Ayessa Dawnsinger","If the High Order gave any mind at all to actually solving the problems we face and spent less time obsessing over the old magic, we'd be in a far better position as a people. It was Highborne magic that brought about the ruin of the kaldorei to begin with. Those self-absorbed fools seek to repeat those mistakes!\r\n\r\nThe fact that they attempted to make peace with the cult is bad enough, but spilling Windshaper blood is what is truly unforgivable. Were it not for the imminent threat of the cult, I'd gather up our forces and go put an end to Elaadrin and the High Order once and for all.","Kdyby High Order věnoval aspoň trochu pozornosti skutečnému řešení problémů, kterým čelíme, a méně času posedlosti starou magií, byli bychom jako lid v mnohem lepší situaci. Právě magie Highborne přivedla kaldorei ke zkáze. Ti samolibí hlupáci se snaží zopakovat stejné chyby!\n\nUž to, že se pokusili uzavřít mír s kultem, je dost špatné, ale prolít krev Windshapers je skutečně neodpustitelné. Nebýt bezprostřední hrozby kultu, shromáždil bych naše síly a jednou provždy ukončil Elaadrina i High Order.")
-- source_id 294
add("Brix Xizzix","Another fresh face! Welcome to Azeroth, pal. Come back and see me if you need help setting yourself up for success.\r\n\r\nBring money.","Další nová tvář! Vítej v Azerothu, kámo. Vrať se za mnou, pokud budeš potřebovat pomoc, aby ses dobře rozjel.\n\nPřines peníze.")
-- source_id 295
add("Constable Aonda","<Constable Aonda wears an intense look on her face, clearly deep in thought.>","<Constable Aonda má ve tváři soustředěný výraz a zjevně je hluboce zamyšlená.>")
-- source_id 296
add("Constable Aonda","More than I'd like, I'm afraid. We've been harassed by a group of bandits camping out in a cave to the north, and the Al'Aketh cult recently took over Falaath Village to the south of us. I trust every peacekeeper and citizen here, but we are far too few to keep the village secure. \r\n\r\nIf the cult decides to continue their expansion here, there's little we can do to stop them.","Víc, než bych chtěla, obávám se. Obtěžuje nás skupina banditů, která táboří v jeskyni na severu, a kult Al'Aketh nedávno obsadil Falaath Village jižně od nás. Věřím každému peacekeeperovi i občanovi tady, ale je nás příliš málo na to, abychom vesnici udrželi bezpečnou.\n\nPokud se kult rozhodne pokračovat v expanzi sem, jen málo můžeme udělat, abychom je zastavili.")
-- source_id 297
add("Dead Cultist","<This cultist is dead. Upon close inspection, you notice that he seems to be clutching something to his chest, almost as if he was protecting it.>","<Tento kultista je mrtvý. Při bližším pohledu si všimneš, že něco svírá u hrudi, téměř jako by to chránil.>")
-- source_id 298
add("Elaadrin Evengale","<Elaadrin eyes you with barely-contained hatred.> \r\n\r\nYou would dare step foot into our sanctum after spilling High Order blood? You are very brave, or very stupid. The High Order does not forgive, nor do we forget.\r\n\r\nSomeday, you will pay for your crimes in blood.","<Elaadrin si tě změří s jen stěží skrývanou nenávistí.>\n\nOpovažuješ se vstoupit do našeho sancta poté, co jsi prolil krev High Order? Jsi velmi statečný, nebo velmi hloupý. High Order neodpouští a nezapomíná.\n\nJednoho dne za své zločiny zaplatíš krví.")
-- source_id 299
add("Elaadrin Evengale","Hmm, I see. Very well then, $c. The High Order will assist the Peacekeepers. Please inform Valennia that she can count on us for this fight.\r\n\r\n<Elaadrin lowers his voice dangerously.>\r\n\r\nDo not mistake our willing cooperation for any sort of clemency. You owe the High Order blood, and we always collect on our debts.","Hmm, chápu. Velmi dobře, $c. High Order pomůže Peacekeepers. Řekni prosím Valennii, že s námi v tomto boji může počítat.\n\n<Elaadrin nebezpečně ztiší hlas.>\n\nNepleť si naši ochotu spolupracovat s jakoukoli milostí. Dlužíš High Order krev a my své dluhy vždy vybíráme.")
-- source_id 300
add("Halaan Hawk-Eye","<The gaze of the ranger standing before you is fixed on the enormous anchor pylon in the distance.>","<Pohled rangera stojícího před tebou je upřen na obrovský kotevní pylon v dálce.>")
-- source_id 301
add("Hyusaa Quickbreeze","Most of the cultists at the Sanctum of Storms seem to have come out to respond to our attack. I never would have expected this to go so well. This was almost too easy...\r\n\r\nI think that the Windshapers and High Order have made their push. Valennia should be with them. You should head inside and find her. We'll stay here and and keep watch while Valennia and the others finish what they came here to do.","Většina kultistů v Sanctum of Storms zřejmě vyšla ven, aby zareagovala na náš útok. Nikdy bych nečekal, že to půjde tak dobře. Bylo to skoro až příliš snadné...\n\nMyslím, že Windshapers a High Order už zahájili svůj postup. Valennia by měla být s nimi. Měl bys zamířit dovnitř a najít ji. My zůstaneme tady a budeme hlídat, zatímco Valennia a ostatní dokončí to, kvůli čemu přišli.")
-- source_id 302
add("Illaya Amberwind","Greetings, child. I am Illaya Amberwind and I am the Elder Windshaper here on Zephras Isle. It's always nice to meet young new faces that make their way down from the grove.\r\n\r\nDon't let this old shaman hold you up, no doubt you've got many adventures to see to. Do feel free to stop by later if you'd like.","Zdravím tě, dítě. Jsem Illaya Amberwind a zde na Zephras Isle jsem Elder Windshaper. Vždy mě těší poznat nové mladé tváře, které sestoupí z háje.\n\nNenech se touto starou shamankou zdržovat, bezpochyby na tebe čeká mnoho dobrodružství. Kdykoli se později zastav, pokud budeš chtít.")
-- source_id 303
add("Illaya Amberwind","In all of our years dealing with the wind spirits, at no point did they speak of the Windlord as a figure of reverence. They acknowledged the existence of a being named Al'Akir, but they avoided invoking his name, almost as if they feared him. \r\n\r\nEven if this Al'Akir is an all-powerful \"Windlord\" or ruler of the wind elementals, my centuries of communion with the spirits has convinced me that at the very least he is not universally loved amongst the denizens of Skywall. I fear that attempting to treat with Al'Akir could merely hasten our doom.","Za všechna léta, kdy jsme jednali s duchy větru, o Windlordovi nikdy nemluvili jako o bytosti hodné úcty. Připouštěli existenci bytosti jménem Al'Akir, ale vyhýbali se vyslovování jeho jména, téměř jako by se ho báli.\n\nI kdyby byl tento Al'Akir všemocným „Windlordem“ či vládcem větrných elementálů, staletí mého spojení s duchy mě přesvědčila, že přinejmenším mezi obyvateli Skywallu rozhodně není všeobecně milován. Obávám se, že pokus vyjednávat s Al'Akirem by naši zkázu mohl jen urychlit.")
-- source_id 304
add("Illaya Amberwind","Many disagree on this point.  I believe that simple communication is the key. The songs of the wind rang so clearly to us when the spirits where still here. Since they left, its grown quiet and our power as windshapers has weakened. \r\n\r\nHowever, there are those of us who can still hear something. A hushed tone. Fragments of a melody. Those that can still hear and see into the elemental planes must grow in strength. I believe that is the key to our salvation.","V tomto bodě se mnozí neshodnou. Já věřím, že klíčem je prostá komunikace. Dokud tu duchové byli, písně větru k nám zněly naprosto jasně. Od jejich odchodu vše utichlo a naše síla jako Windshapers zeslábla.\n\nNěkteří z nás však stále něco slyší. Tichý tón. Úlomky melodie. Ti, kteří ještě dokážou slyšet a nahlížet do elementárních rovin, musí zesílit. Věřím, že právě to je klíčem k naší záchraně.")
-- source_id 305
add("Illaya Amberwind","Why is this happening? Put simply, the spirits of the wind just... vanished. They were there one day, and they were gone the next. I can't quite describe the feeling that we windshapers felt when it happened. It was as if a great silence fell over all of us and then... a profound absence.\r\n\r\nThe petty wraiths you've likely encountered out there are just shades of the glory of the true spirits of wind. Non-sentient, aimless, and a far cry from the kindly spirits we lived in harmony alongside for thousands of years.","Proč se to děje? Jednoduše řečeno, duchové větru prostě... zmizeli. Jeden den tu byli a další byli pryč. Nedokážu pořádně popsat, co jsme my Windshapers v tu chvíli cítili. Jako by na nás všechny padlo velké ticho a potom... hluboká prázdnota.\n\nDrobné přízraky, které jsi tam venku nejspíš potkal, jsou jen stíny slávy skutečných duchů větru. Bez rozumu, bez cíle a na hony vzdálené laskavým duchům, s nimiž jsme po tisíce let žili v harmonii.")
-- source_id 306
add("Illaya Amberwind","You must remember that while this realm has been our home for millennia, we will always be somewhat alien to this place. We are not in the terrestrial world that birthed our people. We are in the realm of Skywall, a part of the elemental plane.\r\n\r\nWe arrived here as the guests of spirits with whom we found common cause in ages past. Now that we Shen'dorei find ourselves bereft of their presence--and potentially--their protection, there's no telling how the other denizens of this plane may perceive us.","Musíš pamatovat, že ačkoli je tato říše naším domovem už tisíciletí, vždy jí budeme do určité míry cizí. Nejsme v pozemském světě, který zrodil náš lid. Jsme ve Skywallu, součásti elementární roviny.\n\nPřišli jsme sem jako hosté duchů, s nimiž jsme kdysi dávno našli společnou řeč. Teď, když jsme my Shen'dorei přišli o jejich přítomnost — a možná i ochranu — nikdo neví, jak nás mohou ostatní obyvatelé této roviny vnímat.")
-- source_id 307
add("Jornah","Greetings and well met, $N! Your arrival is timely, and we here at the Durotar Supply and Logistics company are always in need of new contractors.\r\n\r\nIf you are someone with a knack for gathering useful materials or the skills to craft something from scratch, you have a place here.\r\n\r\nPlease let me know if you have any questions.","Zdravím a buď vítán, $N! Přicházíš právě včas a my v Durotar Supply and Logistics stále potřebujeme nové smluvní pracovníky.\n\nPokud umíš sbírat užitečné materiály nebo něco vyrobit od základů, máš u nás své místo.\n\nKdybys měl nějaké otázky, dej mi vědět.")
-- source_id 308
add("Jornah","I am glad you asked! We are far more than just a delivery service, $N. We employ and contract craftsman across a variety of specialties and trades, and keep our ear to the ground for any new opportunities to keep their hands busy and goods flowing. We cannot possibly predict the emergent needs of any potential client, so we depend on their crafting orders to arrive to us.\r\n\r\nYou can imagine that this pipeline is... not as effective as we would hope. We encourage any crafters to satisfy these demands and deliver the goods directly to the customers,  wherever they may be. Worry not, you will be fairly compensated for your troubles and earn respect among our organization.","Jsem rád, že se ptáš! Jsme mnohem víc než jen doručovací služba, $N. Zaměstnáváme a najímáme řemeslníky mnoha specializací a oborů a neustále vyhlížíme nové příležitosti, jak zaměstnat jejich ruce a udržet tok zboží. Nemůžeme předvídat všechny náhlé potřeby potenciálních zákazníků, takže spoléháme na to, že nám budou posílat výrobní objednávky.\n\nDokážeš si představit, že tento systém je... méně účinný, než bychom si přáli. Povzbuzujeme proto všechny řemeslníky, aby tyto požadavky plnili a zboží doručovali přímo zákazníkům, ať jsou kdekoli. Neboj, za své potíže dostaneš spravedlivou odměnu a získáš respekt v naší organizaci.")
-- source_id 309
add("Jornah","Recently there has been a sharp rise in lost orders. We strive to ensure that each delivery is efficient and safe, but with a rise of bandits, rowdy creatures, and those damned Alliance, inevitably not every delivery goes according to plan.\r\n\r\nShould you find these shipments, take a look over the label for what it should contain. It is not your responsibility to deal with our mistakes, but if you complete the shipment, you will be rewarded in kind. \r\n\r\nDokimi over by the wagon can handle the logistics and your compensation. We will take it from there.","V poslední době prudce přibylo ztracených objednávek. Snažíme se, aby každé doručení bylo rychlé a bezpečné, ale s přibývajícími bandity, divokými tvory a tou zatracenou Aliancí se nevyhnutelně ne každá zásilka dostane do cíle podle plánu.\n\nPokud takovou zásilku najdeš, podívej se na štítek a zjistíš, co má obsahovat. Není tvou povinností napravovat naše chyby, ale pokud zásilku doplníš, odpovídajícím způsobem tě odměníme.\n\nDokimi u vozu se postará o logistiku i tvou odměnu. O zbytek se postaráme my.")
-- source_id 310
add("Mebok Mizzyrix","Yes yes yes!  You're just the $r I'm looking for!\n\nSit!  We have much to discuss!!","Ano ano ano! Právě takového $r hledám!\n\nSedni si! Musíme toho hodně probrat!!")
