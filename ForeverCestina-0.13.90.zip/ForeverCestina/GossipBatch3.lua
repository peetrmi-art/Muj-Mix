-- Classic NPC/Gossip translations from persistent offline source pool.
-- Data-only batch for ForeverCestina 0.13.60; runtime logic remains unchanged.
local _, A = ...
A.GossipEntries = A.GossipEntries or {}
local E = A.GossipEntries
local function add(npc,en,cs)
 E[#E+1]={npc=npc,en=en,cs=cs}
end
-- source_id 601
add("Warlord Gorchuk","Give me a moment; there are a lot of numbers to remember here. It looks like we have $2066w of $2067w heavy leather skins collected. As well, we have $2070w out of $2071w thick leather, and $2073w of $2074w rugged leather stockpiled.","Dejte mi chvilku; je tu spousta čísel, která si musím pamatovat. Vypadá to, že máme nasbíráno $2066w z $2067w kusů heavy leather. Dále máme $2070w z $2071w kusů thick leather a $2073w z $2074w kusů rugged leather uložených do zásoby.")
-- source_id 602
add("Selina Dourman","Glad you asked. Darkmoon Faire Prize Tickets are our way of letting you help with the faire, and in return you can turn in your tickets for special prizes!\n\nTo get started you'll want to talk to Chronos, Kerri Hicks, Ringling and Yebb Nebblegear to see who you can best help. They always have something that needs doing to improve and expand our attractions.\n\nThen when you have enough tickets, speak with Gelvas Grimegate and he will give you a list of prizes to choose from.","Jsem rád, že se ptáš. Darkmoon Faire Prize Tickets jsou náš způsob, jak ti umožnit pomáhat s veletrhem, a na oplátku můžeš své lístky vyměnit za speciální ceny!\n\nNejprve si promluv s Chronosem, Kerri Hicks, Ringlingem a Yebb Nebblegearem a zjisti, komu můžeš nejlépe pomoct. Vždycky mají něco, co je potřeba udělat, abychom naše atrakce vylepšili a rozšířili.\n\nAž budeš mít dost lístků, promluv si s Gelvas Grimegatem a on ti dá seznam cen, ze kterých si můžeš vybrat.")
-- source_id 603
add("Jaxin Chong","Glyx and I have an understanding: he keeps me supplied, and I keep him rich. Seriously! What that pirate charges me for a measly pouch of crumpled kingsblood... it's enough to make a grown goblin cry.","Glyx a já máme dohodu: on mě zásobuje a já zajišťuji, aby byl bohatý. Vážně! To, co si ten pirát účtuje za mizerný váček pomačkaného kingsbloodu... z toho by se rozplakal i dospělý goblin.")
-- source_id 604
add("Innkeeper Abeqwa","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Adegwa","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Allison","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Anderson","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Bates","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Belm","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Boorand Plainswind","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Brianna","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Byula","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Faralia","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Farley","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Firebrew","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Fizzgrimble","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Greul","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Grosk","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Gryshka","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Hearthstove","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Heather","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Helbrek","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Janene","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Jayka","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Karakul","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Kauth","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Kaylisk","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Keldamyr","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Kimlya","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Lyshaerya","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Norman","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Pala","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Renee","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Saelienne","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Shaussiy","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Shay","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Shul'kar","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Shyria","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Sikewa","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Skindle","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Thulbek","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Thulfram","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Trelayne","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Vizzie","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Innkeeper Wiley","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Lard","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
add("Vikki Lonsav","Gnomeregan can be found in western Dun Morogh.","Gnomeregan najdeš v západní části Dun Morogh.")
-- source_id 605
add("Bluffwatcher","Go see Una at Thunder Bluff Armorers then.  It can be found on the middle rise.","Tak zajdi za Unou do Thunder Bluff Armorers. Najdeš je na prostřední vyvýšenině.")
-- source_id 606
add("Undercity Guardian","Go to inner ring of War Quarter.  Brom Killian there.","Jdi do vnitřního okruhu War Quarter. Je tam Brom Killian.")
-- source_id 607
add("Orgrimmar Grunt","Go to Kodohide Leatherworkers in The Drag. Ask for Kamari.","Jdi ke Kodohide Leatherworkers v The Drag. Ptej se po Kamari.")
-- source_id 608
add("Elder Dreamseer","Go to the Freewind Post in Thousand Needles and you will find Elder Skyseer.","Jdi na Freewind Post v Thousand Needles a najdeš tam Elder Skyseer.")
add("Elder Morningdew","Go to the Freewind Post in Thousand Needles and you will find Elder Skyseer.","Jdi na Freewind Post v Thousand Needles a najdeš tam Elder Skyseer.")
add("Elder Ragetotem","Go to the Freewind Post in Thousand Needles and you will find Elder Skyseer.","Jdi na Freewind Post v Thousand Needles a najdeš tam Elder Skyseer.")
add("Elder Wildmane","Go to the Freewind Post in Thousand Needles and you will find Elder Skyseer.","Jdi na Freewind Post v Thousand Needles a najdeš tam Elder Skyseer.")
-- source_id 609
add("Bluffwatcher","Go to the Hunter Rise. You will find the battlemasters there.","Jdi na Hunter Rise. Tam najdeš battlemasters.")
-- source_id 610
add("Orgrimmar Grunt","Go to the Hunter's Hall in the Valley of Honor, west of the Coliseum.  Talk to Ormak Grimshot there.","Jdi do Hunter's Hall ve Valley of Honor, západně od Coliseum. Tam si promluv s Ormak Grimshotem.")
-- source_id 611
add("Orgrimmar Grunt","Go to the Valley of Honor and seek out Xon'cha near the stables.","Jdi do Valley of Honor a poblíž stájí vyhledej Xon'chu.")
-- source_id 612
add("Orgrimmar Grunt","Go to the Valley of Strength and look for the Bank of Orgrimmar to the south of the Sky Tower.","Jdi do Valley of Strength a jižně od Sky Tower hledej Bank of Orgrimmar.")
-- source_id 613
add("Orgrimmar Grunt","Godan's Runeworks is where you'll go.  Look for it on the west end of The Drag, right next to the Valley of Wisdom.","Musíš do Godan's Runeworks. Hledej je na západním konci The Drag, hned vedle Valley of Wisdom.")
-- source_id 614
add("Innkeeper Allison","Gonna make a guild, are ya? Good luck to ya then!\n\nTalk to Aldwin Laughlin in the Stormwind Vistor's Center. It's in the Trade District right as you come in from the Valley of Heroes.","Chceš založit guild, co? Tak hodně štěstí!\n\nPromluv si s Aldwin Laughlinem ve Stormwind Visitor's Center. Je v Trade District hned za vstupem z Valley of Heroes.")
add("Innkeeper Heather","Gonna make a guild, are ya? Good luck to ya then!\n\nTalk to Aldwin Laughlin in the Stormwind Vistor's Center. It's in the Trade District right as you come in from the Valley of Heroes.","Chceš založit guild, co? Tak hodně štěstí!\n\nPromluv si s Aldwin Laughlinem ve Stormwind Visitor's Center. Je v Trade District hned za vstupem z Valley of Heroes.")
add("Innkeeper Janene","Gonna make a guild, are ya? Good luck to ya then!\n\nTalk to Aldwin Laughlin in the Stormwind Vistor's Center. It's in the Trade District right as you come in from the Valley of Heroes.","Chceš založit guild, co? Tak hodně štěstí!\n\nPromluv si s Aldwin Laughlinem ve Stormwind Visitor's Center. Je v Trade District hned za vstupem z Valley of Heroes.")
add("Stormwind City Guard","Gonna make a guild, are ya? Good luck to ya then!\n\nTalk to Aldwin Laughlin in the Stormwind Vistor's Center. It's in the Trade District right as you come in from the Valley of Heroes.","Chceš založit guild, co? Tak hodně štěstí!\n\nPromluv si s Aldwin Laughlinem ve Stormwind Visitor's Center. Je v Trade District hned za vstupem z Valley of Heroes.")
add("Stormwind City Patroller","Gonna make a guild, are ya? Good luck to ya then!\n\nTalk to Aldwin Laughlin in the Stormwind Vistor's Center. It's in the Trade District right as you come in from the Valley of Heroes.","Chceš založit guild, co? Tak hodně štěstí!\n\nPromluv si s Aldwin Laughlinem ve Stormwind Visitor's Center. Je v Trade District hned za vstupem z Valley of Heroes.")
add("Vikki Lonsav","Gonna make a guild, are ya? Good luck to ya then!\n\nTalk to Aldwin Laughlin in the Stormwind Vistor's Center. It's in the Trade District right as you come in from the Valley of Heroes.","Chceš založit guild, co? Tak hodně štěstí!\n\nPromluv si s Aldwin Laughlinem ve Stormwind Visitor's Center. Je v Trade District hned za vstupem z Valley of Heroes.")
-- source_id 615
add("Tognus Flintfire","Good day to ye $g lad : lass;. Can I be of service?","Dobrý den, $gmladíku:slečno;. Mohu být k službám?")
-- source_id 616
add("Sellandus","Good day to you.","Dobrý den.")
-- source_id 617
add("Alchemist Mallory","Good day, $gsir:ma'am;. I'd shake your hand, but as you see, I'm in the middle of something. May I be of assistance?","Dobrý den, $g pane:madam;. Potřásl bych vám rukou, ale jak vidíte, zrovna něco dělám. Mohu vám nějak pomoci?")
-- source_id 618
add("Stormwind Guard","Good ol' Erma, she's been taking care of the local animals for years now.  I'm sure she'd be happy to take care of any you'd like to put up.  She can be found right outside of the Lion's Pride Inn.","Stará dobrá Erma, už roky se stará o místní zvířata. Určitě se ráda postará i o jakékoli zvíře, které u ní budeš chtít nechat. Najdeš ji hned před Lion's Pride Inn.")
-- source_id 619
add("Dun Morogh Mountaineer","Good ol' Thamner bandaged me up just the other day when I had a run in with a nasty trogg.  I'm good as new I tell ye!  I'm sure Thamner would be happy to show ye how to make a good bandage.","Starej dobrej Thamner mě zrovna nedávno obvázal, když jsem měl nepříjemné setkání s troggem. Jsem zas jako novej, říkám ti! Thamner ti určitě rád ukáže, jak udělat pořádný obvaz.")
add("Ironforge Mountaineer","Good ol' Thamner bandaged me up just the other day when I had a run in with a nasty trogg.  I'm good as new I tell ye!  I'm sure Thamner would be happy to show ye how to make a good bandage.","Starej dobrej Thamner mě zrovna nedávno obvázal, když jsem měl nepříjemné setkání s troggem. Jsem zas jako novej, říkám ti! Thamner ti určitě rád ukáže, jak udělat pořádný obvaz.")
add("Mounted Ironforge Mountaineer","Good ol' Thamner bandaged me up just the other day when I had a run in with a nasty trogg.  I'm good as new I tell ye!  I'm sure Thamner would be happy to show ye how to make a good bandage.","Starej dobrej Thamner mě zrovna nedávno obvázal, když jsem měl nepříjemné setkání s troggem. Jsem zas jako novej, říkám ti! Thamner ti určitě rád ukáže, jak udělat pořádný obvaz.")
-- source_id 620
add("Field Marshal Snowfall","Good question, $c. Last I was informed; we have managed to collect $1997w copper bars out of $1998w needed. Additionally, I am told that we have $2002w iron bars out of $2003w, and $2011w out of $2012w thorium bars requested.","Dobrá otázka, $c. Naposledy jsem dostal zprávu, že jsme dokázali shromáždit $1997w copper bars z potřebných $1998w. Kromě toho prý máme $2002w iron bars z $2003w a $2011w z požadovaných $2012w thorium bars.")
-- source_id 621
add("Rohan the Assassin","Good question, $r. In my younger days I was footloose and fancy free without a care in the world. In those days I would sing in a barber shop quartet out of Stormwind known as the Four Dons. That's where I learned how to craft the Bonescythe digs.","Dobrá otázka, $r. Za mlada jsem byl bezstarostný a neměl jsem jedinou starost na světě. V těch dobách jsem zpíval ve stormwindském holičském kvartetu jménem Four Dons. Právě tam jsem se naučil vyrábět výbavu Bonescythe.")
-- source_id 622
add("Georgio Bolero","Good! I can tell that my efforts will not be wasted!","Dobře! Vidím, že moje úsilí nepřijde nazmar!")
add("Josef Gregorian","Good! I can tell that my efforts will not be wasted!","Dobře! Vidím, že moje úsilí nepřijde nazmar!")
-- source_id 623
add("Rhiannon Davis","Good, you've got some grit! I like that. Well then, let's get going!","Dobře, máš kuráž! To se mi líbí. Tak tedy, pusťme se do toho!")
-- source_id 624
add("Magistrate Marduke","Good. In order to carry out my plan, we must first create a lifestone. Are you prepared to act?","Dobře. Abychom mohli uskutečnit můj plán, musíme nejprve vytvořit lifestone. Jsi připraven jednat?")
-- source_id 625
add("Gordo","Gordo like picking flowers. Pick flowers kind of like killing.","Gordo rád trhat květiny. Trhat květiny skoro jako zabíjet.")
-- source_id 626
add("Adele Fielder","Gosh, I'm sorry. I don't have anything new to teach you. How about you go talk to Simon Tanner in the Old Town section of Stormwind? He's a human with big muscles and dreamy red hair.","Ach, omlouvám se. Nemám nic nového, co bych tě mohl naučit. Co kdybys zašel za Simonem Tannerem do Old Town ve Stormwindu? Je to člověk s velkými svaly a nádhernými zrzavými vlasy.")
-- source_id 627
add("Vizzklick","Grab your things, $N! I've just gotten word from Nilith Lokrav in the Searing Gorge that the Undermarket has set up operations in the heart of the Cauldron. Find Nilith Lokrav in the Searing Gorge and get the low down!","Popadni věci, $N! Právě jsem dostal zprávu od Nilith Lokrav v Searing Gorge, že Undermarket zahájil činnost přímo v srdci Cauldronu. Najdi Nilith Lokrav v Searing Gorge a zjisti podrobnosti!")
-- source_id 628
add("Undercity Guardian","Graham Van Talen in Rogues' Quarter on outer ring of Undercity.","Graham Van Talen je v Rogues' Quarter na vnějším okruhu Undercity.")
-- source_id 629
add("Karang Amakkar","Greeting $c - welcome to the front lines in our conquest of Ashenvale!  If you are looking for something to do, then you've come to the right place.  I'm always looking for able-bodied individuals to help bring glory to the Horde!","Zdravím, $c — vítej v první linii našeho dobývání Ashenvale! Pokud hledáš něco na práci, jsi na správném místě. Neustále hledám schopné jedince, kteří pomohou přinést slávu Hordě!")
-- source_id 630
add("Pratt McGrubben","Greetings $c -- if you're looking for leather goods and leatherworking supplies, you've come to the right semi-retired Paladin.","Zdravím, $c — pokud hledáš kožené zboží a potřeby pro leatherworking, přišel jsi ke správnému polovičnímu vysloužilému paladinovi.")
-- source_id 631
add("Aethalas","Greetings $c.  Do you wish to aid the Silverwing Sentinels in their fight at Warsong Gulch?","Zdravím, $c. Chceš pomoci Silverwing Sentinels v jejich boji ve Warsong Gulch?")
-- source_id 632
add("Tharnariun Treetender","Greetings $R, I am Tharnariun Treetender.","Zdravím, $R, jsem Tharnariun Treetender.")
-- source_id 633
add("Dirk Thunderwood","Greetings and salutations from the manor Ravenholdt, adventurer.","Pozdravy a úcta z panství Ravenholdt, dobrodruhu.")
-- source_id 634
add("Bluff Runner Windstrider","Greetings and salutations, hero!  I have the latest news from both continents and points beyond for your consideration.","Zdravím tě, hrdino! Mám pro tebe nejnovější zprávy z obou kontinentů i vzdálenějších míst.")
add("Courier Hammerfall","Greetings and salutations, hero!  I have the latest news from both continents and points beyond for your consideration.","Zdravím tě, hrdino! Mám pro tebe nejnovější zprávy z obou kontinentů i vzdálenějších míst.")
add("Crier Goodman","Greetings and salutations, hero!  I have the latest news from both continents and points beyond for your consideration.","Zdravím tě, hrdino! Mám pro tebe nejnovější zprávy z obou kontinentů i vzdálenějších míst.")
add("Harbinger Balthazad","Greetings and salutations, hero!  I have the latest news from both continents and points beyond for your consideration.","Zdravím tě, hrdino! Mám pro tebe nejnovější zprávy z obou kontinentů i vzdálenějších míst.")
add("Herald Moonstalker","Greetings and salutations, hero!  I have the latest news from both continents and points beyond for your consideration.","Zdravím tě, hrdino! Mám pro tebe nejnovější zprávy z obou kontinentů i vzdálenějších míst.")
add("Warcaller Gorlach","Greetings and salutations, hero!  I have the latest news from both continents and points beyond for your consideration.","Zdravím tě, hrdino! Mám pro tebe nejnovější zprávy z obou kontinentů i vzdálenějších míst.")
-- source_id 635
add("Bluffwatcher","Greetings honored one.  Turak Runetotem and the other druids have been expecting you at the Hall of Elders on Elder Rise.","Zdravím tě, ctěný. Turak Runetotem a ostatní druidové tě očekávají v Hall of Elders na Elder Rise.")
-- source_id 636
add("Elsharin","Greetings mage.  Shall I provide you with further insight into the world of magic?","Zdravím, mágu. Mám ti nabídnout další vhled do světa magie?")
add("Jennea Cannon","Greetings mage.  Shall I provide you with further insight into the world of magic?","Zdravím, mágu. Mám ti nabídnout další vhled do světa magie?")
add("Khelden Bremen","Greetings mage.  Shall I provide you with further insight into the world of magic?","Zdravím, mágu. Mám ti nabídnout další vhled do světa magie?")
add("Maginor Dumas","Greetings mage.  Shall I provide you with further insight into the world of magic?","Zdravím, mágu. Mám ti nabídnout další vhled do světa magie?")
add("Zaldimar Wefhellt","Greetings mage.  Shall I provide you with further insight into the world of magic?","Zdravím, mágu. Mám ti nabídnout další vhled do světa magie?")
-- source_id 637
add("Silas Darkmoon","Greetings my friend, and welcome to the greatest show on Azeroth!$B$BPlease, step right up and take in all we have to offer.  Amaze at the wonders that the Darkmoon Faire has uncovered in this vast and mysterious world!  We have spared no expense in bringing you excitement that children of all ages will delight in!","Zdravím tě, příteli, a vítej na největší podívané v Azerothu!$B$BPojď blíž a užij si vše, co nabízíme. Žasni nad divy, které Darkmoon Faire objevil v tomto rozlehlém a tajemném světě! Nešetřili jsme na ničem, abychom ti přinesli vzrušení, které potěší děti každého věku!")
-- source_id 638
add("Annora","Greetings traveler, you have my undying gratitude for dispensing with those dreadful creatures! I was beginning to think I might have to hide out forever!","Zdravím tě, poutníku, máš mou nehynoucí vděčnost za to, že ses vypořádal s těmi příšernými tvory! Už jsem si začínal myslet, že se budu muset skrývat navždy!")
-- source_id 639
add("Cairne Bloodhoof","Greetings young one, and welcome to Thunder Bluff.  You'll find safe refuge from the burdens of the world here.  All denizens of the Horde are welcome here.$B$BThe spirits of the present and past come alive here in this sacred place, my friend.  Honor them, and in doing so honor yourself.","Zdravím tě, mladý, a vítej v Thunder Bluff. Zde najdeš bezpečné útočiště před břemeny světa. Všichni obyvatelé Hordy jsou zde vítáni.$B$BDuchové současnosti i minulosti zde v tomto posvátném místě ožívají, příteli. Cti je, a tím uctíš i sám sebe.")
-- source_id 640
add("Frahun Shadewhisper","Greetings young rogue. What do you seek?","Zdravím, mladý rogue. Co hledáš?")
add("Hogral Bakkan","Greetings young rogue. What do you seek?","Zdravím, mladý rogue. Co hledáš?")
add("Keryn Sylvius","Greetings young rogue. What do you seek?","Zdravím, mladý rogue. Co hledáš?")
-- source_id 641
add("Vazario Linkgrease","Greetings!  If you are here to access goblin engineering schemata, please have your goblin engineer membership card ready for verification.","Zdravím! Pokud jsi tu kvůli přístupu ke goblin engineering schematům, připrav si prosím členskou kartu goblin engineera k ověření.")
-- source_id 642
add("Darnassus Commendation Officer","Greetings, $c - I'm a Commendation Officer acting on behalf of Darnassus.  It is my duty to assist adventurers who have received Alliance Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Darnassus for your duty and service.","Zdravím, $c — jsem Commendation Officer jednající jménem Darnassusu. Mou povinností je pomáhat dobrodruhům, kteří obdrželi Alliance Commendation Signets.$B$BPřijímám signety v různém množství, ale nejvýhodnější je odevzdat deset najednou. Při jejich odevzdání zapíšu tvé zásluhy do našich záznamů. Díky tomu získáš uznání Darnassusu za svou službu a oddanost.")
add("Officer Lunalight","Greetings, $c - I'm a Commendation Officer acting on behalf of Darnassus.  It is my duty to assist adventurers who have received Alliance Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Darnassus for your duty and service.","Zdravím, $c — jsem Commendation Officer jednající jménem Darnassusu. Mou povinností je pomáhat dobrodruhům, kteří obdrželi Alliance Commendation Signets.$B$BPřijímám signety v různém množství, ale nejvýhodnější je odevzdat deset najednou. Při jejich odevzdání zapíšu tvé zásluhy do našich záznamů. Díky tomu získáš uznání Darnassusu za svou službu a oddanost.")
-- source_id 643
add("Ironforge Commendation Officer","Greetings, $c - I'm a Commendation Officer acting on behalf of Ironforge.  It is my duty to assist adventurers who have received Alliance Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Ironforge for your duty and service.","Zdravím, $c — jsem Commendation Officer jednající jménem Ironforge. Mou povinností je pomáhat dobrodruhům, kteří obdrželi Alliance Commendation Signets.$B$BPřijímám signety v různém množství, ale nejvýhodnější je odevzdat deset najednou. Při jejich odevzdání zapíšu tvé zásluhy do našich záznamů. Díky tomu získáš uznání Ironforge za svou službu a oddanost.")
add("Officer Ironbeard","Greetings, $c - I'm a Commendation Officer acting on behalf of Ironforge.  It is my duty to assist adventurers who have received Alliance Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Ironforge for your duty and service.","Zdravím, $c — jsem Commendation Officer jednající jménem Ironforge. Mou povinností je pomáhat dobrodruhům, kteří obdrželi Alliance Commendation Signets.$B$BPřijímám signety v různém množství, ale nejvýhodnější je odevzdat deset najednou. Při jejich odevzdání zapíšu tvé zásluhy do našich záznamů. Díky tomu získáš uznání Ironforge za svou službu a oddanost.")
-- source_id 644
add("Orgrimmar Commendation Officer","Greetings, $c - I'm a Commendation Officer acting on behalf of Orgrimmar.  It is my duty to assist adventurers who have received Horde Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Orgrimmar for your duty and service.","Zdravím, $c — jsem Commendation Officer jednající jménem Orgrimmaru. Mou povinností je pomáhat dobrodruhům, kteří obdrželi Horde Commendation Signets.$B$BPřijímám signety v různém množství, ale nejvýhodnější je odevzdat deset najednou. Při jejich odevzdání zapíšu tvé zásluhy do našich záznamů. Díky tomu získáš uznání Orgrimmaru za svou službu a oddanost.")
-- source_id 645
add("Officer Maloof","Greetings, $c - I'm a Commendation Officer acting on behalf of Stormwind.  It is my duty to assist adventurers who have received Alliance Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Stormwind for your duty and service.","Zdravím, $c — jsem Commendation Officer jednající jménem Stormwindu. Mou povinností je pomáhat dobrodruhům, kteří obdrželi Alliance Commendation Signets.$B$BPřijímám signety v různém množství, ale nejvýhodnější je odevzdat deset najednou. Při jejich odevzdání zapíšu tvé zásluhy do našich záznamů. Díky tomu získáš uznání Stormwindu za svou službu a oddanost.")
add("Stormwind Commendation Officer","Greetings, $c - I'm a Commendation Officer acting on behalf of Stormwind.  It is my duty to assist adventurers who have received Alliance Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Stormwind for your duty and service.","Zdravím, $c — jsem Commendation Officer jednající jménem Stormwindu. Mou povinností je pomáhat dobrodruhům, kteří obdrželi Alliance Commendation Signets.$B$BPřijímám signety v různém množství, ale nejvýhodnější je odevzdat deset najednou. Při jejich odevzdání zapíšu tvé zásluhy do našich záznamů. Díky tomu získáš uznání Stormwindu za svou službu a oddanost.")
-- source_id 646
add("Darkspear Commendation Officer","Greetings, $c - I'm a Commendation Officer acting on behalf of the Darkspear tribe.  It is my duty to assist adventurers who have received Horde Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from the Darkspear tribe for your duty and service.","Zdravím, $c — jsem Commendation Officer jednající jménem kmene Darkspear. Mou povinností je pomáhat dobrodruhům, kteří obdrželi Horde Commendation Signets.$B$BPřijímám signety v různém množství, ale nejvýhodnější je odevzdat deset najednou. Při jejich odevzdání zapíšu tvé zásluhy do našich záznamů. Díky tomu získáš uznání kmene Darkspear za svou službu a oddanost.")
-- source_id 647
add("Gnomeregan Commendation Officer","Greetings, $c - I'm a Commendation Officer acting on behalf of the Gnomeregan Exiles.  It is my duty to assist adventurers who have received Alliance Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from the Gnomeregan Exiles for your duty and service.","Zdravím, $c — jsem Commendation Officer jednající jménem Gnomeregan Exiles. Mou povinností je pomáhat dobrodruhům, kteří obdrželi Alliance Commendation Signets.$B$BPřijímám signety v různém množství, ale nejvýhodnější je odevzdat deset najednou. Při jejich odevzdání zapíšu tvé zásluhy do našich záznamů. Díky tomu získáš uznání Gnomeregan Exiles za svou službu a oddanost.")
add("Officer Porterhouse","Greetings, $c - I'm a Commendation Officer acting on behalf of the Gnomeregan Exiles.  It is my duty to assist adventurers who have received Alliance Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from the Gnomeregan Exiles for your duty and service.","Zdravím, $c — jsem Commendation Officer jednající jménem Gnomeregan Exiles. Mou povinností je pomáhat dobrodruhům, kteří obdrželi Alliance Commendation Signets.$B$BPřijímám signety v různém množství, ale nejvýhodnější je odevzdat deset najednou. Při jejich odevzdání zapíšu tvé zásluhy do našich záznamů. Díky tomu získáš uznání Gnomeregan Exiles za svou službu a oddanost.")
-- source_id 648
add("Undercity Commendation Officer","Greetings, $c - I'm a Commendation Officer acting on behalf of the Undercity.  It is my duty to assist adventurers who have received Horde Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from the Undercity for your duty and service.","Zdravím, $c — jsem Commendation Officer jednající jménem Undercity. Mou povinností je pomáhat dobrodruhům, kteří obdrželi Horde Commendation Signets.$B$BPřijímám signety v různém množství, ale nejvýhodnější je odevzdat deset najednou. Při jejich odevzdání zapíšu tvé zásluhy do našich záznamů. Díky tomu získáš uznání Undercity za svou službu a oddanost.")
-- source_id 649
add("Thunder Bluff Commendation Officer","Greetings, $c - I'm a Commendation Officer acting on behalf of Thunder Bluff.  It is my duty to assist adventurers who have received Horde Commendation Signets.$B$BI accept signets in different quantities, but the most beneficial exchange for you is to hand in a set of ten at once.  I will enter your deeds into our records when you hand in your signets.  As a result, you will earn recognition from Thunder Bluff for your duty and service.","Zdravím, $c — jsem Commendation Officer jednající jménem Thunder Bluff. Mou povinností je pomáhat dobrodruhům, kteří obdrželi Horde Commendation Signets.$B$BPřijímám signety v různém množství, ale nejvýhodnější je odevzdat deset najednou. Při jejich odevzdání zapíšu tvé zásluhy do našich záznamů. Díky tomu získáš uznání Thunder Bluff za svou službu a oddanost.")
-- source_id 650
add("Deino","Greetings, $c.  Are you here to learn of the hidden arts?","Zdravím, $c. Jsi tu, abys poznal skrytá umění?")
add("Enyo","Greetings, $c.  Are you here to learn of the hidden arts?","Zdravím, $c. Jsi tu, abys poznal skrytá umění?")
add("Mai'ah","Greetings, $c.  Are you here to learn of the hidden arts?","Zdravím, $c. Jsi tu, abys poznal skrytá umění?")
add("Pephredo","Greetings, $c.  Are you here to learn of the hidden arts?","Zdravím, $c. Jsi tu, abys poznal skrytá umění?")
add("Un'Thuwa","Greetings, $c.  Are you here to learn of the hidden arts?","Zdravím, $c. Jsi tu, abys poznal skrytá umění?")
add("Uthel'nay","Greetings, $c.  Are you here to learn of the hidden arts?","Zdravím, $c. Jsi tu, abys poznal skrytá umění?")
-- source_id 651
add("Exzhal","Greetings, $c.  I am Exzhal, Servitor of Rastakhan.","Zdravím, $c. Jsem Exzhal, služebník Rastakhana.")
-- source_id 652
add("Quartermaster Miranda Breechlock","Greetings, $c.  I am Miranda Breechlock - one of but a few authorized equipment and materiel quartermasters for the Dawn.$B$BAs you fight evil under our commission - all the while earning our respect and trust - you'll earn valor tokens from Duke Zverenhoff.  Tokens serve two purposes: use them to gain increased standing within our ranks, or use them as tender in acquiring special items.$B$BAs you improve your standing with the Dawn, you'll discover that more items will be made available to you.","Zdravím, $c. Jsem Miranda Breechlock — jedna z mála oprávněných quartermasterů vybavení a materiálu pro Dawn.$B$BKdyž budeš bojovat proti zlu v našich službách a získávat náš respekt a důvěru, budeš od Duke Zverenhoff dostávat valor tokens. Ty mají dva účely: můžeš je použít ke zvýšení svého postavení v našich řadách, nebo jako platidlo za speciální předměty.$B$BČím lepší postavení u Dawn získáš, tím více předmětů ti bude k dispozici.")
-- source_id 653
add("Deino","Greetings, $c.  I pity your kind, for the secrets of true magic are beyond you...","Zdravím, $c. Lituji tvůj druh, neboť tajemství skutečné magie jsou mimo tvé chápání...")
add("Enyo","Greetings, $c.  I pity your kind, for the secrets of true magic are beyond you...","Zdravím, $c. Lituji tvůj druh, neboť tajemství skutečné magie jsou mimo tvé chápání...")
add("Mai'ah","Greetings, $c.  I pity your kind, for the secrets of true magic are beyond you...","Zdravím, $c. Lituji tvůj druh, neboť tajemství skutečné magie jsou mimo tvé chápání...")
add("Pephredo","Greetings, $c.  I pity your kind, for the secrets of true magic are beyond you...","Zdravím, $c. Lituji tvůj druh, neboť tajemství skutečné magie jsou mimo tvé chápání...")
add("Un'Thuwa","Greetings, $c.  I pity your kind, for the secrets of true magic are beyond you...","Zdravím, $c. Lituji tvůj druh, neboť tajemství skutečné magie jsou mimo tvé chápání...")
add("Uthel'nay","Greetings, $c.  I pity your kind, for the secrets of true magic are beyond you...","Zdravím, $c. Lituji tvůj druh, neboť tajemství skutečné magie jsou mimo tvé chápání...")
-- source_id 654
add("Javnir Nashak","Greetings, $c.  It is the time of the Harvest Festival - a time of great bounties and a time of remembrance.  We partake of feasts to celebrate all we have to be thankful of, and we remember our ancestors and past heroes to give thanks to the legacy they gave us.$B$BPlease feel free to partake of the feast being offered here.  Also, I am offering some fireworks to help celebrate this joyous time of year.","Zdravím, $c. Nastal čas Harvest Festivalu — čas hojnosti a vzpomínek. Hodujeme, abychom oslavili vše, za co můžeme být vděční, a vzpomínáme na své předky a dávné hrdiny, abychom poděkovali za odkaz, který nám zanechali.$B$BKlidně se připoj k hostině, která se zde podává. Nabízím také několik ohňostrojů, abychom tento radostný čas náležitě oslavili.")
add("Wagner Hammerstrike","Greetings, $c.  It is the time of the Harvest Festival - a time of great bounties and a time of remembrance.  We partake of feasts to celebrate all we have to be thankful of, and we remember our ancestors and past heroes to give thanks to the legacy they gave us.$B$BPlease feel free to partake of the feast being offered here.  Also, I am offering some fireworks to help celebrate this joyous time of year.","Zdravím, $c. Nastal čas Harvest Festivalu — čas hojnosti a vzpomínek. Hodujeme, abychom oslavili vše, za co můžeme být vděční, a vzpomínáme na své předky a dávné hrdiny, abychom poděkovali za odkaz, který nám zanechali.$B$BKlidně se připoj k hostině, která se zde podává. Nabízím také několik ohňostrojů, abychom tento radostný čas náležitě oslavili.")
-- source_id 655
add("Yeh'kinya","Greetings, $c.  Though time and drink have dulled my outer senses, my inner eyes remain strong.","Zdravím, $c. Přestože čas a pití otupily mé vnější smysly, mé vnitřní oči zůstávají ostré.")
-- source_id 656
add("Windcaller Proudhorn","Greetings, $c.  Welcome to Cenarion Hold.  From here we will strike against the silithid where they're at their strongest.  I hope you've come to lend a hand.","Zdravím, $c. Vítej v Cenarion Hold. Odtud udeříme na silithidy tam, kde jsou nejsilnější. Doufám, že jsi přišel přiložit ruku k dílu.")
-- source_id 657
add("Quintis Jonespyre","Greetings, $c.  What may this humble servant of the Feathermoon Stronghold do for you today?","Zdravím, $c. Co pro tebe dnes může udělat tento skromný služebník Feathermoon Stronghold?")
-- source_id 658
add("Dendrite Starblaze","Greetings, $c.  You are welcome in Nighthaven, as well as all of Moonglade.  The Cenarion Circle welcomes all beings who respect the authority and command of nature.$B$BWhile you are here, please be sure to preserve the balance in all things.  Disturbances are not welcome here, and our wardens are trained to cease all hostilities without question.","Zdravím, $c. V Nighthaven i v celém Moonglade jsi vítán. Cenarion Circle vítá všechny bytosti, které respektují moc a řád přírody.$B$BPo dobu svého pobytu prosím zachovávej rovnováhu ve všech věcech. Nepokoje zde nejsou vítány a naši strážci jsou vycvičeni ukončit jakékoli nepřátelství bez váhání.")
-- source_id 659
add("Alexia Ironknife","Greetings, $c. Don't have too much time to talk--I'm just using Chillwind as a camp to get some rest before heading to Hearthglen. I've heard word that before they went crazy, the Scarlet Crusade had a mage working for them who was trying to create powerful bows and guns for their soldiers. I'm not sure if he succeeded or not... the Crusade killed him before any of his finished product made it out. Maybe they killed him to keep it a secret... or maybe they distrust the arcane that much.","Zdravím, $c. Nemám moc času na povídání — Chillwind používám jen jako tábor, kde si odpočinu před cestou do Hearthglenu. Slyšel jsem, že než Scarlet Crusade zešílela, pracoval pro ni mág, který se snažil vytvořit mocné luky a pušky pro její vojáky. Nevím, zda uspěl... Crusade ho zabila dřív, než se některý z jeho hotových výrobků dostal ven. Možná ho zabili, aby tajemství zachovali... nebo snad tolik nedůvěřují arcane magii.")
-- source_id 660
add("Torwa Pathfinder","Greetings, $c. For some, the hunter is a way of life, a chosen profession. For others, it is something of a pastime, a badge of courage, or a rite of passage depending on your tribe.$B$BFor me, race and profession mean nothing--it is the testing of your spirit and mind that I respect. For one to stand against the forces of nature and test all of their skills is the true mark of honor.$B$BIf you wish to test yourself and earn my respect, then speak to me more.","Zdravím, $c. Pro některé je lov způsobem života a zvoleným povoláním. Pro jiné je to zábava, odznak odvahy nebo obřad dospělosti podle tradic kmene.$B$BPro mě rasa ani povolání nic neznamenají — vážím si zkoušky ducha a mysli. Postavit se silám přírody a prověřit všechny své schopnosti, to je skutečný znak cti.$B$BChceš-li se prověřit a získat můj respekt, promluv si se mnou dál.")
-- source_id 661
add("Ravenholdt Guard","Greetings, $c. Have you spoken with Fahrad yet?","Zdravím, $c. Už jsi mluvil s Fahradem?")
-- source_id 662
add("Field Marshal Snowfall","Greetings, $c. I am Field Marshal Snowfall, commander of the war effort here. We've a hard road to plow ahead of us, $g lad : lass;, so if you can help out, please do so. And feel free to ask questions.","Zdravím, $c. Jsem Field Marshal Snowfall, velitel zdejšího válečného úsilí. Čeká nás těžká cesta, $gmladíku:slečno;, takže pokud můžeš pomoci, udělej to. A klidně se ptej.")
-- source_id 663
add("Squire Leoren Mal'derath","Greetings, $c. I am Leoren, stable master of Cenarion Hold.","Zdravím, $c. Jsem Leoren, stable master z Cenarion Hold.")
-- source_id 664
add("Aboda","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Alassin","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Antarius","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Anya Maulray","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Awenasa","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Azzleby","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Bethaine Flinthammer","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Bulrug","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Durik","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Erma","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Frostwolf Stable Master","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Gereck","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Greth","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Grimestack","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Hekkru","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Jaelysia","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Jenova Stoneshield","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Kelsuwa","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Killium Bouldertoe","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Kirk Maxwell","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Laziphus","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Lina Hearthstove","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Maluressian","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Michael","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Morganus","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Penny","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Qeeju","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Reggifuz","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Sarah Goode","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Seikwa","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Seriadne","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Shelby Stoneflint","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Shelgrayn","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Shoja'my","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Shyrka Wolfrunner","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Sikwa","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Steven Black","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Sylista","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Tharlidun","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Theodore Mont Claire","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Ulbrek Firehand","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Wesley","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
add("Xon'cha","Greetings, $c. I can assist you in recovering lost companions.","Zdravím, $c. Mohu ti pomoci získat zpět ztracené společníky.")
-- source_id 665
add("Aboda","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Alassin","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Antarius","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Anya Maulray","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Awenasa","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Azzleby","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Bethaine Flinthammer","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Bulrug","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Durik","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Erma","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Frostwolf Stable Master","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Gereck","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Greth","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Grimestack","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Hekkru","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Jaelysia","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Jenova Stoneshield","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Kelsuwa","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Killium Bouldertoe","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Kirk Maxwell","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Laziphus","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Lina Hearthstove","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Maluressian","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Michael","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Morganus","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Penny","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Qeeju","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Reggifuz","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Sarah Goode","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Seikwa","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Seriadne","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Shelby Stoneflint","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Shelgrayn","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Shoja'my","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Shyrka Wolfrunner","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Sikwa","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Steven Black","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Sylista","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Tharlidun","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Theodore Mont Claire","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Ulbrek Firehand","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Wesley","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
add("Xon'cha","Greetings, $c. I can help stable your pets or assist you in recovering lost companions.","Zdravím, $c. Mohu ustájit tvé pety nebo ti pomoci získat zpět ztracené společníky.")
-- source_id 666
add("Braug Dimspirit","Greetings, $c. Is there something I can help you with?","Zdravím, $c. Mohu ti s něčím pomoci?")
-- source_id 667
add("Chief Sharpclaw","Greetings, $c. It is good to see you interested in helping with the war effort. The collectors here are organizing the gathering of various stockpiles of goods so that we will be prepared when the time comes.$B$BI am in charge of obtaining $2106w baked salmon to store away for those involved in the fighting at Ahn'Qiraj. The last time that I counted, we had collected $2105w.","Zdravím, $c. Je dobře, že se zajímáš o pomoc s válečným úsilím. Sběrači zde organizují shromažďování různých zásob, abychom byli připraveni, až přijde čas.$B$BMám na starosti získání $2106w baked salmon do zásoby pro ty, kteří budou bojovat u Ahn'Qiraj. Při posledním sčítání jsme měli nasbíráno $2105w.")
-- source_id 668
add("Shindrell Swiftfire","Greetings, $c. Our position here is a bit exposed given the build up of the Horde's forces to the south.$B$BAnything that you can do to help will be greatly appreciated.","Zdravím, $c. Naše pozice je zde poněkud odkrytá vzhledem k rostoucím silám Hordy na jihu.$B$BCokoli, čím můžeš pomoci, bude velmi vítané.")
-- source_id 669
add("Loh'atu","Greetings, $c.$B$BThose Sentinels over there have allowed me to share their camp as long as I promise no trouble will follow--I am sure you can appreciate the need for diplomacy while here, yes?$B$BI am here investigating disturbances to the land, and since it aids their cause also, they have agreed that my presence here could only aid the tenuous alliance between all of Azeroth's races. If you wish to aid me, then I would appreciate it, but regardless, please try not to cause any trouble.","Zdravím, $c.$B$BTamti Sentinels mi dovolili sdílet jejich tábor pod podmínkou, že sem nepřivedu žádné potíže — jistě chápeš, že zde musíme jednat diplomaticky, že ano?$B$BZkoumám zde narušení země, a protože to zároveň pomáhá i jejich věci, souhlasili, že má přítomnost může jen prospět křehkému spojenectví mezi všemi rasami Azerothu. Pokud mi chceš pomoci, budu rád, ale v každém případě se prosím snaž nezpůsobit žádné potíže.")
-- source_id 670
add("Grelin Whitebeard","Greetings, $glad:lass;. I'm Grelin Whitebeard. I'm here to examine the threat posed by the growing numbers of trolls in Coldridge Valley. What have I found? It's a bit troubling...","Zdravím, $gmladíku:slečno;. Jsem Grelin Whitebeard. Jsem tu, abych prozkoumal hrozbu rostoucího počtu trollů v Coldridge Valley. Co jsem zjistil? Je to trochu znepokojivé...")
-- source_id 671
add("Nyrill","Greetings, $Gsir:miss;. I am Master Xylem's apprentice Nyrill. If you have any concerns, please feel free to bring them up with the master.$B$BI will be here to serve you when you're ready to return down to the base of the mountain.","Zdravím, $Gpane:slečno;. Jsem Nyrill, učedník Master Xylema. Pokud máš jakékoli obavy, neváhej je přednést mistrovi.$B$BAž budeš připraven vrátit se dolů k úpatí hory, budu ti zde k službám.")
-- source_id 672
add("Grull Hawkwind","Greetings, $N, and welcome to Camp Narache. News of your arrival spread quickly among the tribe.","Zdravím, $N, a vítej v Camp Narache. Zpráva o tvém příchodu se kmenem rychle roznesla.")
-- source_id 673
add("Lunar Festival Harbinger","Greetings, $N.  We've travelled from Moonglade to spread the spirit of the Lunar Festival far and wide.$B$BWon't you join us in our celebration?","Zdravím, $N. Přicestovali jsme z Moonglade, abychom ducha Lunar Festivalu šířili široko daleko.$B$BNechceš se k nám přidat a slavit s námi?")
-- source_id 674
add("Royal Historian Archesonus","Greetings, $N. Have you come to learn of the history of Ironforge?","Zdravím, $N. Přišel jsi poznat historii Ironforge?")
-- source_id 675
add("Doctor Gregory Victor","Greetings, $N. I am Doctor Gregory Victor, head trauma surgeon of Horde Trauma.","Zdravím, $N. Jsem Doctor Gregory Victor, hlavní traumatolog Horde Trauma.")
-- source_id 676
add("Doctor Gustaf VanHowzen","Greetings, $N. I am Doctor Gustaf VanHowzen, head trauma surgeon of Alliance Trauma.","Zdravím, $N. Jsem Doctor Gustaf VanHowzen, hlavní traumatolog Alliance Trauma.")
-- source_id 677
add("Johnny McWeaksauce","Greetings, $N. I am Johnny McWeaksauce. I am used as a tool by developers to carry out specific functions for the purpose of testing. For this test period, I am set to do two specific things:$B$B(1) Flag you as having done the Naxxramas attunement quest so that you are able to accept the next quest, \"Echoes of War\" from Commander Eligor Dawnbringer. You must first complete that quest to be able to access the quests for your Tier 3 armor set.$B$B(2) Teleport you to Naxxramas.$B$BWhat is it that you require?","Zdravím, $N. Jsem Johnny McWeaksauce. Vývojáři mě používají jako nástroj k provádění konkrétních funkcí pro účely testování. Pro toto testovací období jsem nastaven na dvě konkrétní věci:$B$B(1) Označím tě, jako bys dokončil attunement quest do Naxxramasu, abys mohl přijmout následující quest „Echoes of War“ od Commander Eligor Dawnbringera. Nejprve musíš dokončit tento quest, abys získal přístup k questům pro svůj Tier 3 armor set.$B$B(2) Teleportuji tě do Naxxramasu.$B$BCo potřebuješ?")
-- source_id 678
add("Myolor Sunderfury","Greetings, $N. I am Myolor Sunderfury, keeper of the Great Forge.","Zdravím, $N. Jsem Myolor Sunderfury, správce Great Forge.")
-- source_id 679
add("Johnny McWeaksauce","Greetings, $N. I see that you are already flagged as having completed the quest to gain entry to Naxxramas. Be sure to speak with Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands to acquire the quest, \"Echoes of War.\" You must first complete that quest to be able to access the quests for your Tier 3 armor set.$B$BI am able to teleport you directly to Naxxramas or you may use the portal found in Plaguewood, to the west.","Zdravím, $N. Vidím, že už jsi označen jako někdo, kdo dokončil quest potřebný pro vstup do Naxxramasu. Nezapomeň si promluvit s Commander Eligor Dawnbringerem v Light's Hope Chapel v Eastern Plaguelands a získat quest „Echoes of War“. Nejprve jej musíš dokončit, abys získal přístup k questům pro svůj Tier 3 armor set.$B$BMohu tě teleportovat přímo do Naxxramasu, nebo můžeš použít portál v Plaguewood na západě.")
-- source_id 680
add("Commander Stronghammer","Greetings, $r $c. I am Commander Stronghammer, the ambassador representing the Alliance here. If you have any questions concerning the status of Alliance collections for the Ahn'Qiraj war effort, $g lad : lass;, don't hesitate to ask.","Zdravím, $r $c. Jsem Commander Stronghammer, velvyslanec zastupující zde Alliance. Pokud máš nějaké otázky ohledně stavu aliančních sbírek pro válečné úsilí u Ahn'Qiraj, $gmladíku:slečno;, neváhej se zeptat.")
-- source_id 681
add("Ironus Coldsteel","Greetings, $r.","Zdravím, $r.")
-- source_id 682
add("Franclorn Forgewright","Greetings, $r. I am Franclorn Forgewright. Are you here to learn of the Spire and of Dark Iron?","Zdravím, $r. Jsem Franclorn Forgewright. Jsi tu, abys poznal historii Spire a Dark Iron?")
-- source_id 683
add("Huntress Swiftriver","Greetings, $r. The war materiel is gradually being sent on its way and should be at Cenarion Hold within $2113w day's time. We can only hope that once it is there that someone, having assembled the Scepter of the Shifting Sands, will step forward to ring the gong and open the gates.","Zdravím, $r. Válečný materiál je postupně odesílán a do Cenarion Hold by měl dorazit během $2113w dne. Můžeme jen doufat, že až tam dorazí, někdo, kdo sestavil Scepter of the Shifting Sands, vystoupí vpřed, zazvoní na gong a otevře brány.")
-- source_id 684
add("Huntress Swiftriver","Greetings, $r. The war materiel is on its way and should be at Cenarion Hold within a day's time. We can only hope that once it is there that someone, having assembled the Scepter of the Shifting Sands, will step forward to ring the gong and open the gates.","Zdravím, $r. Válečný materiál je na cestě a do Cenarion Hold by měl dorazit během jednoho dne. Můžeme jen doufat, že až tam dorazí, někdo, kdo sestavil Scepter of the Shifting Sands, vystoupí vpřed, zazvoní na gong a otevře brány.")
-- source_id 685
add("Gordon Wendham","Greetings, and welcome.  I am not very good at smiling, but trust me; I am happy to serve you.","Zdravím a vítej. Neumím se moc usmívat, ale věř mi, rád ti posloužím.")
-- source_id 686
add("Squire Rowe","Greetings, citizen. I ask that you move along if you have nothing to ask of me.","Zdravím, občane. Pokud ode mě nic nepotřebuješ, žádám tě, abys pokračoval dál.")
-- source_id 687
add("Mux Manascrambler","Greetings, friend!  Can I interest you in some ectoplasmic capacitors?  Or perhaps a nice omni-directional spectral assimilator?","Zdravím, příteli! Neměl bys zájem o nějaké ectoplasmic capacitors? Nebo snad pěkný omni-directional spectral assimilator?")
-- source_id 688
add("Hydraxian Honor Guard","Greetings, little one.  You have business with the Waterlords?","Zdravím, maličký. Máš něco s Waterlords?")
-- source_id 689
add("Gregor Greystone","Greetings, my friend.  May the Dawn keep you well in these troubled times.","Zdravím, příteli. Kéž tě Dawn v těchto neklidných časech chrání.")
-- source_id 690
add("Bashana Runetotem","Greetings, noble $c.  This humble servant of the Cenarion Circle wishes blessings and bounties be given unto you and yours.","Zdravím, vznešený $c. Tento skromný služebník Cenarion Circle přeje požehnání a hojnost tobě i tvým blízkým.")
-- source_id 691
add("Vance Undergloom","Greetings, traveler! Care to delve into the mysteries of the arcane? Hm?","Zdravím, poutníku! Chceš proniknout do tajemství arcane magie? Hm?")
-- source_id 692
add("Ralo'shan the Eternal Watcher","Greetings, traveler. It was here, nearly 1,000 years past, that the Qiraji began their march of destruction across Kalimdor.$B$BThousands of lives were lost during the war, most in this cursed desert during the initial invasion.$B$BI am one of only a few that remain, chained to both the past and the present. I know not why I am to remain stationed here but I know that I must.","Zdravím, poutníku. Právě zde, téměř před 1 000 lety, zahájili Qiraji svůj ničivý pochod napříč Kalimdorem.$B$BBěhem války zahynuly tisíce životů, většina v této prokleté poušti při počáteční invazi.$B$BJsem jedním z mála, kteří zůstali, připoután k minulosti i přítomnosti. Nevím, proč zde musím zůstávat, ale vím, že musím.")
-- source_id 693
add("Eitrigg","Greetings, young $c.","Zdravím, mladý $c.")
-- source_id 694
add("Master Nightsong","Greetings, young $c. In preparation for the war at Ahn'Qiraj against the Silithid, the Alliance has asked me to head up their collection of purple lotus. This flower has many uses that I am aware of, and thus, I have agreed to help them attain $2055w. To date we have collected $2053w.","Zdravím, mladý $c. V rámci příprav na válku proti Silithidům u Ahn'Qiraj mě Alliance požádala, abych vedl sběr purple lotus. Tato květina má mnoho využití, která znám, a proto jsem souhlasil, že pomohu získat $2055w. Dosud jsme nasbírali $2053w.")
-- source_id 695
add("Alyissia","Greetings.  Do you seek instruction in art of war?","Zdravím. Hledáš výcvik v umění boje?")
add("Arias'ta Bladesinger","Greetings.  Do you seek instruction in art of war?","Zdravím. Hledáš výcvik v umění boje?")
add("Darnath Bladesinger","Greetings.  Do you seek instruction in art of war?","Zdravím. Hledáš výcvik v umění boje?")
add("Kelv Sternhammer","Greetings.  Do you seek instruction in art of war?","Zdravím. Hledáš výcvik v umění boje?")
add("Kyra Windblade","Greetings.  Do you seek instruction in art of war?","Zdravím. Hledáš výcvik v umění boje?")
-- source_id 696
add("Chronos","Greetings.  I am Chronos - He Who Never Forgets.  My memory is without flaw, and exact to the most minor detail.$B$BTrust me.","Zdravím. Jsem Chronos — Ten, který nikdy nezapomíná. Má paměť je bezchybná a přesná do nejmenšího detailu.$B$BVěř mi.")
-- source_id 697
add("Bink","Greetings.  I'm a gnome mage trainer, and you're a mage.","Zdravím. Jsem gnome mage trainer a ty jsi mág.")
add("Dink","Greetings.  I'm a gnome mage trainer, and you're a mage.","Zdravím. Jsem gnome mage trainer a ty jsi mág.")
add("Juli Stormkettle","Greetings.  I'm a gnome mage trainer, and you're a mage.","Zdravím. Jsem gnome mage trainer a ty jsi mág.")
add("Magis Sparkmantle","Greetings.  I'm a gnome mage trainer, and you're a mage.","Zdravím. Jsem gnome mage trainer a ty jsi mág.")
add("Marryk Nurribit","Greetings.  I'm a gnome mage trainer, and you're a mage.","Zdravím. Jsem gnome mage trainer a ty jsi mág.")
add("Nittlebur Sparkfizzle","Greetings.  I'm a gnome mage trainer, and you're a mage.","Zdravím. Jsem gnome mage trainer a ty jsi mág.")
-- source_id 698
add("Anastasia Hartwell","Greetings.  I'm an undead mage trainer, and you're a mage.","Zdravím. Jsem undead mage trainer a ty jsi mág.")
add("Archmage Shymm","Greetings.  I'm an undead mage trainer, and you're a mage.","Zdravím. Jsem undead mage trainer a ty jsi mág.")
add("Cain Firesong","Greetings.  I'm an undead mage trainer, and you're a mage.","Zdravím. Jsem undead mage trainer a ty jsi mág.")
add("Isabella","Greetings.  I'm an undead mage trainer, and you're a mage.","Zdravím. Jsem undead mage trainer a ty jsi mág.")
add("Kaelystia Hatebringer","Greetings.  I'm an undead mage trainer, and you're a mage.","Zdravím. Jsem undead mage trainer a ty jsi mág.")
add("Pierce Shackleton","Greetings.  I'm an undead mage trainer, and you're a mage.","Zdravím. Jsem undead mage trainer a ty jsi mág.")
add("Thurston Xane","Greetings.  I'm an undead mage trainer, and you're a mage.","Zdravím. Jsem undead mage trainer a ty jsi mág.")
add("Ursyn Ghull","Greetings.  I'm an undead mage trainer, and you're a mage.","Zdravím. Jsem undead mage trainer a ty jsi mág.")
-- source_id 699
add("Ahanu","Greetings.  If you are here for leather goods, then you will find my wares well crafted.","Zdravím. Pokud hledáš kožené zboží, zjistíš, že mé výrobky jsou kvalitně zpracované.")
-- source_id 700
add("Karos Razok","Greetings.  Our bats are well trained and fed.  You'll not find faster.","Zdravím. Naši netopýři jsou dobře vycvičení a krmení. Rychlejší nenajdeš.")
-- source_id 701
add("Alyissia","Greetings.  You seek instruction in the art of war?","Zdravím. Hledáš výcvik v umění boje?")
add("Arias'ta Bladesinger","Greetings.  You seek instruction in the art of war?","Zdravím. Hledáš výcvik v umění boje?")
add("Darnath Bladesinger","Greetings.  You seek instruction in the art of war?","Zdravím. Hledáš výcvik v umění boje?")
add("Kelv Sternhammer","Greetings.  You seek instruction in the art of war?","Zdravím. Hledáš výcvik v umění boje?")
add("Kyra Windblade","Greetings.  You seek instruction in the art of war?","Zdravím. Hledáš výcvik v umění boje?")
-- source_id 702
add("Dun Morogh Mountaineer","Gremlock doesn't always have the best of luck with cooking, but he does have some tasty recipies worth learning.  Go chat him up in the Thunderbrew Distillery and see what he'll teach ye.","Gremlock nemá při vaření vždycky největší štěstí, ale zná pár chutných receptů, které stojí za to se naučit. Zajdi za ním do Thunderbrew Distillery a zjisti, co tě může naučit.")
add("Ironforge Mountaineer","Gremlock doesn't always have the best of luck with cooking, but he does have some tasty recipies worth learning.  Go chat him up in the Thunderbrew Distillery and see what he'll teach ye.","Gremlock nemá při vaření vždycky největší štěstí, ale zná pár chutných receptů, které stojí za to se naučit. Zajdi za ním do Thunderbrew Distillery a zjisti, co tě může naučit.")
add("Mounted Ironforge Mountaineer","Gremlock doesn't always have the best of luck with cooking, but he does have some tasty recipies worth learning.  Go chat him up in the Thunderbrew Distillery and see what he'll teach ye.","Gremlock nemá při vaření vždycky největší štěstí, ale zná pár chutných receptů, které stojí za to se naučit. Zajdi za ním do Thunderbrew Distillery a zjisti, co tě může naučit.")
-- source_id 703
add("Ironforge Guard","Grimnur Stonebrand will tell ye some whoppers about the one that got away, but he's still one o' the best fishermen around.  He's got a shop set up in The Forlorn Cavern called the Traveling Fisherman.","Grimnur Stonebrand ti bude vykládat neuvěřitelné historky o tom, co mu uniklo, ale pořád patří k nejlepším rybářům v okolí. Má obchod v The Forlorn Cavern jménem Traveling Fisherman.")
-- source_id 704
add("Bloodguard Rawtar","Grrr, what do you want, $r? Oh, you must be here about the lean wolf steaks for the impending Ahn'Qiraj War. Yes, you heard right, I'm collecting them, what about it? Do you have a fresh stack for me? I only need $2096w, and it looks like we have $2095w right now.","Grrr, co chceš, $r? Aha, ty jsi určitě přišel kvůli lean wolf steaks pro nadcházející válku u Ahn'Qiraj. Ano, slyšel jsi správně, sbírám je, no a co? Máš pro mě čerstvou hromádku? Potřebuji jen $2096w a právě teď to vypadá, že máme $2095w.")
-- source_id 705
add("Miblon Snarltooth","Grumble, grumble...","Brbl, brbl...")
-- source_id 706
add("Innkeeper Allison","Gryphons, eh? Never really cared for the beasts but to each their own.\n\nYou can find Dungar Longdrink on the rampart in the Trade District.","Gryphoni, jo? Nikdy jsem těm bestiím moc nepřišel na chuť, ale každému co jeho jest.\n\nDungar Longdrink najdeš na hradbě v Trade District.")
add("Innkeeper Heather","Gryphons, eh? Never really cared for the beasts but to each their own.\n\nYou can find Dungar Longdrink on the rampart in the Trade District.","Gryphoni, jo? Nikdy jsem těm bestiím moc nepřišel na chuť, ale každému co jeho jest.\n\nDungar Longdrink najdeš na hradbě v Trade District.")
add("Innkeeper Janene","Gryphons, eh? Never really cared for the beasts but to each their own.\n\nYou can find Dungar Longdrink on the rampart in the Trade District.","Gryphoni, jo? Nikdy jsem těm bestiím moc nepřišel na chuť, ale každému co jeho jest.\n\nDungar Longdrink najdeš na hradbě v Trade District.")
add("Stormwind City Guard","Gryphons, eh? Never really cared for the beasts but to each their own.\n\nYou can find Dungar Longdrink on the rampart in the Trade District.","Gryphoni, jo? Nikdy jsem těm bestiím moc nepřišel na chuť, ale každému co jeho jest.\n\nDungar Longdrink najdeš na hradbě v Trade District.")
add("Stormwind City Patroller","Gryphons, eh? Never really cared for the beasts but to each their own.\n\nYou can find Dungar Longdrink on the rampart in the Trade District.","Gryphoni, jo? Nikdy jsem těm bestiím moc nepřišel na chuť, ale každému co jeho jest.\n\nDungar Longdrink najdeš na hradbě v Trade District.")
add("Vikki Lonsav","Gryphons, eh? Never really cared for the beasts but to each their own.\n\nYou can find Dungar Longdrink on the rampart in the Trade District.","Gryphoni, jo? Nikdy jsem těm bestiím moc nepřišel na chuť, ale každému co jeho jest.\n\nDungar Longdrink najdeš na hradbě v Trade District.")
-- source_id 707
add("Bixi Wobblebonk","Guns are a specialty of Buliwyf's! He's around this shop somewhere.","Pušky jsou Buliwyfova specialita! Někde tady v obchodě určitě bude.")
-- source_id 708
add("Neeru Fireblade","Haha! Save for their leaders--the satyr, Bazzalan, and the warlock Jergosh--yes, all of them. That is why I constantly send Thrall's worshippers at them. It gives Thrall the impression that I am weeding out the evil in the bowels of his great city. The victory is in reality two-fold: kill Thrall's faithful and test the strength of those in the Searing Blade to see if they are truly worthy of joining me.","Haha! Kromě jejich vůdců — satyra Bazzalana a warlocka Jergoshe — ano, všech. Proto proti nim neustále posílám Thrallovy uctívače. Thrall tak získává dojem, že čistím útroby jeho velkého města od zla. Ve skutečnosti je vítězství dvojí: zabiji Thrallovy věrné a zároveň otestuji sílu těch ze Searing Blade, abych zjistil, zda jsou opravdu hodni přidat se ke mně.")
-- source_id 709
add("Sergeant Stonebrow","Haha, $g boyo : girlie;! The Alliance has gathered everything that we're needin' to get this here war started! Maybe the Horde will catch up soon?","Haha, $gchlapče:děvče;! Alliance už shromáždila všechno, co potřebujeme, abychom tuhle válku rozjeli! Třeba se Horde brzy dotáhne?")
-- source_id 710
add("Batrider Pele'keiki","Haha, you be pullin' me leg mon. Pele'keiki know that you know we Horde already be havin' all the war stuff we be needin'. Now we just waitin' on that Alliance to get all theirs and we startin' up the war.","Haha, taháš mě za nohu, mon. Pele'keiki ví, že ty víš, že my Horde už máme všechen válečný materiál, co potřebujeme. Teď jen čekáme, až Alliance nasbírá ten svůj, a pak rozjedeme válku.")
-- source_id 711
add("Garel Redrock","Hail $c. Didn't I see you recently at an exclusive gathering? You look familiar, but then again this city is a busy place.$B$BIf you attended that convention, then surely you were given a secret code. Tell me your code and I will give you a special prize in return.","Zdravím, $c. Neviděl jsem tě nedávno na jednom exkluzivním setkání? Jsi mi povědomý, ale tohle město je zase plné lidí.$B$BPokud ses té akce účastnil, určitě jsi dostal tajný kód. Řekni mi ho a na oplátku ti dám speciální cenu.")
add("Ransin Donner","Hail $c. Didn't I see you recently at an exclusive gathering? You look familiar, but then again this city is a busy place.$B$BIf you attended that convention, then surely you were given a secret code. Tell me your code and I will give you a special prize in return.","Zdravím, $c. Neviděl jsem tě nedávno na jednom exkluzivním setkání? Jsi mi povědomý, ale tohle město je zase plné lidí.$B$BPokud ses té akce účastnil, určitě jsi dostal tajný kód. Řekni mi ho a na oplátku ti dám speciální cenu.")
add("Tharl Stonebleeder","Hail $c. Didn't I see you recently at an exclusive gathering? You look familiar, but then again this city is a busy place.$B$BIf you attended that convention, then surely you were given a secret code. Tell me your code and I will give you a special prize in return.","Zdravím, $c. Neviděl jsem tě nedávno na jednom exkluzivním setkání? Jsi mi povědomý, ale tohle město je zase plné lidí.$B$BPokud ses té akce účastnil, určitě jsi dostal tajný kód. Řekni mi ho a na oplátku ti dám speciální cenu.")
add("Zas'Tysh","Hail $c. Didn't I see you recently at an exclusive gathering? You look familiar, but then again this city is a busy place.$B$BIf you attended that convention, then surely you were given a secret code. Tell me your code and I will give you a special prize in return.","Zdravím, $c. Neviděl jsem tě nedávno na jednom exkluzivním setkání? Jsi mi povědomý, ale tohle město je zase plné lidí.$B$BPokud ses té akce účastnil, určitě jsi dostal tajný kód. Řekni mi ho a na oplátku ti dám speciální cenu.")
-- source_id 712
add("Rumstag Proudstrider","Hail $g brother : sister;... I'd like a moment of your time, if I may.$B$BWe tauren have endured much in our trials and tribulations in establishing our homeland.  We now find ourselves in a dire shortage of cloth.  If you have the materials to spare, I ask that you please donate them.  You certainly would earn the gratitude of tauren everywhere in helping us out!","Zdravím, $gbratře:sestro;... rád bych na chvíli tvůj čas, pokud smím.$B$BMy taureni jsme při zakládání své domoviny prošli mnoha zkouškami a útrapami. Nyní máme vážný nedostatek látky. Pokud můžeš nějaký materiál postrádat, prosím, daruj ho. Pomocí nám si určitě získáš vděčnost taurenů po celém světě!")
-- source_id 713
add("Raedon Duskstriker","Hail friend - a moment of your time, if I may...$B$BWe have endured much in our trials and tribulations in establishing Teldrassil.  Were the constant strife of the times not enough, we now find ourselves in a dire shortage of cloth.  If you have the materials to spare, I ask that you please donate them.  You certainly would earn the gratitude of night elves everywhere in helping us out!","Zdravím, příteli — rád bych na chvíli tvůj čas, pokud smím...$B$BPři zakládání Teldrassilu jsme prošli mnoha zkouškami a útrapami. Jako by neustálé spory této doby nestačily, nyní máme vážný nedostatek látky. Pokud můžeš nějaký materiál postrádat, prosím, daruj ho. Pomocí nám si určitě získáš vděčnost night elfů po celém světě!")
-- source_id 714
add("Captain Kromcrush","Hail to da new king!","Sláva novému králi!")
add("Gordok Brute","Hail to da new king!","Sláva novému králi!")
add("Gordok Bushwacker","Hail to da new king!","Sláva novému králi!")
add("Gordok Captain","Hail to da new king!","Sláva novému králi!")
add("Gordok Mage-Lord","Hail to da new king!","Sláva novému králi!")
add("Gordok Reaver","Hail to da new king!","Sláva novému králi!")
add("Gordok Warlock","Hail to da new king!","Sláva novému králi!")
-- source_id 715
add("Elfarran","Hail to thee $N.  Do you wish me to aid you in your journey to Warsong Gulch?","Buď zdráv, $N. Přeješ si, abych ti pomohl na cestě do Warsong Gulch?")
-- source_id 716
add("Borgosh Corebender","Hail, $c!","Buď zdráv, $c!")
-- source_id 717
add("Janela Stouthammer","Hail, $c.  The Ironforge Brigade is stationed here to keep an eye on Hive'Zora.  The Cenarion Circle druids have been monitoring silithid movement and they're anticipating something major in this area.","Buď zdráv, $c. Ironforge Brigade je zde umístěna, aby dohlížela na Hive'Zora. Druidové z Cenarion Circle sledují pohyb silithidů a očekávají v této oblasti něco velkého.")
-- source_id 718
add("Frostwolf Emissary","Hail, $c.  There is a great need and even greater honor and renown to be had in Alterac Valley at this time. Will you join our fight against the Stormpike Guard?","Buď zdráv, $c. V Alterac Valley je teď velká potřeba pomoci a ještě větší čest a sláva, které tam můžeš získat. Přidáš se k našemu boji proti Stormpike Guard?")
-- source_id 719
add("Sergeant Major Germaine","Hail, $c. As you may know, we've completed all collections necessary for the Alliance's role in the upcoming war. Now it's up to the Horde to finish with theirs and we'll ship out to Silithus.","Buď zdráv, $c. Jak možná víš, dokončili jsme všechny sbírky potřebné pro podíl Alliance v nadcházející válce. Teď je na Horde, aby dokončila své, a pak vyrazíme do Silithusu.")
-- source_id 720
add("Senior Sergeant Grimsford","Hail, $c. I trust you are here to inquire on the Ahn'Qiraj war effort. We are going to need a great deal of assistance.$B$BThe war effort is a united effort between the Horde and Alliance to prepare for the impending war against the Silithid and their masters in Ahn'Qiraj. In Orgrimmar's Valley of Spirits, we are collecting a vast number of goods to create war materiel, and these gathering tasks are what we need your help with.$B$BCan I convince you to speak with our commander about helping out?","Buď zdráv, $c. Předpokládám, že ses přišel zeptat na válečné úsilí u Ahn'Qiraj. Budeme potřebovat opravdu hodně pomoci.$B$BVálečné úsilí je společnou snahou Horde a Alliance připravit se na nadcházející válku proti Silithidům a jejich pánům v Ahn'Qiraj. Ve Valley of Spirits v Orgrimmaru shromažďujeme obrovské množství zásob pro výrobu válečného materiálu a právě s těmito sběry potřebujeme tvou pomoc.$B$BMohu tě přesvědčit, abys o pomoci promluvil s naším velitelem?")
add("Senior Sergeant Kai'jin","Hail, $c. I trust you are here to inquire on the Ahn'Qiraj war effort. We are going to need a great deal of assistance.$B$BThe war effort is a united effort between the Horde and Alliance to prepare for the impending war against the Silithid and their masters in Ahn'Qiraj. In Orgrimmar's Valley of Spirits, we are collecting a vast number of goods to create war materiel, and these gathering tasks are what we need your help with.$B$BCan I convince you to speak with our commander about helping out?","Buď zdráv, $c. Předpokládám, že ses přišel zeptat na válečné úsilí u Ahn'Qiraj. Budeme potřebovat opravdu hodně pomoci.$B$BVálečné úsilí je společnou snahou Horde a Alliance připravit se na nadcházející válku proti Silithidům a jejich pánům v Ahn'Qiraj. Ve Valley of Spirits v Orgrimmaru shromažďujeme obrovské množství zásob pro výrobu válečného materiálu a právě s těmito sběry potřebujeme tvou pomoc.$B$BMohu tě přesvědčit, abys o pomoci promluvil s naším velitelem?")
add("Senior Sergeant Taiga","Hail, $c. I trust you are here to inquire on the Ahn'Qiraj war effort. We are going to need a great deal of assistance.$B$BThe war effort is a united effort between the Horde and Alliance to prepare for the impending war against the Silithid and their masters in Ahn'Qiraj. In Orgrimmar's Valley of Spirits, we are collecting a vast number of goods to create war materiel, and these gathering tasks are what we need your help with.$B$BCan I convince you to speak with our commander about helping out?","Buď zdráv, $c. Předpokládám, že ses přišel zeptat na válečné úsilí u Ahn'Qiraj. Budeme potřebovat opravdu hodně pomoci.$B$BVálečné úsilí je společnou snahou Horde a Alliance připravit se na nadcházející válku proti Silithidům a jejich pánům v Ahn'Qiraj. Ve Valley of Spirits v Orgrimmaru shromažďujeme obrovské množství zásob pro výrobu válečného materiálu a právě s těmito sběry potřebujeme tvou pomoc.$B$BMohu tě přesvědčit, abys o pomoci promluvil s naším velitelem?")
-- source_id 721
add("Lieutenant Haggerdin","Hail, $r! I am Lieutenant Haggerdin, officer in charge of recruitment for the Stormpike Guard.$B$BAs you gain prestige and notoriety among the Stormpike, return to me and I shall see about upgrading your insignia. Also, should you ever lose your insignia, I am able to supply a replacement.","Buď zdráv, $r! Jsem Lieutenant Haggerdin, důstojník odpovědný za nábor do Stormpike Guard.$B$BJak budeš mezi Stormpike získávat prestiž a věhlas, vrať se ke mně a podívám se na vylepšení tvého insignia. A kdybys své insignia někdy ztratil, mohu ti obstarat náhradu.")
-- source_id 722
add("Rin'wosho the Trader","Hail, adventurer. I am Rin'wosho, trader of Zuldazar. I come from the South Seas and bring many exotic goods and items from my homeland.$B$BPerhaps if you prove your worth to my tribe, I shall barter.  If you have any of my tribe's Honor Tokens, then perhaps we shall barter even more.","Buď zdráv, dobrodruhu. Jsem Rin'wosho, obchodník ze Zuldazaru. Přicházím z South Seas a přivážím mnoho exotického zboží a předmětů ze své domoviny.$B$BMožná s tebou budu obchodovat, pokud svému kmeni prokážeš svou hodnotu. A pokud máš nějaké Honor Tokens mého kmene, možná budeme obchodovat ještě více.")
-- source_id 723
add("Betty Quin","Hail, traveler! What brings you to my doorstep?","Buď zdráv, poutníku! Co tě přivádí k mým dveřím?")
-- source_id 724
add("Sayoc","Hanashi here knows staves. If you want a sturdier instructor, go to Thunder Bluff. Ansekhwa will teach you on the lower central rise there.","Hanashi tady rozumí holím. Pokud chceš zkušenějšího instruktora, jdi do Thunder Bluff. Ansekhwa tě bude učit na dolní centrální vyvýšenině.")
-- source_id 725
add("Shen'dralar Zealot","Has the Prince recanted the tale of the Ashbringer? It is our most favorite of his stories. His favorite is the followup to the Ashbringer. Of course, nobody has ever been able to get that story out of him.","Vyprávěl ti princ příběh o Ashbringeru? Je to náš nejoblíbenější z jeho příběhů. Jeho nejoblíbenější je pokračování Ashbringera. Samozřejmě, ten příběh z něj ještě nikdo nikdy nedokázal dostat.")
-- source_id 726
add("Darnassus Sentinel","Has the sun risen already?  There are just never enough hours in the night!  Well, Saelienne will take good care of you.  You can find her tending to her guests over in the Craftsmen's Terrace in northeastern Darnassus.","Už vyšlo slunce? Noci prostě nikdy nemají dost hodin! No, Saelienne se o tebe dobře postará. Najdeš ji, jak se stará o hosty v Craftsmen's Terrace na severovýchodě Darnassusu.")
-- source_id 727
add("Grim Patron","Have a drink, $c.  It might be your last!","Dej si něco k pití, $c. Mohlo by to být tvoje poslední!")
-- source_id 728
add("Zargh","Have a look at my meats, friend.  You won't want to go out into the Barrens without a good stock of provisions.","Prohlédni si moje maso, příteli. Do Barrens se nebudeš chtít vydat bez pořádné zásoby proviantu.")
-- source_id 729
add("Guchie Jinglepocket","Have a wondrous Feast of Winter Veil!  Start it off right with treats from Smokywood Pastures!","Užij si kouzelný Feast of Winter Veil! Začni ho správně s dobrotami od Smokywood Pastures!")
add("Jaycrue Copperpinch","Have a wondrous Feast of Winter Veil!  Start it off right with treats from Smokywood Pastures!","Užij si kouzelný Feast of Winter Veil! Začni ho správně s dobrotami od Smokywood Pastures!")
add("Kaymard Copperpinch","Have a wondrous Feast of Winter Veil!  Start it off right with treats from Smokywood Pastures!","Užij si kouzelný Feast of Winter Veil! Začni ho správně s dobrotami od Smokywood Pastures!")
add("Khole Jinglepocket","Have a wondrous Feast of Winter Veil!  Start it off right with treats from Smokywood Pastures!","Užij si kouzelný Feast of Winter Veil! Začni ho správně s dobrotami od Smokywood Pastures!")
add("Macey Jinglepocket","Have a wondrous Feast of Winter Veil!  Start it off right with treats from Smokywood Pastures!","Užij si kouzelný Feast of Winter Veil! Začni ho správně s dobrotami od Smokywood Pastures!")
add("Penney Copperpinch","Have a wondrous Feast of Winter Veil!  Start it off right with treats from Smokywood Pastures!","Užij si kouzelný Feast of Winter Veil! Začni ho správně s dobrotami od Smokywood Pastures!")
add("Seersa Copperpinch","Have a wondrous Feast of Winter Veil!  Start it off right with treats from Smokywood Pastures!","Užij si kouzelný Feast of Winter Veil! Začni ho správně s dobrotami od Smokywood Pastures!")
add("Wulmort Jinglepocket","Have a wondrous Feast of Winter Veil!  Start it off right with treats from Smokywood Pastures!","Užij si kouzelný Feast of Winter Veil! Začni ho správně s dobrotami od Smokywood Pastures!")
-- source_id 730
add("Lhara","Have you any idea what I go through to bring these incomparable valuables to sell?  Come see them all for yourself!","Máš vůbec ponětí, čím vším si musím projít, abych sem tyto jedinečné cennosti přivezl k prodeji? Přijď se na ně všechny podívat!")
-- source_id 731
add("Krulmoo Fullmoon","Have you come for further training? Shake the dust of the road from your garments, then, and let us get to work.","Přišel jsi na další výcvik? Tak ze šatů setřes prach z cesty a pusťme se do práce.")
-- source_id 732
add("Vectus","Have you come from the Burning Steppes?  Do you have my black dragon eggs?","Přicházíš z Burning Steppes? Máš moje black dragon eggs?")
-- source_id 733
add("Kylanna Windwhisper","Have you come here for instruction in the art of making potions? You were mistaken if you thought that I would offer such a privilege to you, unearned. Go, and do not return to me until you have greater skill.","Přišel jsi sem pro výuku umění výroby lektvarů? Jestli sis myslel, že ti takové privilegium nabídnu bez zásluh, mýlil ses. Jdi a nevracej se, dokud nezískáš větší dovednost.")
-- source_id 734
add("Woo Ping","Have you come seeking training in the ways of armed combat?","Přišel jsi hledat výcvik v ozbrojeném boji?")
-- source_id 735
add("Hgarth","Have you come to seek the knowledge of Hgarth?","Přišel jsi hledat Hgarthovy znalosti?")
-- source_id 736
add("Midsummer Celebrant","Have you danced at the ribbon pole yet?","Už jsi tančil u ribbon pole?")
-- source_id 737
add("Lorekeeper Lydros","Have you heard of the brood mother of the Black Flight? I believe she is called Onyxia...","Slyšel jsi o brood mother Black Flight? Myslím, že se jmenuje Onyxia...")
-- source_id 738
add("Field Marshal Snowfall","Have you heard the good news, $c? The Alliance has completed all of its war effort collections! Now we simply await the Horde to finish theirs. When they do, we'll begin shipping all of the war materiel over to Silithus, and it shouldn't be long after that until the Ahn'Qiraj War begins.","Slyšel jsi tu dobrou zprávu, $c? Alliance dokončila všechny své sbírky pro válečné úsilí! Teď už jen čekáme, až Horde dokončí ty svoje. Jakmile se tak stane, začneme všechen válečný materiál převážet do Silithusu a pak už by nemělo trvat dlouho, než válka u Ahn'Qiraj začne.")
-- source_id 739
add("Karna Remtravel","Have you seen all the wonderful things here in Ungoro Crater, $N? It's simply amazing. Not as amazing as some of the things I can make with my skill at engineering, but for it being all natural here... it's not too bad.$B$BMy uncle Remtravel loves old stuff like this place. I'm following in his footsteps kinda--I want to discover new things from lost cultures too!","Viděl jsi všechny ty úžasné věci tady v Un'Goro Crater, $N? Je to prostě neuvěřitelné. Ne tak úžasné jako některé věci, které dokážu vyrobit díky svému engineeringu, ale na to, že je to tu všechno přírodní... to není špatné.$B$BMůj strýc Remtravel má staré věci jako tohle místo moc rád. Tak trochu jdu v jeho stopách — taky chci objevovat nové věci ze ztracených kultur!")
-- source_id 740
add("Sentinel Velene Starstrike","Have you seen the befouled water elementals in our lake, $N? It is a sorry sight, but I do not know where they are coming from.$B$BYour name has been mentioned in conversations past, perhaps you could help me with this problem.$B$BThe first thing we must learn is who is in control of these elementals.","Viděl jsi znečištěné vodní elementály v našem jezeře, $N? Je to smutný pohled, ale nevím, odkud přicházejí.$B$BTvé jméno už v minulosti v rozhovorech zaznělo, možná bys mi s tímto problémem mohl pomoci.$B$BNejdřív musíme zjistit, kdo tyto elementály ovládá.")
-- source_id 741
add("Watcher Brownell","Have you seen Watcher Backus? So brave...$B$BI think he's the toughest of all the Night Watch. I wonder if he even notices I'm around....","Viděl jsi Watcher Backuse? Je tak statečný...$B$BMyslím, že je nejtvrdší ze všech Night Watch. Zajímalo by mě, jestli vůbec ví, že jsem tady...")
-- source_id 742
add("Menara Voidrender","Have you spoken to either of my acolytes inside the tower yet, $N? We cannot complete your orb until you've done one of their tasks. Speak to them now, if you're ready.","Už jsi mluvil s některým z mých akolytů uvnitř věže, $N? Tvůj orb nemůžeme dokončit, dokud nesplníš jeden z jejich úkolů. Pokud jsi připraven, promluv si s nimi teď.")
-- source_id 743
add("Caer Darrow Citizen","Have you tried our bread? Baker Masterson must be the most gifted chef to have ever lived!","Ochutnal jsi náš chléb? Baker Masterson musí být ten nejnadanější kuchař, který kdy žil!")
-- source_id 744
add("Guzzling Patron","Have you tried that Thunderbrew Lager?  It's good stuff!","Ochutnal jsi Thunderbrew Lager? Je to dobré pití!")
-- source_id 745
add("Darkmoon Faire Carnie","Having a good time?","Dobře se bavíš?")
-- source_id 746
add("Hulfdan Blackbeard","He grows fatter and more corrupt with each passing day. Ye can smell the stink comin' off o' his body. He be dirty, an' I dun just mean he be needin' a wash.$B$BEnough babblin' from Hulfdan. Where did ye come from and how can me help ye, $c?","Každým dnem tloustne a je zkaženější. Smrad z jeho těla je cítit na dálku. Je špinavej, a nemyslím tím jen, že by potřeboval koupel.$B$BDost Hulfdanova žvanění. Odkud přicházíš a jak ti můžu pomoct, $c?")
-- source_id 747
add("Lorax","He took the unforged rune covered breastplate, used in the making of the demon forged breastplate and ran away without making payment. A fool, I am not, however... the unforged chest piece is useless without knowledge or the recipe to apply said knowledge.$B$BI wonder... does he sit safely in his city of Blackrock Spire and attempt to create the item from the raw material? I know he dare not leave!","Vzal neukovanou runami pokrytou breastplate, používanou při výrobě demon forged breastplate, a utekl bez zaplacení. Nejsem ale žádný hlupák... ta neukovaná chest piece je bez znalostí nebo receptu k jejich použití k ničemu.$B$BZajímalo by mě... sedí bezpečně ve svém městě Blackrock Spire a snaží se z té suroviny ten předmět vyrobit? Vím, že se neodváží odejít!")
-- source_id 748
add("Smiling Jim","He'll bring you mead$bHe'll bring you beer$bA grinning face from ear to ear$bHe's served us all from year to year$bWe call him Smiling Jim.","Přinese ti medovinu$bPřinese ti pivo$bÚsměv od ucha k uchu$bSlouží nám rok co rok$bŘíkáme mu Smiling Jim.")
-- source_id 749
add("Kirsta Deepshadow","He... hello, $N. Sorry, I'm recovering from my wounds.$B$BThose Scarlet Crusaders are tougher than I had given them credit for. They almost did me in.$B$BYou should be careful too. I'd hate to see them get the jump on you.","A... ahoj, $N. Promiň, zotavuji se ze svých zranění.$B$BTi Scarlet Crusaders jsou tvrdší, než jsem jim přisuzoval. Málem mě dostali.$B$BTaky bys měl být opatrný. Nerad bych, aby tě překvapili.")
-- source_id 750
add("Razor Hill Grunt","Head north up the road to Orgrimmar.  You can ask one of the grunts there for directions to the Cooking Trainer.","Vydej se po cestě na sever do Orgrimmaru. Tam se můžeš některého z gruntů zeptat na cestu ke Cooking Trainerovi.")
-- source_id 751
add("Orgrimmar Grunt","Healing is for those who cannot endure pain.  However if you must, seek out the Spirit Lodge on the lake in the Valley of Spirits, up and above the Valley of Strength to the west.","Léčení je pro ty, kteří neumějí snášet bolest. Pokud ale musíš, vyhledej Spirit Lodge u jezera ve Valley of Spirits, nahoře a západně od Valley of Strength.")
-- source_id 752
add("Hegnar Rumbleshot","Hegnar Rumbleshot, at your service!","Hegnar Rumbleshot, k službám!")
-- source_id 753
add("Undercity Guardian","Heh, bombs, us like bombs.  Graham Van Talen show you how to make.  He in outer ring of Rogues' Quarter.","Heh, bomby, my mít rádi bomby. Graham Van Talen ukáže, jak vyrábět. Je ve vnějším okruhu Rogues' Quarter.")
-- source_id 754
add("Gregan Brewspewer","Heh, heh... Quite the inquisitive one, aren't ya, $n? Well, here's what you need to do.$B$BNorth of here, in the old ruins, lives a very disagreeable gnoll by the name of Miblon Snarltooth. He guards the only Evoroot I know of, but he watches it night and day! Seems like he never even sleeps!$B$BWhat you can do, is bribe him. I can sell you some bait that he'll find tasty -- just put it down near him and that will distract him long enough for you to grab the Evoroot. Good luck!","Heh, heh... Ty jsi ale zvědavec, co, $n? Dobře, řeknu ti, co musíš udělat.$B$BSeverně odsud, ve starých ruinách, žije velmi nepříjemný gnoll jménem Miblon Snarltooth. Hlídá jediný Evoroot, o kterém vím, a střeží ho dnem i nocí! Vypadá to, že snad nikdy nespí!$B$BMůžeš ho ale podplatit. Prodám ti návnadu, která mu bude chutnat — polož ji poblíž něj a zabaví ho na dost dlouho, abys Evoroot mohl sebrat. Hodně štěstí!")
-- source_id 755
add("Batrider Pele'keiki","Hehehe, how you doin' mon. You gonna help Pele'keiki great deal he be thinkin'. We be needin' a bombastic amount of the firebloom herb to be preparin' right for the Ahn'Qiraj War. The Horde, they say, 'Pele'keiki, you get us $2051w of the fire petals right quick'.$B$BPele'keiki tell you now, he only have $2050w firebloom, but you gonna add to that real soon, right mon?","Hehehe, jak se vede, mon. Pele'keiki myslí, že mu hodně pomůžeš. Na pořádnou přípravu na válku u Ahn'Qiraj potřebujeme obrovské množství byliny firebloom. Horde říká: „Pele'keiki, rychle nám sežeň $2051w těch ohnivých květů.“$B$BPele'keiki ti teď říká, že má jen $2050w firebloom, ale ty to brzy navýšíš, že jo, mon?")
-- source_id 756
add("Stormwind Guard","Helene Peltskinner has had years of experience skinning animals for Adele Fielder to make leather items.  You can find Helene in her house by Crystal Lake.","Helene Peltskinner má mnohaleté zkušenosti se stahováním zvířat z kůže pro Adele Fielder, která z ní vyrábí kožené předměty. Helene najdeš v jejím domě u Crystal Lake.")
-- source_id 757
add("Selina Dourman","Hello $c, and welcome to the Darkmoon Faire. There is so much to do here at the faire that it can be a little overwhelming for our first time visitors. That's why I'm here to help. Do you have any questions?","Ahoj, $c, a vítej na Darkmoon Faire. Je tu tolik věcí, které můžeš dělat, že to na naše návštěvníky, kteří jsou tu poprvé, může působit trochu zahlcujícím dojmem. Proto jsem tady, abych pomohl. Máš nějaké otázky?")
-- source_id 758
add("Chromie","Hello once again, $N.  I sense that the flow of time remains threatened by forces that are quite powerful indeed.  Your continued assistance is always welcomed by the bronze dragonflight.$B$BWhile the past is set in its ways, the future is always changing.  The decisions you make in the here and now help guide that change.","Znovu tě zdravím, $N. Cítím, že tok času stále ohrožují opravdu mocné síly. Bronze dragonflight tvou další pomoc vždy vítá.$B$BMinulost už má svou podobu pevně danou, ale budoucnost se neustále mění. Rozhodnutí, která učiníš tady a teď, pomáhají tuto změnu vést.")
-- source_id 759
add("Williden Marshal","Hello stranger, and welcome to the untamed majesty of Un'Goro Crater!$B$BMy name is Williden Marshal.  My sister, our companions, and I make up Marshal Expeditions - scientists and explorers of Azeroth's wild and great unknown.$B$BWe've hit a bit of a rough patch here, and we're looking for some help if you have the time!","Ahoj, cizinče, a vítej v nespoutané nádheře Un'Goro Crater!$B$BJmenuji se Williden Marshal. Moje sestra, naši společníci a já tvoříme Marshal Expeditions — vědce a průzkumníky divokých a velkých neznámých oblastí Azerothu.$B$BTady jsme narazili na menší potíže a pokud máš čas, hledáme pomoc!")
-- source_id 760
add("Shawn","Hello there $g mister : ma'am;... do you have a little time that you could help us out?  Please?","Ahoj, $g pane:madam;... neměl bys chvilku, abys nám pomohl? Prosím?")
-- source_id 761
add("Oglethorpe Obnoticus","Hello there $glad:lass;... the name's Oglethorpe and I may be responsible for one of the amazing gnomish devices you might possess!  If it blew up, then it wasn't me; if it made you rich though, we can discuss royalties!$B$BOh, and if you're from Gnomeregan, you can just take two ninety degree angles, smash them together, and start marching.  I have nothing to say to you.","Ahoj, $gmladíku:slečno;... jmenuji se Oglethorpe a možná jsem zodpovědný za některé z úžasných gnomish zařízení, která můžeš vlastnit! Pokud vybuchlo, nebyl jsem to já; pokud tě ale udělalo bohatým, můžeme se pobavit o licenčních poplatcích!$B$BA jestli jsi z Gnomereganu, můžeš prostě vzít dva pravé úhly, praštit je k sobě a vyrazit na pochod. Nemám ti co říct.")
-- source_id 762
add("Jenna Lemkenilli","Hello there! My name's Jenna! And you?","Ahoj! Jmenuji se Jenna! A ty?")
-- source_id 763
add("Chromie","Hello there, $N.  I am known as Chronormu, but you may call me Chromie.  I am comfortable with such familiarity.$B$BNow - how did I know your name, you ask?  I am one of the bronze dragonflight, forever attuned to the ebb and flow of time.  You could say that we have met before.  To that end, we shall also meet again.$B$BI hope that my choice of visual demeanor does not disturb you; while I might be charged to be a sentry of sorrowful places, I choose not to drown in the sorrow of the locale.","Ahoj, $N. Jsem znám jako Chronormu, ale můžeš mi říkat Chromie. Taková důvěrnost mi nevadí.$B$BPtáš se, jak jsem znal tvé jméno? Jsem jedním z bronze dragonflight, navždy naladěn na příliv a odliv času. Dalo by se říci, že jsme se už setkali. A stejně tak se ještě znovu setkáme.$B$BDoufám, že tě má zvolená podoba neznepokojuje; i když mohu být pověřen hlídkou na smutných místech, rozhodl jsem se neutápět ve smutku tohoto kraje.")
-- source_id 764
add("Petra Grossen","Hello there, my name is Petra.  To my right is my kodo, Dadanga.  We're with Marshal Expeditions - been so for a few years now, ever since Dadanga was a babe.$B$BIf you have any lit torches or any open sources of flame, I'd like to ask you to keep them stashed if you could.  Dadanga dislikes smoke.","Ahoj, jmenuji se Petra. Po mé pravici je můj kodo, Dadanga. Jsme s Marshal Expeditions — už několik let, vlastně od doby, kdy byla Dadanga ještě mládě.$B$BPokud máš nějaké zapálené pochodně nebo jiné otevřené zdroje ohně, prosím, schovej je. Dadanga nemá ráda kouř.")
-- source_id 765
add("Eva Sarkhoff","Hello young $g Master:Mistress;. I am Eva Sarkhoff and this is my husband, Lucien. It is a pleasure to make your acquaintance.","Dobrý den, mladý $gmistře:paní;. Jsem Eva Sarkhoff a toto je můj manžel Lucien. Těší mě, že vás poznávám.")
-- source_id 766
add("Rinling","Hello!  And welcome!  I'm afraid my booth is not open... many repairs are needed...$B$BBut I am still bound by blood oath to put a smile on your face.  So please, smile, or I must cut off my hand and consume no living flesh until it regenerates...","Ahoj! A vítej! Obávám se, že můj stánek není otevřený... potřebuje mnoho oprav...$B$BStále mě ale krevní přísaha zavazuje vykouzlit ti úsměv na tváři. Tak se prosím usměj, jinak si budu muset useknout ruku a nejíst žádné živé maso, dokud mi znovu nedoroste...")
-- source_id 767
add("Ribbly Screwspigot","Hello!  You're just the person I was looking for.  Take a seat and listen, because I have a plan that will make us both rich!","Ahoj! Jsi přesně ten člověk, kterého jsem hledal. Posaď se a poslouchej, protože mám plán, který nás oba udělá bohatými!")
-- source_id 768
add("Donova Snowden","Hello! What brings you to Winterspring? These cold and vast lands may seem dismal, but this is a place of many secrets...","Ahoj! Co tě přivádí do Winterspringu? Tyto chladné a rozlehlé kraje mohou působit ponuře, ale skrývá se tu mnoho tajemství...")
-- source_id 769
add("Marta Finespindle","Hello, $c! I've went around and asked, and it looks like all of us here have collected everything that the Alliance needs to prepare for the Ahn'Qiraj War. Now we just need to encourage the Horde to do the same and then we'll be able to ship it all over to Cenarion Hold in Silithus.","Ahoj, $c! Obešel jsem všechny a podle všeho jsme tu nasbírali vše, co Alliance potřebuje pro přípravy na válku u Ahn'Qiraj. Teď už jen musíme povzbudit Horde, aby udělala totéž, a pak to všechno budeme moci poslat do Cenarion Hold v Silithusu.")
-- source_id 770
add("Lady Callow","Hello, $c, good of you to show up. Allow me to be succinct; we are gathering supplies for the Ahn'Qiraj war effort. We wouldn't want to have more casualties than necessary, now would we? I have the responsibility of coordinating the collection of $2086w mageweave bandages. To date we have garnered $2085w. Care to assist?","Ahoj, $c, jsem rád, že ses ukázal. Budu stručný: shromažďujeme zásoby pro válečné úsilí u Ahn'Qiraj. Nechceme přece mít víc obětí, než je nutné, že? Mám na starosti koordinaci sběru $2086w mageweave bandages. Dosud jsme získali $2085w. Pomůžeš?")
-- source_id 771
add("Dame Twinbraid","Hello, $c. From what I've been told, everything's been collected, and all of the materiel for the war is being shipped over to Silithus as we speak. It should all be there in less than $2113w days. Once that's done, and the gong has been rung with the Scepter of the Shifting Sands, the war will really begin.","Ahoj, $c. Podle toho, co mi řekli, už bylo všechno shromážděno a všechen válečný materiál se právě teď převáží do Silithusu. Do méně než $2113w dnů by tam měl být celý. Jakmile to bude hotové a někdo zazvoní na gong pomocí Scepter of the Shifting Sands, válka skutečně začne.")
-- source_id 772
add("Dame Twinbraid","Hello, $c. From what I've been told, everything's been collected, and all of the materiel for the war is being shipped over to Silithus as we speak. It should all be there in less than a day. Once that's done, and the gong has been rung with the Scepter of the Shifting Sands, the war will really begin.","Ahoj, $c. Podle toho, co mi řekli, už bylo všechno shromážděno a všechen válečný materiál se právě teď převáží do Silithusu. Do jednoho dne by tam měl být celý. Jakmile to bude hotové a někdo zazvoní na gong pomocí Scepter of the Shifting Sands, válka skutečně začne.")
-- source_id 773
add("Sentinel Silversky","Hello, $c. I am collecting linen bandages here for the Ahn'Qiraj war effort; an effort that will put us all to the test, but strengthen us for the war to come. I can assure you that any bandages that you choose to donate will be put to good use in helping to save the lives of our soldiers when the time comes. I am in need of $2077w, and to this point have managed to collect $2076w. Will you assist us?","Ahoj, $c. Sbírám zde linen bandages pro válečné úsilí u Ahn'Qiraj; úsilí, které nás všechny prověří, ale posílí nás pro válku, která přijde. Ujišťuji tě, že všechny obvazy, které se rozhodneš darovat, dobře poslouží k záchraně životů našich vojáků, až přijde čas. Potřebuji $2077w a dosud se nám podařilo shromáždit $2076w. Pomůžeš nám?")
-- source_id 774
add("Jessir Moonbow","Hello, $c. I am Jessir Moonbow. I have come from Darnassus seeking two friends who came looking for signs of the Shadow Council in Felwood.$B$BIt seems those vile creatures who claim responsibility for much of the orcish race's suffering seeks to regain some of its power.$B$BMy two friends went looking in Jaedenar to prove one way or the other what was happening.$B$BI expected them to be here when I arrived, but now they are days late.","Ahoj, $c. Jsem Jessir Moonbow. Přicestoval jsem z Darnassusu a hledám dva přátele, kteří sem přišli pátrat po známkách Shadow Council ve Felwoodu.$B$BVypadá to, že ti odporní tvorové, kteří jsou zodpovědní za velkou část utrpení orčí rasy, se snaží znovu získat část své moci.$B$BMí dva přátelé šli do Jaedenaru zjistit, co se skutečně děje.$B$BOčekával jsem, že tu budou, až dorazím, ale teď mají už několik dní zpoždění.")
-- source_id 775
add("Doctor Serratus","Hello, $c. I trust that you bring good tidings concerning the Ahn'Qiraj War preparations. I myself have been placed in charge of all accumulation of rugged leather for the Horde; a task to which I feel uniquely qualified. Never underestimate the utility of a sharpened knife.$B$BAs to the rugged leather, we currently have $2073w out of $2074w needed.","Ahoj, $c. Věřím, že přinášíš dobré zprávy o přípravách na válku u Ahn'Qiraj. Mně samotnému bylo svěřeno veškeré shromažďování rugged leather pro Horde; úkol, na který se cítím jedinečně kvalifikován. Nikdy nepodceňuj užitečnost nabroušeného nože.$B$BCo se rugged leather týče, máme nyní $2073w z potřebných $2074w.")
-- source_id 776
add("Bardu Sharpeye","Hello, $c. I've set up camp here at the Bulwark to make my preparations for my journey into the Plaguelands. I've heard rumor that a great human wizard took up residency in Hearthglen not terribly long ago. He was commissioned by the Scarlet Crusade to fashion their warriors and hunters new bows and guns. It's said that he completed a remarkable weapon before the Crusade killed him.$B$BI guess their mistrust of the arcane has grown.","Ahoj, $c. Založil jsem si tábor zde u Bulwarku, abych se připravil na cestu do Plaguelands. Slyšel jsem zvěsti, že se v Hearthglenu nedávno usadil významný lidský čaroděj. Scarlet Crusade ho pověřila výrobou nových luků a pušek pro své válečníky a lovce. Říká se, že dokončil pozoruhodnou zbraň, než ho Crusade zabila.$B$BVypadá to, že jejich nedůvěra k arcane magii roste.")
-- source_id 777
add("Rayne","Hello, $c. Please excuse me as I am having a conversation with Rimblat. He believes that even this land is not beyond saving.","Ahoj, $c. Prosím, omluv mě, zrovna vedu rozhovor s Rimblatem. Věří, že ani tato země ještě není za hranicí záchrany.")
-- source_id 778
add("Scooty","Hello, $N! I am master engineer, Scooty.","Ahoj, $N! Jsem mistr engineer Scooty.")
-- source_id 779
add("Sovik","Hello, $N! If you don't see it in my shop, chances are good I can get it!","Ahoj, $N! Pokud to nevidíš v mém obchodě, je velká šance, že to dokážu sehnat!")
-- source_id 780
add("Theodore Griffs","Hello, $N.","Ahoj, $N.")
-- source_id 781
add("Mountaineer Kadrell","Hello, $n.  Welcome to Thelsamar, and while you're here don't forget to visit our local brewery!","Ahoj, $n. Vítej v Thelsamaru a nezapomeň během pobytu navštívit náš místní pivovar!")
-- source_id 782
add("Erelas Ambersky","Hello, $N. I train and care for young hippogryphs here; feel free to have a look around.","Ahoj, $N. Tady trénuji a starám se o mladé hippogryphy; klidně se porozhlédni.")
-- source_id 783
add("Apprentice Kryten","Hello, $N. Welcome to Refuge Pointe.","Ahoj, $N. Vítej v Refuge Pointe.")
-- source_id 784
add("Nurse Stonefield","Hello, how are you feeling today, $c? Well, I hope. You may be wondering what is going on here. There's a war at Ahn'Qiraj that is being planned and prepared for. We and the Horde are preparing as best we can for it.$B$BTo that end, the Alliance has asked me to supervise the collection of silk bandages here. To date we've managed to put together $2082w out of $2083w needed. Are you thinking about helping out?","Ahoj, jak se dnes cítíš, $c? Doufám, že dobře. Možná se divíš, co se tu děje. Plánuje a připravuje se válka u Ahn'Qiraj. My i Horde se na ni připravujeme, jak nejlépe umíme.$B$BZa tímto účelem mě Alliance požádala, abych zde dohlížel na sběr silk bandages. Dosud se nám podařilo shromáždit $2082w z potřebných $2083w. Přemýšlíš, že bys pomohl?")
-- source_id 785
add("Rivern Frostwind","Hello, traveler. Not many find me out this way.$B$BMy name is Rivern, and I train the Winterspring Frostsabers to become mounts.$B$BThese cats are the most feral and difficult to subdue of all the sabers. Only the most trusted and exalted may attempt to ride one.$B$BI will not sell such a mount to just anyone; no, you must work for it and earn your acceptance not only with me, but with the sabers themselves.","Ahoj, poutníku. Málokdo mě najde takhle daleko.$B$BJmenuji se Rivern a trénuji Winterspring Frostsabers, aby se z nich stali mounti.$B$BTyto kočky jsou ze všech saberů nejdivočejší a nejobtížněji se podrobují. Jen ti nejdůvěryhodnější a nejváženější se mohou pokusit na některém jezdit.$B$BTakového mounta neprodám jen tak někomu; musíš si ho zasloužit a získat přijetí nejen u mě, ale i u samotných saberů.")
-- source_id 786
add("Herbalist Proudfeather","Hello, young $c. Are you here to bring me a batch of peacebloom? We are collecting them to make potions and elixirs for the Ahn'Qiraj war effort. Though tragic that we are forced into this war, the results will be even more terrible if we do not prepare properly.$B$BThe Horde has tasked me with the collection of $2020w peacebloom, and so far we've managed to put together $2021w. If you have it within your ability, please gather up all that you can and return them to me here.","Ahoj, mladý $c. Přinesl jsi mi dávku peacebloom? Sbíráme je na výrobu lektvarů a elixírů pro válečné úsilí u Ahn'Qiraj. Je tragické, že jsme do této války nuceni, ale důsledky budou ještě strašnější, pokud se řádně nepřipravíme.$B$BHorde mě pověřila nasbíráním $2020w peacebloom a zatím se nám podařilo dát dohromady $2021w. Pokud je to v tvých silách, nasbírej vše, co můžeš, a přines mi to sem.")
-- source_id 787
add("Sergeant Bly","Help!  My band and I have been captured by trolls, and they're going to sacrifice us!$B$BGet us out of here and I'll give you anything you want.","Pomoc! Mě i mou kapelu zajali trollové a chtějí nás obětovat!$B$BDostaň nás odsud a dám ti cokoli, co budeš chtít.")
-- source_id 788
add("Weegli Blastfuse","Help!$B$BIf you get me out of here, I can blow up the door that leads to the chief of Zul'Farrak!","Pomoc!$B$BKdyž mě odsud dostaneš, dokážu vyhodit do povětří dveře vedoucí k náčelníkovi Zul'Farraku!")
-- source_id 789
add("Lady Jaina Proudmoore","Hendel is in our custody now, $N, thanks to you.$B$BAlthough the questioning goes slowly, I assure you, he will tell us everything he knows.$B$BFor now, please be patient. I will contact you immediately if we have need of your assistance.$B$BUntil then, please, enjoy Theramore and I invite you to stay for as long as you like within our city's walls as a friend of the Alliance.","Hendel je teď díky tobě v naší vazbě, $N.$B$BVýslech sice postupuje pomalu, ale ujišťuji tě, že nám řekne všechno, co ví.$B$BProzatím buď prosím trpělivý. Pokud budeme potřebovat tvou pomoc, okamžitě se ti ozvu.$B$BDo té doby si užij Theramore a jako přítel Alliance můžeš zůstat uvnitř našich městských hradeb tak dlouho, jak budeš chtít.")
-- source_id 790
add("Teldrassil Sentinel","Herbalism requires a gentle touch that few such as Malorne can teach.  Seek him out east of the Inn in Dolanaar.","Herbalism vyžaduje jemný dotek, jaký umí naučit jen málokdo, například Malorne. Vyhledej ho východně od Inn v Dolanaaru.")
-- source_id 791
add("Field Marshal Snowfall","Herbs, herbs, hmmm, let me see here. Ah yes, here it is. To date we have accumulated $2047w out of $2048w stranglekelp, $2053w out of $2055w purple lotuses, and $2057w out of $2058w arthas' tears needed.","Byliny, byliny, hmmm, podívám se. Ano, tady to je. Dosud jsme shromáždili $2047w z $2048w stranglekelp, $2053w z $2055w purple lotus a $2057w z potřebných $2058w arthas' tears.")
-- source_id 792
add("Orgrimmar Grunt","Herbs... you need to speak to Jandi at her arboretum in The Drag.  There are some wooden steps behind Asoran's Market in the Valley of Wisdom.  Follow them to the upper level of The Drag and you'll find her.","Byliny... musíš si promluvit s Jandi v jejím arboretu v The Drag. Za Asoran's Market ve Valley of Wisdom jsou dřevěné schody. Vyjdi po nich do horní úrovně The Drag a najdeš ji.")
-- source_id 793
add("Darnassus Sentinel","Here among the craftsmen of Darnassus, there is a millenium of knowledge for the benefit of your chosen craft.  Now tell me, which craft do you find the most intriguing?","Zde mezi řemeslníky Darnassusu je tisíc let znalostí, které mohou prospět tvému zvolenému řemeslu. Tak mi řekni, které řemeslo tě nejvíc zajímá?")
-- source_id 794
add("Marek Ironheart","Here at the Farstrider lodge, we prize hunting skills above all else. Wish to gain my approval? You'll have to earn it.$B$BYou look up to the challenge, $Glad:lass;!","Tady ve Farstrider Lodge si ceníme loveckých schopností nade vše. Chceš získat můj souhlas? Budeš si ho muset zasloužit.$B$BVypadáš, že na tu výzvu máš, $Gmladíku:slečno;!")
-- source_id 795
add("Vi'el","Here for the rod? Or, maybe you're simply stocking up on runes?$B$BWait a minute! Are you just trying to offload a whole bunch of junk on me?! Curse my never-ending compulsion to buy, buy, buy!","Jdeš pro prut? Nebo si snad jen doplňuješ zásoby run?$B$BPočkej! Ty se na mě jen snažíš vyklopit hromadu harampádí?! Proklínám tu svou nekonečnou potřebu kupovat, kupovat, kupovat!")
-- source_id 796
add("Tognus Flintfire","Here for training eh? Just began my training meself, but I would be glad ta teach ye what I can.","Tak ty chceš výcvik? Sám jsem teprve začal trénovat, ale rád tě naučím, co umím.")
-- source_id 797
add("Darnassus Sentinel","Here in Darnassus you will find skilled trainers who have perfected the skills of their chosen class through ages of training and dedication.  I will guide you to one who can become your mentor, you have but to name your chosen path.","Tady v Darnassusu najdeš zkušené trenéry, kteří své třídní schopnosti zdokonalovali po celé věky výcviku a oddanosti. Dovedu tě k tomu, kdo se může stát tvým mentorem; stačí pojmenovat cestu, kterou sis zvolil.")
-- source_id 798
add("Sayge","Here is your fortune, $N.  May it serve you well.","Tady je tvá věštba, $N. Ať ti dobře poslouží.")
-- source_id 799
add("Carolai Anise","Here to learn about potions? I've got plenty to teach you. I might be dead, but I haven't lost my brains. Yet.","Přišel jsi se něco naučit o lektvarech? Mám toho spoustu, co tě můžu naučit. Možná jsem mrtvý, ale o mozek jsem ještě nepřišel. Zatím.")
-- source_id 800
add("Sayoc","Here to learn how to wield a new weapon, or just to waste my time?","Přišel jsi naučit se ovládat novou zbraň, nebo jen plýtvat mým časem?")
-- source_id 801
add("Doctor Marsh","Here to learn? Very well. I suppose you can't cause our allies much harm if I teach you. Just as long as you actually do manage to harm our enemies.","Přišel ses učit? Dobrá. Předpokládám, že když tě něco naučím, našim spojencům tím příliš neublížíš. Hlavně když se ti opravdu podaří ublížit našim nepřátelům.")
-- source_id 802
add("Whiskey Slim","Here's to you!  Here's to me!  May we never disagree.$b$bBut if we do... BLAST YOU!  Here's to me.","Na tebe! Na mě! Kéž se nikdy nepřeme.$b$bA jestli ano... AŤ TĚ TO TREFÍ! Na mě.")
-- source_id 803
add("Merithra of the Dream","Heroes of the Brood? C'Thun must be banished! We can assist you, mortal!","Hrdinové Brood? C'Thun musí být vyhnán! Můžeme ti pomoci, smrtelníku!")
-- source_id 804
add("Jinar'Zillen","Hey mon! You've ever been diving deep in the ocean? I'll let you in on a little secret, eh. Deep in the ocean you can find bubbly fissures; they'll allow you to breathe air while underwater.  Let's keep this secret between you and me though, eh. I don't need no competition for me shellfish traps elsewhere... if you get my drift!","Hej, mon! Už ses někdy potápěl hluboko v oceánu? Prozradím ti malé tajemství, eh. Hluboko pod hladinou najdeš bublající pukliny; díky nim můžeš pod vodou dýchat vzduch. Ale nechme si to mezi sebou, eh. Nepotřebuju konkurenci u svých pastí na shellfish jinde... jestli víš, co tím myslím!")
-- source_id 805
add("Kil'hala","Hey mon, what can I be doin' for you?","Hej, mon, co pro tebe můžu udělat?")
-- source_id 806
add("Senior Sergeant T'kelah","Hey mon, you be here ta bring me mithril bars no doubt. There be big trouble brewin' in the Silithus desert at Ahn'Qiraj. We and the Alliance goin' all out this time to stop them bugs, and that be why you seein' everyone here.$B$BThe Horde be askin' me to collect $2009w for the war effort, but I only have $2008w. So ya gonna help me out, or what?","Hej, mon, ty jsi určitě přišel přinést mithril bars. V poušti Silithus u Ahn'Qiraj se schyluje k velkým problémům. My i Alliance tentokrát uděláme všechno, abychom ty brouky zastavili, a proto tu všechny vidíš.$B$BHorde mě požádala, abych pro válečné úsilí shromáždil $2009w, ale mám jen $2008w. Tak mi pomůžeš, nebo co?")
-- source_id 807
add("Jen'shan","Hey mon, you be needin' to head on over to da $c trainer.","Hej, mon, musíš zamířit za $c trainerem.")
add("Sian'dur","Hey mon, you be needin' to head on over to da $c trainer.","Hej, mon, musíš zamířit za $c trainerem.")
add("Xor'juul","Hey mon, you be needin' to head on over to da $c trainer.","Hej, mon, musíš zamířit za $c trainerem.")
-- source_id 808
add("Marta Finespindle","Hey there, $c! Looks like the Horde collected the last of their stuff, and now theirs and ours is being shipped over to Silithus as we speak. I'm told it'll be there in less than $2113w days, and then someone can ring that big gong near the Ahn'Qiraj gates to start the war.","Hej, $c! Vypadá to, že Horde shromáždila poslední zásoby a teď se jejich i naše právě převážejí do Silithusu. Prý tam budou za méně než $2113w dnů a pak někdo může zazvonit na ten velký gong u bran Ahn'Qiraj a zahájit válku.")
-- source_id 809
add("Marta Finespindle","Hey there, $c! Looks like the Horde collected the last of their stuff, and now theirs and ours is being shipped over to Silithus as we speak. I'm told it'll be there in less than a day, and then someone can ring that big gong near the Ahn'Qiraj gates to start the war.","Hej, $c! Vypadá to, že Horde shromáždila poslední zásoby a teď se jejich i naše právě převážejí do Silithusu. Prý tam budou za méně než jeden den a pak někdo může zazvonit na ten velký gong u bran Ahn'Qiraj a zahájit válku.")
-- source_id 810
add("Sarah Sadwhistle","Hey there, $c. I've talked with everyone around here, and it seems like we have all of the stuff that the Alliance wants for the war. That mean orc ambassador said that the Horde is still gathering though, which means we have some time before we need to ship all of this stuff over to Silithus.","Hej, $c. Mluvil jsem tu se všemi a vypadá to, že máme všechno, co Alliance pro válku požaduje. Ten protivný orčí velvyslanec ale říkal, že Horde stále shromažďuje zásoby, takže máme ještě trochu času, než to všechno budeme muset odeslat do Silithusu.")
-- source_id 811
add("Winkey","Hey there, cutie!  Mind rubbing some lotion on my exposed areas?","Ahoj, zlatíčko! Nemohl bys mi natřít trochou krému odkrytá místa?")
-- source_id 812
add("Noggle Ficklespragg","Hey!  Thanks for saving my hide!  I think I'll be lying down for a while until I recover my strength.","Hej! Díky, že jsi mi zachránil kůži! Asi si na chvíli lehnu, dokud se mi nevrátí síly.")
-- source_id 813
add("Renato Gallina","Hey, $gmister:miss;.  You look like a $C with discerning tastes in wine.  I have a favor to ask, and I think I can make you an offer you can't refuse...forget about it!","Hej, $gpane:slečno;. Vypadáš jako $C s vytříbenou chutí na víno. Mám jednu prosbu a myslím, že ti můžu udělat nabídku, která se neodmítá... zapomeň na to!")
-- source_id 814
add("Marshal McBride","Hey, citizen!  You look like a stout one.  We guards are spread a little thin out here, and I could use your help...","Hej, občane! Vypadáš jako někdo, kdo něco vydrží. Nás strážných je tu trochu málo a hodila by se mi tvoje pomoc...")
-- source_id 815
add("Flik","Hey, someone help me catch this thing!","Hej, někdo mi pomozte chytit tu věc!")
-- source_id 816
add("Innkeeper Allison","Hey, that reminds me, I need to have my rocket boots repaired.  Word to the wise my friend, rocket boots and gryphons don't mix.  \n\nOh, but you need directions...  just head on over to the Dwarven District, you'll find Lilliam Sparkspindle towards the back.","Hej, to mi připomíná, že si musím nechat opravit rocket boots. Rada od zkušeného, příteli: rocket boots a gryphoni nejdou dohromady.  \n\nAha, ty ale potřebuješ cestu... zajdi do Dwarven District, Lilliam Sparkspindle najdeš vzadu.")
add("Innkeeper Heather","Hey, that reminds me, I need to have my rocket boots repaired.  Word to the wise my friend, rocket boots and gryphons don't mix.  \n\nOh, but you need directions...  just head on over to the Dwarven District, you'll find Lilliam Sparkspindle towards the back.","Hej, to mi připomíná, že si musím nechat opravit rocket boots. Rada od zkušeného, příteli: rocket boots a gryphoni nejdou dohromady.  \n\nAha, ty ale potřebuješ cestu... zajdi do Dwarven District, Lilliam Sparkspindle najdeš vzadu.")
add("Innkeeper Janene","Hey, that reminds me, I need to have my rocket boots repaired.  Word to the wise my friend, rocket boots and gryphons don't mix.  \n\nOh, but you need directions...  just head on over to the Dwarven District, you'll find Lilliam Sparkspindle towards the back.","Hej, to mi připomíná, že si musím nechat opravit rocket boots. Rada od zkušeného, příteli: rocket boots a gryphoni nejdou dohromady.  \n\nAha, ty ale potřebuješ cestu... zajdi do Dwarven District, Lilliam Sparkspindle najdeš vzadu.")
add("Stormwind City Guard","Hey, that reminds me, I need to have my rocket boots repaired.  Word to the wise my friend, rocket boots and gryphons don't mix.  \n\nOh, but you need directions...  just head on over to the Dwarven District, you'll find Lilliam Sparkspindle towards the back.","Hej, to mi připomíná, že si musím nechat opravit rocket boots. Rada od zkušeného, příteli: rocket boots a gryphoni nejdou dohromady.  \n\nAha, ty ale potřebuješ cestu... zajdi do Dwarven District, Lilliam Sparkspindle najdeš vzadu.")
add("Stormwind City Patroller","Hey, that reminds me, I need to have my rocket boots repaired.  Word to the wise my friend, rocket boots and gryphons don't mix.  \n\nOh, but you need directions...  just head on over to the Dwarven District, you'll find Lilliam Sparkspindle towards the back.","Hej, to mi připomíná, že si musím nechat opravit rocket boots. Rada od zkušeného, příteli: rocket boots a gryphoni nejdou dohromady.  \n\nAha, ty ale potřebuješ cestu... zajdi do Dwarven District, Lilliam Sparkspindle najdeš vzadu.")
add("Vikki Lonsav","Hey, that reminds me, I need to have my rocket boots repaired.  Word to the wise my friend, rocket boots and gryphons don't mix.  \n\nOh, but you need directions...  just head on over to the Dwarven District, you'll find Lilliam Sparkspindle towards the back.","Hej, to mi připomíná, že si musím nechat opravit rocket boots. Rada od zkušeného, příteli: rocket boots a gryphoni nejdou dohromady.  \n\nAha, ty ale potřebuješ cestu... zajdi do Dwarven District, Lilliam Sparkspindle najdeš vzadu.")
-- source_id 817
add("Grinkle","Heya Heya Heya!   If you want to test your fishing skills then I have just the place for you!   This Sunday we have a fishing tournament in Stranglethorn!","Hej hej hej! Pokud chceš otestovat své rybářské schopnosti, mám pro tebe přesně to místo! Tuto neděli pořádáme ve Stranglethornu rybářský turnaj!")
-- source_id 818
add("Bom'bay","Heya mon.  Go talk to mah Master Gadrin right over there.  Take care of that Zalazane crazy for him and I fix ya right up!","Hej, mon. Promluv si tamhle s mým Master Gadrinem. Vyřiď pro něj toho šílence Zalazaneho a já se o tebe postarám!")
-- source_id 819
add("Hanashi","Heya mon.  You come right place learn how ta wield a new weapon.","Hej, mon. Přišel jsi na správné místo, pokud se chceš naučit ovládat novou zbraň.")
-- source_id 820
add("Fisherman Lin'do","Heya, $c! Lookin' like we got all the spotted yellowtail that we be needin' for that war. Maybe you going to some of the other collectors 'round here and askin' them if they be needin' your help?","Hej, $c! Vypadá to, že už máme všechen spotted yellowtail, který pro tu válku potřebujeme. Možná bys měl zajít za ostatními sběrači tady kolem a zeptat se, jestli nepotřebují pomoct?")
-- source_id 821
add("Skinner Jamani","Heya, $c, don't you know? The Horde is done with all of its collecting. We're just finishing up final preparations while we wait for the Alliance to finish their gathering. Then it will be time to ship everything over to Silithus for the war.","Hej, $c, ty to nevíš? Horde už dokončila všechny své sbírky. Jen dokončujeme poslední přípravy a čekáme, až Alliance dokončí svoje. Pak přijde čas všechno odeslat do Silithusu na válku.")
-- source_id 822
add("Augustus the Touched","Hi $N!  Are you here to buy something?  Or maybe sell something?$B$BYou won't find better prices anywhere, or my name isn't Augustus the Touched!","Ahoj, $N! Jsi tu něco koupit? Nebo snad něco prodat?$B$BLepší ceny nikde nenajdeš, jinak se nejmenuji Augustus the Touched!")
-- source_id 823
add("Curgle Cranklehop","Hi there! I have a proposition for an adventure-seeker such as you, if you are up to the challenge!$B$BAlong with my invention, the Super Egg-O-Matic, I am hard at work aiding the druids with their campaign to save the hippogryphs. The birds are being affected by the evil effects of the Gordunni ogres inhabiting the ruins of Feralas, and their numbers are dwindling.$B$BI collect many different types of eggs.  Will you help and find some for me?","Ahoj! Mám nabídku pro dobrodruha, jako jsi ty, pokud se nebojíš výzvy!$B$BSpolu se svým vynálezem Super Egg-O-Matic pilně pomáhám druidům v jejich snaze zachránit hippogryphy. Ptáci trpí zlými vlivy Gordunni ogrů obývajících ruiny Feralasu a jejich počet klesá.$B$BSbírám mnoho různých druhů vajec. Pomůžeš mi nějaká najít?")
-- source_id 824
add("Linken","Hi there! I'm glad you came back, $n. Tell me, have you completed the first quest I gave you? If you have, I might have a second quest for you...","Ahoj! Jsem rád, že ses vrátil, $n. Řekni mi, dokončil jsi první quest, který jsem ti dal? Pokud ano, možná pro tebe mám druhý...")
-- source_id 825
add("Gregan Brewspewer","Hi there! The name's Gregan. What can I do for ya?","Ahoj! Jmenuji se Gregan. Co pro tebe můžu udělat?")
-- source_id 826
add("Marta Finespindle","Hi there, $c! With the Ahn'Qiraj War drawing near, our preparations here are in full swing. I'm in charge of thick leather collections. It's a fine day for gathering thick leather, don't ya think? I got my stacks here and it looks like we've got $2069w right now. Our magic number is $2071w. Want to help out?","Ahoj, $c! Válka u Ahn'Qiraj se blíží a naše přípravy jsou v plném proudu. Mám na starosti sběr thick leather. Dnes je pěkný den na shánění thick leather, nemyslíš? Mám tu své hromádky a vypadá to, že teď máme $2069w. Naše cílové číslo je $2071w. Chceš pomoct?")
-- source_id 827
add("Gubber Blump","Hi there.  I'm Gubber Blump.","Ahoj. Jsem Gubber Blump.")
-- source_id 828
add("Kwee Q. Peddlefeet","Hi!  I'm Kwee Q. Peddlefeet!  I'm here to find out who is the most popular of all the heroes in Azeroth!$B$BIt sure warms my heart to see so many adoring fans greet their leaders, but... do you know what would warm me even more?$B$BA kiss!","Ahoj! Jsem Kwee Q. Peddlefeet! Jsem tu, abych zjistil, kdo je nejoblíbenější ze všech hrdinů Azerothu!$B$BVždycky mě zahřeje u srdce, když vidím tolik oddaných fanoušků vítat své vůdce, ale... víš, co by mě zahřálo ještě víc?$B$BPusa!")
-- source_id 829
add("Ranshalla","Hi! I just got back from exploring the Ruins of Kel'Theril, to the southwest. Now I'm intent on investigating the Wildkin that lie just up the ridge here, in Owl Wing Thicket.$B$BHave you spoken to Erelas Ambersky in Rut'theran Village? He requested that I come here, and perhaps he has a task for you as well.","Ahoj! Právě jsem se vrátil z průzkumu Ruins of Kel'Theril na jihozápadě. Teď se chci zaměřit na Wildkin, kteří jsou hned nahoře na hřebeni v Owl Wing Thicket.$B$BMluvil jsi s Erelas Ambersky v Rut'theran Village? Požádal mě, abych sem přišel, a možná má nějaký úkol i pro tebe.")
-- source_id 830
add("Undercity Guardian","Him's at inner ring of Rogues' Quarter.","Je ve vnitřním okruhu Rogues' Quarter.")
-- source_id 831
add("Liv Rizzlefix","Hiya! This workshop isn't mine, no! But one day after I finish training I am going to be an inventor, just like my hero, Marvon Rivetseeker.$B$BYou've never heard of him? Well it just so happens that he left quite some time ago to study some ancient troll ruins he kept talking about. He left in a zeppelin... not quite sure about where exactly he went...$B$BTanarasin? Tenkeris? Taneranisany?$B$B<Liv shakes her head.>$B$BNo, that's not it...","Ahoj! Tahle dílna není moje, ne! Ale až dokončím výcvik, jednoho dne ze mě bude vynálezce, stejně jako můj hrdina Marvon Rivetseeker.$B$BTy jsi o něm nikdy neslyšel? Tak věz, že už před nějakou dobou odešel studovat prastaré trollí ruiny, o kterých pořád mluvil. Odletěl zeppelinem... nejsem si úplně jistá, kam přesně...$B$BTanarasin? Tenkeris? Taneranisany?$B$B<Liv zavrtí hlavou.>$B$BNe, to není ono...")
-- source_id 832
add("Henry Stern","Hm... yes, I do have a recipe you might find useful.  Let me teach you!","Hm... ano, mám recept, který by se ti mohl hodit. Naučím tě ho!")
-- source_id 833
add("Finbus Geargrind","Hmm well, I can't help you quite yet! You have to learn the basics first. Why don't you go see Sprite Jumpsprocket in Stormwind!","Hmm, zatím ti pomoct nemůžu! Nejdřív se musíš naučit základy. Co kdybys zašel za Sprite Jumpsprocket ve Stormwindu?")
-- source_id 834
add("Simon Tanner","Hmm, I guess I can take on another student. Well, don't just stand there. Tell me what you're looking to learn.","Hmm, myslím, že si můžu vzít ještě jednoho žáka. Tak tam jen nestůj. Řekni mi, co se chceš naučit.")
-- source_id 835
add("Rogvar","Hmm, well, I can see that you have a little skill at making potions. Whether you're worthy to be my student remains to be seen, however. I have a job for you. Impress me.","Hmm, no, vidím, že už máš s výrobou lektvarů trochu zkušeností. Jestli jsi hoden stát se mým žákem, to se teprve ukáže. Mám pro tebe práci. Udělej na mě dojem.")
-- source_id 836
add("Clarise Gnarltree","Hmm, your work is allright but it's nowhere near the quality I look for in a student. Go talk with Smith Argus in Goldshire, I'm sure he can teach you some basics. Then when you're done, come on back to me and I'll give you a little test to make sure you are ready.","Hmm, tvoje práce je celkem slušná, ale ani zdaleka nedosahuje kvality, kterou od žáka očekávám. Promluv si se Smith Argusem v Goldshire, určitě tě naučí nějaké základy. Až budeš hotový, vrať se ke mně a dám ti malou zkoušku, abych zjistil, zda jsi připraven.")
-- source_id 837
add("Lawrence Schneider","Hmm... the things you need to learn are a little above my head. Have a talk with Sellandus over at Larson's Clothiers just up the path to the right. He taught me everything I know!","Hmm... to, co se potřebuješ naučit, už je trochu nad moje schopnosti. Promluv si se Sellandusem v Larson's Clothiers hned po cestě napravo. Naučil mě všechno, co umím!")
-- source_id 838
add("Betty Quin","Hmm... well you seem capable enough. If you truly desire to learn, then nothing will stand in your way! I will guide you through your first steps on what I hope will be a long and fulfilling path.","Hmm... vypadáš docela schopně. Pokud se opravdu chceš učit, nic ti nebude stát v cestě! Provedu tě prvními kroky na cestě, která, doufám, bude dlouhá a naplňující.")
-- source_id 839
add("Jormund Stonebrow","Hmm... you show a little promise, I'll give you that. Okay then, where were we?","Hmm... vidím v tobě trochu nadání, to ti uznám. Dobře tedy, kde jsme skončili?")
-- source_id 840
add("Brave Cloudmane","Hmmm, I think you will need to go up to Thunder Bluff to learn that.  Head north on the road out of Bloodhoof Village.  It will take you to the base of Thunder Bluff.  Ride the elevator to the top and you should be able to ask any of the Bluffwatchers there for further assistance.","Hmmm, myslím, že se to budeš muset naučit v Thunder Bluff. Vydej se po cestě na sever z Bloodhoof Village. Dovede tě k úpatí Thunder Bluff. Vyjeď výtahem nahoru a pak se můžeš kteréhokoli Bluffwatchera zeptat na další pomoc.")
add("Brave Darksky","Hmmm, I think you will need to go up to Thunder Bluff to learn that.  Head north on the road out of Bloodhoof Village.  It will take you to the base of Thunder Bluff.  Ride the elevator to the top and you should be able to ask any of the Bluffwatchers there for further assistance.","Hmmm, myslím, že se to budeš muset naučit v Thunder Bluff. Vydej se po cestě na sever z Bloodhoof Village. Dovede tě k úpatí Thunder Bluff. Vyjeď výtahem nahoru a pak se můžeš kteréhokoli Bluffwatchera zeptat na další pomoc.")
add("Brave Dawneagle","Hmmm, I think you will need to go up to Thunder Bluff to learn that.  Head north on the road out of Bloodhoof Village.  It will take you to the base of Thunder Bluff.  Ride the elevator to the top and you should be able to ask any of the Bluffwatchers there for further assistance.","Hmmm, myslím, že se to budeš muset naučit v Thunder Bluff. Vydej se po cestě na sever z Bloodhoof Village. Dovede tě k úpatí Thunder Bluff. Vyjeď výtahem nahoru a pak se můžeš kteréhokoli Bluffwatchera zeptat na další pomoc.")
add("Brave Ironhorn","Hmmm, I think you will need to go up to Thunder Bluff to learn that.  Head north on the road out of Bloodhoof Village.  It will take you to the base of Thunder Bluff.  Ride the elevator to the top and you should be able to ask any of the Bluffwatchers there for further assistance.","Hmmm, myslím, že se to budeš muset naučit v Thunder Bluff. Vydej se po cestě na sever z Bloodhoof Village. Dovede tě k úpatí Thunder Bluff. Vyjeď výtahem nahoru a pak se můžeš kteréhokoli Bluffwatchera zeptat na další pomoc.")
add("Brave Leaping Deer","Hmmm, I think you will need to go up to Thunder Bluff to learn that.  Head north on the road out of Bloodhoof Village.  It will take you to the base of Thunder Bluff.  Ride the elevator to the top and you should be able to ask any of the Bluffwatchers there for further assistance.","Hmmm, myslím, že se to budeš muset naučit v Thunder Bluff. Vydej se po cestě na sever z Bloodhoof Village. Dovede tě k úpatí Thunder Bluff. Vyjeď výtahem nahoru a pak se můžeš kteréhokoli Bluffwatchera zeptat na další pomoc.")
add("Brave Rainchaser","Hmmm, I think you will need to go up to Thunder Bluff to learn that.  Head north on the road out of Bloodhoof Village.  It will take you to the base of Thunder Bluff.  Ride the elevator to the top and you should be able to ask any of the Bluffwatchers there for further assistance.","Hmmm, myslím, že se to budeš muset naučit v Thunder Bluff. Vydej se po cestě na sever z Bloodhoof Village. Dovede tě k úpatí Thunder Bluff. Vyjeď výtahem nahoru a pak se můžeš kteréhokoli Bluffwatchera zeptat na další pomoc.")
add("Brave Rockhorn","Hmmm, I think you will need to go up to Thunder Bluff to learn that.  Head north on the road out of Bloodhoof Village.  It will take you to the base of Thunder Bluff.  Ride the elevator to the top and you should be able to ask any of the Bluffwatchers there for further assistance.","Hmmm, myslím, že se to budeš muset naučit v Thunder Bluff. Vydej se po cestě na sever z Bloodhoof Village. Dovede tě k úpatí Thunder Bluff. Vyjeď výtahem nahoru a pak se můžeš kteréhokoli Bluffwatchera zeptat na další pomoc.")
add("Brave Strongbash","Hmmm, I think you will need to go up to Thunder Bluff to learn that.  Head north on the road out of Bloodhoof Village.  It will take you to the base of Thunder Bluff.  Ride the elevator to the top and you should be able to ask any of the Bluffwatchers there for further assistance.","Hmmm, myslím, že se to budeš muset naučit v Thunder Bluff. Vydej se po cestě na sever z Bloodhoof Village. Dovede tě k úpatí Thunder Bluff. Vyjeď výtahem nahoru a pak se můžeš kteréhokoli Bluffwatchera zeptat na další pomoc.")
add("Brave Swiftwind","Hmmm, I think you will need to go up to Thunder Bluff to learn that.  Head north on the road out of Bloodhoof Village.  It will take you to the base of Thunder Bluff.  Ride the elevator to the top and you should be able to ask any of the Bluffwatchers there for further assistance.","Hmmm, myslím, že se to budeš muset naučit v Thunder Bluff. Vydej se po cestě na sever z Bloodhoof Village. Dovede tě k úpatí Thunder Bluff. Vyjeď výtahem nahoru a pak se můžeš kteréhokoli Bluffwatchera zeptat na další pomoc.")
add("Brave Wildrunner","Hmmm, I think you will need to go up to Thunder Bluff to learn that.  Head north on the road out of Bloodhoof Village.  It will take you to the base of Thunder Bluff.  Ride the elevator to the top and you should be able to ask any of the Bluffwatchers there for further assistance.","Hmmm, myslím, že se to budeš muset naučit v Thunder Bluff. Vydej se po cestě na sever z Bloodhoof Village. Dovede tě k úpatí Thunder Bluff. Vyjeď výtahem nahoru a pak se můžeš kteréhokoli Bluffwatchera zeptat na další pomoc.")
-- source_id 841
add("Undercity Guardian","Hmmm, that good idea.  Maybe we head there to get some stitches replaced?  Him sew good.  You find Josef Gregorian on inner circle of Magic Quarter.","Hmmm, to dobrý nápad. Možná tam zajít vyměnit pár stehů? On šije dobře. Josef Gregorian najdeš na vnitřním okruhu Magic Quarter.")
-- source_id 842
add("Stormwind Guard","Hmmm... only enchanters I know of around here work out of Stormwind.  Why don't you ask one of the guards up in Stormwind?","Hmmm... jediní enchanters, které tady znám, pracují ve Stormwindu. Proč se nezeptáš některého ze strážných ve Stormwindu?")
-- source_id 843
add("Uthrar Threx","Hold on there, I'm just an assistant. If ye want to start learnin' the fancy stuff, talk to old Stonebrew over there.","Počkej, já jsem jen pomocník. Jestli se chceš začít učit ty složitější věci, promluv si támhle se starým Stonebrewem.")
-- source_id 844
add("Rhiannon Davis","How can I share my secrets with a beginner? Try speaking with Victor Ward first.","Jak se můžu dělit o svá tajemství s úplným začátečníkem? Nejdřív si promluv s Victorem Wardem.")
-- source_id 845
add("Rogvar","How dare you ask me for training, maggot? What were you hoping for, you slack-jawed yokel, a lecture on the proper uses of silverleaf? Out! You're lucky I don't thrash you senseless for wasting my time.","Jak se mě opovažuješ žádat o výcvik, červe? V co jsi doufal, ty tupohlavý balíku, v přednášku o správném využití silverleafu? Ven! Můžeš být rád, že tě nezmlátím do bezvědomí za to, že plýtváš mým časem.")
-- source_id 846
add("Tamed Kodo","How do the goblins ever manage to secure packs to these beasts?  Kodos are ten times the size!","Jak se goblinům vůbec daří připevnit náklad k těmhle bestiím? Kodos jsou desetkrát větší!")
-- source_id 847
add("Hands Springsprocket","How do you do, $c?","Jak se vede, $c?")
-- source_id 848
add("Kharan Mighthammer","How else could this have happened? Someone must have tipped the Dark Irons off.$B$B<Kharan shakes his fist at you.>$B$BSo help me, if I ever get out of here, I will spend the rest of my days finding the traitor.","Jak jinak by se to mohlo stát? Někdo musel Dark Irons varovat.$B$B<Kharan na tebe zatřese pěstí.>$B$BPřísahám, že jestli se odtud někdy dostanu, strávím zbytek života hledáním zrádce.")
-- source_id 849
add("James Van Brunt","How is the edge of your steel? Good enough to cut through the belly of your enemy? Let me show you some things to make it even sharper.","Jak ostré je ostří tvé zbraně? Dost ostré, aby rozpáralo břicho tvého nepřítele? Ukážu ti pár věcí, díky kterým bude ještě ostřejší.")
-- source_id 850
add("General Zog","How many metal bars you say? As of my last update on the situation, here is what I know. The Horde has collected $2018w copper bars out of $1998w needed, $2005w tin bars out of $2006w and of $2009w mithril bars sought, $2008w have been gathered.","Kolik metal bars říkáš? Podle mé poslední zprávy o situaci vím toto. Horde shromáždila $2018w copper bars z potřebných $1998w, $2005w tin bars z $2006w a z požadovaných $2009w mithril bars už bylo nasbíráno $2008w.")
-- source_id 851
add("Gringer","How may I be of service?","Jak ti mohu posloužit?")
add("Michael Garrett","How may I be of service?","Jak ti mohu posloužit?")
-- source_id 852
add("Grimtak","How may I help you?","Jak ti mohu pomoci?")
add("Varg Windwhisper","How may I help you?","Jak ti mohu pomoci?")
-- source_id 853
add("Lady Callow","How unfortunate; it would appear that we have collected all of the mageweave bandages necessary. Perhaps you can go sell them on the auction house? But before you go, be a good $g boy : girl; and check with the other collectors present. They may have an errand to send you off on.","To je škoda; vypadá to, že jsme už shromáždili všechny potřebné mageweave bandages. Možná je můžeš prodat v auction house? Než ale půjdeš, buď hodný $gchlapec:dívka; a podívej se i za ostatními sběrači tady. Možná pro tebe mají nějaký úkol.")
-- source_id 854
add("Adele Fielder","How's it going? I love the smell of leather; don't you?","Jak se vede? Miluju vůni kůže; ty ne?")
-- source_id 855
add("Finkle Einhorn","How?? Well, it's a long story.","Jak?? No, to je dlouhý příběh.")
-- source_id 856
add("Razor Hill Grunt","Huh?  You'll find the bank in Orgrimmar.  Head north up the road to get there and then talk to one of their grunts.","Cože? Banku najdeš v Orgrimmaru. Vydej se po cestě na sever a pak se tam zeptej některého z gruntů.")
-- source_id 857
add("Royal Historian Archesonus","Hundreds of years ago, the great city of Thaurissan stood proudly in a lush expanse of land that is now the dilapidated Burning Steppes.$B$BThaurissan was home to the nation of Dark Iron dwarves and at the time, in the midst of a civil war among the dwarven nation at large.$B$BYou see, that area of the world was at one point in time part of the Redridge Mountains - until the day that Thaurissan was consumed by a gigantic explosion. The city lay in ruin, the surrounding areas reduced to an ashy wasteland.","Před stovkami let stálo velké město Thaurissan hrdě uprostřed úrodné krajiny, která je dnes zchátralými Burning Steppes.$B$BThaurissan byl domovem národa Dark Iron dwarfů a v té době zuřila uvnitř celého trpasličího národa občanská válka.$B$BVíš, tato část světa kdysi patřila k Redridge Mountains — až do dne, kdy Thaurissan pohltil obrovský výbuch. Město zůstalo v troskách a okolní krajina se proměnila v popelavou pustinu.")
-- source_id 858
add("Skullsplitter Speaker","Hurry! You should talk to Mekkatorque! If we don't start the assault soon, we're going to be late.$B$BAnd my boss HATES it when we're late!","Rychle! Měl bys promluvit s Mekkatorquem! Pokud útok brzy nezahájíme, přijdeme pozdě.$B$BA můj šéf NESNÁŠÍ, když chodíme pozdě!")
-- source_id 859
add("Midsummer Celebrant","I admire the skill that torch jugglers have.","Obdivuji dovednost žonglérů s pochodněmi.")
-- source_id 860
add("Randal Worth","I already know a lot about style. Now it's just a matter of mastering the techniques for working with leather. Good thing Simon's a real sport about helping me learn them.","O stylu už vím hodně. Teď už jde jen o to zvládnout techniky práce s kůží. Ještě že je Simon tak ochotný mi s učením pomáhat.")
-- source_id 861
add("Rayne","I am a crafter of some renown, $c. With the proper materials, I am able to craft an armor known as Dreamwalker. Druids - and even some shaman - are drawn to this armor due to its magical properties. Are you interested?","Jsem poměrně uznávaný řemeslník, $c. Se správnými materiály dokážu vyrobit armor známý jako Dreamwalker. Druidové — a dokonce i někteří shamani — jsou k tomuto armoru přitahováni kvůli jeho magickým vlastnostem. Máš zájem?")
-- source_id 862
add("Al'tabim the All-Seeing","I am Al'tabim the All-Seeing - an envoy of King Rastakhan.$B$BMy dealings are with priests, mages, and warlocks.","Jsem Al'tabim the All-Seeing — vyslanec King Rastakhana.$B$BJednám s priests, mages a warlocks.")
-- source_id 863
add("Royal Overseer Bauhaus","I am an officer of the city, working in the capacity of the Undercity's census.  Since our liberation from the Scourge, we have tried to keep an accurate track of our city's populace.  Through arcane methods and sharpened mental discipline, I am able to access these records.  If you have business with me accordingly, please proceed.  You should know if you do, at any rate.","Jsem městský úředník a pracuji pro sčítání obyvatel Undercity. Od našeho osvobození od Scourge se snažíme vést přesný přehled o obyvatelstvu města. Pomocí arcane metod a vytříbené duševní disciplíny dokážu k těmto záznamům přistupovat. Pokud se mnou v této věci něco potřebuješ, pokračuj. Ostatně měl bys vědět, jestli ano.")
-- source_id 864
add("Deathly Usher","I am bound eternally to this cursed world. What is it you desire, mortal?","Jsem navěky připoután k tomuto prokletému světu. Co si přeješ, smrtelníku?")
-- source_id 865
add("Teldrassil Sentinel","I am certain there is a Tailor that could provide you training in Darnassus.  When you arrive, ask one of the Sentinels in Darnassus about seeing a Tailor.","Jsem si jistý, že v Darnassusu najdeš Tailora, který tě může vycvičit. Až dorazíš, zeptej se některé ze Sentinels v Darnassusu na Tailora.")
-- source_id 866
add("Gloom'rel","I am forever denied the touch of stone.  I will never again know the glory of shaped iron...","Navždy mi byl odepřen dotek kamene. Už nikdy nepoznám slávu tvarovaného železa...")
-- source_id 867
add("Overlord Runthak","I am he that carries out the Warchief's commands without question. I am Horde.","Jsem ten, kdo bez otázek plní rozkazy Warchiefa. Jsem Horde.")
-- source_id 868
add("High Overlord Saurfang","I am he that watches they. I am the fist of retribution. That which does quell the recalcitrant. Dare you defy the Warchief? Dare you face my merciless judgement?","Jsem ten, kdo je sleduje. Jsem pěst odplaty. Ten, který zkrotí vzdorovité. Odvážíš se vzdorovat Warchiefovi? Odvážíš se čelit mému nemilosrdnému soudu?")
-- source_id 869
add("Tel'Athir","I am honored to share my knowledge with you, $N. See that you use it well.","Je mi ctí podělit se s tebou o své znalosti, $N. Dbej, abys je dobře využil.")
-- source_id 870
add("Duke Hydraxis","I am Hydraxis, Duke of the Waterlords.  You are not an elemental and so cannot understand our struggle, but perhaps we can strike a deal that will benefit us both...","Jsem Hydraxis, Duke of the Waterlords. Nejsi elemental, a proto nemůžeš pochopit náš boj, ale možná můžeme uzavřít dohodu, která prospěje nám oběma...")
-- source_id 871
add("Warmaster Laggrond","I am in charge of recruitment for the Frostwolf Clan. As a soldier of Frostwolf, it is your responsibility to check in with me as your rank among the clan rises.$B$BHonor and respect are earned on this frigid field.","Mám na starosti nábor pro Frostwolf Clan. Jako voják Frostwolf je tvou povinností hlásit se u mě, jak bude tvá hodnost v klanu růst.$B$BČest a respekt si na tomto ledovém bojišti musíš zasloužit.")
-- source_id 872
add("Jin'rokh the Breaker","I am Jin'rokh the Breaker, envoy of Mugamba: Fist of Rastakhan!$B$BMy dealings are with warriors and heathens.","Jsem Jin'rokh the Breaker, vyslanec Mugamby: Fist of Rastakhan!$B$BJednám s warriors a heathens.")
-- source_id 873
add("Kilram","I am Kilram, master of the axe.","Jsem Kilram, mistr sekery.")
-- source_id 874
add("Bowen Brisboise","I am knowledgable, but I am not an expert. You know who you should talk to? Rhiannon! She's not far. Ask around for her in Undercity","Něco vím, ale nejsem žádný expert. Víš, s kým by sis měl promluvit? S Rhiannon! Není daleko. Zeptej se na ni v Undercity.")
-- source_id 875
add("Tarn","I am pleased with your progress so far. Surely the Earth Mother has inspired your hands.","S tvým dosavadním pokrokem jsem spokojen. Earth Mother jistě vedla tvé ruce.")
-- source_id 876
add("Captain Kromcrush","I am so smart!  S-M-R-T!","Jsem tak chytrý! S-M-R-T!")
add("Gordok Brute","I am so smart!  S-M-R-T!","Jsem tak chytrý! S-M-R-T!")
add("Gordok Bushwacker","I am so smart!  S-M-R-T!","Jsem tak chytrý! S-M-R-T!")
add("Gordok Captain","I am so smart!  S-M-R-T!","Jsem tak chytrý! S-M-R-T!")
add("Gordok Mage-Lord","I am so smart!  S-M-R-T!","Jsem tak chytrý! S-M-R-T!")
add("Gordok Reaver","I am so smart!  S-M-R-T!","Jsem tak chytrý! S-M-R-T!")
add("Gordok Warlock","I am so smart!  S-M-R-T!","Jsem tak chytrý! S-M-R-T!")
-- source_id 877
add("Aethalas","I am sorry $c, but you are not seasoned enough yet to enter Warsong Gulch.","Je mi líto, $c, ale ještě nejsi dost zkušený na vstup do Warsong Gulch.")
add("Brakgul Deathbringer","I am sorry $c, but you are not seasoned enough yet to enter Warsong Gulch.","Je mi líto, $c, ale ještě nejsi dost zkušený na vstup do Warsong Gulch.")
add("Elfarran","I am sorry $c, but you are not seasoned enough yet to enter Warsong Gulch.","Je mi líto, $c, ale ještě nejsi dost zkušený na vstup do Warsong Gulch.")
add("Kergul Bloodaxe","I am sorry $c, but you are not seasoned enough yet to enter Warsong Gulch.","Je mi líto, $c, ale ještě nejsi dost zkušený na vstup do Warsong Gulch.")
add("Kurden Bloodclaw","I am sorry $c, but you are not seasoned enough yet to enter Warsong Gulch.","Je mi líto, $c, ale ještě nejsi dost zkušený na vstup do Warsong Gulch.")
-- source_id 878
add("Brogun Stoneshield","I am sorry $c, but you need to be more experienced before you can survive in Alterac Valley.","Je mi líto, $c, ale než budeš moci přežít v Alterac Valley, potřebuješ více zkušeností.")
add("Grizzle Halfmane","I am sorry $c, but you need to be more experienced before you can survive in Alterac Valley.","Je mi líto, $c, ale než budeš moci přežít v Alterac Valley, potřebuješ více zkušeností.")
add("Kartra Bloodsnarl","I am sorry $c, but you need to be more experienced before you can survive in Alterac Valley.","Je mi líto, $c, ale než budeš moci přežít v Alterac Valley, potřebuješ více zkušeností.")
add("Taim Ragetotem","I am sorry $c, but you need to be more experienced before you can survive in Alterac Valley.","Je mi líto, $c, ale než budeš moci přežít v Alterac Valley, potřebuješ více zkušeností.")
add("Thelman Slatefist","I am sorry $c, but you need to be more experienced before you can survive in Alterac Valley.","Je mi líto, $c, ale než budeš moci přežít v Alterac Valley, potřebuješ více zkušeností.")
-- source_id 879
add("Deze Snowbane","I am sorry $c, but you need to be more powerful before I can allow you to enter Arathi Basin.","Je mi líto, $c, ale než ti budu moci dovolit vstoupit do Arathi Basin, musíš být silnější.")
add("Keras Wolfheart","I am sorry $c, but you need to be more powerful before I can allow you to enter Arathi Basin.","Je mi líto, $c, ale než ti budu moci dovolit vstoupit do Arathi Basin, musíš být silnější.")
add("Lady Hoteshem","I am sorry $c, but you need to be more powerful before I can allow you to enter Arathi Basin.","Je mi líto, $c, ale než ti budu moci dovolit vstoupit do Arathi Basin, musíš být silnější.")
add("Martin Lindsey","I am sorry $c, but you need to be more powerful before I can allow you to enter Arathi Basin.","Je mi líto, $c, ale než ti budu moci dovolit vstoupit do Arathi Basin, musíš být silnější.")
-- source_id 880
add("Super-Seller 680","I am the latest incarnation of automated vendors... we will rule the world one day... don't tell my boss that I am skimming money off his merchandise...","Jsem nejnovější inkarnace automatizovaných prodejců... jednoho dne ovládneme svět... neříkej mému šéfovi, že si ulévám peníze z jeho zboží...")
-- source_id 881
add("Tinkmaster Overspark","I am Tinkmaster Overspark, and I am the chief architect for modern gnomish engineering principles in the world today.  It is my job to ensure that the power of invention continues to shine brightest from our arclight spanners than anywhere else!$B$BAlso, if you happen to know a good schematic for radiation elimination, we just so happen to be in the market for one right about now...","Jsem Tinkmaster Overspark a jsem hlavním architektem moderních principů gnomish engineeringu v dnešním světě. Mým úkolem je zajistit, aby síla vynálezů zářila z našich arclight spanners jasněji než kdekoli jinde!$B$BA pokud náhodou znáš dobré schéma na odstranění radiace, zrovna teď bychom o jedno opravdu měli zájem...")
-- source_id 882
add("Lore Keeper of Norgannon","I am unable to process your chronological reference in comparison to the recording of this data, my apologies.$B$BThe trogg retains some composition of Azeroth's various stone core compounds, but the loss of cognitive power makes this variant unacceptable to the Creators.$B$BThe trogg procreates as per a standard biomass.  By default it consumes stone and anything else it can acquire, including other troggs.  Cannibalism is considered unacceptable by the Creators.","Nedokážu zpracovat tvůj časový odkaz ve vztahu k době záznamu těchto dat, omlouvám se.$B$BTrogg si zachovává část složení různých kamenných sloučenin jádra Azerothu, ale ztráta kognitivních schopností činí tuto variantu pro Creators nepřijatelnou.$B$BTrogg se rozmnožuje jako standardní biomasa. Ve výchozím stavu požírá kámen a cokoli dalšího, co dokáže získat, včetně jiných troggů. Cannibalism je Creators považován za nepřijatelný.")
-- source_id 883
add("Lore Keeper of Norgannon","I am unable to process your chronological reference in comparison to the recording of this data, my apologies.$B$BThough the dwarf maintains most of the Earthen's mental attunement to Azeroth's stone composition, the reversion back into living biomass remains the main degeneration of the matrix.  Dwarves eat and procreate through means typical to other standard biomasses.$B$BThe Creators view the dwarf as an acceptable variant, worthy of genesis in its own right.","Nedokážu zpracovat tvůj časový odkaz ve vztahu k době záznamu těchto dat, omlouvám se.$B$BPřestože dwarf si zachovává většinu mentálního napojení Earthen na kamenné složení Azerothu, návrat zpět k živé biomase zůstává hlavní degenerací matrice. Dwarves jedí a rozmnožují se způsoby typickými pro jiné standardní biomasy.$B$BCreators považují dwarfa za přijatelnou variantu, která je sama o sobě hodna geneze.")
-- source_id 884
add("Carolai Anise","I appreciate the company, but let's face it: you have more experience with potions than I do. Talk to Doctor Marsh instead if you want training. He's a Forsaken in the Apothecarium of the Undercity.","Společnost je příjemná, ale přiznejme si to: s lektvary máš víc zkušeností než já. Pokud chceš výcvik, promluv si raději s Doctor Marshem. Je to Forsaken v Apothecarium v Undercity.")
-- source_id 885
add("Var'jun","I be seeking someone, $c. Please, leave me be... it is important I find them.","Někoho hledám, $c. Prosím, nech mě být... je důležité, abych ho našel.")
-- source_id 886
add("Arygos","I bear witness to a miracle that stands before me! In one thousand years of captivity, I have not seen a single LIVING specimen - other than those foul Qiraji and silithid - enter these chambers.","Jsem svědkem zázraku, který stojí přímo přede mnou! Za tisíc let zajetí jsem neviděl jediný ŽIVÝ exemplář — kromě těch odporných Qiraji a silithidů — vstoupit do těchto komnat.")
-- source_id 887
add("Stormwind Guard","I believe Aldwin Laughlin is still the resident Guild Master of Stormwind.  Look for his residence on your left as you pass the inner gate of Stormwind.","Myslím, že Aldwin Laughlin je stále zdejším Guild Masterem Stormwindu. Jeho sídlo hledej vlevo, jakmile projdeš vnitřní branou Stormwindu.")
-- source_id 888
add("Bluffwatcher","I believe I noticed a new shipment of mail being delivered not too long ago.  You'll find the mailbox just outside the Thunder Bluff Bank on the lower rise.","Myslím, že jsem před chvílí viděl dorazit novou zásilku pošty. Mailbox najdeš hned před Thunder Bluff Bank na dolní vyvýšenině.")
-- source_id 889
add("Stormwind Guard","I bet Josetta would be more than happy to teach you some new spells.  She is probably up in her room at the Lion's Pride Inn.","Vsadím se, že Josetta tě ráda naučí nějaká nová kouzla. Nejspíš bude nahoře ve svém pokoji v Lion's Pride Inn.")
-- source_id 890
add("Gelman Stonehand","I came from Ironforge to help out with the rebuilding effort here. If I can teach enough of ye my skills then maybe I can leave it to ye and take myself back home.","Přišel jsem z Ironforge, abych pomohl s obnovou tady. Když dost z vás naučím své dovednosti, možná vám to budu moct nechat a vrátit se domů.")
-- source_id 891
add("Mankrik","I came to the Crossroads from the south seeking help, $c, but I find only cowards who turn their backs on me--even the mighty Thork insults me so. He is a good leader, but his dismissal of my plea causes me greater anger.$B$BHe claims my rage makes me hasty--that it clouds my judgement--but I will not rest until I have vengeance!","Přišel jsem do Crossroads z jihu hledat pomoc, $c, ale nacházím tu jen zbabělce, kteří se ke mně obracejí zády — dokonce i mocný Thork mě odmítá. Je to dobrý vůdce, ale jeho přehlížení mé prosby ve mně vyvolává ještě větší hněv.$B$BTvrdí, že mě můj vztek nutí jednat ukvapeně — že mi zatemňuje úsudek — ale já nebudu mít klid, dokud se nepomstím!")
-- source_id 892
add("Brek Stonehoof","I can instruct you in mining.  Interested?","Mohu tě vyučit v miningu. Máš zájem?")
add("Brom Killian","I can instruct you in mining.  Interested?","Mohu tě vyučit v miningu. Máš zájem?")
add("Dank Drizzlecut","I can instruct you in mining.  Interested?","Mohu tě vyučit v miningu. Máš zájem?")
add("Geofram Bouldertoe","I can instruct you in mining.  Interested?","Mohu tě vyučit v miningu. Máš zájem?")
add("Makaru","I can instruct you in mining.  Interested?","Mohu tě vyučit v miningu. Máš zájem?")
add("Matt Johnson","I can instruct you in mining.  Interested?","Mohu tě vyučit v miningu. Máš zájem?")
add("Yarr Hammerstone","I can instruct you in mining.  Interested?","Mohu tě vyučit v miningu. Máš zájem?")
-- source_id 893
add("Drakk Stonehand","I can make amazing things with the materials I find out here. By Muradin's beard, there are fantastic creatures in these hills! Go have a whack at them, $N, and bring me back some tall tales.","Z materiálů, které tu nacházím, dokážu vyrábět úžasné věci. Při Muradinových vousech, v těchto kopcích žijí fantastická stvoření! Jdi si do nich praštit, $N, a vrať se mi s nějakými pořádnými historkami.")
-- source_id 894
add("Harutt Thunderhorn","I can not train you, $c.","Nemohu tě vycvičit, $c.")
add("Ker Ragetotem","I can not train you, $c.","Nemohu tě vycvičit, $c.")
add("Krang Stonehoof","I can not train you, $c.","Nemohu tě vycvičit, $c.")
add("Sark Ragetotem","I can not train you, $c.","Nemohu tě vycvičit, $c.")
add("Torm Ragetotem","I can not train you, $c.","Nemohu tě vycvičit, $c.")
-- source_id 895
add("Holt Thunderhorn","I can not train you, young one.","Nemohu tě vycvičit, mladý.")
-- source_id 896
add("Ormak Grimshot","I can not train you.","Nemohu tě vycvičit.")
-- source_id 897
add("Carolyn Ward","I can not train you. You need to talk to your class trainer.","Nemohu tě vycvičit. Musíš si promluvit se svým class trainerem.")
add("David Trias","I can not train you. You need to talk to your class trainer.","Nemohu tě vycvičit. Musíš si promluvit se svým class trainerem.")
add("Frahun Shadewhisper","I can not train you. You need to talk to your class trainer.","Nemohu tě vycvičit. Musíš si promluvit se svým class trainerem.")
add("Gregory Charles","I can not train you. You need to talk to your class trainer.","Nemohu tě vycvičit. Musíš si promluvit se svým class trainerem.")
add("Marion Call","I can not train you. You need to talk to your class trainer.","Nemohu tě vycvičit. Musíš si promluvit se svým class trainerem.")
add("Miles Dexter","I can not train you. You need to talk to your class trainer.","Nemohu tě vycvičit. Musíš si promluvit se svým class trainerem.")
-- source_id 898
add("Ug'thok","I can show you what you wish to know, but you must be patient. Take your time to work the steel and feel the way it shapes beneath your hammer. When you become one with the steel, then you will understand.","Mohu ti ukázat to, co chceš vědět, ale musíš být trpělivý. Při práci s ocelí nespěchej a vnímej, jak se pod tvým kladivem tvaruje. Až s ocelí splyneš, pochopíš.")
-- source_id 899
add("Androl Oakhand","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Armand Cromwell","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Arnold Leland","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Astaia","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Brannock","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Clyde Kellen","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Donald Rabonne","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Grimnur Stonebrand","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Harold Riggs","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Kah Mistrunner","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Katoom the Angler","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Kil'Hiwana","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Lau'Tiki","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Lee Brown","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Lui'Mala","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Matthew Hooper","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Myizz Luckycatch","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Paxton Ganter","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Uthan Stillwater","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
add("Warg Deepwater","I can teach you fishing skills.","Mohu tě naučit rybářským dovednostem.")
-- source_id 900
add("Alegorn","I can teach you how to cook!","Mohu tě naučit vařit!")
add("Aska Mistrunner","I can teach you how to cook!","Mohu tě naučit vařit!")
add("Cook Ghilm","I can teach you how to cook!","Mohu tě naučit vařit!")
add("Crystal Boughman","I can teach you how to cook!","Mohu tě naučit vařit!")
add("Duhng","I can teach you how to cook!","Mohu tě naučit vařit!")
add("Eunice Burch","I can teach you how to cook!","Mohu tě naučit vařit!")
add("Gremlock Pilsnor","I can teach you how to cook!","Mohu tě naučit vařit!")
add("Mudduk","I can teach you how to cook!","Mohu tě naučit vařit!")
add("Pyall Silentstride","I can teach you how to cook!","Mohu tě naučit vařit!")
add("Slagg","I can teach you how to cook!","Mohu tě naučit vařit!")
add("Tomas","I can teach you how to cook!","Mohu tě naučit vařit!")
add("Zarrin","I can teach you how to cook!","Mohu tě naučit vařit!")
