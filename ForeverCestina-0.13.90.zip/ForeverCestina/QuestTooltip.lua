-- Read native data without changing it. Localize FontStrings in line-post,
-- before the engine's Show pass measures the complete text.
local _, A = ...
local states=setmetatable({},{__mode="k"})
local writing=setmetatable({},{__mode="k"})
local minimapOutputs=setmetatable({},{__mode="k"})
local function enabled()
 return (not A.DB or A.DB.enabled~=false) and not (IsShiftKeyDown and IsShiftKeyDown())
end
-- Map pins use SetText/AddLine, not GetQuestPartyProgress.
-- A blob pin represents many quests: its stored questID is the selected quest,
-- not necessarily the area under the cursor. Resolve that area once per header.
local mapAreas=setmetatable({},{__mode="k"})
local function mapInfo(tip,refresh)
 if tip~=GameTooltip or not tip.GetOwner then return end
 local owner=tip:GetOwner()
 if not A.Accessible(owner) or not owner then return end
 -- QuestMapLogTitleButton_OnEnter builds a manual tooltip from self.info.
 -- Require the actual quest-log ancestry, not arbitrary frames with quest IDs.
 local info=owner.info
 if A.Accessible(info) and type(info)=='table' and A.PublicNumber(info.questID) and info.questID>0 then
  local parent=owner
  for _=1,12 do
   if not A.Accessible(parent) or not parent then break end
   if parent==_G.QuestScrollFrame or parent==_G.QuestMapFrame then return owner,info.questID end
   parent=parent.GetParent and parent:GetParent()
  end
 end
 if not _G.WorldMapFrame or not owner.GetMap then return end
 local map=owner:GetMap()
 if not A.Accessible(map) or map~=WorldMapFrame then return end
 if owner.UpdateMouseOverTooltip then
  if refresh then
   mapAreas[tip]=nil
   if not map.GetNormalizedCursorPosition then return end
   local x,y=map:GetNormalizedCursorPosition()
   if not A.PublicNumber(x) or not A.PublicNumber(y) then return end
   local id=owner:UpdateMouseOverTooltip(x,y)
   if A.PublicNumber(id) and id>0 then mapAreas[tip]={owner=owner,id=id} end
  end
  local area=mapAreas[tip]
  if area and area.owner==owner then return owner,area.id end
  return
 end
 if not owner.GetQuestID then return end
 local id=owner:GetQuestID()
 if A.PublicNumber(id) and id>0 then return owner,id end
end
local function infoFor(tip)
 local output=minimapOutputs[tip]
 if output then return output,0 end
 local owner,id=mapInfo(tip)
 if owner then return owner,id end
 if not tip.GetProcessingTooltipInfo then return end
 local info=tip:GetProcessingTooltipInfo()
 if not A.Accessible(info) or type(info)~="table" then return end
 if not A.Accessible(info.getterName) then return end
 if not A.Accessible(info.getterArgs) or type(info.getterArgs)~="table" then return end
 if info.getterName=="GetHyperlink" and tip==_G.ItemRefTooltip then
  local link=info.getterArgs[1]
  if not A.Accessible(link) or type(link)~="string" then return end
  local id=tonumber(link:match("^quest:(%d+):") or link:match("^quest:(%d+)$"))
  if A.PublicNumber(id) and id>0 then return info,id end
 elseif info.getterName=="GetQuestPartyProgress" then
  local id=info.getterArgs[1]
  if A.PublicNumber(id) and id>0 then return info,id end
 elseif info.getterName=="GetMinimapMouseover" and tip==GameTooltip then
  return info,0 -- A minimap tooltip can contain more than one quest.
 end
end
local function minimapQuestTitle(source)
 if not C_QuestLog or not C_QuestLog.GetNumQuestLogEntries or not C_QuestLog.GetInfo then return end
 local count=C_QuestLog.GetNumQuestLogEntries()
 if not A.PublicNumber(count) or count<0 or count>500 or count%1~=0 then return end
 local clean=A.Normalize(source)
 local found
 for index=1,count do
  local row=C_QuestLog.GetInfo(index)
  if A.Accessible(row) and type(row)=='table' and A.PublicNumber(row.questID) and row.questID>0
      and A.Accessible(row.title) and type(row.title)=='string' and A.Normalize(row.title)==clean then
   if found and found~=row.questID then return end -- Ambiguous names stay English.
   found=row.questID
  end
 end
 return found
end
local hints={
 ["<Click to view Quest Details>"]="<Kliknutím zobrazíš podrobnosti úkolu>",
 ["Press F6 to submit an issue for this Quest"]="F6: nahlásit problém s tímto úkolem",
}
function A.TranslateQuestTooltip(id,text)
 local clean=A.Normalize(text)
 if not clean or clean=="" then return end
 if hints[clean] then return hints[clean] end
 local prefix,body=clean:match("^(%- )(.+)$")
 body=body or clean
 -- Chat-link tooltips use required counts, not progress fractions.
 local count,target=body:match("^(%d+) x (.+)$")
 local required=count and A.TranslateQuestTarget and A.TranslateQuestTarget(id,target)
 if required then return (prefix or "")..count.." x "..required end
 if body=="Requirements:" then return (prefix or "").."Požadavky:" end
 local cs=(A.TranslateQuestTitle and A.TranslateQuestTitle(id,body)) or A.TranslateQuestObjective(id,body)
 if not cs then
  for _,field in ipairs({"objectives","description","progress","completion"}) do
   cs=A.TranslateQuest(id,field,body);if cs then break end
  end
 end
 if cs then return (prefix or "")..cs end
end
-- The live minimap packs several quests into ONE FontString, with newline and
-- color markers spanning logical rows. Keep those bytes; replace only a whole
-- exact visible text segment, using the active quest belonging to that title.
local function minimapText(source,previousID)
 local id,changed=previousID,false
 local function segment(raw)
  local clean=A.Normalize(raw)
  local titleID=minimapQuestTitle(raw)
  if titleID then id=titleID
  elseif clean~='' and not clean:match('^%- ') then id=nil end
  if not id or clean=='' then return raw end
  local cs=A.TranslateQuestTooltip(id,clean)
  if not cs then return raw end
  local first,last=raw:find(clean,1,true)
  if not first then return raw end
  local before,after=raw:sub(1,first-1),raw:sub(last+1)
  if A.Normalize(before)~='' or A.Normalize(after)~='' then return raw end
  changed=true
  return before..cs..after
 end
 local parts,pos={},1
 while true do
  local first,last=source:find('\r?\n',pos)
  if not first then parts[#parts+1]=segment(source:sub(pos));break end
  parts[#parts+1]=segment(source:sub(pos,first-1))
  parts[#parts+1]=source:sub(first,last);pos=last+1
 end
 return changed and table.concat(parts) or nil,id
end
local function begin(tip)
 minimapOutputs[tip]=nil
 local info,id=infoFor(tip)
 if info then states[tip]={id=id,mode=enabled(),items={}} else states[tip]=nil end
end
local function postLine(tip,row)
 local state=states[tip]
 if not state or not A.Accessible(row) or type(row)~="table" then return end
 local _,id=infoFor(tip);if id~=state.id then return end
 local source=row.leftText
 if not A.Accessible(source) or type(source)~="string" then
  if id==0 then state.minimapID=nil end
  return
 end
 local cs
 if id==0 then cs,state.minimapID=minimapText(source,state.minimapID)
 else cs=A.TranslateQuestTooltip(id,source) end
 if not cs then return end
 local name,index=tip:GetName(),row.lineIndex
 if not A.Accessible(name) or type(name)~="string" or not A.PublicNumber(index)
     or index<1 or index>500 or index%1~=0 then return end
 local font=_G[name.."TextLeft"..index];if not font then return end
 local color=source:match("^(|c%x%x%x%x%x%x%x%x)")
 if color and id~=0 then cs=color..cs.."|r" end
 local item={font=font,en=source,cs=cs}
 state.items[#state.items+1]=item
 if state.mode then item.output=A.WriteTooltipRowText(tip,font,source,cs,false) end
end
function A.HandleQuestTooltip(tip)
 local info,id=infoFor(tip)
 if not info then states[tip]=nil;return false end
 local state=states[tip]
 if state and id~=state.id then states[tip]=nil;return true end
 local mode=enabled()
 if state and state.mode~=mode and not writing[tip] then
  writing[tip]=true
  local ok,err=pcall(function()
   state.mode=mode
   for _,item in ipairs(state.items) do
    if item.output then A.ToggleTooltipRowText(tip,item.output,mode)
    elseif mode then item.output=A.WriteTooltipRowText(tip,item.font,item.en,item.cs,false) end
   end
   if tip.Show then tip:Show() end
  end)
  writing[tip]=nil
  if not ok then A.NoteError("Quest tooltip refresh",err) end
 end
 return true
end
local manualHooked
local function manualLine(tip,first)
 if first then minimapOutputs[tip]=nil end
 local owner,id=mapInfo(tip,first)
 if not owner then if first then states[tip]=nil end;return end
 if first or not states[tip] or states[tip].id~=id then begin(tip) end
 local index=first and 1 or tip:NumLines()
 local name=tip:GetName()
 if not A.Accessible(name) or type(name)~="string" or not A.PublicNumber(index)
     or index<1 or index>500 or index%1~=0 then return end
 local font=_G[name.."TextLeft"..index]
 if font then postLine(tip,{leftText=font:GetText(),lineIndex=index}) end
end
-- Minimap_OnUpdate calls SetMinimapMouseover each refresh. Some client output
-- does not reach our line-post path, or is finalized after it. Read only the
-- finished public rows, and reuse the exact active-quest matcher and text writer.
local function minimapFinished(tip)
 if tip~=GameTooltip or not tip.GetName or not tip.NumLines then return end
 local name,count=tip:GetName(),tip:NumLines()
 if not A.Accessible(name) or type(name)~='string' or not A.PublicNumber(count)
     or count<1 or count>500 or count%1~=0 then return end
 local rows,found={},false
 for index=1,count do
  local font=_G[name..'TextLeft'..index]
  local source=font and font.GetText and font:GetText()
  rows[index]={leftText=source,lineIndex=index}
  if A.Accessible(source) and type(source)=='string' and minimapText(source) then found=true end
 end
 if not found then return end
 if minimapOutputs[tip] or not states[tip] or states[tip].id~=0 then states[tip]={id=0,mode=enabled(),items={}} end
 minimapOutputs[tip]={}
 states[tip].minimapID=nil
 for _,row in ipairs(rows) do postLine(tip,row) end
end
local function installManual()
 local tip=_G.GameTooltip
 if manualHooked or not tip or not tip.SetText or not tip.AddLine then return end
 manualHooked=true
 if tip.SetMinimapMouseover then
  hooksecurefunc(tip,'SetMinimapMouseover',function(self)
   A.SafeCall('Minimap quest output',minimapFinished,self)
  end)
  -- Owner changes delimit tooltip lifetimes; never carry minimap text context
  -- into a unit, spell, settings or other tooltip using the same pooled frame.
  if tip.SetOwner then hooksecurefunc(tip,'SetOwner',function(self)
   if minimapOutputs[self] then states[self]=nil;minimapOutputs[self]=nil end
  end) end
 end
 for _,method in ipairs({"SetText","AddLine","AddDoubleLine"}) do
  if tip[method] then
   local first=method=="SetText"
   hooksecurefunc(tip,method,function(self)
    local ok,err=pcall(manualLine,self,first)
    if not ok then A.NoteError("Map quest tooltip",err) end
   end)
  end
 end
end
local hooked
local function install()
 installManual()
 if hooked or not TooltipDataProcessor or not TooltipDataProcessor.AddLinePostCall then return end
 local p=TooltipDataProcessor
 local function safe(fn)
  return function(tip,row)
   local ok,err=pcall(fn,tip,row)
   if not ok then A.NoteError("Quest tooltip",err) end
  end
 end
 p.AddTooltipPreCall(p.AllTypes,safe(begin))
 p.AddLinePostCall(p.AllTypes,safe(postLine))
 hooked=true
end
local frame=CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED");frame:RegisterEvent("PLAYER_LOGIN");frame:RegisterEvent("MODIFIER_STATE_CHANGED")
frame:SetScript("OnEvent",function(_,event,key)
 install()
 if event=="MODIFIER_STATE_CHANGED" and (key=="LSHIFT" or key=="RSHIFT") then
  for tip in pairs(states) do
   if tip.IsShown and tip:IsShown() then A.SafeCall("Quest tooltip Shift",A.HandleQuestTooltip,tip) end
  end
 end
end)
install()
