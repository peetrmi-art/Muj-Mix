-- Legacy QUEST_GREETING: public FontStrings only, from an addon-owned refresh.
-- No hooks on native frames, pooled buttons, APIs, actions, or their geometry.
local _, A = ...
local font="Interface\\AddOns\\ForeverCestina\\Fonts\\ForeverSerif-Medium.ttf"
local states=setmetatable({},{__mode="k"})
local events=CreateFrame("Frame")
local refreshing=false
local elapsed=0
local function read(fn,...)
 if type(fn)~="function" then return end
 local ok,value=pcall(fn,...)
 if ok and A.Accessible(value) then return value end
end
local function safeObject(object)
 if not A.Accessible(object) or not object then return false end
 if object.IsForbidden and read(object.IsForbidden,object)~=false then return false end
 return true
end
local function shown(object)
 return safeObject(object) and read(object.IsShown,object)==true
end
local function enabled()
 return (not A.DB or A.DB.enabled~=false) and read(IsShiftKeyDown)~=true
end
local function apply(fs,en,cs,context,delta)
 if not safeObject(fs) or type(en)~="string" or not A.Accessible(en) then return end
 if not fs.GetText or not fs.SetText or not fs.GetFont then return end
 local text=read(fs.GetText,fs)
 if type(text)~="string" then return end
 local state=states[fs]
 -- Recycled rows may still contain another quest's text. Never put a stale
 -- translation into a row merely because its font object has been seen before.
 if A.Normalize(text)~=A.Normalize(en) and not (state and state.context==context and text==state.cs) then return end
 if not state then state={};states[fs]=state end
 state.en,state.context=en,context
 if not enabled() then cs=nil end
 if cs then
  state.base=state.base or A.CaptureFont(fs)
  local current=A.CaptureFont(fs)
  if not state.changed or current.path~=font or current.size~=state.base.size+delta then
   A.SetLocalizedFont(fs,state.base,font,delta)
   state.changed=true
  end
  if text~=cs then fs:SetText(cs) end
  state.cs=cs
 else
  if state.cs and text==state.cs then fs:SetText(en) end
  if state.changed and state.base then A.RestoreFont(fs,state.base) end
  state.changed,state.cs=nil,nil
 end
end
local function cleanup()
 if read(InCombatLockdown)==true then return end
 for fs,state in pairs(states) do
  A.SafeCall("Quest greeting restore",function()
   if not safeObject(fs) then return end
   local text=read(fs.GetText,fs)
   if type(text)=="string" and state.cs and text==state.cs then fs:SetText(state.en) end
   if state.changed and state.base then A.RestoreFont(fs,state.base) end
   states[fs]=nil
  end)
 end
end
local function capture(npc,text,cs)
 if cs or not A.DB or type(text)~="string" or #text<2 or #text>8000 then return end
 local samples=A.DB.gossipSamples
 if type(samples)~="table" then samples={};A.DB.gossipSamples=samples end
 for _,row in ipairs(samples) do
  if row.npc==npc and row.kind=="greeting" and row.en==text then return end
 end
 if #samples<200 then
  samples[#samples+1]={npc=npc,kind="greeting",en=text,route="QUEST_GREETING",
   build=A.DB.client and A.DB.client.build}
 end
end
local function row(button,npc)
 if not shown(button) or not button.GetFontString then return end
 local index=read(button.GetID,button)
 if type(index)~="number" or index<1 or index>100 then return end
 local active=button.isActive
 if not A.Accessible(active) then return end
 local en,id
 if active==1 or active==true then
  en=read(GetActiveTitle,index)
  id=read(GetActiveQuestID,index)
 elseif active==0 or active==false then
  en=read(GetAvailableTitle,index)
  if type(GetAvailableQuestInfo)=="function" then
   local ok,_,_,_,_,questID=pcall(GetAvailableQuestInfo,index)
   if ok and A.Accessible(questID) then id=questID end
  end
 else return end
 if not A.Accessible(en) or type(en)~="string" then return end
 local cs=A.TranslateQuestTitle and A.TranslateQuestTitle(id,en)
 -- Older clients expose the title but not the quest ID. Only the exact shared
 -- EN-to-CS title dictionary is eligible; no similarity or NPC-name fallback.
 if not cs and not id then cs=A.QuestTitleTranslations and A.QuestTitleTranslations[en] end
 local fs=read(button.GetFontString,button)
 A.SafeCall("Quest greeting title",apply,fs,en,cs,npc..":"..tostring(active)..":"..index,1)
end
local function refresh()
 if refreshing or read(InCombatLockdown)==true then return end
 local panel=_G.QuestFrameGreetingPanel
 if not shown(panel) then events:SetScript("OnUpdate",nil);cleanup();return end
 refreshing=true
 local ok,err=pcall(function()
  local npc=read(UnitName,"npc")
  if type(npc)~="string" or #npc>200 then return end
  local en=read(GetGreetingText)
  if type(en)=="string" and A.TranslateGossip then
   local cs=A.TranslateGossip(npc,en)
   capture(npc,en,cs)
   A.SafeCall("Quest greeting prose",apply,_G.GreetingText,en,cs,npc,1)
  end
  for _,item in ipairs({{"CurrentQuestsText","Current Quests"},{"AvailableQuestsText","Available Quests"}}) do
   local cs=A.TranslateUI and A.TranslateUI(item[2])
   A.SafeCall("Quest greeting header",apply,_G[item[1]],item[2],cs,item[1],0)
  end
  local pool=panel.titleButtonPool
  if safeObject(pool) and type(pool.EnumerateActive)=="function" then
   for button in pool:EnumerateActive() do A.SafeCall("Quest greeting row",row,button,npc) end
  else
   for i=1,25 do A.SafeCall("Quest greeting row",row,_G["QuestTitleButton"..i],npc) end
  end
 end)
 refreshing=false
 if not ok then A.NoteError("Quest greeting",err) end
end
local function tick(_,dt)
 elapsed=elapsed+dt
 if elapsed>=0.15 then elapsed=0;refresh() end
end
for _,event in ipairs({"QUEST_GREETING","QUEST_FINISHED","MODIFIER_STATE_CHANGED","PLAYER_REGEN_ENABLED"}) do events:RegisterEvent(event) end
events:SetScript("OnEvent",function(_,event)
 if event=="QUEST_FINISHED" then
  events:SetScript("OnUpdate",nil)
  cleanup()
 elseif event=="QUEST_GREETING" then
  -- Allow native event handlers to populate the panel first.
  elapsed=0;events:SetScript("OnUpdate",tick)
 else
  refresh()
 end
end)
