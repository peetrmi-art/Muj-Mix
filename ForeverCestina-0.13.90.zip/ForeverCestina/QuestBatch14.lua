local _, A = ...
-- Additive quest translations: 200 additional quest IDs selected only from the current Forever-specific quest dataset.
-- English source strings are kept verbatim; exact-match runtime leaves changed client variants in English rather than applying a stale translation.
local entries = {}

local function add(id, title, enDesc, csDesc, enObj, csObj)
    local e = { title = title }
    if enDesc and enDesc ~= "" then e.description = {enDesc, csDesc} end
    if enObj and enObj ~= "" then e.objectives = {enObj, csObj} end
    entries[id] = e
end

add(1269, [[Lieutenant Paval Reethe]],
[[A glint of light on the ground catches your eye from underneath the rubble. Brushing debris and ash caked onto the object reveals the insignia of a gold anchor on white, enameled on the surface: the sign of Theramore. Underneath the anchor is embossed the name "Lieutenant Paval Reethe".]],
[[Pod sutinami tě upoutá záblesk světla. Když z předmětu setřeš nános trosek a popela, objeví se na jeho povrchu znak zlaté kotvy na bílém podkladu – symbol Theramore. Pod kotvou je vyraženo jméno „Lieutenant Paval Reethe“.]],
[[Bring Reethe's Badge to Krog in Brackenwall Village.]],
[[Přines Reethe's Badge Krogovi do Brackenwall Village.]])

add(1276, [[The Black Shield]],
[[Ah, I remember now! Mosarn is a well-respected blacksmith in Thunder Bluff. I knew I had heard his name somewhere, before. In thanks, the Earthen Ring awarded me with a set of armor crafted by Mosarn. Very good work. Perhaps he can tell you more about the shield he crafted. It's not much of a lead, but since we didn't get anything useful out of Reethe, it's all we have.]],
[[Ach, už si vzpomínám! Mosarn je uznávaný kovář v Thunder Bluff. Věděl jsem, že jsem jeho jméno už někde slyšel. Earthen Ring mě kdysi odměnil sadou zbroje, kterou Mosarn vyrobil. Byla to výborná práce. Možná ti dokáže říct víc o štítu, který vykoval. Není to moc silná stopa, ale po tom, co jsme od Reetha nic užitečného nezískali, je to jediné, co máme.]],
[[Show the Blackened Iron Shield to Mosarn in Thunder Bluff.]],
[[Ukaž Blackened Iron Shield Mosarnovi v Thunder Bluff.]])

add(1285, [[Daelin's Men]],
[[Reddon... Redpath... Ah, here it is! Lieutenant Paval Reethe. Joined the Theramore guard along with most of the recruits that came across the sea with Lady Proudmoore. Enlisted with the marines of Kul Tiras at the age of sixteen. Distinguished service, promotions... Listed as missing.]],
[[Reddon... Redpath... Tady to je! Lieutenant Paval Reethe. Přidal se ke stráži Theramore spolu s většinou rekrutů, kteří připluli přes moře s Lady Proudmoore. Ve věku šestnácti let vstoupil k námořní pěchotě Kul Tiras. Vyznamenaná služba, povýšení... veden jako nezvěstný.]],
[[Return the information about Reethe to Captain Garran Vimes in Theramore.]],
[[Předej informace o Reethovi Captain Garran Vimesovi v Theramore.]])

add(1286, [[The Deserters]],
[[It has been a struggle maintaining a presence in the marsh, but through strength of our resolve, we have been able to maintain several defensive watchtowers throughout the area. The latest information and scouting reports I have received indicate that a group of deserters has squatted in our abandoned tower at Lost Point, southeast of the inn. The local lieutenant seems to be Balos Jacken. See if you can get some information out of him. Be warned, $n. He may be a tough nut to crack.]],
[[Udržet naši přítomnost v bažinách nebylo snadné, ale díky odhodlání se nám podařilo zachovat několik obranných strážních věží v celé oblasti. Nejnovější zprávy a hlášení zvědů naznačují, že skupina dezertérů obsadila naši opuštěnou věž v Lost Point jihovýchodně od hostince. Jejich místním velitelem je zřejmě Balos Jacken. Zkus z něj dostat nějaké informace. Dávej si pozor, $n. Nemusí být snadné ho přesvědčit.]],
[[Get information about Reethe from Balos Jacken and the deserters in Dustwallow Marsh.]],
[[Získej od Balos Jackena a dezertérů v Dustwallow Marsh informace o Reethovi.]])

add(1287, [[The Deserters]],
[[Reethe? That coward? We threw him out of camp because he insisted on raiding the supplies of the ogres up at Brackenwall Village. We're not so many in number that we could stand up to those mindless brutes. He crossed the line one too many times, so we left him to fend for himself. Now, I helped you out... So, why don't you help us out and forget you bumped into us?]],
[[Reethe? Ten zbabělec? Vyhodili jsme ho z tábora, protože pořád trval na přepadávání zásob ogrů u Brackenwall Village. Není nás tolik, abychom se mohli postavit těm tupým surovcům. Zašel příliš daleko, a tak jsme ho nechali, ať se o sebe postará sám. Teď jsem ti pomohl já... tak co kdybys pomohl nám a zapomněl, že jsi nás vůbec potkal?]],
[[Speak with Captain Garran Vimes in Theramore about Reethe.]],
[[Promluv si s Captain Garran Vimesem v Theramore o Reethovi.]])

add(1301, [[James Hyal]],
[[Before working here at the Blue Recluse, I was trained by one of the best chefs and innkeepers I'd ever met. His name was James Hyal. Everything I have and everywhere I've gotten in life is thanks to him. I wonder how he's doing. His brother Vincent and he went to work in a tavern in Menethil Harbor, but I haven't heard from him recently. If you ever happen to be headed in that direction, maybe you could say hello to him for me?]],
[[Než jsem začal pracovat tady v Blue Recluse, učil mě jeden z nejlepších kuchařů a hostinských, jaké jsem kdy poznal. Jmenoval se James Hyal. Za všechno, co mám a kam jsem se v životě dostal, vděčím jemu. Zajímalo by mě, jak se mu vede. Se svým bratrem Vincentem odešli pracovat do hospody v Menethil Harbor, ale už dlouho jsem o něm neslyšel. Kdybys měl cestu tím směrem, mohl bys ho ode mě pozdravit?]],
[[Speak with Vincent Hyal in Menethil Harbor.]],
[[Promluv si s Vincentem Hyalem v Menethil Harbor.]])

add(1302, [[James Hyal]],
[[My brother James went with Lady Proudmoore across the sea. Last I heard, the fighting had settled down over there, and James was setting up an inn somewhere on the continent. Wherever he is, I'm sure he's doing good business. Damn fine cook he was. I haven't heard from him for a while now--too busy with his inn, I'd wager--but the clerk in Theramore could probably point you to him. Look for him on the top floor of that keep near the middle of the city. What's it called... Foothold Citadel, that's it.]],
[[Můj bratr James odplul přes moře s Lady Proudmoore. Naposledy jsem slyšel, že tam boje utichly a James si někde na kontinentu zařizoval hostinec. Ať je kdekoliv, určitě se mu daří. Byl to zatraceně dobrý kuchař. Už nějakou dobu jsem o něm neslyšel – nejspíš má plné ruce práce s hostincem – ale úředník v Theramore by tě k němu mohl nasměrovat. Hledej ho v horním patře pevnosti uprostřed města. Jak se jen jmenuje... Foothold Citadel, přesně tak.]],
[[Speak with Clerk Lendry at Foothold Citadel in Theramore.]],
[[Promluv si s Clerk Lendrym ve Foothold Citadel v Theramore.]])

add(1318, [[Unfinished Gordok Business]],
[[Now you da king, so maybe you get prized Gordok artifact back from creepy elf who calls himself Prince! Da king before you failed, just like all da other kings since Tortheldrin - da creepy elf - stole it from old timey Gordok king! Artifact is called da Gauntlet of Gordok Might. Old timey stories say only da one true king da Gordok can get it back. Old timey story also say creepy elf is still around here - you find it and it will become mighty gauntlet you wear forever! Yar, I show you!]],
[[Teď ty král, tak možná dostaneš vzácný artefakt Gordoků zpátky od děsivého elfa, co si říká Prince! Král před tebou selhal, stejně jako všichni králové od doby, kdy Tortheldrin – ten děsivý elf – ukradl artefakt dávnému králi Gordoků! Artefakt se jmenuje Gauntlet of Gordok Might. Staré příběhy říkají, že ho může získat zpět jen jediný pravý král Gordoků. A také říkají, že ten děsivý elf je pořád někde tady. Najdi rukavici a bude z ní mocná zbraň, kterou budeš nosit navždy! Jo, já ti ukážu!]],
[[Find the Gauntlet of Gordok Might and return it to Captain Kromcrush in Dire Maul. According to Kromcrush, the "old timey story" says that Tortheldrin - a "creepy" elf who called himself a prince - stole it from one of the Gordok kings.]],
[[Najdi Gauntlet of Gordok Might a vrať ji Captain Kromcrushovi v Dire Maul. Podle Kromcrushe ji kdysi jednomu z králů Gordoků ukradl Tortheldrin, „děsivý“ elf, který si říkal princ.]])

add(1360, [[Reclaimed Treasures]],
[[I had myself a fine job as a digger at the Uldaman excavation site in the Badlands... that is until those blasted troggs showed up. I escaped with my hide barely intact, and nothing else. In the chaos, I left my most treasured possession. It's safe from the troggs in my chest, sure, but it's right in the thick of 'em. I'd be in your debt, both in honor and coin, if you could fetch it for me! A chest with my name on it is at the end of the North Common Hall. That's the one you need to get in.]],
[[Měl jsem skvělou práci jako kopáč na vykopávkách Uldamanu v Badlands... dokud se neobjevili ti zatracení troggové. Sotva jsem vyvázl se zdravou kůží a nezbylo mi nic. V tom zmatku jsem tam nechal svůj nejcennější majetek. Před troggy je sice bezpečně uložený v mé truhle, jenže ta stojí přímo mezi nimi. Kdybys mi ho přinesl, byl bych ti zavázán ctí i penězi! Truhla s mým jménem je na konci North Common Hall. Právě do ní se musíš dostat.]],
[[Get Krom Stoutarm's treasured possession from his chest in the North Common Hall of Uldaman, and bring it to him in Ironforge.]],
[[Vezmi cenný majetek Krom Stoutarma z jeho truhly v North Common Hall v Uldamanu a přines mu ho do Ironforge.]])

add(1362, [[The Kolkar of Desolace]],
[[The Kolkar centaur live in Desolace, and their forces have spread into the Barrens. This is a known fact and we have Horde agents dealing with them here. But as long as the centaur are strong in Desolace, they will always pose a threat. It is time we rid ourselves of that threat. Speak with Felgur Twocuts at Ghost Walker Post in Desolace. He was sent to gather intelligence on the centaur. He will know how to best deal with the Kolkar of Desolace.]],
[[Kentauři Kolkar žijí v Desolace a jejich síly se rozšířily až do Barrens. To dobře víme a zdejší agenti Hordy se s nimi vypořádávají. Dokud ale budou kentauři v Desolace silní, budou vždy představovat hrozbu. Je čas se jí zbavit. Promluv si s Felgur Twocutsem na Ghost Walker Post v Desolace. Byl vyslán, aby o kentaurech získal informace, a bude vědět, jak nejlépe naložit s Kolkary z Desolace.]],
[[Speak with Felgur Twocuts at Ghost Walker Post in Desolace.]],
[[Promluv si s Felgur Twocutsem na Ghost Walker Post v Desolace.]])

add(1363, [[Mazen's Behest]],
[[As caretaker of the works here in the library of the Academy of Arcane Arts and Sciences, it is my responsibility to ensure all the magical tomes and scrolls are accounted for at all times. Who knows what folly would unfold if some of these enchanted texts were to fall into the wrong hands? Which reminds me... my assistant, Dellis, made a horrible mistake last week. He's quite able in the library but incompetent when he leaves the gates of Stormwind. Be a hero, and help old Dellis out, would you?]],
[[Jako správce zdejších děl v knihovně Academy of Arcane Arts and Sciences mám povinnost zajistit, aby byly všechny magické svazky a svitky vždy řádně evidované. Kdo ví, jaká pohroma by nastala, kdyby se některé z těchto očarovaných textů dostaly do nesprávných rukou? Když už o tom mluvím... můj pomocník Dellis minulý týden udělal strašnou chybu. V knihovně je schopný, ale jakmile opustí brány Stormwindu, je naprosto neschopný. Buď hrdina a pomoz starému Dellisovi, ano?]],
[[Speak with Acolyte Dellis in Stormwind.]],
[[Promluv si s Acolyte Dellisem ve Stormwindu.]])

add(1364, [[Mazen's Behest]],
[[Master Mazen's directions were quite clear: Deliver a very important essay to Watcher Mahar Ba in Nethergarde Keep. But I had never been to the Blasted Lands before! The journey was frightening! When I got to the Swamp of Sorrows, I made a wrong turn and ended up surrounded by horrible plant-like swamp creatures. They lurched as if to attack me so I ran. But in my haste I dropped the essay. One of the beasts took it I am sure. Could you please try to retrieve it and deliver it to Mahar Ba?]],
[[Master Mazen mi dal naprosto jasné pokyny: doručit velmi důležitou esej Watcher Mahar Baovi v Nethergarde Keep. Jenže v Blasted Lands jsem nikdy předtím nebyl! Ta cesta byla děsivá! Ve Swamp of Sorrows jsem špatně odbočil a obklopily mě strašlivé rostlinám podobné bažinné nestvůry. Vrhaly se na mě, jako by chtěly zaútočit, a tak jsem utekl. Ve spěchu jsem ale esej upustil a jsem si jistý, že ji jedna z těch bestií vzala. Mohl bys ji prosím získat zpět a doručit Mahar Baovi?]],
[[Retrieve Khadgar's Essays on Dimensional Convergence and deliver them to Watcher Mahar Ba in Nethergarde Keep.]],
[[Získej Khadgar's Essays on Dimensional Convergence a doruč je Watcher Mahar Baovi v Nethergarde Keep.]])

add(1365, [[Khan Dez'hepah]],
[[The Kolkar are not the only centaur of Desolace. Many clans wander these dry plains, fighting and dying against each other. And it is good that they fight among themselves, for they are strong and brutal. If the centaur united against us, they would be a fierce foe. We must deal with them before they unite. Your first task is to disrupt the Kolkar clan. Do this by killing its leader, Khan Dez'hepah. The Kolkar Village is northeast of here. Go, and may fortune go with you.]],
[[Kolkarové nejsou jediní kentauři v Desolace. Po těchto vyprahlých pláních se potuluje mnoho klanů, které mezi sebou bojují a umírají. Je dobře, že bojují mezi sebou, protože jsou silní a brutální. Kdyby se kentauři spojili proti nám, byli by hrozivým nepřítelem. Musíme je oslabit dřív, než se sjednotí. Tvým prvním úkolem je narušit klan Kolkar. Zabij jeho vůdce, Khan Dez'hepaha. Kolkar Village leží severovýchodně odsud. Vydej se tam a ať tě provází štěstí.]],
[[Bring Khan Dez'hepah's Head to Felgur Twocuts in Desolace.]],
[[Přines Khan Dez'hepah's Head Felgur Twocutsovi v Desolace.]])

add(1366, [[Centaur Bounty]],
[[Now that you scared the centaur clans, it's time to bleed them. When traveling Desolace, hunt centaur. I don't care which clan you hunt. Just gather ears. A hoard of ears. By weakening their numbers you will weaken their resolve, and stamp out any thoughts of expansion. Good hunting, $n.]],
[[Teď, když jsi klany kentaurů vyděsil, je čas je nechat krvácet. Při cestách po Desolace lov kentaury. Je mi jedno, který klan si vybereš. Prostě sbírej uši. Hromadu uší. Když snížíš jejich počty, oslabíš i jejich odhodlání a zarazíš všechny myšlenky na další rozšiřování. Dobrý lov, $n.]],
[[Bring 15 Centaur Ears to Felgur Twocuts in Desolace.]],
[[Přines Felgur Twocutsovi v Desolace 15 Centaur Ears.]])

add(1367, [[Magram Alliance]],
[[To beat the centaur, we must use their hatred against them. We will ally with one of the clans and through them, we will learn how to defeat all the clans. If you choose to ally with the Magram then slay their foes, the Gelkis. This will earn you respect among the Magram. When you earn enough, then meet with the Magram spokesman Warug, on the outskirts of the Magram Village, in southeast Desolace.]],
[[Abychom kentaury porazili, musíme proti nim využít jejich vlastní nenávist. Spojíme se s jedním z klanů a díky němu zjistíme, jak porazit všechny ostatní. Pokud se rozhodneš spojit s Magram, zabíjej jejich nepřátele, Gelkis. Tím si mezi Magram získáš respekt. Až ho budeš mít dost, setkej se s jejich mluvčím Warugem na okraji Magram Village v jihovýchodní části Desolace.]],
[[Gain a Friendly reputation with the Magram, then speak with Warug.]],
[[Získej u Magram reputaci Friendly a potom promluv s Warugem.]])

add(1368, [[Gelkis Alliance]],
[[To beat the centaur, we must use their hatred against them. We will ally with one of the clans and through them, we will learn how to defeat all the clans. If you choose to ally with the Gelkis then slay their most hated rival, the Magram. After you earn the respect of the Gelkis, meet with the Gelkis shaman Uthek the Wise, on the outskirts of the Gelkis Village, in southwest Desolace.]],
[[Abychom kentaury porazili, musíme proti nim využít jejich vlastní nenávist. Spojíme se s jedním z klanů a díky němu zjistíme, jak porazit všechny ostatní. Pokud se rozhodneš spojit s Gelkis, zabíjej jejich nejnenáviděnější soupeře, Magram. Až si získáš respekt Gelkis, setkej se s jejich šamanem Uthekem the Wise na okraji Gelkis Village v jihozápadní části Desolace.]],
[[Gain a Friendly reputation with the Gelkis, then speak with Uthek the Wise.]],
[[Získej u Gelkis reputaci Friendly a potom promluv s Uthekem the Wise.]])

add(1369, [[Broken Tears]],
[[The Gelkis think our centaur mother, Theradras, protects us. They are stupid. No one protects the centaur. The Magram do not need protection! We are the strongest! Show the Gelkis they are stupid. Go to the cave in their village. They hoard crystals in that cave, the tears of Theradras. Destroy the tears and bring me the broken pieces!]],
[[Gelkis si myslí, že nás chrání naše kentauří matka Theradras. Jsou hloupí. Kentaury nikdo nechrání. Magram žádnou ochranu nepotřebují! Jsme nejsilnější! Ukaž Gelkis, jak jsou hloupí. Jdi do jeskyně v jejich vesnici. Hromadí tam krystaly, slzy Theradras. Slzy znič a přines mi jejich rozbité kusy!]],
[[Maintain your reputation with the Magram, and bring 3 Broken Tears to Warug in the Magram Village.]],
[[Udrž si reputaci u Magram a přines Warugovi v Magram Village 3 Broken Tears.]])

add(1370, [[Stealing Supplies]],
[[When we are not at war, we hunt for meat. Meat gives us strength, and full bellies fight harder than empty ones. It is the same with the Magram. They store extra meat so they may fight longer between hunts. If you raid their village to the east and take their stores of meat, then their strength will fail.]],
[[Když neválčíme, lovíme maso. Maso nám dává sílu a s plným žaludkem se bojuje lépe než s prázdným. U Magram je to stejné. Skladují si zásoby masa, aby mohli mezi lovy bojovat déle. Když přepadneš jejich vesnici na východě a odneseš jim zásoby masa, jejich síla ochabne.]],
[[Bring 6 bags of Crudely Dried Meat to Uthek the Wise in the Gelkis Village.]],
[[Přines Uthekovi the Wise v Gelkis Village 6 pytlů Crudely Dried Meat.]])

add(3481, [[Trinkets...]],
[[The chest appears locked.]],
[[Truhla vypadá, že je zamčená.]],
[[Open the chest.]],
[[Otevři truhlu.]])

add(1952, [[Mage's Wand]],
[[I'll go make the wands now.]],
[[Teď půjdu ty hůlky vyrobit.]],
[[Speak with Tabetha after her ritual.]],
[[Promluv si s Tabetou po dokončení jejího rituálu.]])

add(1704, [[Klockmort Spannerspan]],
[[I made a copy of my notes on the techniques I learned while making your armor, and need someone to take them to Klockmort Spannerspan.  He's a gnomish blacksmith in Ironforge and when he learns what I've learned... I bet he'll pull off his own beard in excitement.]],
[[Pořídil jsem kopii svých poznámek o postupech, které jsem se naučil při výrobě tvé zbroje, a potřebuji, aby je někdo odnesl Klockmortovi Spannerspanovi. Je to gnómský kovář v Ironforge a až zjistí, co jsem se naučil... vsadím se, že si nadšením vytrhne vlastní vousy.]],
[[Bring Furen's Notes to Klockmort Spannerspan.]],
[[Dones Furenovy poznámky Klockmortovi Spannerspanovi.]])

add(9234, [[Icebane Gauntlets]],
[[Thanks to you and Omarion, may he rest in peace, I am now able to create Icebane gauntlets. All you need to do is bring me the materials and pay a small crafting fee.]],
[[Díky tobě a Omarionovi, nechť odpočívá v pokoji, nyní dokážu vyrobit rukavice Icebane. Stačí mi přinést potřebné materiály a zaplatit malý poplatek za výrobu.]],
[[Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 5 Frozen Runes, 12 Thorium Bars, 2 Arcanite Bars, 2 Essences of Water and 200 gold.]],
[[Řemeslník Wilhelm v Light's Hope Chapel v Eastern Plaguelands chce 5 Frozen Runes, 12 Thorium Bars, 2 Arcanite Bars, 2 Essences of Water a 200 zlatých.]])

add(9242, [[Polar Gloves]],
[[Thanks to you and Omarion (May he rest in peace), I am now able to create Polar gloves. All you need to do is bring me the materials and pay a small crafting fee.]],
[[Díky tobě a Omarionovi (nechť odpočívá v pokoji) nyní dokážu vyrobit polární rukavice. Stačí mi přinést potřebné materiály a zaplatit malý poplatek za výrobu.]],
[[Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 5 Frozen Runes, 12 Enchanted Leather, 3 Essence of Water, 3 Cured Rugged Hides and 200 gold.]],
[[Řemeslník Wilhelm v Light's Hope Chapel v Eastern Plaguelands chce 5 Frozen Runes, 12 Enchanted Leather, 3 Essence of Water, 3 Cured Rugged Hides a 200 zlatých.]])

add(9295, [[Letter from the Front]],
[[You found this letter on one of the many Scourge minions you've slain. From its appearance and smell, it has been with the undead for some time. Perhaps someone at Light's Hope Chapel would be interested in examining it further...]],
[[Tento dopis jsi našel u jednoho z mnoha přisluhovačů Scourge, které jsi zabil. Podle vzhledu a zápachu ho nemrtví nosili už nějakou dobu. Možná by někoho v Light's Hope Chapel zajímalo prozkoumat ho podrobněji...]],
[[Take the Torn Letter to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.]],
[[Dones Torn Letter Keeperovi of the Rolls v Light's Hope Chapel v Eastern Plaguelands.]])

add(9300, [[Page from the Front]],
[[You found this letter on one of the many Scourge minions you've slain. From its appearance and smell, it has been with the undead for some time. Perhaps someone at Light's Hope Chapel would be interested in examining it further...]],
[[Tento dopis jsi našel u jednoho z mnoha přisluhovačů Scourge, které jsi zabil. Podle vzhledu a zápachu ho nemrtví nosili už nějakou dobu. Možná by někoho v Light's Hope Chapel zajímalo prozkoumat ho podrobněji...]],
[[Take the Ragged Page to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.]],
[[Dones Ragged Page Keeperovi of the Rolls v Light's Hope Chapel v Eastern Plaguelands.]])

add(9299, [[Note from the Front]],
[[You found this letter on one of the many Scourge minions you've slain. From its appearance and smell, it has been with the undead for some time. Perhaps someone at Light's Hope Chapel would be interested in examining it further...]],
[[Tento dopis jsi našel u jednoho z mnoha přisluhovačů Scourge, které jsi zabil. Podle vzhledu a zápachu ho nemrtví nosili už nějakou dobu. Možná by někoho v Light's Hope Chapel zajímalo prozkoumat ho podrobněji...]],
[[Take the Careworn Note to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.]],
[[Dones Careworn Note Keeperovi of the Rolls v Light's Hope Chapel v Eastern Plaguelands.]])

add(9238, [[Glacial Wrists]],
[[Thanks to you and Omarion, may he rest in peace, I am now able to create Glacial wrists. All you need to do is bring me the materials and pay a small crafting fee.]],
[[Díky tobě a Omarionovi, nechť odpočívá v pokoji, nyní dokážu vyrobit ledovcové nátepníky. Stačí mi přinést potřebné materiály a zaplatit malý poplatek za výrobu.]],
[[Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 4 Frozen Runes, 2 Bolts of Runecloth, 2 Essences of Water, 2 Ironweb Spider Silks and 200 gold.]],
[[Řemeslník Wilhelm v Light's Hope Chapel v Eastern Plaguelands chce 4 Frozen Runes, 2 Bolts of Runecloth, 2 Essences of Water, 2 Ironweb Spider Silks a 200 zlatých.]])

add(9239, [[Glacial Gloves]],
[[Thanks to you and Omarion, may he rest in peace, I am now able to create Glacial gloves. All you need to do is bring me the materials and pay a small crafting fee.]],
[[Díky tobě a Omarionovi, nechť odpočívá v pokoji, nyní dokážu vyrobit ledovcové rukavice. Stačí mi přinést potřebné materiály a zaplatit malý poplatek za výrobu.]],
[[Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 5 Frozen Runes, 4 Bolts of Runecloth, 4 Essences of Water, 2 Ironweb Spider Silks and 200 gold.]],
[[Řemeslník Wilhelm v Light's Hope Chapel v Eastern Plaguelands chce 5 Frozen Runes, 4 Bolts of Runecloth, 4 Essences of Water, 2 Ironweb Spider Silks a 200 zlatých.]])

add(8934, [[Just Compensation]],
[[You kept your word and brought the device built by Mux.  I believe a reward is in order if I'm to keep you interested in saving my skin.  Bring me the belt and set of gloves that you wish to upgrade.  I promise the ones I give you in return will be far superior.]],
[[Dodržel jsi slovo a přinesl zařízení, které vyrobil Mux. Myslím, že si zasloužíš odměnu, pokud tě mám udržet ochotného zachraňovat mi kůži. Přines mi opasek a rukavice, které chceš vylepšit. Slibuji, že ty, které dostaneš zpět, budou mnohem lepší.]],
[[Bring a Devout Belt and a set of Devout Gloves to Deliana in Ironforge.]],
[[Dones Devout Belt a Devout Gloves Delianě v Ironforge.]])

add(9302, [[Missive from the Front]],
[[You found this letter on one of the many Scourge minions you've slain. From its appearance and smell, it has been with the undead for some time. Perhaps someone at Light's Hope Chapel would be interested in examining it further...]],
[[Tento dopis jsi našel u jednoho z mnoha přisluhovačů Scourge, které jsi zabil. Podle vzhledu a zápachu ho nemrtví nosili už nějakou dobu. Možná by někoho v Light's Hope Chapel zajímalo prozkoumat ho podrobněji...]],
[[Take the Crumpled Missive to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.]],
[[Dones Crumpled Missive Keeperovi of the Rolls v Light's Hope Chapel v Eastern Plaguelands.]])

add(9304, [[Document from the Front]],
[[You found this letter on one of the many Scourge minions you've slain. From its appearance and smell, it has been with the undead for some time. Perhaps someone at Light's Hope Chapel would be interested in examining it further...]],
[[Tento dopis jsi našel u jednoho z mnoha přisluhovačů Scourge, které jsi zabil. Podle vzhledu a zápachu ho nemrtví nosili už nějakou dobu. Možná by někoho v Light's Hope Chapel zajímalo prozkoumat ho podrobněji...]],
[[Take the Smudged Document to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.]],
[[Dones Smudged Document Keeperovi of the Rolls v Light's Hope Chapel v Eastern Plaguelands.]])

add(1386, [[Assault on the Kolkar]],
[[The Kolkar think they are strong, but we laugh at them!  We laugh and we kill them!  You kill them too.  Show me you can kill Kolkar like we do. Head north and slay them all!]],
[[Kolkarové si myslí, že jsou silní, ale my se jim smějeme! Smějeme se a zabíjíme je! Zabíjej je také. Ukaž mi, že umíš zabíjet Kolkary jako my. Vydej se na sever a pobij je všechny!]],
[[Maintain your reputation with the Magram. Kill 12 Kolkar Centaurs, 12 Kolkar Scouts and 6 Kolkar Maulers, then return to Warug in the Magram Village in Desolace.]],
[[Udrž si přízeň Magramů. Zabij 12 Kolkar Centaurs, 12 Kolkar Scouts a 6 Kolkar Maulers a potom se vrať k Warugovi v Magram Village v Desolace.]])

add(8926, [[Just Compensation]],
[[You kept your word and brought the device built by Mux.  I believe a reward is in order if I'm to keep you interested in saving my skin.  Bring me the belt and set of gloves that you wish to upgrade.  I promise the ones I give you in return will be far superior.]],
[[Dodržel jsi slovo a přinesl zařízení, které vyrobil Mux. Myslím, že si zasloužíš odměnu, pokud tě mám udržet ochotného zachraňovat mi kůži. Přines mi opasek a rukavice, které chceš vylepšit. Slibuji, že ty, které dostaneš zpět, budou mnohem lepší.]],
[[Bring a Wildheart Belt and a set of Wildheart Gloves Deliana in Ironforge.]],
[[Dones Wildheart Belt a Wildheart Gloves Delianě v Ironforge.]])

add(9244, [[Icy Scale Bracers]],
[[Thanks to you and Omarion, may he rest in peace, I am now able to create Icy Scale bracers. All you need to do is bring me the materials and pay a small crafting fee.]],
[[Díky tobě a Omarionovi, nechť odpočívá v pokoji, nyní dokážu vyrobit nátepníky z ledových šupin. Stačí mi přinést potřebné materiály a zaplatit malý poplatek za výrobu.]],
[[Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 4 Frozen Runes, 16 Heavy Scorpid Scales, 5 Essences of Water, 3 Cured Rugged Hides and 200 gold.]],
[[Řemeslník Wilhelm v Light's Hope Chapel v Eastern Plaguelands chce 4 Frozen Runes, 16 Heavy Scorpid Scales, 5 Essences of Water, 3 Cured Rugged Hides a 200 zlatých.]])

add(9245, [[Icy Scale Gauntlets]],
[[Thanks to you and Omarion (May he rest in peace), I am now able to create Icy Scale gauntlets. All you need to do is bring me the materials and pay a small crafting fee.]],
[[Díky tobě a Omarionovi (nechť odpočívá v pokoji) nyní dokážu vyrobit rukavice z ledových šupin. Stačí mi přinést potřebné materiály a zaplatit malý poplatek za výrobu.]],
[[Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 5 Frozen Runes, 16 Heavy Scorpid Scale, 5 Essence of Water, 3 Cured Rugged Hides and 200 gold.]],
[[Řemeslník Wilhelm v Light's Hope Chapel v Eastern Plaguelands chce 5 Frozen Runes, 16 Heavy Scorpid Scale, 5 Essence of Water, 3 Cured Rugged Hides a 200 zlatých.]])

add(8936, [[Just Compensation]],
[[You kept your word and brought the device built by Mux.  I believe a reward is in order if I'm to keep you interested in saving my skin.  Bring me the belt and set of gloves that you wish to upgrade.  I promise the ones I give you in return will be far superior.]],
[[Dodržel jsi slovo a přinesl zařízení, které vyrobil Mux. Myslím, že si zasloužíš odměnu, pokud tě mám udržet ochotného zachraňovat mi kůži. Přines mi opasek a rukavice, které chceš vylepšit. Slibuji, že ty, které dostaneš zpět, budou mnohem lepší.]],
[[Bring a Dreadmist Belt and a set of Dreadmist Wraps to Deliana in Ironforge.]],
[[Dones Dreadmist Belt a Dreadmist Wraps Delianě v Ironforge.]])

add(9301, [[Envelope from the Front]],
[[You found this letter on one of the many Scourge minions you've slain. From its appearance and smell, it has been with the undead for some time. Perhaps someone at Light's Hope Chapel would be interested in examining it further...]],
[[Tento dopis jsi našel u jednoho z mnoha přisluhovačů Scourge, které jsi zabil. Podle vzhledu a zápachu ho nemrtví nosili už nějakou dobu. Možná by někoho v Light's Hope Chapel zajímalo prozkoumat ho podrobněji...]],
[[Take the Bloodstained Envelope to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.]],
[[Dones Bloodstained Envelope Keeperovi of the Rolls v Light's Hope Chapel v Eastern Plaguelands.]])

add(8935, [[Just Compensation]],
[[You kept your word and brought the device built by Mux.  I believe a reward is in order if I'm to keep you interested in saving my skin.  Bring me the belt and set of gloves that you wish to upgrade.  I promise the ones I give you in return will be far superior.]],
[[Dodržel jsi slovo a přinesl zařízení, které vyrobil Mux. Myslím, že si zasloužíš odměnu, pokud tě mám udržet ochotného zachraňovat mi kůži. Přines mi opasek a rukavice, které chceš vylepšit. Slibuji, že ty, které dostaneš zpět, budou mnohem lepší.]],
[[Bring a Shadowcraft Belt and a set of Shadowcraft Gloves to Deliana in Ironforge.]],
[[Dones Shadowcraft Belt a Shadowcraft Gloves Delianě v Ironforge.]])

add(8937, [[Just Compensation]],
[[You kept your word and brought the device built by Mux.  I believe a reward is in order if I'm to keep you interested in saving my skin.  Bring me the belt and set of gauntlets that you wish to upgrade.  I promise the ones I give you in return will be far superior.]],
[[Dodržel jsi slovo a přinesl zařízení, které vyrobil Mux. Myslím, že si zasloužíš odměnu, pokud tě mám udržet ochotného zachraňovat mi kůži. Přines mi opasek a rukavice, které chceš vylepšit. Slibuji, že ty, které dostaneš zpět, budou mnohem lepší.]],
[[Bring a Belt of Valor and a set of Gauntlets of Valor to Deliana in Ironforge.]],
[[Dones Belt of Valor a Gauntlets of Valor Delianě v Ironforge.]])

add(8782, [[Uniform Supplies]],
[[The latest influx of volunteers has caused a shortage of uniforms.  Procure a batch of uniform materials and bring them to Windcaller Proudhorn.]],
[[Poslední příliv dobrovolníků způsobil nedostatek uniforem. Obstarej zásobu materiálu na uniformy a dones ji Windcallerovi Proudhornovi.]],
[[Bring 1 Mooncloth, 2 Bolts of Runecloth and 1 Ironweb Spider Silk to Windcaller Proudhorn at Cenarion Hold in Silithus.  You must also bring Logistics Task Briefing VIII in order to complete this quest.]],
[[Dones 1 Mooncloth, 2 Bolts of Runecloth a 1 Ironweb Spider Silk Windcallerovi Proudhornovi v Cenarion Hold v Silithus. K dokončení tohoto úkolu musíš přinést také Logistics Task Briefing VIII.]])

add(8808, [[Uniform Supplies]],
[[The latest influx of volunteers has caused a shortage of uniforms.  Procure a batch of uniform materials and bring them to Windcaller Proudhorn.]],
[[Poslední příliv dobrovolníků způsobil nedostatek uniforem. Obstarej zásobu materiálu na uniformy a dones ji Windcallerovi Proudhornovi.]],
[[Bring 1 Mooncloth, 2 Bolts of Runecloth and 1 Ironweb Spider Silk to Windcaller Proudhorn at Cenarion Hold in Silithus.  You must also bring Logistics Task Briefing VIII in order to complete this quest.]],
[[Dones 1 Mooncloth, 2 Bolts of Runecloth a 1 Ironweb Spider Silk Windcallerovi Proudhornovi v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Logistics Task Briefing VIII.]])

add(8540, [[Boots for the Guard]],
[[The mounted division of the Cenarion Hold guard is in short supply of ornate mithril boots.  Procure a batch and deliver them immediately to Captain Vish Kozus in Cenarion Hold.]],
[[Jezdeckému oddílu stráže Cenarion Hold docházejí zdobené mithrilové boty. Obstarej další a okamžitě je dones kapitánu Vish Kozusovi v Cenarion Hold.]],
[[Bring 3 Ornate Mithril Boots to Vish Kozus, Captain of the Guard at Cenarion Hold in Silithus.  You must also bring Logistics Task Briefing II in order to complete this quest.]],
[[Dones 3 Ornate Mithril Boots Vish Kozusovi, kapitánovi stráže v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Logistics Task Briefing II.]])

add(8805, [[Boots for the Guard]],
[[The mounted division of the Cenarion Hold guard is in short supply of ornate mithril boots.  Procure a batch and deliver them immediately to Captain Vish Kozus in Cenarion Hold.]],
[[Jezdeckému oddílu stráže Cenarion Hold docházejí zdobené mithrilové boty. Obstarej další a okamžitě je dones kapitánu Vish Kozusovi v Cenarion Hold.]],
[[Bring 3 Ornate Mithril Boots to Vish Kozus, Captain of the Guard at Cenarion Hold in Silithus.  You must also bring Logistics Task Briefing II in order to complete this quest.]],
[[Dones 3 Ornate Mithril Boots Vish Kozusovi, kapitánovi stráže v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Logistics Task Briefing II.]])

add(7704, [[Look at the Size of It!]],
[[Well, well, well... Isn't this a surprise. The Chambermaid had a gigantic ornate pillow and now it's yours. Evonice Sootsmoker will definitely want to get her grubby little hands all over this item. Take it to her and see if she'll offer you any goodies for your trouble.]],
[[No podívejme... To je překvapení. Komorná měla obrovský zdobený polštář a teď je tvůj. Evonice Sootsmoker na něj určitě bude chtít položit své špinavé pracky. Dones jí ho a uvidíš, jestli ti za námahu nabídne něco zajímavého.]],
[[Take Chambermaid Pillaclencher's Pillow to Evonice Sootsmoker in the Searing Gorge.]],
[[Dones polštář Chambermaid Pillaclencher Evonice Sootsmoker v Searing Gorge.]])

add(8773, [[Target: Hive'Zora Reavers]],
[[Reinforcements have been called on to join the assault on Hive'Zora.  You have been selected to target Hive'Zora reavers.  Report back to Commander Mar'alith after completing your task.]],
[[K útoku na Hive'Zora byly povolány posily. Byl jsi vybrán, abys zaútočil na Hive'Zora Reavers. Po splnění úkolu se vrať ke Commanderovi Mar'alithovi.]],
[[Slay 30 Hive'Zora Reavers and report back to Commander Mar'alith at Cenarion Hold in Silithus.  You must also bring Combat Task Briefing IV in order to complete this quest.]],
[[Zabij 30 Hive'Zora Reavers a vrať se ke Commanderovi Mar'alithovi v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Combat Task Briefing IV.]])

add(8539, [[Target: Hive'Zora Hive Sisters]],
[[Reinforcements have been called on to join the assault on Hive'Zora.  You have been selected to target Hive'Zora hive sisters.  Report back to Commander Mar'alith after completing your task.]],
[[K útoku na Hive'Zora byly povolány posily. Byl jsi vybrán, abys zaútočil na Hive'Zora Hive Sisters. Po splnění úkolu se vrať ke Commanderovi Mar'alithovi.]],
[[Slay 30 Hive'Zora Hive Sisters and report back to Commander Mar'alith at Cenarion Hold in Silithus.  You must also bring Combat Task Briefing V in order to complete this quest.]],
[[Zabij 30 Hive'Zora Hive Sisters a vrať se ke Commanderovi Mar'alithovi v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Combat Task Briefing V.]])

add(4964, [[The Completed Orb of Dar'Orahil]],
[[I will get started immediately on crafting your orb and infusing your new demon into it. When done, you will have the choice of having it in the form of a staff or orb. I always felt it was important to cater to a warlock's chosen weapon... I see no reason not to continue that practice.]],
[[Hned se pustím do výroby tvé koule a spoutání tvého nového démona s ní. Až bude hotová, budeš si moci vybrat podobu hole nebo koule. Vždycky jsem považoval za důležité respektovat, jakou zbraň si warlock zvolí... nevidím důvod s tím přestávat.]],
[[Wait for Menara Voidrender to complete the Orb of Dar'Orahil and then speak to her again.]],
[[Počkej, až Menara Voidrender dokončí Orb of Dar'Orahil, a potom s ní znovu promluv.]])

add(4975, [[The Completed Orb of Noh'Orahil]],
[[I will get started immediately on crafting your orb and infusing your new demon into it. When done, you will have the choice of having it in the form of a staff or orb. I always felt it was important to cater to a warlock's chosen weapon... I see no reason not to continue that practice.]],
[[Hned se pustím do výroby tvé koule a spoutání tvého nového démona s ní. Až bude hotová, budeš si moci vybrat podobu hole nebo koule. Vždycky jsem považoval za důležité respektovat, jakou zbraň si warlock zvolí... nevidím důvod s tím přestávat.]],
[[Wait for Menara Voidrender to complete the Orb of Noh'Orahil and then speak to her again.]],
[[Počkej, až Menara Voidrender dokončí Orb of Noh'Orahil, a potom s ní znovu promluv.]])

add(8778, [[The Ironforge Brigade Needs Explosives!]],
[[The Ironforge Brigade has put in an unusual request for highly... volatile... components.  Gather them and bring them to Mr. Nozzlespring from the Ironforge Brigade.]],
[[Ironforge Brigade vznesla neobvyklou žádost o velmi... výbušné... součásti. Sežeň je a dones panu Nozzlespringovi z Ironforge Brigade.]],
[[Bring 6 Oils of Immolation, 5 Goblin Rocket Fuel and 10 Dense Blasting Powder to Arcanist Nozzlespring near Hive'Zora in Silithus.  You must also bring Logistics Task Briefing IV in order to complete this quest.]],
[[Dones 6 Oils of Immolation, 5 Goblin Rocket Fuel a 10 Dense Blasting Powder Arcanistovi Nozzlespringovi poblíž Hive'Zora v Silithus. K dokončení úkolu musíš přinést také Logistics Task Briefing IV.]])

add(1440, [[Return to Vahlarriel]],
[[So, the time is now then? I appreciate your efforts, and if the situation does not lend itself, then allow me to thank you now for everything you've done for me and my family. If you're ready, then there is nothing else for me here--we can leave when you feel the time is right.]],
[[Takže ten čas přišel? Vážím si tvého úsilí, a kdyby už nebyla další příležitost, dovol mi poděkovat ti za všechno, co jsi udělal pro mě a mou rodinu. Jestli jsi připraven, nic dalšího mě tu nedrží -- můžeme odejít, až uznáš, že nastal správný čas.]],
[[Escort Dalinda Malem from Thunder Axe Fortress and then return to Vahlarriel Demonslayer in Desolace.]],
[[Doprovoď Dalindu Malem z Thunder Axe Fortress a potom se vrať k Vahlarriel Demonslayer v Desolace.]])

add(8541, [[Grinding Stones for the Guard]],
[[The Cenarion Hold guard is in short supply of grinding stones.  Procure a batch and deliver them immediately to Captain Vish Kozus in Cenarion Hold.]],
[[Stráži v Cenarion Hold docházejí brusné kameny. Obstarej další a okamžitě je dones kapitánu Vish Kozusovi v Cenarion Hold.]],
[[Bring 10 Dense Grinding Stones, 10 Solid Grinding Stones and 10 Heavy Grinding Stones to Vish Kozus, Captain of the Guard at Cenarion Hold in Silithus.  You must also bring Logistics Task Briefing III in order to complete this quest.]],
[[Dones 10 Dense Grinding Stones, 10 Solid Grinding Stones a 10 Heavy Grinding Stones Vish Kozusovi, kapitánovi stráže v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Logistics Task Briefing III.]])

add(8806, [[Grinding Stones for the Guard]],
[[The Cenarion Hold guard is in short supply of grinding stones.  Procure a batch and deliver them immediately to Captain Vish Kozus in Cenarion Hold.]],
[[Stráži v Cenarion Hold docházejí brusné kameny. Obstarej další a okamžitě je dones kapitánu Vish Kozusovi v Cenarion Hold.]],
[[Bring 10 Dense Grinding Stones, 10 Solid Grinding Stones and 10 Heavy Grinding Stones to Vish Kozus, Captain of the Guard at Cenarion Hold in Silithus.  You must also bring Logistics Task Briefing III in order to complete this quest.]],
[[Dones 10 Dense Grinding Stones, 10 Solid Grinding Stones a 10 Heavy Grinding Stones Vish Kozusovi, kapitánovi stráže v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Logistics Task Briefing III.]])

add(8786, [[Arms for the Field]],
[[The Orgrimmar Legion has put in a request for additional weapons that we haven't been able to provide at the moment.  Obtain the weapons they've requested and bring them to Merok Longstride outside of Hive'Regal.]],
[[Orgrimmar Legion požádala o další zbraně, které jí zatím nedokážeme dodat. Obstarej požadované zbraně a dones je Merokovi Longstride před Hive'Regal.]],
[[Bring 3 Massive Iron Axes to Merok Longstride at the Orgrimmar Legion camp outside of Hive'Regal.  You must also bring Logistics Task Briefing VI in order to complete this quest.]],
[[Dones 3 Massive Iron Axes Merokovi Longstride do tábora Orgrimmar Legion před Hive'Regal. K dokončení úkolu musíš přinést také Logistics Task Briefing VI.]])

add(9243, [[Polar Tunic]],
[[Thanks to you and Omarion, may he rest in peace, I am now able to create a Polar tunic. All you need to do is bring me the materials and pay a small crafting fee.]],
[[Díky tobě a Omarionovi, nechť odpočívá v pokoji, nyní dokážu vyrobit polární tuniku. Stačí mi přinést potřebné materiály a zaplatit malý poplatek za výrobu.]],
[[Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 8 Frozen Runes, 16 Enchanted Leathers, 5 Essences of Water, 5 Cured Rugged Hides and 300 gold. You must also be of Exalted reputation with the Argent Dawn.]],
[[Řemeslník Wilhelm v Light's Hope Chapel v Eastern Plaguelands chce 8 Frozen Runes, 16 Enchanted Leathers, 5 Essences of Water, 5 Cured Rugged Hides a 300 zlatých. U Argent Dawn musíš mít také reputaci Exalted.]])

add(9240, [[Glacial Vest]],
[[Thanks to you and Omarion, may he rest in peace, I am now able to create a Glacial vest. All you need to do is bring me the materials and pay a small crafting fee.]],
[[Díky tobě a Omarionovi, nechť odpočívá v pokoji, nyní dokážu vyrobit ledovcovou vestu. Stačí mi přinést potřebné materiály a zaplatit malý poplatek za výrobu.]],
[[Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 8 Frozen Runes, 8 Bolts of Runecloth, 6 Essences of Water, 4 Ironweb Spider Silks and 300 gold. You must also be of Exalted reputation with the Argent Dawn.]],
[[Řemeslník Wilhelm v Light's Hope Chapel v Eastern Plaguelands chce 8 Frozen Runes, 8 Bolts of Runecloth, 6 Essences of Water, 4 Ironweb Spider Silks a 300 zlatých. U Argent Dawn musíš mít také reputaci Exalted.]])

add(9237, [[Glacial Cloak]],
[[Thanks to you and Omarion, may he rest in peace, I am now able to create a Glacial cloak. All you need to do is bring me the materials and pay a small crafting fee.]],
[[Díky tobě a Omarionovi, nechť odpočívá v pokoji, nyní dokážu vyrobit ledovcový plášť. Stačí mi přinést potřebné materiály a zaplatit malý poplatek za výrobu.]],
[[Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 5 Frozen Runes, 4 Bolts of Runecloth, 2 Essences of Water, 4 Ironweb Spider Silks and 200 gold. You must also be of Exalted reputation with the Argent Dawn.]],
[[Řemeslník Wilhelm v Light's Hope Chapel v Eastern Plaguelands chce 5 Frozen Runes, 4 Bolts of Runecloth, 2 Essences of Water, 4 Ironweb Spider Silks a 200 zlatých. U Argent Dawn musíš mít také reputaci Exalted.]])

add(8498, [[Twilight Battle Orders]],
[[Our scouts have reported new battle orders being issued by the Twilight's Hammer leaders.  The orders are being distributed by Twilight Prophets under heavy escort.  Intercept the orders and bring them to Commander Mar'alith.]],
[[Naši zvědové hlásí nové bitevní rozkazy vydané vůdci Twilight's Hammer. Roznášejí je Twilight Prophets pod silnou eskortou. Získej rozkazy a dones je Commanderovi Mar'alithovi.]],
[[Obtain the Twilight Battle Orders and bring them Commander Mar'alith at Cenarion Hold in Silithus.  You must also bring Tactical Task Briefing X in order to complete this quest.]],
[[Získej Twilight Battle Orders a dones je Commanderovi Mar'alithovi v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Tactical Task Briefing X.]])

add(9246, [[Icy Scale Breastplate]],
[[Thanks to you and Omarion (May he rest in peace), I am now able to create an Icy Scale breastplate. All you need to do is bring me the materials and pay a small crafting fee.]],
[[Díky tobě a Omarionovi (nechť odpočívá v pokoji) nyní dokážu vyrobit kyrys z ledových šupin. Stačí mi přinést potřebné materiály a zaplatit malý poplatek za výrobu.]],
[[Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 8 Frozen Runes, 24 Heavy Scorpid Scale, 7 Essence of Water, 5 Cured Rugged Hides and 300 gold. You must also be of Exalted reputation with the Argent Dawn.]],
[[Řemeslník Wilhelm v Light's Hope Chapel v Eastern Plaguelands chce 8 Frozen Runes, 24 Heavy Scorpid Scale, 7 Essence of Water, 5 Cured Rugged Hides a 300 zlatých. U Argent Dawn musíš mít také reputaci Exalted.]])

add(9042, [[Dreadnaught Bracers]],
[[During your battles with the Scourge in Naxxramas, should you come across desecrated battlements and wartorn plate scraps, return them to me and I shall craft for you a piece of armor worn by heroes.]],
[[Pokud během bojů se Scourge v Naxxramas narazíš na znesvěcenou zbroj a válkou poničené plátové úlomky, dones mi je a vyrobím ti část zbroje, jakou nosí hrdinové.]],
[[Korfax at Light's Hope Chapel in the Eastern Plaguelands will make Dreadnaught Bracers if you bring him the following items: 1 Desecrated Bracers, 6 Wartorn Plate Scraps, 1 Arcanite Bar and 1 Nexus Crystal.]],
[[Korfax v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Dreadnaught Bracers, pokud mu přineseš: 1 Desecrated Bracers, 6 Wartorn Plate Scraps, 1 Arcanite Bar a 1 Nexus Crystal.]])

add(9037, [[Dreadnaught Helmet]],
[[During your battles with the Scourge in Naxxramas, should you come across desecrated battlements and wartorn plate scraps, return them to me and I shall craft for you a piece of armor worn by heroes.]],
[[Pokud během bojů se Scourge v Naxxramas narazíš na znesvěcenou zbroj a válkou poničené plátové úlomky, dones mi je a vyrobím ti část zbroje, jakou nosí hrdinové.]],
[[Korfax at Light's Hope Chapel in the Eastern Plaguelands will make a Dreadnaught Helmet if you bring him the following items: 1 Desecrated Helmet, 15 Wartorn Plate Scraps, 5 Arcanite Bars and 1 Nexus Crystal.]],
[[Korfax v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Dreadnaught Helmet, pokud mu přineseš: 1 Desecrated Helmet, 15 Wartorn Plate Scraps, 5 Arcanite Bars a 1 Nexus Crystal.]])

add(8781, [[Arms for the Field]],
[[The Ironforge Brigade has been a worthy ally in our fight in Silithus.  Unfortunately, many of their supplies were lost on their way here.  Procure a batch of weapons and deliver them to Janela Stouthammer near Hive'Zora.]],
[[Ironforge Brigade je v našem boji v Silithus cenným spojencem. Bohužel se cestou sem ztratila velká část jejich zásob. Obstarej zbraně a dones je Janele Stouthammer poblíž Hive'Zora.]],
[[Bring 2 Moonsteel Broadswords to Janela Stouthammer at the Ironforge Brigade Outpost outside of Hive'Zora.  You must also bring Logistics Task Briefing VI in order to complete this quest.]],
[[Dones 2 Moonsteel Broadswords Janele Stouthammer na stanoviště Ironforge Brigade před Hive'Zora. K dokončení úkolu musíš přinést také Logistics Task Briefing VI.]])

add(8529, [[The Alliance Needs More Spotted Yellowtail!]],
[[If you're still willing I'd like to send you back out to bring in another haul of spotted yellowtail, $N. I'd imagine with the expertise you gained the first time out that this catch should be much faster and easier. Are you game?]],
[[Pokud jsi stále ochotný, rád bych tě poslal pro další várku Spotted Yellowtail, $N. Díky zkušenostem z minula by tenhle úlovek měl být mnohem rychlejší a snazší. Jdeš do toho?]],
[[Bring 20 spotted yellowtail to Huntress Swiftriver at the airfield in Dun Morogh.]],
[[Dones 20 Spotted Yellowtail Huntress Swiftriver na letiště v Dun Morogh.]])

add(8533, [[The Horde Needs More Copper Bars!]],
[[Back so soon? You'll be a real miner in no time $c. So, you already know the drill; I need you to go out, mine up a mess of copper ore, smelt it into bars and bring it back to me here. I know that's something you're capable of, the question is, are you willing?]],
[[Už jsi zpátky? Brzy z tebe bude skutečný horník, $c. Postup už znáš: vyraz ven, vytěž pořádnou zásobu měděné rudy, přetav ji na pruty a dones mi je sem. Vím, že to zvládneš. Otázka je, jestli do toho chceš jít.]],
[[Bring 20 copper bars to Miner Cromwell in Durotar.]],
[[Dones 20 měděných prutů Minerovi Cromwellovi v Durotar.]])

add(8780, [[Armor Kits for the Field]],
[[The Ironforge Brigade's supply of armor kits in the battlefield is running dangerously low.  Obtain a batch and deliver them to Janela Stouthammer at the Ironforge Brigade's outpost outside Hive'Zora.]],
[[Zásoby sad na zbroj Ironforge Brigade na bojišti nebezpečně docházejí. Obstarej další a dones je Janele Stouthammer na stanoviště Ironforge Brigade před Hive'Zora.]],
[[Bring 8 Rugged Armor Kits and 8 Heavy Armor Kits to Janela Stouthammer at the Ironforge Brigade Outpost near Hive'Zora in Silithus.  You must also bring Logistics Task Briefing VII in order to complete this quest.]],
[[Dones 8 Rugged Armor Kits a 8 Heavy Armor Kits Janele Stouthammer na stanoviště Ironforge Brigade poblíž Hive'Zora v Silithus. K dokončení úkolu musíš přinést také Logistics Task Briefing VII.]])

add(9040, [[Dreadnaught Gauntlets]],
[[During your battles with the Scourge in Naxxramas, should you come across desecrated battlements and wartorn plate scraps, return them to me and I shall craft for you a piece of armor worn by heroes.]],
[[Pokud během bojů se Scourge v Naxxramas narazíš na znesvěcenou zbroj a válkou poničené plátové úlomky, dones mi je a vyrobím ti část zbroje, jakou nosí hrdinové.]],
[[Korfax at Light's Hope Chapel in the Eastern Plaguelands will make Dreadnaught Gauntlets if you bring him the following items: 1 Desecrated Gauntlets, 8 Wartorn Plate Scraps, 1 Arcanite Bar and 5 Cured Rugged Hides.]],
[[Korfax v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Dreadnaught Gauntlets, pokud mu přineseš: 1 Desecrated Gauntlets, 8 Wartorn Plate Scraps, 1 Arcanite Bar a 5 Cured Rugged Hides.]])

add(9036, [[Dreadnaught Legplates]],
[[During your battles with the Scourge in Naxxramas, should you come across desecrated battlements and wartorn plate scraps, return them to me and I shall craft for you a piece of armor worn by heroes.]],
[[Pokud během bojů se Scourge v Naxxramas narazíš na znesvěcenou zbroj a válkou poničené plátové úlomky, dones mi je a vyrobím ti část zbroje, jakou nosí hrdinové.]],
[[Korfax at Light's Hope Chapel in the Eastern Plaguelands will make Dreadnaught Legplates if you bring him the following items: 1 Desecrated Legplates, 20 Wartorn Plate Scraps, 4 Arcanite Bars and 3 Cured Rugged Hides.]],
[[Korfax v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Dreadnaught Legplates, pokud mu přineseš: 1 Desecrated Legplates, 20 Wartorn Plate Scraps, 4 Arcanite Bars a 3 Cured Rugged Hides.]])

add(9038, [[Dreadnaught Pauldrons]],
[[During your battles with the Scourge in Naxxramas, should you come across desecrated battlements and wartorn plate scraps, return them to me and I shall craft for you a piece of armor worn by heroes.]],
[[Pokud během bojů se Scourge v Naxxramas narazíš na znesvěcenou zbroj a válkou poničené plátové úlomky, dones mi je a vyrobím ti část zbroje, jakou nosí hrdinové.]],
[[Korfax at Light's Hope Chapel in the Eastern Plaguelands will make Dreadnaught Pauldrons if you bring him the following items: 1 Desecrated Pauldrons, 12 Wartorn Plate Scraps, 2 Arcanite Bars and 3 Cured Rugged Hides.]],
[[Korfax v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Dreadnaught Pauldrons, pokud mu přineseš: 1 Desecrated Pauldrons, 12 Wartorn Plate Scraps, 2 Arcanite Bars a 3 Cured Rugged Hides.]])

add(9041, [[Dreadnaught Waistguard]],
[[During your battles with the Scourge in Naxxramas, should you come across desecrated battlements and wartorn plate scraps, return them to me and I shall craft for you a piece of armor worn by heroes.]],
[[Pokud během bojů se Scourge v Naxxramas narazíš na znesvěcenou zbroj a válkou poničené plátové úlomky, dones mi je a vyrobím ti část zbroje, jakou nosí hrdinové.]],
[[Korfax at Light's Hope Chapel in the Eastern Plaguelands will make a Dreadnaught Waistguard if you bring him the following items: 1 Desecrated Waistguard, 8 Wartorn Plate Scraps, 1 Arcanite Bar and 5 Cured Rugged Hides.]],
[[Korfax v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Dreadnaught Waistguard, pokud mu přineseš: 1 Desecrated Waistguard, 8 Wartorn Plate Scraps, 1 Arcanite Bar a 5 Cured Rugged Hides.]])

add(2996, [[Seeking Strahad]],
[[I have taught you skills in the past, but the time has come for another to teach you. He is in Ratchet, and his name is Strahad. He is human, but do not let that fool you into thinking he is weak. He is powerful even though he may be small. He can teach you about more powerful summonings--I feel you are ready. Go to him now. He is in Ratchet... above the port town next to his tower.]],
[[V minulosti jsem tě učil, ale nastal čas, aby tě vedl někdo jiný. Je v Ratchet a jmenuje se Strahad. Je člověk, ale nenech se tím zmást a nemysli si, že je slabý. I přes svou postavu je mocný. Může tě naučit silnějším způsobům vyvolávání -- myslím, že jsi připraven. Vyhledej ho v Ratchet, nad přístavním městem u jeho věže.]],
[[Speak to Strahad Farsan in Ratchet.]],
[[Promluv si se Strahadem Farsanem v Ratchet.]])

add(8783, [[Extraordinary Materials]],
[[Vargus, Cenarion Hold's blacksmith, has requested enchanted materials to be used in the crafting of powerful weapons for our forces.  Obtain these and bring them directly to Vargus so that Cenarion Hold's troops may continue to be well equipped.]],
[[Vargus, kovář z Cenarion Hold, požádal o očarované materiály pro výrobu mocných zbraní pro naše jednotky. Obstarej je a dones je přímo Vargusovi, aby vojáci Cenarion Hold zůstali dobře vybaveni.]],
[[Bring 2 Enchanted Thorium Bars and 2 Enchanted Leather to Vargus at Cenarion Hold in Silithus.  You must also bring Logistics Task Briefing IX in order to complete this quest.]],
[[Dones 2 Enchanted Thorium Bars a 2 Enchanted Leather Vargusovi v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Logistics Task Briefing IX.]])

add(8809, [[Extraordinary Materials]],
[[Vargus, Cenarion Hold's blacksmith, has requested enchanted materials to be used in the crafting of powerful weapons for our forces.  Obtain these and bring them directly to Vargus so that Cenarion Hold's troops may continue to be well equipped.]],
[[Vargus, kovář z Cenarion Hold, požádal o očarované materiály pro výrobu mocných zbraní pro naše jednotky. Obstarej je a dones je přímo Vargusovi, aby vojáci Cenarion Hold zůstali dobře vybaveni.]],
[[Bring 2 Enchanted Thorium Bars and 2 Enchanted Leather to Vargus at Cenarion Hold in Silithus.  You must also bring Logistics Task Briefing IX in order to complete this quest.]],
[[Dones 2 Enchanted Thorium Bars a 2 Enchanted Leather Vargusovi v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Logistics Task Briefing IX.]])

add(8504, [[The Alliance Needs More Stranglekelp!]],
[[Well hello again there... what was it? Ah yes, $N! Come to see if I still need more stranglekelp have you? Well, it's your lucky day, because the answer to that very important question is a very affirmative YES! Think you could gather up twenty more?]],
[[Tak zase zdravím... jak že to bylo? Ano, $N! Přišel ses podívat, jestli ještě potřebuji další Stranglekelp? Máš štěstí, protože odpověď na tuhle velmi důležitou otázku je rozhodné ANO! Dokážeš nasbírat dalších dvacet?]],
[[Bring 20 stranglekelp to Private Draxlegauge at the airfield in Dun Morogh.]],
[[Dones 20 Stranglekelp Private Draxlegauge na letiště v Dun Morogh.]])

add(8305, [[Long Forgotten Memories]],
[[In the southern desert of Silithus, near the sacred barrier, exists a single crystalline tear. This tear serves as a symbol of the great losses beset upon us during the War of the Shifting Sands. Locate this tear and gaze into its depths to gain enlightenment.$B]],
[[V jižní poušti Silithus poblíž posvátné bariéry se nachází jediná krystalická slza. Je symbolem obrovských ztrát, které jsme utrpěli během War of the Shifting Sands. Najdi ji a zahleď se do její hloubky, abys získal poznání.$B]],
[[Locate the Crystalline Tear in Silithus and gaze into its depths.]],
[[Najdi Crystalline Tear v Silithus a zahleď se do její hloubky.]])

add(9241, [[Polar Bracers]],
[[Thanks to you and Omarion (May he rest in peace), I am now able to create Polar bracers. All you need to do is bring me the materials and pay a small crafting fee.]],
[[Díky tobě a Omarionovi (nechť odpočívá v pokoji) nyní dokážu vyrobit polární nátepníky. Stačí mi přinést potřebné materiály a zaplatit malý poplatek za výrobu.]],
[[Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 4 Frozen Runes, 12 Enchanted Leather, 3 Essence of Water, 3 Cured Rugged Hides and 200 gold. $B]],
[[Řemeslník Wilhelm v Light's Hope Chapel v Eastern Plaguelands chce 4 Frozen Runes, 12 Enchanted Leather, 3 Essence of Water, 3 Cured Rugged Hides a 200 zlatých. $B]])

add(4322, [[Jail Break!]],
[[We need to get out of here, $N. Help me get my gear back from the supply area and free my friends. If we make it out of here, you are to proceed to Morgan's Vigil and speak with Marshal Maxwell. He will give you further instruction.]],
[[Musíme se odsud dostat, $N. Pomoz mi získat zpět výbavu ze skladu a osvobodit mé přátele. Pokud se nám podaří uniknout, vydej se do Morgan's Vigil a promluv si s Marshalem Maxwellem. Dá ti další pokyny.]],
[[Help Marshal Windsor get his gear back and free his friends. Return to Marshal Maxwell if you succeed.]],
[[Pomoz Marshalovi Windsorovi získat zpět jeho výbavu a osvobodit přátele. Pokud uspěješ, vrať se k Marshalovi Maxwellovi.]])

add(8496, [[Bandages for the Field]],
[[Our supply of bandages in the battlefield is running dangerously low after the recent casualties we have incurred.  Obtain a batch of first-aid supplies and deliver them to Windcaller Proudhorn in Cenarion Hold.]],
[[Po nedávných ztrátách nám na bojišti nebezpečně docházejí obvazy. Obstarej zásoby první pomoci a dones je Windcallerovi Proudhornovi v Cenarion Hold.]],
[[Bring 30 Heavy Runecloth Bandages, 30 Heavy Silk Bandages and 30 Heavy Mageweave Bandages to Windcaller Proudhorn at Cenarion Hold in Silithus.  You must also bring Logistics Task Briefing X in order to complete this quest.]],
[[Dones 30 Heavy Runecloth Bandages, 30 Heavy Silk Bandages a 30 Heavy Mageweave Bandages Windcallerovi Proudhornovi v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Logistics Task Briefing X.]])

add(8518, [[The Alliance Needs More Linen Bandages!]],
[[Ever am I amazed by the selflessness exhibited when so many would instead turn to selfishness instead. $C, I am still in need of a number of linen bandages before my assignment here is fulfilled. Will you aid me once more in the collection of those bandages?]],
[[Stále mě udivuje obětavost některých, když by tolik jiných dalo přednost sobectví. $C, k dokončení mého úkolu tu stále potřebuji další lněné obvazy. Pomůžeš mi je ještě jednou shromáždit?]],
[[Bring 20 linen bandages to Sentinel Silversky at the airfield in Dun Morogh.]],
[[Dones 20 lněných obvazů Sentinel Silversky na letiště v Dun Morogh.]])

add(8787, [[Armor Kits for the Field]],
[[The brave volunteers of the Orgrimmar Legion have arrived to Silithus to aid us in our cause.  Their supplies of armor kits were somehow lost in the trip.  Obtain a batch of armor kits and deliver them to Merok Longstride at the location of the Orgrimmar Legion camp.]],
[[Stateční dobrovolníci Orgrimmar Legion dorazili do Silithus, aby nám pomohli. Jejich zásoby sad na zbroj se však cestou ztratily. Obstarej další sady a dones je Merokovi Longstride do tábora Orgrimmar Legion.]],
[[Bring 8 Rugged Armor Kits and 8 Heavy Armor Kits to Merok Longstride near Hive'Regal.  You must also bring Logistics Task Briefing VII in order to complete this quest.]],
[[Dones 8 Rugged Armor Kits a 8 Heavy Armor Kits Merokovi Longstride poblíž Hive'Regal. K dokončení úkolu musíš přinést také Logistics Task Briefing VII.]])

add(8810, [[Bandages for the Field]],
[[Our supply of bandages in the battlefield is running dangerously low after the recent casualties we have incurred.  Obtain a batch of first-aid supplies and deliver them to Windcaller Proudhorn in Cenarion Hold.]],
[[Po nedávných ztrátách nám na bojišti nebezpečně docházejí obvazy. Obstarej zásoby první pomoci a dones je Windcallerovi Proudhornovi v Cenarion Hold.]],
[[Bring 30 Heavy Runecloth Bandages, 30 Heavy Silk Bandages and 30 Heavy Mageweave Bandages to Windcaller Proudhorn at Cenarion Hold in Silithus.  You must also bring Logistics Task Briefing X in order to complete this quest.]],
[[Dones 30 Heavy Runecloth Bandages, 30 Heavy Silk Bandages a 30 Heavy Mageweave Bandages Windcallerovi Proudhornovi v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Logistics Task Briefing X.]])

add(8856, [[Desert Survival Kits]],
[[With the arrival of fresh recruits to Cenarion Hold comes the problem of keeping them alive in the desert.  Dehydration as well as numerous poisonous creatures present a serious threat to inexperienced volunteers.  Gather the supplies necessary for a desert survival kit and bring them to Calandrath in Cenarion Hold.]],
[[S příchodem nových rekrutů do Cenarion Hold přichází problém, jak je udržet naživu v poušti. Dehydratace i množství jedovatých tvorů představují pro nezkušené dobrovolníky vážnou hrozbu. Shromáždi zásoby pro pouštní sadu na přežití a dones je Calandrathovi v Cenarion Hold.]],
[[Bring 4 Globes of Water, 4 Powerful Anti-Venom and 4 Baked Salmon to Calandrath at the inn in Cenarion Hold in Silithus.]],
[[Dones 4 Globes of Water, 4 Powerful Anti-Venom a 4 Baked Salmon Calandrathovi v hostinci v Cenarion Hold v Silithus.]])

add(8785, [[The Orgrimmar Legion Needs Mojo!]],
[[The Orgrimmar Legion has put in a request for several unusual ingredients.  Given their current performance in Silithus, we'd like to comply with their request as soon as possible.  Gather the materials and bring them to the troll called Shai.]],
[[Orgrimmar Legion požádala o několik neobvyklých přísad. Vzhledem k jejich výkonům v Silithus bychom jejich žádosti rádi vyhověli co nejdříve. Shromáždi materiály a dones je trollce jménem Shai.]],
[[Bring 6 Powerful Mojo, 6 Flasks of Big Mojo and 8 Oils of Immolation to Shadow Priestess Shai near Hive'Regal in Silithus.  You must also bring Logistics Task Briefing IV in order to complete this quest.]],
[[Dones 6 Powerful Mojo, 6 Flasks of Big Mojo a 8 Oils of Immolation Shadow Priestess Shai poblíž Hive'Regal v Silithus. K dokončení úkolu musíš přinést také Logistics Task Briefing IV.]])

add(3884, [[Williden's Journal]],
[[You have uncovered a mangled journal.  Parts of it remain legible, with a Williden Marshal claiming ownership over the contents therein.  If the journal is accurate, then Williden may be found somewhere in the northern part of the Crater; according to the journal, he and his companions sought higher ground from the savage beasts of the Crater once their base camps were overrun.]],
[[Našel jsi poničený deník. Některé části jsou stále čitelné a jako jeho majitel je uveden Williden Marshal. Pokud je deník přesný, Williden se nachází někde v severní části Crateru; podle zápisků se se svými společníky uchýlil do vyšších poloh před divokými tvory poté, co byly jejich základní tábory přemoženy.]],
[[Return the journal to Williden Marshal somewhere in Un'Goro Crater.]],
[[Vrať deník Willidenu Marshalovi někde v Un'Goro Crater.]])

add(7907, [[Darkmoon Beast Deck]],
[[Now that you have gathered all of the Beast cards together into a deck, a ninth card mysteriously appears with the same backing as the first eight.   On this card is inscribed, "Return these cards to the Darkmoon Faire and be rewarded."   You have heard that this faire alternately stops at Mulgore and Goldshire every few months, so you will have to wait until they are here next.]],
[[Když jsi spojil všechny karty Beast do jednoho balíčku, záhadně se objevila devátá karta se stejným rubem jako prvních osm. Je na ní napsáno: „Vrať tyto karty na Darkmoon Faire a budeš odměněn.“ Slyšel jsi, že se tento jarmark každých pár měsíců střídavě zastavuje v Mulgore a Goldshire, takže budeš muset počkat na jeho další návštěvu.]],
[[Return the Beast Deck to the Darkmoon Faire when it comes to town.]],
[[Až Darkmoon Faire dorazí do města, dones tam Beast Deck.]])

add(8933, [[Just Compensation]],
[[You kept your word and brought the device built by Mux.  I believe a reward is in order if I'm to keep you interested in saving my skin.  Bring me the belt and set of gauntlets that you wish to upgrade.  I promise the ones I give you in return will be far superior.]],
[[Dodržel jsi slovo a přinesl zařízení, které vyrobil Mux. Myslím, že si zasloužíš odměnu, pokud tě mám udržet ochotného zachraňovat mi kůži. Přines mi opasek a rukavice, které chceš vylepšit. Slibuji, že ty, které dostaneš zpět, budou mnohem lepší.]],
[[Bring a Lightforge Belt and a set of Lightforge Gauntlets to Deliana in Ironforge.$B]],
[[Dones Lightforge Belt a Lightforge Gauntlets Delianě v Ironforge.$B]])

add(7927, [[Darkmoon Portals Deck]],
[[Now that you have gathered all of the Portal cards together into a deck, a ninth card mysteriously appears with the same backing as the first eight.   On this card is inscribed, "Return these cards to the Darkmoon Faire and be rewarded."   You have heard that this faire alternately stops at Mulgore and Goldshire every few months, so you will have to wait until they are here next.]],
[[Když jsi spojil všechny karty Portal do jednoho balíčku, záhadně se objevila devátá karta se stejným rubem jako prvních osm. Je na ní napsáno: „Vrať tyto karty na Darkmoon Faire a budeš odměněn.“ Slyšel jsi, že se tento jarmark každých pár měsíců střídavě zastavuje v Mulgore a Goldshire, takže budeš muset počkat na jeho další návštěvu.]],
[[Return the Portals Deck to the Darkmoon Faire when it comes to town.]],
[[Až Darkmoon Faire dorazí do města, dones tam Portals Deck.]])

add(7928, [[Darkmoon Warlords Deck]],
[[Now that you have gathered all of the Warlord cards together into a deck, a ninth card mysteriously appears with the same backing as the first eight.   On this card is inscribed, "Return these cards to the Darkmoon Faire and be rewarded."   You have heard that this faire alternately stops at Mulgore and Goldshire every few months, so you will have to wait until they are here next.]],
[[Když jsi spojil všechny karty Warlord do jednoho balíčku, záhadně se objevila devátá karta se stejným rubem jako prvních osm. Je na ní napsáno: „Vrať tyto karty na Darkmoon Faire a budeš odměněn.“ Slyšel jsi, že se tento jarmark každých pár měsíců střídavě zastavuje v Mulgore a Goldshire, takže budeš muset počkat na jeho další návštěvu.]],
[[Return the Warlords Deck to the Darkmoon Faire when it comes to town.]],
[[Až Darkmoon Faire dorazí do města, dones tam Warlords Deck.]])

add(7929, [[Darkmoon Elementals Deck]],
[[Now that you have gathered all of the Elemental cards together into a deck, a ninth card mysteriously appears with the same backing as the first eight.   On this card is inscribed, "Return these cards to the Darkmoon Faire and be rewarded."   You have heard that this faire alternately stops at Mulgore and Goldshire every few months, so you will have to wait until they are here next.]],
[[Když jsi spojil všechny karty Elemental do jednoho balíčku, záhadně se objevila devátá karta se stejným rubem jako prvních osm. Je na ní napsáno: „Vrať tyto karty na Darkmoon Faire a budeš odměněn.“ Slyšel jsi, že se tento jarmark každých pár měsíců střídavě zastavuje v Mulgore a Goldshire, takže budeš muset počkat na jeho další návštěvu.]],
[[Return the Elementals Deck to the Darkmoon Faire when it comes to town.]],
[[Až Darkmoon Faire dorazí do města, dones tam Elementals Deck.]])

add(8283, [[Wanted - Deathclasp, Terror of the Sands]],
[[The terrible scorpid, Deathclasp, is believed to have retreated to the southern mountain range in the presence of increased silithid activity.  She presents a great threat to patrols and expeditions in the southern regions.  Individuals participating in her destruction will be remunerated handsomely.  Inquire with Captain Vish Kozus, at the top of the Cenarion Hold Watchtower, regarding a reward.]],
[[Předpokládá se, že strašlivá škorpídka Deathclasp se kvůli zvýšené aktivitě silithidů stáhla do jižního pohoří. Představuje velkou hrozbu pro hlídky a výpravy v jižních oblastech. Ti, kdo se podílejí na jejím zničení, budou štědře odměněni. Na odměnu se zeptej kapitána Vish Kozuse na vrcholu strážní věže Cenarion Hold.]],
[[Bring Deathclasp's Pincer to Vish Kozus, Captain of the Guard.]],
[[Dones Deathclasp's Pincer Vish Kozusovi, kapitánovi stráže.]])

add(8687, [[Target: Hive'Zora Tunnelers]],
[[Reinforcements have been called on to join the assault on Hive'Zora.  You have been selected to target Hive'Zora tunnelers.  Report back to Commander Mar'alith after completing your task.]],
[[K útoku na Hive'Zora byly povolány posily. Byl jsi vybrán, abys zaútočil na Hive'Zora Tunnelers. Po splnění úkolu se vrať ke Commanderovi Mar'alithovi.]],
[[Slay 30 Hive'Zora Tunnelers and report back to Commander Mar'alith at Cenarion Hold in Silithus.  You must also bring Combat Task Briefing VII in order to complete this quest.$B]],
[[Zabij 30 Hive'Zora Tunnelers a vrať se ke Commanderovi Mar'alithovi v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Combat Task Briefing VII.$B]])

add(5305, [[Sweet Serenity]],
[[Within the confines of the Scarlet Bastion lies sweet Serenity. The Crimson Hammersmith guards the recipe with his life. Defeat him and bring me his apron. For that, I shall reward you with the knowledge required to create an enchanted battlehammer!]],
[[Uvnitř Scarlet Bastion se skrývá sladké tajemství Serenity. Crimson Hammersmith střeží recept vlastním životem. Poraz ho a dones mi jeho zástěru. Za to tě odměním znalostí potřebnou k výrobě očarovaného válečného kladiva!]],
[[Travel to Stratholme and kill the Crimson Hammersmith. Recover the Crimson Hammersmith's Apron and return to Lilith.$B]],
[[Vydej se do Stratholme a zabij Crimson Hammersmith. Získej Crimson Hammersmith's Apron a vrať se k Lilith.$B]])

add(8772, [[Target: Hive'Zora Waywatchers]],
[[Reinforcements have been called on to join the assault on Hive'Zora.  You have been selected to target Hive'Zora waywatchers.  Report back to Commander Mar'alith after completing your task.]],
[[K útoku na Hive'Zora byly povolány posily. Byl jsi vybrán, abys zaútočil na Hive'Zora Waywatchers. Po splnění úkolu se vrať ke Commanderovi Mar'alithovi.]],
[[Slay 30 Hive'Zora Waywatchers and report back to Commander Mar'alith at Cenarion Hold in Silithus.  You must also bring Combat Task Briefing VI in order to complete this quest.$B]],
[[Zabij 30 Hive'Zora Waywatchers a vrať se ke Commanderovi Mar'alithovi v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Combat Task Briefing VI.$B]])

add(8857, [[Secrets of the Colossus - Ashi]],
[[I'm looking for battle hardened adventurers willing and able to get a fresh husk sample from the fallen Colossus of Ashi to Oglethorpe in Booty Bay. No, no, I wouldn't want you to go anywhere near that thing's corpse. Just take one of my samples and make it snappy. These things are no good to him rotten!]],
[[Hledám ostřílené dobrodruhy, kteří dokážou doručit čerstvý vzorek krunýře padlého Colossus of Ashi Oglethorpovi do Booty Bay. Ne, ne, nechci, abys chodil k mrtvole té věci. Vezmi prostě jeden z mých vzorků a pospěš si. Shnilý mu bude k ničemu!]],
[[Take the Colossus of Ashi's Husk to Oglethorpe Obnoticus in Booty Bay.$B]],
[[Dones Colossus of Ashi's Husk Oglethorpovi Obnoticusovi v Booty Bay.$B]])

add(9049, [[Redemption Girdle]],
[[You will find the remnants of our fallen heroes on the corpses of the Lords of Naxxramas. Bring those desecrated keepsakes to me along with wartorn plate scraps and crafting materials capable of revitalizing the cursed armor and I shall craft a fine piece of armor for you.]],
[[Na tělech Lords of Naxxramas najdeš pozůstatky našich padlých hrdinů. Dones mi tyto znesvěcené památky spolu s válkou poničenými plátovými úlomky a materiály schopnými obnovit prokletou zbroj a vyrobím ti kvalitní kus výstroje.]],
[[Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make a Redemption Girdle if you bring him the following: 1 Desecrated Girdle, 8 Wartorn Plate Scraps, 1 Arcanite Bar and 3 Nexus Crystals.]],
[[Commander Eligor Dawnbringer v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Redemption Girdle, pokud mu přineseš: 1 Desecrated Girdle, 8 Wartorn Plate Scraps, 1 Arcanite Bar a 3 Nexus Crystals.]])

add(9047, [[Redemption Boots]],
[[You will find the remnants of our fallen heroes on the corpses of the Lords of Naxxramas. Bring those desecrated keepsakes to me along with wartorn plate scraps and crafting materials capable of revitalizing the cursed armor and I shall craft a fine piece of armor for you.]],
[[Na tělech Lords of Naxxramas najdeš pozůstatky našich padlých hrdinů. Dones mi tyto znesvěcené památky spolu s válkou poničenými plátovými úlomky a materiály schopnými obnovit prokletou zbroj a vyrobím ti kvalitní kus výstroje.]],
[[Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make Redemption Boots if you bring him the following: 1 Desecrated Boots, 12 Wartorn Plate Scraps, 2 Arcanite Bars and 3 Cured Rugged Hides.]],
[[Commander Eligor Dawnbringer v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Redemption Boots, pokud mu přineseš: 1 Desecrated Boots, 12 Wartorn Plate Scraps, 2 Arcanite Bars a 3 Cured Rugged Hides.]])

add(9043, [[Redemption Tunic]],
[[You will find the remnants of our fallen heroes on the corpses of the Lords of Naxxramas. Bring those desecrated keepsakes to me along with wartorn plate scraps and crafting materials capable of revitalizing the cursed armor and I shall craft a fine piece of armor for you.]],
[[Na tělech Lords of Naxxramas najdeš pozůstatky našich padlých hrdinů. Dones mi tyto znesvěcené památky spolu s válkou poničenými plátovými úlomky a materiály schopnými obnovit prokletou zbroj a vyrobím ti kvalitní kus výstroje.]],
[[Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make a Redemption Tunic if you bring him the following: 1 Desecrated Tunic, 25 Wartorn Plate Scraps, 4 Arcanite Bars and 3 Cured Rugged Hides.]],
[[Commander Eligor Dawnbringer v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Redemption Tunic, pokud mu přineseš: 1 Desecrated Tunic, 25 Wartorn Plate Scraps, 4 Arcanite Bars a 3 Cured Rugged Hides.]])

add(9236, [[Icebane Breastplate]],
[[Thanks to you and Omarion (May he rest in peace), I am now able to create an Icebane breastplate. All you need to do is bring me the materials and pay a small crafting fee.]],
[[Díky tobě a Omarionovi (nechť odpočívá v pokoji) nyní dokážu vyrobit kyrys Icebane. Stačí mi přinést potřebné materiály a zaplatit malý poplatek za výrobu.]],
[[Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 8 Frozen Runes, 16 Thorium Bars, 2 Arcanite Bars, 4 Essence of Water and 300 gold. You will also need to be of Exalted reputation with the Argent Dawn.$B]],
[[Řemeslník Wilhelm v Light's Hope Chapel v Eastern Plaguelands chce 8 Frozen Runes, 16 Thorium Bars, 2 Arcanite Bars, 4 Essence of Water a 300 zlatých. U Argent Dawn musíš mít také reputaci Exalted.$B]])

add(9048, [[Redemption Handguards]],
[[You will find the remnants of our fallen heroes on the corpses of the Lords of Naxxramas. Bring those desecrated keepsakes to me along with wartorn plate scraps and crafting materials capable of revitalizing the cursed armor and I shall craft a fine piece of armor for you.]],
[[Na tělech Lords of Naxxramas najdeš pozůstatky našich padlých hrdinů. Dones mi tyto znesvěcené památky spolu s válkou poničenými plátovými úlomky a materiály schopnými obnovit prokletou zbroj a vyrobím ti kvalitní kus výstroje.]],
[[Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make Redemption Handguards if you bring him the following: 1 Desecrated Handguards, 8 Wartorn Plate Scraps, 1 Arcanite Bar and 5 Cured Rugged Hides.]],
[[Commander Eligor Dawnbringer v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Redemption Handguards, pokud mu přineseš: 1 Desecrated Handguards, 8 Wartorn Plate Scraps, 1 Arcanite Bar a 5 Cured Rugged Hides.]])

add(9045, [[Redemption Headpiece]],
[[You will find the remnants of our fallen heroes on the corpses of the Lords of Naxxramas. Bring those desecrated keepsakes to me along with wartorn plate scraps and crafting materials capable of revitalizing the cursed armor and I shall craft a fine piece of armor for you.]],
[[Na tělech Lords of Naxxramas najdeš pozůstatky našich padlých hrdinů. Dones mi tyto znesvěcené památky spolu s válkou poničenými plátovými úlomky a materiály schopnými obnovit prokletou zbroj a vyrobím ti kvalitní kus výstroje.]],
[[Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make a Redemption Headpiece if you bring him the following: 1 Desecrated Headpiece, 15 Wartorn Plate Scraps, 5 Arcanite Bars and 2 Cured Rugged Hides.]],
[[Commander Eligor Dawnbringer v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Redemption Headpiece, pokud mu přineseš: 1 Desecrated Headpiece, 15 Wartorn Plate Scraps, 5 Arcanite Bars a 2 Cured Rugged Hides.]])

add(9050, [[Redemption Wristguards]],
[[You will find the remnants of our fallen heroes on the corpses of the Lords of Naxxramas. Bring those desecrated keepsakes to me along with wartorn plate scraps and crafting materials capable of revitalizing the cursed armor and I shall craft a fine piece of armor for you.]],
[[Na tělech Lords of Naxxramas najdeš pozůstatky našich padlých hrdinů. Dones mi tyto znesvěcené památky spolu s válkou poničenými plátovými úlomky a materiály schopnými obnovit prokletou zbroj a vyrobím ti kvalitní kus výstroje.]],
[[Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make Redemption Wristguards if you bring him the following: 1 Desecrated Wristguards, 6 Wartorn Plate Scraps, 1 Arcanite Bar and 2 Cured Rugged Hides.]],
[[Commander Eligor Dawnbringer v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Redemption Wristguards, pokud mu přineseš: 1 Desecrated Wristguards, 6 Wartorn Plate Scraps, 1 Arcanite Bar a 2 Cured Rugged Hides.]])

add(117, [[Thunderbrew Lager]],
[[Hurry, my friend, move with haste $bIn order for our rich lager to taste $bMore like beer and less like stew, $bHops are needed to make the brew.]],
[[Pospěš si, příteli, není čas stát,$baby náš ležák měl správný říz a slad,$ba chutnal jak pivo, ne jako guláš,$bchmel do něj přidej, ať dobrý mok máš.]],
[[Bring Grimbooze Thunderbrew 5 hops to complete his special brew.]],
[[Dones Grimboozovi Thunderbrewovi 5 chmelů, aby mohl dokončit svůj speciální ležák.]])

add(9044, [[Redemption Legguards]],
[[You will find the remnants of our fallen heroes on the corpses of the Lords of Naxxramas. Bring those desecrated keepsakes to me along with wartorn plate scraps and crafting materials capable of revitalizing the cursed armor and I shall craft a fine piece of armor for you.]],
[[Na tělech Lords of Naxxramas najdeš pozůstatky našich padlých hrdinů. Dones mi tyto znesvěcené památky spolu s válkou poničenými plátovými úlomky a materiály schopnými obnovit prokletou zbroj a vyrobím ti kvalitní kus výstroje.]],
[[Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make a pair of Redemption Legguards if you bring him the following: 1 Desecrated Legguards, 20 Wartorn Plate Scraps, 4 Arcanite Bars and 2 Nexus Crystals.]],
[[Commander Eligor Dawnbringer v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Redemption Legguards, pokud mu přineseš: 1 Desecrated Legguards, 20 Wartorn Plate Scraps, 4 Arcanite Bars a 2 Nexus Crystals.]])

add(9046, [[Redemption Spaulders]],
[[You will find the remnants of our fallen heroes on the corpses of the Lords of Naxxramas. Bring those desecrated keepsakes to me along with wartorn plate scraps and crafting materials capable of revitalizing the cursed armor and I shall craft a fine piece of armor for you.]],
[[Na tělech Lords of Naxxramas najdeš pozůstatky našich padlých hrdinů. Dones mi tyto znesvěcené památky spolu s válkou poničenými plátovými úlomky a materiály schopnými obnovit prokletou zbroj a vyrobím ti kvalitní kus výstroje.]],
[[Commander Eligor Dawnbringer at Light's Hope Chapel in the Eastern Plaguelands will make a pair of Redemption Spaulders if you bring him the following: 1 Desecrated Spaulders, 12 Wartorn Plate Scraps, 2 Arcanite Bars and 2 Nexus Crystals.]],
[[Commander Eligor Dawnbringer v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Redemption Spaulders, pokud mu přineseš: 1 Desecrated Spaulders, 12 Wartorn Plate Scraps, 2 Arcanite Bars a 2 Nexus Crystals.]])

add(9039, [[Dreadnaught Sabatons]],
[[During your battles with the Scourge in Naxxramas, should you come across desecrated battlements and wartorn plate scraps, return them to me and I shall craft for you a piece of armor worn by heroes.]],
[[Pokud během bojů se Scourge v Naxxramas narazíš na znesvěcenou zbroj a válkou poničené plátové úlomky, dones mi je a vyrobím ti část zbroje, jakou nosí hrdinové.]],
[[Korfax at Light's Hope Chapel in the Eastern Plaguelands will make Dreadnaught Sabatons if you bring him the following items: 1 Desecrated Sabatons, 12 Wartorn Plate Scraps, 2 Arcanite Bars and 3 Cured Rugged Hides.$B]],
[[Korfax v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Dreadnaught Sabatons, pokud mu přineseš: 1 Desecrated Sabatons, 12 Wartorn Plate Scraps, 2 Arcanite Bars a 3 Cured Rugged Hides.$B]])

add(6567, [[The Champion of the Horde]],
[[Rexxar, one of my most loyal champions, has discovered a way into the lair of the dragon. However he has left Azeroth to join our expedition into Outland.$b$bHowever, he left his companion, Rokaro, in Shadowprey Village with this information. You are to seek him out.]],
[[Rexxar, jeden z mých nejvěrnějších šampionů, objevil cestu do dračího doupěte. Odešel však z Azerothu, aby se připojil k naší výpravě do Outlandu.$b$bTyto informace ale zanechal svému společníkovi Rokarovi v Shadowprey Village. Vyhledej ho.]],
[[Seek out Rokaro at Shadowprey Village in Desolace.]],
[[Vyhledej Rokara v Shadowprey Village v Desolace.]])

add(9034, [[Dreadnaught Breastplate]],
[[During your battles with the Scourge in Naxxramas, should you come across desecrated battlements and wartorn plate scraps, return them to me and I shall craft for you a piece of armor worn by heroes.]],
[[Pokud během bojů se Scourge v Naxxramas narazíš na znesvěcenou zbroj a válkou poničené plátové úlomky, dones mi je a vyrobím ti část zbroje, jakou nosí hrdinové.]],
[[Korfax at Light's Hope Chapel in the Eastern Plaguelands will make a Dreadnaught Breastplate if you bring him the following items: 1 Desecrated Breastplate, 25 Wartorn Plate Scraps, 4 Arcanite Bars and 2 Nexus Crystals.$B]],
[[Korfax v Light's Hope Chapel v Eastern Plaguelands ti vyrobí Dreadnaught Breastplate, pokud mu přineseš: 1 Desecrated Breastplate, 25 Wartorn Plate Scraps, 4 Arcanite Bars a 2 Nexus Crystals.$B]])

add(2967, [[Return to Thunder Bluff]],
[[You access the pedestal again; the platinum discs suddenly appear once more in your backpack.$B$BWith the knowledge of the stone watcher learned and the discs returned to your possession, the time has come to return to Thunder Bluff and inform the Nara Wildmane of your discovery.]],
[[Znovu se dotkneš podstavce a platinové disky se náhle opět objeví v tvém batohu.$B$BTeď, když znáš tajemství kamenného strážce a disky máš zpět, nastal čas vrátit se do Thunder Bluff a říct Nara Wildmane o svém objevu.]],
[[Speak with Nara Wildmane in Thunder Bluff.]],
[[Promluv si s Nara Wildmane v Thunder Bluff.]])

add(2940, [[Feralas: A History]],
[[This book looks as if no one has opened it for quite a long time. Its covers are quite worn, and its pages yellowed, but after examining it, you notice that it might be just what Troyas is looking for.$B$BYou pick it up, but realize you should probably ask before borrowing it.]],
[[Vypadá to, že tuto knihu už hodně dlouho nikdo neotevřel. Desky jsou značně opotřebované a stránky zažloutlé, ale po prohlédnutí zjistíš, že by mohla být přesně tím, co Troyas hledá.$B$BKnihu zvedneš, ale uvědomíš si, že by bylo lepší nejdřív požádat o svolení.]],
[[Ask Daryn Lightwind if you may borrow her book.]],
[[Zeptej se Daryn Lightwind, zda si můžeš její knihu půjčit.]])

add(5230, [[Return to the Bulwark]],
[[You fill the bottle with enough of the cauldron's poisonous concoction for a suitable sample to be studied.$B$BWith the poison in hand, it is time to return to Shadow Priestess Vandis at the Bulwark to complete the mission.]],
[[Naplníš láhev dostatečným množstvím jedovatého odvaru z kotle, aby posloužil jako vzorek k výzkumu.$B$BS jedem v ruce je čas vrátit se k Shadow Priestess Vandis do Bulwarku a dokončit misi.]],
[[Bring the Filled Felstone Field Bottle to Shadow Priestess Vandis at the Bulwark, Western Plaguelands.]],
[[Dones Filled Felstone Field Bottle Shadow Priestess Vandis do Bulwarku v Western Plaguelands.]])

add(8497, [[Desert Survival Kits]],
[[With the arrival of fresh recruits to Cenarion Hold comes the problem of keeping them alive in the desert.  Dehydration as well as numerous poisonous creatures present a serious threat to inexperienced volunteers.  Gather the supplies necessary for a desert survival kit and bring them to Calandrath in Cenarion Hold.]],
[[S příchodem nových rekrutů do Cenarion Hold přichází problém, jak je udržet naživu v poušti. Dehydratace i množství jedovatých tvorů představují pro nezkušené dobrovolníky vážnou hrozbu. Shromáždi zásoby pro pouštní sadu na přežití a dones je Calandrathovi v Cenarion Hold.]],
[[Bring 4 Globes of Water, 4 Powerful Anti-Venom and 4 Smoked Desert Dumplings to Calandrath at the inn in Cenarion Hold in Silithus.  You must also bring Logistics Task Briefing I in order to complete this quest.]],
[[Dones 4 Globes of Water, 4 Powerful Anti-Venom a 4 Smoked Desert Dumplings Calandrathovi v hostinci v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Logistics Task Briefing I.]])

add(8804, [[Desert Survival Kits]],
[[With the arrival of fresh recruits to Cenarion Hold comes the problem of keeping them alive in the desert.  Dehydration as well as numerous poisonous creatures present a serious threat to inexperienced volunteers.  Gather the supplies necessary for a desert survival kit and bring them to Calandrath in Cenarion Hold.]],
[[S příchodem nových rekrutů do Cenarion Hold přichází problém, jak je udržet naživu v poušti. Dehydratace i množství jedovatých tvorů představují pro nezkušené dobrovolníky vážnou hrozbu. Shromáždi zásoby pro pouštní sadu na přežití a dones je Calandrathovi v Cenarion Hold.]],
[[Bring 4 Globes of Water, 4 Powerful Anti-Venom and 4 Smoked Desert Dumplings to Calandrath at the inn in Cenarion Hold in Silithus.  You must also bring Logistics Task Briefing I in order to complete this quest.]],
[[Dones 4 Globes of Water, 4 Powerful Anti-Venom a 4 Smoked Desert Dumplings Calandrathovi v hostinci v Cenarion Hold v Silithus. K dokončení úkolu musíš přinést také Logistics Task Briefing I.]])

add(8310, [[Breaking the Code]],
[[I think I can formulate an elixir that will allow us to more readily decipher the glyphs and language of the silithid and Qiraji! What do I need? Glad you asked! I need brains! More specifically, a brain from each silithid type that inhabit the hives. Bring me brains and Rutgar's work might not be for naught.]],
[[Myslím, že dokážu připravit elixír, který nám usnadní rozluštění znaků a jazyka silithidů a Qiraji! Co potřebuji? Jsem rád, že se ptáš! Potřebuji mozky! Přesněji mozek od každého druhu silithidů obývajícího úly. Přines mi je a Rutgarova práce možná nepřijde nazmar.]],
[[Frankal Stonebridge at Bronzebeard's Encampment in Silithus wants you to recover a Hive'Zora Silithid Brain, Hive'Ashi Silithid Brain, and a Hive'Regal Silithid Brain. Return to Frankal when you have completed this task.]],
[[Frankal Stonebridge v Bronzebeard's Encampment v Silithus chce, abys získal Hive'Zora Silithid Brain, Hive'Ashi Silithid Brain a Hive'Regal Silithid Brain. Po splnění úkolu se vrať k Frankalovi.]])

add(8735, [[The Nightmare's Corruption]],
[[You must travel to the four dream portals of Azeroth. From each you must draw a fragment of the Nightmare's corruption. The dragonkin that inhabit these areas will hold such fragments. Return to me when you have gathered these fragments.]],
[[Musíš navštívit čtyři snové portály Azerothu. Z každého musíš získat fragment zkaženosti Nightmare. Takové fragmenty mají dračí bytosti obývající tato místa. Až je všechny shromáždíš, vrať se ke mně.]],
[[Travel to the four Emerald Dream portals in Azeroth and collect a Fragment of the Nightmare's Corruption from each. Return to Keeper Remulos in the Moonglade when you have completed this task.$B]],
[[Navštiv čtyři portály Emerald Dream v Azerothu a u každého získej Fragment of the Nightmare's Corruption. Po splnění úkolu se vrať ke Keeperovi Remulosovi v Moonglade.$B]])

add(1428, [[Continued Threat]],
[[It pleases me to see your hatred for the fish men grows with mine.$B$BFind more of their kind along the beach, and when you've had your fill of combat, return to me. We shall speak then of a reward for your diligence.]],
[[Těší mě, že tvá nenávist k rybím lidem roste spolu s mou.$B$BNajdi další z jejich druhu podél pobřeží a až budeš mít boje dost, vrať se ke mně. Pak si promluvíme o odměně za tvou píli.]],
[[Kill 10 Marsh Inkspewers, 10 Marsh Flesheaters, and 10 Marsh Oracles, then return to Katar in the Swamp of Sorrows.]],
[[Zabij 10 Marsh Inkspewers, 10 Marsh Flesheaters a 10 Marsh Oracles a potom se vrať ke Katarovi v Swamp of Sorrows.]])

add(5217, [[Return to Chillwind Camp]],
[[You fill the bottle with enough of the cauldron's poisonous concoction for a suitable sample to be studied.$B$BWith the poison in hand, it is time to return to High Priestess MacDonnell at Chillwind Camp to complete the mission.]],
[[Naplníš láhev dostatečným množstvím jedovatého odvaru z kotle, aby posloužil jako vzorek k výzkumu.$B$BS jedem v ruce je čas vrátit se k High Priestess MacDonnell do Chillwind Camp a dokončit misi.]],
[[Bring the Filled Felstone Field Bottle to High Priestess MacDonnell at Chillwind Camp, Western Plaguelands.]],
[[Dones Filled Felstone Field Bottle High Priestess MacDonnell do Chillwind Camp v Western Plaguelands.]])

add(5232, [[Return to the Bulwark]],
[[You carefully fill the bottle with enough of the cauldron's ichors for what you consider to be suitably sized sample.$B$BWith the poison in hand, it is time to return to Shadow Priestess Vandis at the Bulwark to complete the mission.]],
[[Opatrně naplníš láhev dostatečným množstvím výměšků z kotle, aby vznikl vhodně velký vzorek.$B$BS jedem v ruce je čas vrátit se k Shadow Priestess Vandis do Bulwarku a dokončit misi.]],
[[Bring the Filled Dalson's Tears Bottle to Shadow Priestess Vandis at the Bulwark, Western Plaguelands.]],
[[Dones Filled Dalson's Tears Bottle Shadow Priestess Vandis do Bulwarku v Western Plaguelands.]])

add(8424, [[War on the Shadowsworn]],
[[The continued presence of the shadowsworn in the Blasted Lands bring great pain to me.  Their dark rituals and spells cause agony unlike any I felt while alive.$b$bThrough you I can deliver my own message of pain.  Go forth and deliver my wrath.]],
[[Trvalá přítomnost Shadowsworn v Blasted Lands mi působí velikou bolest. Jejich temné rituály a kouzla způsobují muka, jaká jsem za života nepoznal.$b$bSkrze tebe jim mohu poslat vlastní poselství bolesti. Vydej se a doruč jim můj hněv.]],
[[Slaughter the Shadowsworn in the Blasted Lands and return to the Fallen Hero of the Horde.]],
[[Pobij Shadowsworn v Blasted Lands a vrať se k Fallen Hero of the Horde.]])

add(9227, [[Superior Armaments of Battle - Exalted Amongst the Dawn]],
[[Greetings, friend. Have you insignias of the Dawn or the Crusade that you would like to redeem for items of power?$B$BItems offered to those exalted amongst the Dawn are discounted. I encourage you to make a purchase!]],
[[Zdravím, příteli. Máš insignie Dawn nebo Crusade, které bys chtěl směnit za mocné předměty?$B$BTi, kdo mají u Dawn reputaci Exalted, nakupují se slevou. Doporučuji toho využít!]],
[[For 6 Insignias of the Dawn and 6 Insignias of the Crusade you may choose an item from the Argent Dawn's treasure cache.]],
[[Za 6 Insignias of the Dawn a 6 Insignias of the Crusade si můžeš vybrat předmět z pokladnice Argent Dawn.]])

add(8543, [[The Horde Needs More Tin Bars!]],
[[Very good, I see that you are serious about the war. I'm a little edgy waiting for it to start though, which means I'm going to get angry if you don't start bringing in the goods faster. Maybe I can just practice on you instead.$B$BHar! Maybe not, 'cuz then who would bring me back the tin bars?]],
[[Výborně, vidím, že válku bereš vážně. Z čekání na její začátek jsem ale trochu nervózní, takže se naštvu, pokud nezačneš nosit zásoby rychleji. Možná bych si mohl zacvičit na tobě.$B$BHa! Raději ne, kdo by mi pak nosil cínové pruty?]],
[[Bring 20 tin bars to Grunt Maug in Durotar.]],
[[Dones 20 cínových prutů Gruntovi Maugovi v Durotar.]])

add(2992, [[The Divination]],
[[Give me room while I perform a ritual of divination.  I will find the connection between the feather you brought me and its owner, and follow that connection to Sharpbeak himself.$B$BThat is... I will if all goes according to plan.  If it does not, then... you better close your eyes.]],
[[Dej mi prostor, zatímco provedu věštecký rituál. Najdu spojení mezi perem, které jsi přinesl, a jeho majitelem a po této stopě se dostanu až k Sharpbeakovi.$B$BTedy... pokud všechno půjde podle plánu. Jestli ne, pak... raději zavři oči.]],
[[Wait until Grimshade performs the ritual of divination.]],
[[Počkej, až Grimshade dokončí věštecký rituál.]])

add(4970, [[Frostsaber Provisions]],
[[If you wish to prove yourself, you may begin by doing a very simple, but very important task.$B$BGather meat from the chimaera and from the shardtooth bears in the area. Bring it to me so that I may use it to feed the frostsabers that are being trained.]],
[[Pokud se chceš osvědčit, můžeš začít velmi jednoduchým, ale důležitým úkolem.$B$BNasbírej maso z chimér a medvědů Shardtooth v okolí. Dones mi ho, abych jím mohl krmit cvičené Frostsabery.]],
[[Collect 5 Shardtooth Meats and 5 Chillwind Meats for Rivern Frostwind in Winterspring.]],
[[Nasbírej 5 Shardtooth Meats a 5 Chillwind Meats pro Rivern Frostwinda ve Winterspring.]])

add(8369, [[Invaders of Alterac Valley]],
[[Listen up, $N.  No matter what you might have heard about the battle raging in Alterac Valley, one thing remains true: the Stormpike Expedition invaded Frostwolf Territory.  The day we allow the Alliance to invade Horde lands without a forceful response is the day I hang up my axe and live the rest of my life in shame.  Go forth and expel the invaders!]],
[[Poslouchej, $N. Ať jsi o bitvě v Alterac Valley slyšel cokoli, jedna věc zůstává pravdou: Stormpike Expedition vpadla na území Frostwolf. Den, kdy dovolíme Alianci napadnout země Hordy bez tvrdé odpovědi, bude dnem, kdy odložím sekeru a zbytek života prožiji v hanbě. Vyraz a vyžeň vetřelce!]],
[[Bring 3 Alterac Valley Marks of Honor to a Horde Warbringer outside the battlegrounds.]],
[[Dones 3 Alterac Valley Marks of Honor Horde Warbringerovi před bojištěm.]])

add(5236, [[Return to the Bulwark]],
[[You carefully close the spigot in the control panel, watching the cauldron's putrid ichors drip into the empty bottle.$B$BWith the poison in hand, it is time to return to Shadow Priestess Vandis at the Bulwark to complete the mission.]],
[[Opatrně zavřeš kohout na ovládacím panelu a sleduješ, jak odporný obsah kotle stéká do prázdné láhve.$B$BS jedem v ruce je čas vrátit se k Shadow Priestess Vandis do Bulwarku a dokončit misi.]],
[[Bring the Filled Gahrron's Withering Bottle to Shadow Priestess Vandis at the Bulwark, Western Plaguelands.]],
[[Dones Filled Gahrron's Withering Bottle Shadow Priestess Vandis do Bulwarku v Western Plaguelands.]])

add(8413, [[Da Voodoo]],
[[The spirit totem just isn't enough.  We be needin' some voodoo magic to make it work jus' right.$b$bThe trolls in the sunken temple have feathers strong with voodoo magics.  Go there and kill Gasher, Mijan, Zolo, Hukku, Zul'lor, and Loro.  Then we have magic enough for a real spirit totem.]],
[[Samotný spirit totem nestačí. Potřebujem trochu voodoo magie, aby fungoval, jak má.$b$bTrollové v potopeném chrámu mají pera silná voodoo magií. Jdi tam a zabij Gashera, Mijana, Zola, Hukkua, Zul'lora a Lora. Pak budem mít dost magie na opravdový spirit totem.]],
[[Bring the voodoo feathers to Bath'rah the Windwatcher.]],
[[Dones voodoo feathers Bath'rahovi the Windwatcherovi.]])

add(8586, [[Dirge's Kickin' Chimaerok Chops]],
[[My recipe is complete! What I need from you now is some rocket fuel and deeprock salt. I'll handle the spices and the meat you brought me will cover the rest.$B$BAfter you bring me what I asked for, the chicken will be ready to take back to Narain.]],
[[Můj recept je hotový! Teď od tebe potřebuji trochu raketového paliva a Deeprock Salt. Koření zařídím sám a maso, které jsi přinesl, pokryje zbytek.$B$BAž mi přineseš, co jsem chtěl, kuře bude připravené k odnesení Narainovi.]],
[[Dirge Quikcleave in Gadgetzan wants you to bring him 20 Goblin Rocket Fuel and 20 Deeprock Salt.]],
[[Dirge Quikcleave v Gadgetzan chce, abys mu přinesl 20 Goblin Rocket Fuel a 20 Deeprock Salt.]])

add(9228, [[Epic Armaments of Battle - Exalted Amongst the Dawn]],
[[Greetings, friend. Have you insignias of the Dawn or the Crusade that you would like to redeem for items of great power?$B$BThose exalted amongst the Dawn receive our greatest discounts! I encourage you to make a purchase.]],
[[Zdravím, příteli. Máš insignie Dawn nebo Crusade, které bys chtěl směnit za předměty veliké moci?$B$BTi, kdo mají u Dawn reputaci Exalted, dostávají naše největší slevy! Doporučuji toho využít.]],
[[For 27 Insignias of the Dawn and 27 Insignias of the Crusade you may choose an item from the Argent Dawn's treasure cache.]],
[[Za 27 Insignias of the Dawn a 27 Insignias of the Crusade si můžeš vybrat předmět z pokladnice Argent Dawn.]])

add(1700, [[Grimand Elmore]],
[[I made a copy of my notes on the techniques I learned while making your armor, and I need them sent to Grimand Elmore.  He's here in the Dwarven District, in the weapon shop.$B$BAnd duck when you give these to him.  He's fiercely proud of his skills, and won't like the idea of learning something from me...]],
[[Pořídil jsem kopii svých poznámek o postupech, které jsem se naučil při výrobě tvé zbroje, a potřebuji je doručit Grimandu Elmorovi. Je tady v Dwarven District, v obchodě se zbraněmi.$B$BAž mu je budeš předávat, raději se sehni. Na své schopnosti je nesmírně pyšný a představa, že se ode mě něco naučí, se mu líbit nebude...]],
[[Bring Furen's Notes to Grimand Elmore.]],
[[Dones Furenovy poznámky Grimandu Elmorovi.]])

add(5220, [[Return to Chillwind Camp]],
[[You carefully fill the bottle with enough of the cauldron's ichors for what you consider to be suitably sized sample.$B$BWith the poison in hand, it is time to return to High Priestess MacDonnell at Chillwind Camp to complete the mission.]],
[[Opatrně naplníš láhev dostatečným množstvím výměšků z kotle, aby vznikl vhodně velký vzorek.$B$BS jedem v ruce je čas vrátit se k High Priestess MacDonnell do Chillwind Camp a dokončit misi.]],
[[Bring the Filled Dalson's Tears Bottle to High Priestess MacDonnell at Chillwind Camp, Western Plaguelands.]],
[[Dones Filled Dalson's Tears Bottle High Priestess MacDonnell do Chillwind Camp v Western Plaguelands.]])

add(1947, [[Journey to the Marsh]],
[[Now it is time for you to earn your mage's wand.  To begin this quest, speak with the human hermit Tabetha in Dustwallow Marsh.  You will find her shack deep in the marsh, west of Theramore.$B$BSpeak with her, for her knowledge is vast.  You will find Tabetha's cottage west of Theramore, and just north of the Stonemaul Ruins.]],
[[Teď nastal čas získat svou mágovskou hůlku. Nejprve promluv s lidskou poustevnicí Tabetou v Dustwallow Marsh. Její chatrč najdeš hluboko v močálu západně od Theramore.$B$BPromluv s ní, její znalosti jsou rozsáhlé. Tabetinu chatu najdeš západně od Theramore, těsně severně od Stonemaul Ruins.]],
[[Speak with Tabetha.]],
[[Promluv si s Tabetou.]])

add(9025, [[Morgan's Discovery]],
[[Well, I'll be. It looks like Aristan might be on to something after all. I found traces of substances used in love potions and insidious mind-altering draughts.$b$bIt isn't unheard of for perfumes to have some of them, but a few of the ingredients I detected... Smells funny.]],
[[No podívejme. Zdá se, že Aristan přece jen na něco narazil. Našel jsem stopy látek používaných v nápojích lásky a zákeřných lektvarech ovlivňujících mysl.$b$bNěkteré se v parfémech občas vyskytují, ale pár přísad, které jsem odhalil... To nevoní dobře.]],
[[Return to Aristan Mottar outside the bank in Stormwind's Trade District.]],
[[Vrať se k Aristanu Mottarovi před bankou v Trade District ve Stormwindu.]])

add(9063, [[Torwa Pathfinder]],
[[A hunter by the name of Torwa Pathfinder has requested the help of a druid.  He said only we would possess the necessary skills and respect for nature to help him.$b$bThere is a road that connects the Un'Goro Crater and the desert of Tanaris.  As that road enters the crater, you will find Torwa close by.]],
[[Lovec jménem Torwa Pathfinder požádal o pomoc druida. Tvrdí, že jen my máme potřebné schopnosti a úctu k přírodě, abychom mu mohli pomoci.$b$bUn'Goro Crater a poušť Tanaris spojuje cesta. Když vstoupí do kráteru, najdeš Torwu nedaleko.]],
[[Speak with Torwa Pathfinder in Un'Goro Crater.]],
[[Promluv si s Torwa Pathfinderem v Un'Goro Crater.]])

add(2318, [[Translating the Journal]],
[[At an impasse of sorts, you know that you will need the book translated into a language you can understand.  There certainly are a number of people in the world who could do it; the closest location that might have someone who could, however, is the Kargath outpost in the Badlands.  Perhaps that is a good place to start.$B]],
[[Dostal ses do slepé uličky a víš, že potřebuješ knihu přeložit do jazyka, kterému rozumíš. Na světě jistě existuje několik lidí, kteří to dokážou; nejbližším místem, kde by někdo takový mohl být, je však stanoviště Kargath v Badlands. Možná je dobré začít právě tam.$B]],
[[Find someone who can translate the paladin's journal.  The closest location that might have someone is Kargath, in the Badlands.]],
[[Najdi někoho, kdo dokáže přeložit paladinův deník. Nejbližším místem, kde by někdo takový mohl být, je Kargath v Badlands.]])

add(6604, [[Enraged Wildkin]],
[[Have you noticed the abandoned camp to the south of here? It looks like the wildkin went crazy and destroyed just about everything they could find!$B$BI heard a rumor that one of the survivors of the attack is resting at Starfall Village, west of here. I'm sure curious about what happened... aren't you?]],
[[Všiml sis opuštěného tábora jižně odsud? Vypadá to, že se Wildkin zbláznili a zničili skoro všechno, co našli!$B$BSlyšel jsem, že jeden z přeživších útoku odpočívá ve Starfall Village západně odsud. Docela by mě zajímalo, co se stalo... tebe ne?]],
[[Speak with Jaron Stoneshaper at Starfall Village.]],
[[Promluv si s Jaronem Stoneshaperem ve Starfall Village.]])

add(4769, [[Vivian Lagrave and the Darkstone Tablet]],
[[Vivian Lagrave sent me word from Kargath, in the Badlands.  Through her studies, she believes there is an ancient text within Blackrock Spire that would benefit our research.  To confirm this, she will need someone to extract the text from the spire.  No easy task.$B$BIf interested, then speak with Vivian in Kargath.]],
[[Vivian Lagrave mi poslala zprávu z Kargathu v Badlands. Na základě svého výzkumu se domnívá, že v Blackrock Spire je starobylý text, který by mohl pomoci našemu bádání. Aby to potvrdila, potřebuje někoho, kdo text ze Spire získá. Nebude to snadné.$B$BPokud tě to zajímá, promluv si s Vivian v Kargathu.]],
[[Speak with Shadowmage Vivian Lagrave.]],
[[Promluv si se Shadowmage Vivian Lagrave.]])

add(8929, [[In Search of Anthion]],
[[Well, nothing left for us to do but try out the goblin's invention.  Word has it that Anthion was mowed down by the undead legions of Stratholme as he tried to enter its gates.$B$BTry using the device there and find out whatever Anthion knew.]],
[[Nezbývá nám nic jiného než vyzkoušet goblinův vynález. Říká se, že Anthiona pobily nemrtvé legie Stratholme, když se pokusil projít branou.$B$BVyzkoušej tam zařízení a zjisti, co Anthion věděl.]],
[[Use the Extra-Dimensional Ghost Revealer at the entrance to Stratholme and speak with the ghost of Anthion Harmon.]],
[[Použij Extra-Dimensional Ghost Revealer u vchodu do Stratholme a promluv si s duchem Anthiona Harmona.]])

add(3844, [[It's a Secret to Everybody]],
[[A destroyed raft rests along the shoreline. Considering this is only a small pond, it is not clear as to how it ended up here, although looking at the trees tells you that the water level may not be constant.$B$BPerhaps a little exploration in the area might uncover more clues...]],
[[U břehu leží zničený vor. Vzhledem k tomu, že jde jen o malý rybník, není jasné, jak se sem dostal, i když podle stromů se zdá, že hladina vody nemusí být vždy stejná.$B$BMožná další průzkum okolí odhalí více stop...]],
[[Look around in the pond for a clue about who this wrecked raft may belong to.]],
[[Prohledej okolí rybníka a najdi stopu, komu mohl zničený vor patřit.]])

add(4863, [[Enraged Wildkin]],
[[Looking around, you don't see much that Jaron could want here. However, you do notice that the crate you found has been smashed open, almost as if this was what the wildkin were after...$B$BLooking to the east, you can barely make out an abandoned wagon. Perhaps you might find Jaron's things there. It's worth a look.]],
[[Když se rozhlédneš, nevidíš tu nic, co by Jaron mohl chtít. Všimneš si však, že nalezená bedna byla rozbitá, skoro jako by právě po ní Wildkin šli...$B$BNa východě sotva rozeznáš opuštěný vůz. Možná tam najdeš Jaronovy věci. Stojí za to se podívat.]],
[[Find Jaron Stoneshaper's wrecked wagon.]],
[[Najdi zničený vůz Jarona Stoneshapera.]])

add(4882, [[Guarding Secrets]],
[[You are unsure of the significance of the necklace that fell from the neck of the recently-slain wildkin. It glows brightly, slowly fading in and out.$B$BTrull Failbane might be able to tell you more, since his knowledge of the wildkin seems extensive. Perhaps you should ask him about it.]],
[[Nevíš, jaký význam má náhrdelník, který spadl z krku právě zabitého Wildkin. Jasně září a jeho světlo pomalu sílí a slábne.$B$BTrull Failbane by mohl vědět víc, protože jeho znalosti Wildkin jsou rozsáhlé. Možná by ses ho měl zeptat.]],
[[Take the Blue-feathered Necklace to Trull Failbane at Bloodvenom Post.]],
[[Dones Blue-feathered Necklace Trullu Failbaneovi v Bloodvenom Post.]])

add(4490, [[Summon Felsteed]],
[[I would give you a reward for your patience and hard work. But know this, the ability to summon a Felsteed will be much more difficult in the future. You will have to earn it... and it will not be easy.$B$BFor now, go with the power to summon such a creature and use it as you see fit.]],
[[Za tvou trpělivost a tvrdou práci ti dám odměnu. Ale věz, že schopnost vyvolat Felsteeda bude v budoucnu mnohem těžší získat. Budeš si ji muset zasloužit... a nebude to snadné.$B$BProzatím přijmi moc takového tvora vyvolat a používej ji, jak uznáš za vhodné.]],
[[Speak to Strahad Farsan in Ratchet to learn the ability to summon a Felsteed.]],
[[Promluv si se Strahadem Farsanem v Ratchet a nauč se schopnost vyvolat Felsteeda.]])

add(3042, [[Troll Temper]],
[[The Sandfury trolls of Zul'Farrak make a tempering agent from sandstones, and I can use that to temper the goods I craft, yes I can!  It is highly prized by connoisseurs, so if you bring me a good supply of the temper, then I'll reward you well.$B$BZul'Farrak is northwest of Gadgetzan.  Good luck.]],
[[Sandfury trollové ze Zul'Farrak vyrábějí ze sandstone zvláštní kalidlo a já ho mohu použít při kalení svých výrobků, ano! Znalci si ho velmi cení, takže když mi přineseš pořádnou zásobu, dobře tě odměním.$B$BZul'Farrak leží severozápadně od Gadgetzanu. Hodně štěstí.]],
[[Bring 20 Vials of Troll Temper to Trenton Lighthammer in Gadgetzan.]],
[[Dones 20 Vials of Troll Temper Trentonovi Lighthammerovi v Gadgetzanu.]])

add(2988, [[Witherbark Cages]],
[[The son of our mightiest gryphon is gone! Swiftwing's heir, Sharpbeak, was lost while hunting with his parents a few days ago, and we believe it was the trolls who took him.$B$BYou must aid us!  Search the cages in the two Witherbark troll villages to see if Sharpbeak is there.]],
[[Syn našeho nejmocnějšího gryfona zmizel! Sharpbeak, dědic Swiftwinga, se před několika dny ztratil při lovu se svými rodiči a věříme, že ho unesli trollové.$B$BMusíš nám pomoci! Prohledej klece ve dvou vesnicích trollů Witherbark a zjisti, zda tam Sharpbeak je.]],
[[Check the cages at the two Witherbark villages, then return to Gryphon  Master Talonaxe.]],
[[Prohledej klece ve dvou vesnicích Witherbark a potom se vrať ke Gryphon Master Talonaxe.]])

add(8410, [[Elemental Mastery]],
[[Bath'rah the Windwatcher has sent out a summons for a shaman of your wisdom.  He requests you bring a sample of each of the elements to show you are ready.$b$bTo find Bath'rah, go to the river east of Tarren Mill.  Follow the river north until you come across the ruins where Bath'rah resides.]],
[[Bath'rah the Windwatcher vyslal výzvu pro shamana s tvou moudrostí. Žádá, abys přinesl vzorek každého živlu a dokázal, že jsi připraven.$b$bBath'raha najdeš tak, že zamíříš k řece východně od Tarren Mill a budeš ji sledovat na sever až k ruinám, kde sídlí.]],
[[Collect a sample of air, fire, earth and water for Bath'rah the Windwatcher.]],
[[Nasbírej vzorek vzduchu, ohně, země a vody pro Bath'rah the Windwatchera.]])

add(5123, [[The Final Piece]],
[[The log you found on the high chief looks extensive, but after looking through a couple of the pages, you find that you cannot read the text. The markings are so crude and poorly-formed that you are not sure if anyone would be able to read them.$B$BBut perhaps Donova will be able to tell you what it says... ]],
[[Deník, který jsi našel u náčelníka, vypadá obsáhle, ale po prolistování několika stran zjistíš, že text nedokážeš přečíst. Znaky jsou tak hrubé a špatně vytvořené, že si nejsi jistý, zda je vůbec někdo rozluští.$B$BMožná však Donova dokáže zjistit, co v něm stojí... ]],
[[Bring the Crudely-written Log to Donova Snowden in Winterspring.]],
[[Dones Crudely-written Log Donově Snowden ve Winterspring.]])

add(4968, [[Knowledge of the Orb of Orahil]],
[[Hmm, you've made it this far... truly astonishing. I would have thought the corruption of channeling the arcane would have seeped into your very soul and driven you mad by now. How about we try and push you further then?$B$BIf you want to test your skill, seek out Menara Voidrender above Ratchet in Strahad's tower. She will guide you.]],
[[Hmm, dostal ses až sem... skutečně pozoruhodné. Myslel jsem, že zkaženost z usměrňování arkánní energie už prosákne do tvé duše a připraví tě o rozum. Co kdybychom tě tedy zkusili posunout ještě dál?$B$BChceš-li prověřit své schopnosti, vyhledej Menaru Voidrender nad Ratchet ve Strahadově věži. Povede tě.]],
[[Speak to Menara Voidrender in the Barrens.]],
[[Promluv si s Menarou Voidrender v Barrens.]])

add(8348, [[Signet of the Dukes]],
[[Huum tells me you've figured out how to summon the Abyssal Dukes!  That's quite an accomplishment.$B$BYou know what else would be quite the accomplishment?  Smashing up one of those things really good.  That'll cause an impression on their underlings, if you know what I mean.  Bring back its signet as proof of the deed.]],
[[Huum mi říká, že jsi přišel na to, jak vyvolat Abyssal Dukes! To je slušný úspěch.$B$BVíš, co by byl ještě větší úspěch? Jednoho z nich pořádně rozdrtit. To na jejich podřízené udělá dojem, jestli víš, co tím myslím. Dones jeho pečetní prsten jako důkaz.]],
[[Bring the Abyssal Signet to Bor Wildmane in Cenarion Hold.]],
[[Dones Abyssal Signet Borovi Wildmaneovi v Cenarion Hold.]])

add(7064, [[Corruption of Earth and Seed]],
[[Deep in Maraudon lives an evil creature of chaos--Princess Theradras is an elemental force of earth related to the Old Gods. Ages ago, she and Zaetar, first son of Cenarius, began a relationship. The offspring of their time together became known to the people of Kalimdor as centaur. Ever-thankful creatures, the centaur killed Zaetar, and now hold Zaetar's remains. My quest here is to find those powerful enough to slay Theradras so we may recover Zaetar's remains before returning to Stonetalon.]],
[[Hluboko v Maraudon žije zlá bytost chaosu -- Princess Theradras je elementární silou země spojenou s Old Gods. Před věky navázala vztah se Zaetarem, prvním synem Cenaria. Potomci jejich spojení se lidem Kalimdoru stali známí jako kentauři. Tito „vděční“ tvorové Zaetara zabili a nyní drží jeho ostatky. Mým úkolem je najít někoho dost mocného, aby Theradras zabil, a my mohli získat Zaetarovy ostatky před návratem do Stonetalon.]],
[[Slay Princess Theradras and return to Selendra near Shadowprey Village in Desolace.]],
[[Zabij Princess Theradras a vrať se k Selendře poblíž Shadowprey Village v Desolace.]])

add(8997, [[Back to the Beginning]],
[[I suppose that this is goodbye then, my friend. But, I'll always be here if you want to come back and talk with me from time to time. Probably while you're loitering around waiting for your buddies to join you for a raid on Blackrock Spire.$B$BGo, before I start to cry. Go back to Deliana in Ironforge and tell her what's happened.]],
[[Takže je asi čas se rozloučit, příteli. Ale vždy tu budu, pokud se budeš chtít občas vrátit a promluvit si. Třeba když budeš čekat, až se k tobě přidají kamarádi na výpravu do Blackrock Spire.$B$BJdi, než se rozpláču. Vrať se k Delianě v Ironforge a řekni jí, co se stalo.]],
[[Speak with Deliana at The High Seat in Ironforge.]],
[[Promluv si s Delianou v The High Seat v Ironforge.]])

add(7627, [[Wheel of the Black March]],
[[A Wheel of the Black March contains and directs the violent energies required for the Circle of Greater Summoning.  For Gozeeki to construct a wheel, he will need both large brilliant shards from an enchanter, and dark iron ore from a master miner.$B$BAcquire these and bring them to my servant.]],
[[Wheel of the Black March obsahuje a usměrňuje prudké energie potřebné pro Circle of Greater Summoning. Aby Gozeeki kolo vyrobil, bude potřebovat velké brilliant shards od enchantera a dark iron ore od mistra horníka.$B$BZískej je a dones mému služebníkovi.]],
[[Bring 6 Large Brilliant Shards and 25 Dark Iron Ore to Gorzeeki in the Burning Steppes.]],
[[Dones 6 Large Brilliant Shards a 25 Dark Iron Ore Gorzeekimu v Burning Steppes.]])

add(8534, [[Hive'Zora Scout Report]],
[[We've sent our best scouts deep into the silithid hives to gather intelligence.  Scout Azenel has been watching the silithid movements at Hive'Zora for several days now.  Find her and obtain a written report.  We need to be able to act on that information as soon as possible, $N.]],
[[Vyslali jsme nejlepší zvědy hluboko do silithidských úlů, aby získali informace. Scout Azenel už několik dní sleduje pohyb silithidů v Hive'Zora. Najdi ji a získej písemnou zprávu. Musíme podle těchto informací jednat co nejdříve, $N.]],
[[Contact Cenarion Scout Azenel inside Hive'Zora and return the Hive'Zora Scout Report to Windcaller Proudhorn at Cenarion Hold.  You must also bring Tactical Task Briefing VI in order to complete this quest.]],
[[Najdi Cenarion Scout Azenel uvnitř Hive'Zora a dones Hive'Zora Scout Report Windcallerovi Proudhornovi v Cenarion Hold. K dokončení úkolu musíš přinést také Tactical Task Briefing VI.]])

add(8739, [[Hive'Ashi Scout Report]],
[[We've sent our best scouts deep into the silithid hives to gather intelligence.  Scout Jalia has been watching the silithid movements at Hive'Ashi for several days now.  Find her and obtain a written report.  We need to be able to act on that information as soon as possible, $N.]],
[[Vyslali jsme nejlepší zvědy hluboko do silithidských úlů, aby získali informace. Scout Jalia už několik dní sleduje pohyb silithidů v Hive'Ashi. Najdi ji a získej písemnou zprávu. Musíme podle těchto informací jednat co nejdříve, $N.]],
[[Contact Cenarion Scout Jalia inside Hive'Ashi and return the Hive'Ashi Scout Report to Windcaller Proudhorn at Cenarion Hold.  You must also bring Tactical Task Briefing VIII in order to complete this quest.]],
[[Najdi Cenarion Scout Jalia uvnitř Hive'Ashi a dones Hive'Ashi Scout Report Windcallerovi Proudhornovi v Cenarion Hold. K dokončení úkolu musíš přinést také Tactical Task Briefing VIII.]])

add(8980, [[Zinge's Assessment]],
[[This is unexpected. It looks like Fenstad might be on to something after all. I found traces of substances used in mind control potions.$b$bIt isn't unheard of for perfumes to have some of this, but a few of the ingredients I detected... This is serious alchemy, along the abilities of a member of the Royal Apothecary Society.]],
[[Tohle je nečekané. Zdá se, že Fenstad přece jen na něco narazil. Našel jsem stopy látek používaných v lektvarech k ovládání mysli.$b$bNěkteré z nich se v parfémech občas vyskytují, ale pár přísad, které jsem odhalil... Tohle je vážná alchymie, na úrovni člena Royal Apothecary Society.]],
[[Return to Fenstad Argyle outside the bank in the Undercity.]],
[[Vrať se k Fenstadu Argyleovi před bankou v Undercity.]])

add(5165, [[Dousing the Flames of Protection]],
[[Now, you must return to Jaedenar. The braziers are more than likely spread throughout Shadow Hold. Douse each of their flames and the protections the Council has set up will fall for at least a short period of time. I will be waiting for that to happen. When it does, I will look deep within the Hold and try to find out who the head of this beast is. Then, and only then, will we see about attacking them directly.]],
[[Teď se musíš vrátit do Jaedenaru. Ochranné ohniště jsou nejspíš rozmístěné po celém Shadow Hold. Uhas každý z jejich plamenů a ochrana vytvořená Radou alespoň na krátkou dobu padne. Budu na ten okamžik čekat. Jakmile nastane, nahlédnu hluboko do pevnosti a pokusím se zjistit, kdo stojí v čele této bestie. Teprve potom můžeme uvažovat o přímém útoku.]],
[[Using the Purified Moon Well Water, douse the flames of the four braziers of protection within Shadow Hold in Felwood, then return to Greta Mosshoof in the Emerald Sanctuary.]],
[[Pomocí Purified Moon Well Water uhas plameny čtyř ochranných ohnišť uvnitř Shadow Hold ve Felwood a potom se vrať ke Gretě Mosshoof v Emerald Sanctuary.]])

add(7735, [[Pristine Yeti Hide]],
[[You have found a pristine yeti hide that is exceptionally thick and sturdy - more so than even the ones you've seen from the yeti in Rage Scar.$B$BConsidering that Pratt McGrubben at the Feathermoon Stronghold is in the market for yeti hides, this particular one may be of considerable interest to him.]],
[[Našel jsi neporušenou yeti kožešinu, která je mimořádně silná a odolná -- ještě víc než ty, které jsi viděl u yetiů v Rage Scar.$B$BPratt McGrubben ve Feathermoon Stronghold shání yeti kožešiny, takže tahle by ho mohla velmi zajímat.]],
[[Bring the Pristine Yeti Hide to Pratt McGrubben at the Feathermoon Stronghold, Feralas.]],
[[Dones Pristine Yeti Hide Prattovi McGrubbenovi ve Feathermoon Stronghold ve Feralas.]])

add(1846, [[Dragonmaw Shinbones]],
[[To make the brutal leg guards, I need a brace of sturdy shinbones.  The Dragonmaw orcs of the Wetlands have nice, thick shinbones.  I'll need theirs.$B$BBut they must be sturdy.  Be sure to test the shinbones as you collect them.  If you can break them with your bare hands, then they won't be sturdy enough to work with.]],
[[K výrobě brutálních chráničů nohou potřebuji několik pevných holenních kostí. Orkové Dragonmaw ve Wetlands mají pěkně silné kosti. Potřebuji právě jejich.$B$BAle musí být opravdu pevné. Při sběru je zkoušej. Pokud je dokážeš zlomit holýma rukama, nejsou pro mou práci dost dobré.]],
[[Bring 8 Sturdy Dragonmaw Shinbones to Velora Nitely in the Undercity.]],
[[Dones 8 Sturdy Dragonmaw Shinbones Veloře Nitely v Undercity.]])

add(8738, [[Hive'Regal Scout Report]],
[[We've sent our best scouts deep into the silithid hives to gather intelligence.  Scout Landion has been watching the silithid movements at Hive'Regal for several days now.  Find him and obtain a written report.  We need to be able to act on that information as soon as possible, $N.]],
[[Vyslali jsme nejlepší zvědy hluboko do silithidských úlů, aby získali informace. Scout Landion už několik dní sleduje pohyb silithidů v Hive'Regal. Najdi ho a získej písemnou zprávu. Musíme podle těchto informací jednat co nejdříve, $N.]],
[[Contact Cenarion Scout Landion inside Hive'Regal and return the Hive'Regal Scout Report to Windcaller Proudhorn at Cenarion Hold.  You must also bring Tactical Task Briefing VII in order to complete this quest.]],
[[Najdi Cenarion Scout Landiona uvnitř Hive'Regal a dones Hive'Regal Scout Report Windcallerovi Proudhornovi v Cenarion Hold. K dokončení úkolu musíš přinést také Tactical Task Briefing VII.]])

add(2873, [[Stoley's Shipment]],
[[I owe "Sea Wolf" MacKinley in Booty Bay some rum, to settle a bet, but I'm all out of rum!  Captain Cuergo stole my last shipment, and he has it stowed in that walled pirate town to the south.$B$BIf you can find my shipment of rum and return it to me, then I can prove to MacKinley that Kalimdor's booze beats the dirt out of Booty Bay!]],
[[Dlužím „Sea Wolf“ MacKinleymu v Booty Bay trochu rumu kvůli sázce, ale došel mi! Captain Cuergo ukradl mou poslední zásilku a ukryl ji v tom opevněném pirátském městě na jihu.$B$BKdyž mou zásilku rumu najdeš a vrátíš mi ji, dokážu MacKinleymu, že kalimdorský chlast strčí Booty Bay do kapsy!]],
[[Bring Stoley's Shipment to Stoley in Steamwheedle Port.]],
[[Dones Stoley's Shipment Stoleymu ve Steamwheedle Port.]])

add(8495, [[The Alliance Needs More Iron Bars!]],
[[Back so soon? Stop making me re-evaluate my low opinion of you $c, you're making me feel all gooey inside. So, as you can tell we still don't have enough iron bars for all of the weapons, armor, steam tanks and whatnot that need building for the bug hunt. Think you have it in you to bring back another stack of twenty iron bars in between all of those trips to Zul'Gurub, or wherever it is that you kids hang out these days?]],
[[Už jsi zpátky? Přestaň mě nutit přehodnocovat můj nízký názor na tebe, $c, začínám z toho být naměkko. Jak vidíš, pořád nemáme dost železných prutů na všechny zbraně, zbroje, parní tanky a další věci potřebné k lovu brouků. Zvládneš mezi všemi těmi výlety do Zul'Gurub, nebo kam dnes mladí chodí, přinést dalších dvacet železných prutů?]],
[[Bring 20 iron bars to Corporal Carnes at the airfield in Dun Morogh.]],
[[Dones 20 železných prutů Corporalovi Carnesovi na letiště v Dun Morogh.]])

add(2991, [[Nekrum's Medallion]],
[[I'll find out where your gryphon is, but first you have to do something for me.  There's a troll in Zul'Farrak, Nekrum Gutchewer, who possesses a medallion I would very much like to study.  Bring me that Medallion and I'll use my powers to find Sharpbeak.$B$BZul'Farrak is across the ocean to the west, in the desert of Tanaris.]],
[[Zjistím, kde je tvůj gryfon, ale nejdřív pro mě musíš něco udělat. V Zul'Farrak je troll Nekrum Gutchewer, který má medailon, jenž bych velmi rád prozkoumal. Dones mi ho a použiji své schopnosti k nalezení Sharpbeaka.$B$BZul'Farrak leží za oceánem na západě, v poušti Tanaris.]],
[[Bring Nekrum's Medallion to Thadius Grimshade in the Blasted Lands.]],
[[Dones Nekrum's Medallion Thadiusi Grimshadeovi v Blasted Lands.]])

add(9250, [[Frame of Atiesh]],
[[With the frame formed, Atiesh is nearly whole. Only the head and base of the staff are now missing. There is also a minor issue regarding the staff being a conduit for Sargeras's evil.$B$BFind someone that can assist you in locating the remaining pieces and exorcising the evil from the staff.]],
[[Když je kostra vytvořená, Atiesh je téměř celý. Chybí už jen hlavice a spodní část hole. Zůstává také drobný problém: hůl slouží jako vodič Sargerasova zla.$B$BNajdi někoho, kdo ti pomůže vypátrat zbývající části a vyhnat z hole zlo.]],
[[Find someone that will help you in recovering the last two pieces of the staff and ridding it of evil.]],
[[Najdi někoho, kdo ti pomůže získat poslední dvě části hole a zbavit ji zla.]])

add(5234, [[Return to the Bulwark]],
[[You delicately top off the empty bottle; a sample of the foul substance that churns under the platform of the cauldron now oozes back and forth inside the fragile glass container.$B$BWith the poison in hand, it is time to return to Shadow Priestess Vandis at the Bulwark to complete the mission.]],
[[Opatrně doplníš prázdnou láhev. V křehké skleněné nádobě se teď přelévá vzorek odporné látky vířící pod plošinou kotle.$B$BS jedem v ruce je čas vrátit se k Shadow Priestess Vandis do Bulwarku a dokončit misi.]],
[[Bring the Filled Writhing Haunt Bottle to Shadow Priestess Vandis at The Bulwark, Western Plaguelands.]],
[[Dones Filled Writhing Haunt Bottle Shadow Priestess Vandis do Bulwarku v Western Plaguelands.]])

add(5242, [[A Final Blow]],
[[Unfortunately, I see the only way to stop this threat to Felwood is a frontal attack. There are no other ways into Shadow Hold, and I have no means to teleport you inside. The straight path down to the bottom is the only way... and I also know who you should seek out. His name is Fel'dan... Shadow Lord Fel'dan. He is the mortal in power down below... he is the head of the serpent. Kill him and his two succubus servants and return to me. Fel'dan is the one making pacts with the Legion. He must be stopped.]],
[[Bohužel jediný způsob, jak zastavit tuto hrozbu pro Felwood, je čelní útok. Do Shadow Hold nevede jiná cesta a nemám možnost tě teleportovat dovnitř. Přímá cesta dolů je jediná možnost... a také vím, koho musíš hledat. Jmenuje se Fel'dan... Shadow Lord Fel'dan. Je to smrtelník, který tam dole vládne... hlava hada. Zabij ho i jeho dvě služebnice sukuby a vrať se ke mně. Fel'dan uzavírá dohody s Legií. Musí být zastaven.]],
[[Kill Moora and Salia, and bring Shadow Lord Fel'dan's Head to Greta Mosshoof in Felwood.]],
[[Zabij Mooru a Saliu a dones Shadow Lord Fel'dan's Head Gretě Mosshoof ve Felwood.]])

add(8525, [[The Alliance Needs More Rainbow Fin Albacore!]],
[[What! You again? Well I'll be a monkey's uncle... except that I'm a gnome. Slicky Gastronome to be precise! So you're back to help out again eh? Well, I can't say as I blame you. Don't you just love the smell of all of that food? <drool>$B$BEnough loitering! Get out there and bring me back more rainbow fin albacore!]],
[[Cože! Zase ty? No to mě podrž... i když jsem gnóm. Přesněji Slicky Gastronome! Takže ses vrátil znovu pomoct? Ani se ti nedivím. Necítíš tu nádhernou vůni všeho toho jídla? <slint>$B$BDost lelkování! Vyraz a dones mi další Rainbow Fin Albacore!]],
[[Bring 20 rainbow fin albacore to Slicky Gastronome at the airfield in Dun Morogh.]],
[[Dones 20 Rainbow Fin Albacore Slickymu Gastronome na letiště v Dun Morogh.]])

add(8998, [[Back to the Beginning]],
[[I suppose that this is goodbye then, my friend. But, I'll always be here if you want to come back and talk with me from time to time. Probably while you're loitering around waiting for your buddies to join you for a raid on Blackrock Spire.$B$BGo, before I start to cry. Go back to Mokvar in Orgrimmar and tell him what's happened.]],
[[Takže je asi čas se rozloučit, příteli. Ale vždy tu budu, pokud se budeš chtít občas vrátit a promluvit si. Třeba když budeš čekat, až se k tobě přidají kamarádi na výpravu do Blackrock Spire.$B$BJdi, než se rozpláču. Vrať se k Mokvarovi v Orgrimmaru a řekni mu, co se stalo.]],
[[Speak with Mokvar at Grommash Hold in Orgrimmar's Valley of Wisdom.]],
[[Promluv si s Mokvarem v Grommash Hold v Orgrimmar's Valley of Wisdom.]])

add(1467, [[Reagents for Reclaimers Inc.]],
[[To get paid, you're gonna have to get back to Ironforge and speak to Roetten himself. He'll love getting Leftwitch's package out of the way anyway. Just give him this and it should be enough to get your booty.$B$BAnd don't worry, I'm still going to put in a good word for you when I get back. I shouldn't be in Desolace much longer.]],
[[Abys dostal zaplaceno, musíš se vrátit do Ironforge a promluvit si přímo s Roettenem. Bude rád, že konečně vyřídí Leftwitchův balíček. Prostě mu tohle dej a mělo by to stačit k získání odměny.$B$BA neboj, až se vrátím, stejně se za tebe přimluvím. V Desolace už bych neměl být dlouho.]],
[[Bring Leftwitch's Package back to Roetten Stonehammer in Ironforge.]],
[[Dones Leftwitch's Package zpět Roettenovi Stonehammerovi v Ironforge.]])

add(4581, [[Kayneth Stillwind]],
[[The druid Kayneth Stillwind sent word to me.  He would like a report of the happenings along our coast and in the forests surrounding Astranaar.  He fears there is a corruption moving through Ashenvale... and he may be right.$B$BHere, take my report to him.  You will find him in the shrine of Forest Song, in the Nightsong Woods to the east.]],
[[Druid Kayneth Stillwind mi poslal zprávu. Chce hlášení o dění podél našeho pobřeží a v lesích kolem Astranaaru. Obává se, že se Ashenvale šíří zkaženost... a možná má pravdu.$B$BTady, dones mu mou zprávu. Najdeš ho ve svatyni Forest Song v Nightsong Woods na východě.]],
[[Take Shindrell's Note to Kayneth Stillwind in Forest Song.]],
[[Dones Shindrell's Note Kaynethu Stillwindovi ve Forest Song.]])

add(2876, [[Ship Schedules]],
[[This scroll contains the schedules of shipments between Steamwheedle Port and Booty Bay. Both past and future shipments are included, along with ship names, with large 'X's next to some ships' journeys, and annotations like "GREAT LOOT" and "HARD FIGHT" next to others.$B$BSomeone at Steamwheedle Port would want to see this document.]],
[[Tento svitek obsahuje rozpis zásilek mezi Steamwheedle Port a Booty Bay. Jsou tu minulé i budoucí plavby spolu se jmény lodí; u některých tras jsou velká „X“ a u jiných poznámky jako „SKVĚLÁ KOŘIST“ nebo „TĚŽKÝ BOJ“.$B$BNěkdo ve Steamwheedle Port by tento dokument jistě chtěl vidět.]],
[[Report the Ship Schedules to an authority in Steamwheedle Port.]],
[[Dones Ship Schedules některému z představitelů Steamwheedle Port.]])

add(5055, [[Brumeran of the Chillwind]],
[[Swift, and clever, Brumeran glides silently across the snowy landscape of southern Winterspring. But do not let her graceful appearance convince you that she is harmless. All that cross her pay considerably, and often with their own lives.$B$BSeek out Brumeran of the chillwind among the chimera. Defeat her, then return again to me.]],
[[Rychlá a chytrá Brumeran tiše klouže zasněženou krajinou jižního Winterspring. Nenech se však jejím elegantním vzhledem přesvědčit, že je neškodná. Každý, kdo jí zkříží cestu, draze zaplatí -- často vlastním životem.$B$BNajdi Brumeran mezi chimérami Chillwind. Poraz ji a potom se ke mně vrať.]],
[[Storm Shadowhoof at Everlook in Winterspring wants you to kill Brumeran.]],
[[Storm Shadowhoof v Everlook ve Winterspring chce, abys zabil Brumeran.]])

add(6390, [[A Plague Upon Thee]],
[[You look around the lumber mill for something suitable to open the barrel with. You find a crowbar that looks like it will do the trick.$B$BYou set your feet and pray that you'll be able to get out of the mill before the termites get to you.]],
[[Rozhlédneš se po pile po něčem, čím by šel sud otevřít. Najdeš páčidlo, které by mohlo posloužit.$B$BZapřeš se a modlíš se, abys z pily utekl dřív, než se termiti dostanou k tobě.]],
[[Release the Plagueland Termites in the Northridge Lumber Mill, then return with the Barrel of Plagueland Termites to Mickey Levine at the Bulwark in Tirisfal Glades.]],
[[Vypusť Plagueland Termites v Northridge Lumber Mill a potom se s Barrel of Plagueland Termites vrať k Mickeymu Levineovi v Bulwarku v Tirisfal Glades.]])

add(5223, [[Return to Chillwind Camp]],
[[You delicately top off the empty bottle; a sample of the foul substance that churns under the platform of the cauldron now oozes back and forth inside the fragile glass container.$B$BWith the poison in hand, it is time to return to High Priestess MacDonnell at Chillwind Camp to complete the mission.]],
[[Opatrně doplníš prázdnou láhev. V křehké skleněné nádobě se teď přelévá vzorek odporné látky vířící pod plošinou kotle.$B$BS jedem v ruce je čas vrátit se k High Priestess MacDonnell do Chillwind Camp a dokončit misi.]],
[[Bring the Filled Writhing Haunt Bottle to High Priestess MacDonnell at Chillwind Camp, Western Plaguelands.]],
[[Dones Filled Writhing Haunt Bottle High Priestess MacDonnell do Chillwind Camp v Western Plaguelands.]])

add(1484, [[The Corrupter]],
[[This creature is far more dangerous than I had anticipated.  No doubt Takata questions my abilities to take on such a creature, and it would insult his honor if he were not informed about what just happened.$B$BSpeak to the swordsman, tell him you are willing to slay the demon if he would allow it, but do not press too hard. It is better if he thinks it his own idea.]],
[[Tento tvor je mnohem nebezpečnější, než jsem čekal. Takata nepochybně pochybuje o mé schopnosti takovému tvoru čelit a urazilo by jeho čest, kdyby nevěděl, co se právě stalo.$B$BPromluv s šermířem a řekni mu, že jsi ochoten démona zabít, pokud ti to dovolí, ale příliš netlač. Je lepší, když bude mít pocit, že to byl jeho nápad.]],
[[Speak to Takata Steelblade in Desolace.]],
[[Promluv si s Takatou Steelblade v Desolace.]])

add(4245, [[Chasing A-Me 01]],
[[Checking to see if you're prepared to lead A-Me 01 back to Karna Remtravel, you flip the switch to the "Off" position. Glancing around once again to make sure none of the gorillas are coming, you prepare to see what happens when you flip the switch back to the "On" position.$B$BThis is your last chance... are you sure this is what you want to do?]],
[[Když ověřuješ, zda jsi připraven odvést A-Me 01 zpět ke Karna Remtravel, přepneš spínač do polohy „Off“. Ještě jednou se rozhlédneš, zda se neblíží žádná gorila, a připravíš se zjistit, co se stane po přepnutí zpět na „On“.$B$BTohle je poslední možnost... opravdu to chceš udělat?]],
[[Escort A-Me 01 back to Karna Remtravel in Un'Goro Crater.]],
[[Doprovoď A-Me 01 zpět ke Karna Remtravel v Un'Goro Crater.]])

add(4809, [[Chillwind Horns]],
[[I have most of what Tinkee needs, but I'm missing one important component, and that's chillwind horns.  The horns of the chillwind chimaera in Winterspring are a concentrated source of cold, but only pristine, uncracked horns will do!  I'll need a supply of those to complete Tinkee's order.$B$BBring me the uncracked chillwind horns, and I'll prepare a package for Tinkee.]],
[[Mám většinu toho, co Tinkee potřebuje, ale chybí mi jedna důležitá součást: rohy Chillwind. Rohy chillwind chimér ve Winterspring jsou koncentrovaným zdrojem chladu, ale použitelné jsou jen neporušené rohy bez prasklin! Potřebuji jejich zásobu k dokončení Tinkeeiny objednávky.$B$BDones mi neporušené chillwind rohy a připravím balíček pro Tinkee.]],
[[Collect 8 Uncracked Chillwind Horns.]],
[[Nasbírej 8 Uncracked Chillwind Horns.]])

add(5210, [[Brother Carlin]],
[[The Annals of Darrowshire, through my magic, has gained pages at its end, and now it extends its history beyond the battle.  One of the extra passages tells of another Redpath, Carlin, who survived Joseph's betrayal.  Carlin's now in the Plaguelands to the east, at the Light's Hope Chapel.$B$BTake the book and speak with him.]],
[[Annals of Darrowshire díky mé magii získaly nové stránky a jejich historie nyní pokračuje i za bitvu. Jedna z nových pasáží mluví o dalším Redpathovi, Carlinovi, který přežil Josephovu zradu. Carlin je nyní v Plaguelands na východě, v Light's Hope Chapel.$B$BVezmi knihu a promluv s ním.]],
[[Bring the Extended Annals of Darrowshire to Carlin Redpath in Eastern Plaguelands.]],
[[Dones Extended Annals of Darrowshire Carlinovi Redpathovi v Eastern Plaguelands.]])

add(5639, [[Desperate Prayer]],
[[You're needed in Stormwind, $N. The High Priestess there, Laurena, says it's time for you to prove you're worthy of the next level of your training. Don't waste too much time finding your way there. You can find her in the Cathedral of Light in the center of the city. Give her my regards, and prove how worthy you are of such a calling. The Light be with you, $N.]],
[[Potřebují tě ve Stormwindu, $N. Tamní High Priestess Laurena říká, že nastal čas dokázat, že jsi hoden dalšího stupně výcviku. Neztrácej cestou příliš času. Najdeš ji v Cathedral of Light uprostřed města. Pozdravuj ji ode mě a dokaž, že jsi tohoto poslání hoden. Světlo s tebou, $N.]],
[[Speak to High Priestess Laurena in Stormwind.]],
[[Promluv si s High Priestess Laurenou ve Stormwindu.]])

add(7738, [[Perfect Yeti Hide]],
[[You have found what may very well be a perfect yeti hide.  You easily note that it is exceptionally thick and sturdy - more so than even the ones you've seen from the yeti in Rage Scar.$B$BConsidering that Jangdor Swiftstrider at Camp Mojache is in the market for yeti hides, this particular one may be of considerable interest to him.]],
[[Našel jsi kožešinu, která může být skutečně dokonalou yeti kožešinou. Je mimořádně silná a odolná -- ještě víc než ty, které jsi viděl u yetiů v Rage Scar.$B$BJangdor Swiftstrider v Camp Mojache shání yeti kožešiny, takže tahle by ho mohla velmi zajímat.]],
[[Bring the Perfect Yeti Hide to Jangdor Swiftstrider at Camp Mojache, Feralas.]],
[[Dones Perfect Yeti Hide Jangdorovi Swiftstriderovi v Camp Mojache ve Feralas.]])

add(3961, [[Linken's Adventure]],
[[To think all this time that the reason Linken came here was to rid us of Blazerunner... He seems like such an ordinary guy, but I did notice that he's not at all interested in any of my experiments or gadgets like most gnomes would be. He must be a true warrior at heart.$B$BBring the totem to him. See if that helps him remember why he came here.]],
[[Celou dobu byl důvodem Linkenova příchodu sem Blazerunner... Vypadá jako úplně obyčejný chlapík, ale všiml jsem si, že ho vůbec nezajímají moje pokusy ani udělátka, jak by to u většiny gnómů bývalo. V srdci musí být skutečný válečník.$B$BDones mu totem. Uvidíme, jestli mu pomůže vzpomenout si, proč sem přišel.]],
[[Take the Silver Totem of Aquementas to Linken in Marshal's Refuge.]],
[[Dones Silver Totem of Aquementas Linkenovi v Marshal's Refuge.]])

add(8960, [[Bodley's Unfortunate Fate]],
[[So we need to recover the rest of the medallion?  Finding Bodley's going to be a bit of a headache.  He went back to Blackrock Mountain to attempt to re-enter Blackrock Spire and never came back.$B$BI'd suggest taking the goblin's ghost revealing device with you, as I fear the worst might have happened.]],
[[Takže musíme získat zbytek medailonu? Najít Bodleyho nebude snadné. Vrátil se do Blackrock Mountain a pokusil se znovu vstoupit do Blackrock Spire, ale už se nevrátil.$B$BDoporučuji vzít s sebou gobliní zařízení na odhalování duchů, protože se obávám nejhoršího.]],
[[Travel to Blackrock Mountain and use the Extra-Dimensional Ghost Revealer to find Bodley near Blackrock Spire.]],
[[Vydej se do Blackrock Mountain a pomocí Extra-Dimensional Ghost Revealer najdi Bodleyho poblíž Blackrock Spire.]])

add(6389, [[A Plague Upon Thee]],
[[You look around the lumber mill for something suitable to open the barrel with. You find a crowbar that looks like it will do the trick.$B$BYou set your feet and pray that you'll be able to get out of the mill before the termites get to you.]],
[[Rozhlédneš se po pile po něčem, čím by šel sud otevřít. Najdeš páčidlo, které by mohlo posloužit.$B$BZapřeš se a modlíš se, abys z pily utekl dřív, než se termiti dostanou k tobě.]],
[[Release the Plagueland Termites in the Northridge Lumber Mill, then return with the Barrel of Plagueland Termites to Nathaniel Dumah at Chillwind Camp in Western Plaguelands.]],
[[Vypusť Plagueland Termites v Northridge Lumber Mill a potom se s Barrel of Plagueland Termites vrať k Nathanielu Dumahovi v Chillwind Camp v Western Plaguelands.]])

add(8287, [[A Terrible Purpose]],
[[Ok, here we are... a pretty valuable chunk of information, I must say!  I've seen the Cenarion Circle forces arrive at Silithus.  They plan to drive the Twilight's Hammer out, don't they?  This will help.  $B$BTake this parchment to their leader, Commander Mar'alith.  Soon the Twilight's Hammer will be vanquished and I will be outside their grasp for good!]],
[[Dobrá, tady to máme... musím říct, že je to velmi cenná informace! Viděl jsem jednotky Cenarion Circle dorazit do Silithus. Chtějí vyhnat Twilight's Hammer, že ano? Tohle jim pomůže.$B$BDones tento pergamen jejich veliteli, Commanderovi Mar'alithovi. Twilight's Hammer bude brzy poražen a já budu navždy mimo jejich dosah!]],
[[Take the Decoded Tablet Parchment to Commander Mar'alith.]],
[[Dones Decoded Tablet Parchment Commanderovi Mar'alithovi.]])

add(1384, [[Raid on the Kolkar]],
[[The Kolkar centaurs think their magic is strong.  They do not know magic!  They would not know magic if it bit them!$B$BYou will show them their magic is weak.  Go to the Kolkar  to the northeast and kill them.  Take their charms.  Bring me the charms and I will throw them in the fire and laugh!]],
[[Kentauři Kolkar si myslí, že jejich magie je silná. O magii nevědí nic! Nepoznali by ji, ani kdyby je kousla!$B$BUkaž jim, jak je jejich magie slabá. Vydej se ke Kolkarům na severovýchod a zabíjej je. Vezmi jejich amulety. Dones mi je a já je hodím do ohně a budu se smát!]],
[[Maintain your reputation with the Gelkis, and bring 10 Crude Charms to Uthek the Wise in the Gelkis Village in Desolace.]],
[[Udrž si přízeň Gelkisů a dones 10 Crude Charms Uthekovi the Wise v Gelkis Village v Desolace.]])

add(6823, [[Agent of Hydraxis]],
[[If you truly wish an allegiance with us, then I invite you to wage war on our foes, the servants of air and earth and fire.  Each defeat you heap upon them will weaken their foothold here, and further prove your adherence to our cause.$B$BThe campaign will be long, but if you persevere then your glory and honor will be great.]],
[[Pokud s námi skutečně chceš uzavřít spojenectví, vyzývám tě k válce proti našim nepřátelům, služebníkům vzduchu, země a ohně. Každá jejich porážka oslabí jejich postavení a dále prokáže tvou oddanost naší věci.$B$BTažení bude dlouhé, ale pokud vytrváš, čeká tě velká sláva a čest.]],
[[Earn an Honored faction with the Hydraxian Waterlords, then talk to Duke Hydraxis in Azshara.]],
[[Získej u Hydraxian Waterlords reputaci Honored a potom promluv s Duke Hydraxisem v Azshaře.]])

add(8360, [[Dancing for Marzipan]],
[[Even though you're trick-or-treating for a sick child, you still need to perform a trick for the treat!  We can't very well change the tradition, now can we...$B$BI believe the cost of a piece of marzipan nowadays is to bust out and DANCE!  That's right, let me see your moves!  Dance for me, and I'll give you some tasty marzipan!]],
[[I když koleduješ pro nemocné dítě, za sladkost musíš pořád předvést nějaký kousek! Tradici přece nemůžeme jen tak měnit...$B$BMyslím, že cena za kousek marcipánu je dnes prostě TANEC! Přesně tak, ukaž mi, co umíš! Zatanči mi a dám ti chutný marcipán!]],
[[Do a dance emote at Innkeeper Pala, and in exchange you'll receive Thunder Bluff Marzipan!]],
[[Použij taneční emote u Innkeeper Pala a dostaneš za to Thunder Bluff Marzipan!]])

add(8151, [[The Hunter's Charm]],
[[Ogtinc of Azshara has sent out a call for seasoned hunters such as yourself.  He is a furbolg hunter who has left his tribe to aid the Cenarion Circle.  His teachings are meant to enrich the wisdom of others who share his craft, and guide them toward maintaining a balance.  You would do well to speak with him.$b$bOgtinc resides atop the cliffs of Azshara, northeast from the Ruins of Eldarath.]],
[[Ogtinc z Azshary povolává zkušené lovce, jako jsi ty. Je to furbolg lovec, který opustil svůj kmen, aby pomohl Cenarion Circle. Svým učením chce rozšířit moudrost těch, kteří sdílejí jeho řemeslo, a vést je k zachování rovnováhy. Uděláš dobře, když s ním promluvíš.$b$bOgtinc sídlí na útesech Azshary severovýchodně od Ruins of Eldarath.]],
[[Speak to Ogtinc in Azshara.]],
[[Promluv si s Ogtincem v Azshaře.]])

add(8357, [[Dancing for Marzipan]],
[[Even though you're trick-or-treating for a sick child, you still need to perform a trick for the treat!  We can't very well change the tradition, now can we...$B$BI believe the cost of a piece of marzipan nowadays is to bust out and DANCE!  That's right, let me see your moves!  Dance for me, and I'll give you some tasty marzipan!]],
[[I když koleduješ pro nemocné dítě, za sladkost musíš pořád předvést nějaký kousek! Tradici přece nemůžeme jen tak měnit...$B$BMyslím, že cena za kousek marcipánu je dnes prostě TANEC! Přesně tak, ukaž mi, co umíš! Zatanči mi a dám ti chutný marcipán!]],
[[Do a dance emote at Innkeeper Saelienne, and in exchange you'll receive Darnassus Marzipan!]],
[[Použij taneční emote u Innkeeper Saelienne a dostaneš za to Darnassus Marzipan!]])

add(1939, [[High Sorcerer Andromath]],
[[High Sorcerer Andromath wishes to speak with you, $N.  He is at the top of the wizard's sanctum, in the mage's district of Stormwind.$B$BIt would be wise to speak with him, for Andromath is one of the most powerful mages not locked away in Dalaran.  Council with him is high council indeed.]],
[[High Sorcerer Andromath s tebou chce mluvit, $N. Je na vrcholu čarodějné svatyně v mágovské čtvrti Stormwindu.$B$BBylo by moudré s ním promluvit, protože Andromath je jedním z nejmocnějších mágů, kteří nejsou uzavřeni v Dalaranu. Jeho rada má velikou váhu.]],
[[Speak with High Sorcerer Andromath.]],
[[Promluv si s High Sorcerer Andromathem.]])

add(8791, [[The Fall of Ossirian]],
[[A terrible menace has been laid to rest. The cruel Ossirian has been vanquished.$B$BThe denizens of Kalimdor would be relieved to know of this victory. Take Ossirian's head and present it to Commander Mar'alith of Cenarion Hold.]],
[[Strašlivá hrozba byla odstraněna. Krutý Ossirian byl poražen.$B$BObyvatele Kalimdoru zpráva o tomto vítězství uklidní. Vezmi Ossirianovu hlavu a předej ji Commanderovi Mar'alithovi v Cenarion Hold.]],
[[Deliver the Head of Ossirian the Unscarred to Commander Mar'alith at Cenarion Hold in Silithus.$B]],
[[Dones Head of Ossirian the Unscarred Commanderovi Mar'alithovi v Cenarion Hold v Silithus.$B]])

add(1396, [[Encroaching Wildlife]],
[[My caravan was destined for the eastern coast, but we did not reach our goal.  Lost Ones attacked us, killing guards and dashing supplies.$B$BI alone survived their assault.  I have sworn to protect what supplies remain, but wild creatures skulk near.  Please, help me defend my camp from the beasts!]],
[[Má karavana mířila na východní pobřeží, ale cíle jsme nedosáhli. Lost Ones nás napadli, zabili stráže a zničili zásoby.$B$BJejich útok jsem přežil jen já. Přísahal jsem chránit zbytek zásob, ale poblíž se potulují divoká zvířata. Prosím, pomoz mi bránit tábor před bestiemi!]],
[[Kill 8 Young Sawtooth Crocolisks, 10 Sorrow Spinners and 10 Swamp Jaguars then return to Watcher Biggs in the Swamp of Sorrows.]],
[[Zabij 8 Young Sawtooth Crocolisks, 10 Sorrow Spinners a 10 Swamp Jaguars a potom se vrať k Watcherovi Biggsovi v Swamp of Sorrows.]])

add(9120, [[The Fall of Kel'Thuzad]],
[[The phylactery is all that remains of the master of Naxxramas. Your better judgment dictates that you destroy the phylactery, preventing the lich from ever reforming. Thankfully, you seldom listen to that internal voice of reason.$B$BSomeone at Light's Hope will pay you hugely for this artifact. Who cares if Kel'Thuzad regenerates to full power?]],
[[Fylakterium je vše, co z pána Naxxramasu zůstalo. Zdravý rozum ti říká, abys ho zničil a zabránil lichovi v návratu. Naštěstí svůj vnitřní hlas rozumu posloucháš jen zřídka.$B$BNěkdo v Light's Hope za tento artefakt zaplatí jmění. Koho zajímá, že se Kel'Thuzad může znovu vrátit v plné síle?]],
[[Take the Phylactery of Kel'Thuzad to Light's Hope Chapel in the Eastern Plaguelands.]],
[[Dones Phylactery of Kel'Thuzad do Light's Hope Chapel v Eastern Plaguelands.]])

add(7639, [[To Show Due Judgment]],
[[With my blessings, take the censer.  I myself have used it in several exorcisms, and it should serve you well for the arduous tasks that lie ahead.$B$BReturn now to Lord Grayson Shadowbreaker in Stormwind, $N.  Your quest continues with him.]],
[[S mým požehnáním si vezmi kadidelnici. Sám jsem ji použil při několika exorcismech a měla by ti dobře posloužit při náročných úkolech, které tě čekají.$B$BVrať se nyní k Lordu Graysonovi Shadowbreakerovi ve Stormwindu, $N. Tvé poslání pokračuje u něj.]],
[[Return the Exorcism Censer to Lord Grayson Shadowbreaker in the Cathedral District of Stormwind.]],
[[Vrať Exorcism Censer Lordu Graysonovi Shadowbreakerovi v Cathedral District ve Stormwindu.]])

add(6141, [[Brother Anton]],
[[My brother in arms, Brother Anton, heard rumors of an undead infestation in distant Kalimdor, in a land known as Desolace.  Anton immediately booked passage to that place, to seek and destroy the undead menace!$B$BHe is looking for those with the bravery and resolve to aid him.  If your heart is true, then speak with Anton.  He is in Desolace, in the Alliance town of Nijel's Point. ]],
[[Můj bratr ve zbrani, Brother Anton, slyšel zvěsti o záplavě nemrtvých v dalekém Kalimdoru, v zemi zvané Desolace. Anton se tam ihned vydal, aby nemrtvou hrozbu vyhledal a zničil!$B$BHledá odvážné a odhodlané pomocníky. Pokud máš čisté srdce, promluv s Antonem. Je v Desolace, v aliančním městě Nijel's Point. ]],
[[Speak with Brother Anton at Nijel's Point in Desolace.]],
[[Promluv si s Brotherem Antonem v Nijel's Point v Desolace.]])

add(9009, [[Saving the Best for Last]],
[[A truly amazing story, $N! You have my thanks, and the heartfelt gratitude of all who were involved, I can assure you. Through your efforts we are delivered from the mistakes of our past.$B$BAs to your reward, I believe I have a few things that you have definitely earned and will truly enjoy.]],
[[Opravdu úžasný příběh, $N! Máš můj dík a mohu tě ujistit, že i upřímnou vděčnost všech zúčastněných. Díky tvému úsilí jsme se osvobodili od chyb své minulosti.$B$BCo se týče odměny, myslím, že mám několik věcí, které sis rozhodně zasloužil a které tě potěší.]],
[[Give Mokvar your Devout Crown and Devout Robe.]],
[[Dej Mokvarovi svůj Devout Crown a Devout Robe.]])

add(7945, [[Your Fortune Awaits You...]],
[["Your fortune awaits you outside Palemane Rock."$B$BThe fortune Sayge handed you feels slightly warm to the touch.  Grasping it firmly, you see an image of the Palemane Rock of Mulgore.  Focusing closer in on the image, you see a tree stump that sits close to the cave entrance.$B]],
[[„Tvé štěstí na tebe čeká před Palemane Rock.“$B$BVěštba, kterou ti Sayge předal, je na dotek lehce teplá. Když ji pevně sevřeš, spatříš obraz Palemane Rock v Mulgore. Při bližším soustředění uvidíš pařez poblíž vchodu do jeskyně.$B]],
[[Travel to Palemane Rock in Mulgore and seek out your fortune.]],
[[Vydej se k Palemane Rock v Mulgore a najdi své štěstí.]])

add(9154, [[Light's Hope Chapel]],
[[The Scourge have returned in greater numbers than we have seen before.  This must be the doing of the Lich King!  The Argent Dawn is recruiting all willing and capable men and women to defend our lands.$b$bIf we share common cause, take this document to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.]],
[[Scourge se vrátila v počtech větších, než jsme kdy viděli. To musí být dílo Lich Kinga! Argent Dawn verbuje všechny ochotné a schopné muže i ženy k obraně našich zemí.$b$bPokud sdílíš náš cíl, dones tento dokument Keeperovi of the Rolls v Light's Hope Chapel v Eastern Plaguelands.]],
[[Deliver the Call to Arms Announcement to the Keeper of the Rolls at Light's Hope Chapel in the Eastern Plaguelands.]],
[[Dones Call to Arms Announcement Keeperovi of the Rolls v Light's Hope Chapel v Eastern Plaguelands.]])

add(2935, [[Consult Master Gadrin]],
[[The venom from the broodguards wasn't as potent as the venom you brought originally.  It must have come from a different spider.$B$BI want a fresh sample of that venom.  To find out where it came from, you must consult with a troll who knows the Witherbark well--Master Gadrin in Sen'jin Village.  Travel to Durotar and speak with Gadrin.  With luck, he'll know where the Witherbarks get their venom.]],
[[Jed Broodguardů nebyl tak silný jako ten, který jsi přinesl původně. Musel pocházet z jiného pavouka.$B$BChci čerstvý vzorek. Abys zjistil jeho původ, musíš se poradit s trollem, který dobře zná Witherbark -- Master Gadrinem v Sen'jin Village. Vydej se do Durotaru a promluv s Gadrinem. Snad bude vědět, odkud Witherbarkové svůj jed získávají.]],
[[Speak with Master Gadrin in Sen'jin Village.]],
[[Promluv si s Master Gadrinem v Sen'jin Village.]])

add(6161, [[Claim Rackmore's Treasure!]],
[[Rackmore's log tells of how his ship was sailing for Feathermoon Stronghold when it was attacked by seafaring creatures.  To prevent his treasure from falling into enemy hands, he hid his chest on Ranazjar Isle.$B$BTo open the chest requires two keys, a silver and a gold.  These keys were lost, but if the keys and the chest are found, a treasure awaits!]],
[[Rackmoreův deník popisuje, jak jeho loď plula do Feathermoon Stronghold, když ji napadli mořští tvorové. Aby jeho poklad nepadl do rukou nepřítele, ukryl truhlu na Ranazjar Isle.$B$BK otevření jsou potřeba dva klíče, stříbrný a zlatý. Klíče se ztratily, ale pokud je i truhlu najdeš, čeká na tebe poklad!]],
[[Find Rackmore's Silver Key.  Find Rackmore's Golden Key.  Find and open Rackmore's Chest.]],
[[Najdi Rackmore's Silver Key. Najdi Rackmore's Golden Key. Najdi a otevři Rackmore's Chest.]])

add(9007, [[Saving the Best for Last]],
[[A truly amazing story, $N! You have my thanks, and the heartfelt gratitude of all who were involved, I can assure you. Through your efforts we are delivered from the mistakes of our past.$B$BAs to your reward, I believe I have a few things that you have definitely earned and will truly enjoy.]],
[[Opravdu úžasný příběh, $N! Máš můj dík a mohu tě ujistit, že i upřímnou vděčnost všech zúčastněných. Díky tvému úsilí jsme se osvobodili od chyb své minulosti.$B$BCo se týče odměny, myslím, že mám několik věcí, které sis rozhodně zasloužil a které tě potěší.]],
[[Give Mokvar your Wildheart Cowl and Wildheart Vest.]],
[[Dej Mokvarovi svůj Wildheart Cowl a Wildheart Vest.]])

add(9012, [[Saving the Best for Last]],
[[A truly amazing story, $N! You have my thanks, and the heartfelt gratitude of all who were involved, I can assure you. Through your efforts we are delivered from the mistakes of our past.$B$BAs to your reward, I believe I have a few things that you have definitely earned and will truly enjoy.]],
[[Opravdu úžasný příběh, $N! Máš můj dík a mohu tě ujistit, že i upřímnou vděčnost všech zúčastněných. Díky tvému úsilí jsme se osvobodili od chyb své minulosti.$B$BCo se týče odměny, myslím, že mám několik věcí, které sis rozhodně zasloužil a které tě potěší.]],
[[Give Mokvar your Dreadmist Mask and Dreadmist Robe.]],
[[Dej Mokvarovi svůj Dreadmist Mask a Dreadmist Robe.]])

add(4292, [[The Bait for Lar'korwi]],
[[This will be the most difficult part because there is some complexity to the plan. To the north of here, you will find a small trail into the mountains. It was here I saw Lar'korwi last. You will know you are in the right area because of all the bones from massive creatures that once wandered nearby. Take the meat you recovered and place it there. Then, rub this mixture I created on the meat. If both lures mingled together do not bring Lar'korwi to you, then I know nothing else that will.]],
[[Tohle bude nejtěžší část, protože plán je trochu složitější. Severně odsud najdeš malou stezku do hor. Právě tam jsem Lar'korwiho viděl naposledy. Správné místo poznáš podle množství kostí obrovských tvorů, kteří se kdysi potulovali poblíž. Polož tam maso, které jsi získal, a potřísni ho směsí, kterou jsem připravil. Pokud obě návnady dohromady Lar'korwiho nepřilákají, nevím už, co by mohlo.]],
[[Using the contents of Torwa's Pouch, summon Lar'korwi and defeat him. Then bring Lar'korwi's Head to Torwa Pathfinder near the entrance to Un'Goro Crater.]],
[[Pomocí obsahu Torwa's Pouch přivolej Lar'korwiho a poraz ho. Potom dones Lar'korwi's Head Torwa Pathfinderovi poblíž vstupu do Un'Goro Crater.]])

add(9225, [[Epic Armaments of Battle - Revered Amongst the Dawn]],
[[Greetings, friend. Have you insignias of the Dawn or the Crusade that you would like to redeem for items of great power?$B$BI must warn you; epic purchases made at revered reputation with the Dawn are still quite expensive. I would advise that you gain a better reputation with the Dawn before moving forward with your plans.]],
[[Zdravím, příteli. Máš insignie Dawn nebo Crusade, které bys chtěl směnit za předměty veliké moci?$B$BMusím tě varovat: epické nákupy při reputaci Revered u Dawn jsou stále poměrně drahé. Doporučuji nejdřív získat u Dawn lepší reputaci.]],
[[For 45 Insignias of the Dawn and 45 Insignias of the Crusade you may choose an item from the Argent Dawn's treasure cache.]],
[[Za 45 Insignias of the Dawn a 45 Insignias of the Crusade si můžeš vybrat předmět z pokladnice Argent Dawn.]])

add(9010, [[Saving the Best for Last]],
[[A truly amazing story, $N! You have my thanks, and the heartfelt gratitude of all who were involved, I can assure you. Through your efforts we are delivered from the mistakes of our past.$B$BAs to your reward, I believe I have a few things that you have definitely earned and will truly enjoy.]],
[[Opravdu úžasný příběh, $N! Máš můj dík a mohu tě ujistit, že i upřímnou vděčnost všech zúčastněných. Díky tvému úsilí jsme se osvobodili od chyb své minulosti.$B$BCo se týče odměny, myslím, že mám několik věcí, které sis rozhodně zasloužil a které tě potěší.]],
[[Give Mokvar your Shadowcraft Cap and Shadowcraft Tunic.]],
[[Dej Mokvarovi svůj Shadowcraft Cap a Shadowcraft Tunic.]])

add(9011, [[Saving the Best for Last]],
[[A truly amazing story, $N! You have my thanks, and the heartfelt gratitude of all who were involved, I can assure you. Through your efforts we are delivered from the mistakes of our past.$B$BAs to your reward, I believe I have a few things that you have definitely earned and will truly enjoy.]],
[[Opravdu úžasný příběh, $N! Máš můj dík a mohu tě ujistit, že i upřímnou vděčnost všech zúčastněných. Díky tvému úsilí jsme se osvobodili od chyb své minulosti.$B$BCo se týče odměny, myslím, že mám několik věcí, které sis rozhodně zasloužil a které tě potěší.]],
[[Give Mokvar your Coif of Elements and Vest of Elements.]],
[[Dej Mokvarovi svůj Coif of Elements a Vest of Elements.]])

for id, entry in pairs(entries) do
    if A.QuestEntries[id] == nil then A.QuestEntries[id] = entry end
end

A.QuestTitleTranslations = A.QuestTitleTranslations or {}
local titles = {
    ["A Final Blow"] = [[Poslední úder]],
    ["A Plague Upon Thee"] = [[Mor na tebe]],
    ["A Terrible Purpose"] = [[Strašlivý záměr]],
    ["Agent of Hydraxis"] = [[Agent Hydraxisu]],
    ["Armor Kits for the Field"] = [[Sady na opravu zbroje pro bojiště]],
    ["Arms for the Field"] = [[Zbraně pro bojiště]],
    ["Assault on the Kolkar"] = [[Útok na Kolkary]],
    ["Back to the Beginning"] = [[Zpátky na začátek]],
    ["Bandages for the Field"] = [[Obvazy pro bojiště]],
    ["Bodley's Unfortunate Fate"] = [[Bodleyho nešťastný osud]],
    ["Boots for the Guard"] = [[Boty pro stráž]],
    ["Breaking the Code"] = [[Prolomení kódu]],
    ["Broken Tears"] = [[Rozbité slzy]],
    ["Brother Anton"] = [[Bratr Anton]],
    ["Brother Carlin"] = [[Bratr Carlin]],
    ["Brumeran of the Chillwind"] = [[Brumeran z Chillwindu]],
    ["Centaur Bounty"] = [[Odměna za kentaury]],
    ["Chasing A-Me 01"] = [[Pronásledování A-Me 01]],
    ["Chillwind Horns"] = [[Rohy Chillwind]],
    ["Claim Rackmore's Treasure!"] = [[Získej Rackmoreův poklad!]],
    ["Consult Master Gadrin"] = [[Poraď se s Master Gadrinem]],
    ["Continued Threat"] = [[Pokračující hrozba]],
    ["Corruption of Earth and Seed"] = [[Zkaženost země a semene]],
    ["Da Voodoo"] = [[To voodoo]],
    ["Daelin's Men"] = [[Daelinovi muži]],
    ["Dancing for Marzipan"] = [[Tanec za marcipán]],
    ["Darkmoon Beast Deck"] = [[Balíček Beast z Darkmoon]],
    ["Darkmoon Elementals Deck"] = [[Balíček Elementals z Darkmoon]],
    ["Darkmoon Portals Deck"] = [[Balíček Portals z Darkmoon]],
    ["Darkmoon Warlords Deck"] = [[Balíček Warlords z Darkmoon]],
    ["Desert Survival Kits"] = [[Pouštní sady pro přežití]],
    ["Desperate Prayer"] = [[Zoufalá modlitba]],
    ["Dirge's Kickin' Chimaerok Chops"] = [[Dirgeovy skvělé Chimaerok Chops]],
    ["Document from the Front"] = [[Dokument z fronty]],
    ["Dousing the Flames of Protection"] = [[Uhašení ochranných plamenů]],
    ["Dragonmaw Shinbones"] = [[Holenní kosti Dragonmaw]],
    ["Dreadnaught Bracers"] = [[Nátepníky Dreadnaught]],
    ["Dreadnaught Breastplate"] = [[Kyrys Dreadnaught]],
    ["Dreadnaught Gauntlets"] = [[Rukavice Dreadnaught]],
    ["Dreadnaught Helmet"] = [[Helma Dreadnaught]],
    ["Dreadnaught Legplates"] = [[Nohavice Dreadnaught]],
    ["Dreadnaught Pauldrons"] = [[Nárameníky Dreadnaught]],
    ["Dreadnaught Sabatons"] = [[Boty Dreadnaught]],
    ["Dreadnaught Waistguard"] = [[Opasek Dreadnaught]],
    ["Elemental Mastery"] = [[Ovládnutí živlů]],
    ["Encroaching Wildlife"] = [[Dotěrná divočina]],
    ["Enraged Wildkin"] = [[Rozzuření Wildkin]],
    ["Envelope from the Front"] = [[Obálka z fronty]],
    ["Epic Armaments of Battle - Exalted Amongst the Dawn"] = [[Epická bojová výzbroj - Exalted u Dawn]],
    ["Epic Armaments of Battle - Revered Amongst the Dawn"] = [[Epická bojová výzbroj - Revered u Dawn]],
    ["Extraordinary Materials"] = [[Neobyčejné materiály]],
    ["Feralas: A History"] = [[Feralas: historie]],
    ["Frame of Atiesh"] = [[Kostra Atieshe]],
    ["Frostsaber Provisions"] = [[Zásoby pro Frostsabery]],
    ["Gelkis Alliance"] = [[Spojenectví s Gelkis]],
    ["Glacial Cloak"] = [[Ledovcový plášť]],
    ["Glacial Gloves"] = [[Ledovcové rukavice]],
    ["Glacial Vest"] = [[Ledovcová vesta]],
    ["Glacial Wrists"] = [[Ledovcové nátepníky]],
    ["Grimand Elmore"] = [[Grimand Elmore]],
    ["Grinding Stones for the Guard"] = [[Brusné kameny pro stráž]],
    ["Guarding Secrets"] = [[Střežení tajemství]],
    ["High Sorcerer Andromath"] = [[High Sorcerer Andromath]],
    ["Hive'Ashi Scout Report"] = [[Průzkumná zpráva Hive'Ashi]],
    ["Hive'Regal Scout Report"] = [[Průzkumná zpráva Hive'Regal]],
    ["Hive'Zora Scout Report"] = [[Průzkumná zpráva Hive'Zora]],
    ["Icebane Breastplate"] = [[Kyrys Icebane]],
    ["Icebane Gauntlets"] = [[Rukavice Icebane]],
    ["Icy Scale Bracers"] = [[Nátepníky z ledových šupin]],
    ["Icy Scale Breastplate"] = [[Kyrys z ledových šupin]],
    ["Icy Scale Gauntlets"] = [[Rukavice z ledových šupin]],
    ["In Search of Anthion"] = [[Hledání Anthiona]],
    ["Invaders of Alterac Valley"] = [[Vetřelci v Alterac Valley]],
    ["It's a Secret to Everybody"] = [[Je to tajemství pro všechny]],
    ["Jail Break!"] = [[Útěk z vězení!]],
    ["James Hyal"] = [[James Hyal]],
    ["Journey to the Marsh"] = [[Cesta do močálu]],
    ["Just Compensation"] = [[Spravedlivá odměna]],
    ["Kayneth Stillwind"] = [[Kayneth Stillwind]],
    ["Khan Dez'hepah"] = [[Khan Dez'hepah]],
    ["Klockmort Spannerspan"] = [[Klockmort Spannerspan]],
    ["Knowledge of the Orb of Orahil"] = [[Poznání Orb of Orahil]],
    ["Letter from the Front"] = [[Dopis z fronty]],
    ["Lieutenant Paval Reethe"] = [[Poručík Paval Reethe]],
    ["Light's Hope Chapel"] = [[Light's Hope Chapel]],
    ["Linken's Adventure"] = [[Linkenovo dobrodružství]],
    ["Long Forgotten Memories"] = [[Dávno zapomenuté vzpomínky]],
    ["Look at the Size of It!"] = [[Podívej na tu velikost!]],
    ["Mage's Wand"] = [[Mágova hůlka]],
    ["Magram Alliance"] = [[Spojenectví s Magram]],
    ["Mazen's Behest"] = [[Mazenův příkaz]],
    ["Missive from the Front"] = [[Depeše z fronty]],
    ["Morgan's Discovery"] = [[Morganův objev]],
    ["Nekrum's Medallion"] = [[Nekrumův medailon]],
    ["Note from the Front"] = [[Poznámka z fronty]],
    ["Page from the Front"] = [[Stránka z fronty]],
    ["Perfect Yeti Hide"] = [[Dokonalá yeti kožešina]],
    ["Polar Bracers"] = [[Polární nátepníky]],
    ["Polar Gloves"] = [[Polární rukavice]],
    ["Polar Tunic"] = [[Polární tunika]],
    ["Pristine Yeti Hide"] = [[Neporušená yeti kožešina]],
    ["Raid on the Kolkar"] = [[Nájezd na Kolkary]],
    ["Reagents for Reclaimers Inc."] = [[Činidla pro Reclaimers Inc.]],
    ["Reclaimed Treasures"] = [[Znovuzískané poklady]],
    ["Redemption Boots"] = [[Boty Redemption]],
    ["Redemption Girdle"] = [[Opasek Redemption]],
    ["Redemption Handguards"] = [[Rukavice Redemption]],
    ["Redemption Headpiece"] = [[Pokrývka hlavy Redemption]],
    ["Redemption Legguards"] = [[Nohavice Redemption]],
    ["Redemption Spaulders"] = [[Nárameníky Redemption]],
    ["Redemption Tunic"] = [[Tunika Redemption]],
    ["Redemption Wristguards"] = [[Nátepníky Redemption]],
    ["Return to Chillwind Camp"] = [[Návrat do Chillwind Camp]],
    ["Return to the Bulwark"] = [[Návrat do Bulwarku]],
    ["Return to Thunder Bluff"] = [[Návrat do Thunder Bluff]],
    ["Return to Vahlarriel"] = [[Návrat k Vahlarriel]],
    ["Saving the Best for Last"] = [[To nejlepší nakonec]],
    ["Secrets of the Colossus - Ashi"] = [[Tajemství kolosu - Ashi]],
    ["Seeking Strahad"] = [[Hledání Strahada]],
    ["Ship Schedules"] = [[Lodní jízdní řády]],
    ["Signet of the Dukes"] = [[Pečetní prsten Dukes]],
    ["Stealing Supplies"] = [[Krádež zásob]],
    ["Stoley's Shipment"] = [[Stoleyho zásilka]],
    ["Summon Felsteed"] = [[Vyvolání Felsteeda]],
    ["Superior Armaments of Battle - Exalted Amongst the Dawn"] = [[Vynikající bojová výzbroj - Exalted u Dawn]],
    ["Sweet Serenity"] = [[Sladký klid]],
    ["Target: Hive'Zora Hive Sisters"] = [[Cíl: Hive'Zora Hive Sisters]],
    ["Target: Hive'Zora Reavers"] = [[Cíl: Hive'Zora Reavers]],
    ["Target: Hive'Zora Tunnelers"] = [[Cíl: Hive'Zora Tunnelers]],
    ["Target: Hive'Zora Waywatchers"] = [[Cíl: Hive'Zora Waywatchers]],
    ["The Alliance Needs More Iron Bars!"] = [[Aliance potřebuje další železné pruty!]],
    ["The Alliance Needs More Linen Bandages!"] = [[Aliance potřebuje další lněné obvazy!]],
    ["The Alliance Needs More Rainbow Fin Albacore!"] = [[Aliance potřebuje další Rainbow Fin Albacore!]],
    ["The Alliance Needs More Spotted Yellowtail!"] = [[Aliance potřebuje další Spotted Yellowtail!]],
    ["The Alliance Needs More Stranglekelp!"] = [[Aliance potřebuje další Stranglekelp!]],
    ["The Bait for Lar'korwi"] = [[Návnada na Lar'korwi]],
    ["The Black Shield"] = [[Černý štít]],
    ["The Champion of the Horde"] = [[Šampion Hordy]],
    ["The Completed Orb of Dar'Orahil"] = [[Dokončená Orb of Dar'Orahil]],
    ["The Completed Orb of Noh'Orahil"] = [[Dokončená Orb of Noh'Orahil]],
    ["The Corrupter"] = [[Kazitel]],
    ["The Deserters"] = [[Dezertéři]],
    ["The Divination"] = [[Věštění]],
    ["The Fall of Kel'Thuzad"] = [[Pád Kel'Thuzada]],
    ["The Fall of Ossirian"] = [[Pád Ossiriana]],
    ["The Final Piece"] = [[Poslední část]],
    ["The Horde Needs More Copper Bars!"] = [[Horda potřebuje další měděné pruty!]],
    ["The Horde Needs More Tin Bars!"] = [[Horda potřebuje další cínové pruty!]],
    ["The Hunter's Charm"] = [[Lovcův talisman]],
    ["The Ironforge Brigade Needs Explosives!"] = [[Ironforge Brigade potřebuje výbušniny!]],
    ["The Kolkar of Desolace"] = [[Kolkarové z Desolace]],
    ["The Nightmare's Corruption"] = [[Zkaženost Nightmare]],
    ["The Orgrimmar Legion Needs Mojo!"] = [[Orgrimmar Legion potřebuje mojo!]],
    ["Thunderbrew Lager"] = [[Ležák Thunderbrew]],
    ["To Show Due Judgment"] = [[Prokázání náležitého úsudku]],
    ["Torwa Pathfinder"] = [[Torwa Pathfinder]],
    ["Translating the Journal"] = [[Překlad deníku]],
    ["Trinkets..."] = [[Cetky...]],
    ["Troll Temper"] = [[Trollí kalidlo]],
    ["Twilight Battle Orders"] = [[Bitevní rozkazy Twilightu]],
    ["Unfinished Gordok Business"] = [[Nedokončené záležitosti Gordoků]],
    ["Uniform Supplies"] = [[Materiál na uniformy]],
    ["Vivian Lagrave and the Darkstone Tablet"] = [[Vivian Lagrave a Darkstone Tablet]],
    ["Wanted - Deathclasp, Terror of the Sands"] = [[Hledá se - Deathclasp, postrach písků]],
    ["War on the Shadowsworn"] = [[Válka se Shadowsworn]],
    ["Wheel of the Black March"] = [[Kolo Black March]],
    ["Williden's Journal"] = [[Willidenův deník]],
    ["Witherbark Cages"] = [[Klece Witherbark]],
    ["Your Fortune Awaits You..."] = [[Tvé štěstí na tebe čeká...]],
    ["Zinge's Assessment"] = [[Zingeovo posouzení]],
}
for en, cs in pairs(titles) do
    if A.QuestTitleTranslations[en] == nil then A.QuestTitleTranslations[en] = cs end
end
