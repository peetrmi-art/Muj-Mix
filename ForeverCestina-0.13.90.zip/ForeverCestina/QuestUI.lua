-- Only named quest buttons/headers; prose, item names and quest titles have separate handling.
local _, A = ...
local loggedIn=false
local actionButtons={
 "QuestFrameAcceptButton","QuestFrameDeclineButton","QuestFrameCompleteButton",
 "QuestFrameCompleteQuestButton","QuestFrameGoodbyeButton",
}
local staticLabels={
 "QuestInfoDescriptionHeader","QuestInfoObjectivesHeader","QuestProgressRequiredItemsText",
 "QuestInfoSpellObjectiveLearnLabel","QuestInfoGroupSize",
}
local function label(value)
 if not value then return end
 if value.GetFontString then value=value:GetFontString() end
 if value and A.RegisterUILabel then A.SafeCall("Quest UI label",A.RegisterUILabel,value) end
end
local function install()
 -- Static headers/reward labels are presentation-only and stay localized exactly as in 0.13.42.
 for _,name in ipairs(staticLabels) do label(_G[name]) end
 for _,frameName in ipairs({"QuestInfoRewardsFrame","MapQuestInfoRewardsFrame"}) do
  local rewards=_G[frameName]
  if rewards then
   for _,key in ipairs({"Header","ItemChooseText","ItemReceiveText","PlayerTitleText","QuestSessionBonusReward"}) do label(rewards[key]) end
   if rewards.XPFrame then label(rewards.XPFrame.ReceiveText) end
  end
 end
 for _,frameName in ipairs({"ObjectiveTrackerFrame","QuestObjectiveTracker"}) do
  local tracker=_G[frameName]
  if tracker and tracker.Header then label(tracker.Header.Text) end
 end
 -- The controller path can dispatch protected actions through these native buttons.
 -- Do not attach addon FontString hooks to them while gamepad control is active.
 -- Before PLAYER_LOGIN we also leave them untouched so an early/unknown controller state
 -- cannot permanently install hooks that cannot later be removed.
 if loggedIn and not (A.GamepadActive and A.GamepadActive()) then
  for _,name in ipairs(actionButtons) do label(_G[name]) end
 end
end
local frame=CreateFrame("Frame")
for _,event in ipairs({"ADDON_LOADED","PLAYER_LOGIN","QUEST_DETAIL","QUEST_PROGRESS","QUEST_COMPLETE","QUEST_LOG_UPDATE"}) do frame:RegisterEvent(event) end
frame:SetScript("OnEvent",function(_,event)
 if event=="PLAYER_LOGIN" then loggedIn=true end
 install()
end)
install()
