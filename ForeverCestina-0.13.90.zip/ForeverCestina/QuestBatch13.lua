local _, A = ...
-- Additive quest translations: 200 additional quest IDs not present in the previous ForeverCestina dataset.
-- English source strings are kept verbatim; exact-match runtime leaves changed client variants in English rather than applying a stale translation.
local entries = {}

local function add(id, title, enDesc, csDesc, enObj, csObj)
    local e = { title = title }
    if enDesc and enDesc ~= "" then e.description = {enDesc, csDesc} end
    if enObj and enObj ~= "" then e.objectives = {enObj, csObj} end
    entries[id] = e
end

add(3377, [[Prayer to Elune]],
[[Will you assist me, mortal? Hear my tale.]],
[[Pomůžeš mi, smrtelníku? Vyslechni můj příběh.]],
[[Hear Zamael tell his tale.]],
[[Vyslechni Zamaelův příběh.]])

add(2784, [[Fall From Grace]],
[[Hear my story, $r.]],
[[Vyslechni můj příběh, $r.]],
[[Listen to the Fallen Hero of the Horde tell his story.]],
[[Vyslechni příběh padlého hrdiny Hordy.]])

add(3441, [[Divine Retribution]],
[[Hear my tale, adventurer.]],
[[Vyslechni můj příběh, dobrodruhu.]],
[[Listen as Kalaran Windblade tells his story.]],
[[Vyslechni příběh Kalarana Windbladea.]])

add(7499, [[Codex of Defense]],
[[The tome carries the mark of the Athenaeum.]],
[[Tato kniha nese znak Athenaea.]],
[[Return the book to its rightful owners.]],
[[Vrať knihu jejím právoplatným vlastníkům.]])

add(7502, [[Harnessing Shadows]],
[[The tome carries the mark of the Athenaeum.]],
[[Tato kniha nese znak Athenaea.]],
[[Return the book to its rightful owners.]],
[[Vrať knihu jejím právoplatným vlastníkům.]])

add(7505, [[Frost Shock and You]],
[[The tome carries the mark of the Athenaeum.]],
[[Tato kniha nese znak Athenaea.]],
[[Return the book to its rightful owners.]],
[[Vrať knihu jejím právoplatným vlastníkům.]])

add(4342, [[Kharan's Tale]],
[[Please, hear me out before passing judgement!]],
[[Prosím, vyslechni mě, než mě odsoudíš!]],
[[Listen as Kharan Mighthammer tells his story.]],
[[Vyslechni příběh Kharana Mighthammera.]])

add(7506, [[The Emerald Dream...]],
[[The tome carries the mark of the Athenaeum.]],
[[Tato kniha nese znak Athenaea.]],
[[Return the book to its rightful owners.]],
[[Vrať knihu jejím právoplatným vlastníkům.]])

add(7500, [[The Arcanist's Cookbook]],
[[The tome carries the mark of the Athenaeum.]],
[[Tato kniha nese znak Athenaea.]],
[[Return the book to its rightful owners.]],
[[Vrať knihu jejím právoplatným vlastníkům.]])

add(4298, [[Becoming a Parent]],
[[Whoa, it was a lot more ready than I thought...]],
[[Páni, bylo to mnohem připravenější, než jsem čekal...]],
[[Speak to Agnar Beastamer in the Hinterlands.]],
[[Promluv si s Agnarem Beastamerem v Hinterlands.]])

add(7503, [[The Greatest Race of Hunters]],
[[The tome carries the mark of the Athenaeum.]],
[[Tato kniha nese znak Athenaea.]],
[[Return the book to its rightful owners.]],
[[Vrať knihu jejím právoplatným vlastníkům.]])

add(7501, [[The Light and How To Swing It]],
[[The tome carries the mark of the Athenaeum.]],
[[Tato kniha nese znak Athenaea.]],
[[Return the book to its rightful owners.]],
[[Vrať knihu jejím právoplatným vlastníkům.]])

add(7922, [[Mark of Honor]],
[[You have proven your value to our efforts in Warsong Gulch. Continue to rage against the Silverwing Sentinels! Bring me more marks of honor!]],
[[Prokázal jsi svou cenu v našem boji ve Warsong Gulch. Pokračuj v útocích proti Silverwing Sentinels! Přines mi další znaky cti!]],
[[You obtained a Warsong Mark of Honor for your last task, talk to me again, and you gain your reward.]],
[[Za svůj poslední úkol jsi získal Warsong Mark of Honor. Promluv se mnou znovu a dostaneš odměnu.]])

add(2801, [[A Tale of Sorrow]],
[[Before we may continue, you must hear my story.]],
[[Než budeme pokračovat, musíš vyslechnout můj příběh.]],
[[Listen to the Fallen Hero of the Horde tell his story.]],
[[Vyslechni příběh padlého hrdiny Hordy.]])

add(3454, [[The Torch of Retribution]],
[[The torch must now be bound to its owner. Pick up the torch, $N. ]],
[[Pochodeň teď musí být spoutána se svým majitelem. Zvedni ji, $N. ]],
[[Take the Torch of Retribution.]],
[[Vezmi Pochodeň odplaty.]])

add(7649, [[Enchanted Thorium Platemail: Volume I]],
[[The tome carries the mark of the Athenaeum.]],
[[Tato kniha nese znak Athenaea.]],
[[Return the book to its rightful owners.]],
[[Vrať knihu jejím právoplatným vlastníkům.]])

add(4867, [[Urok Doomhowl]],
[[Argh!So hard to speak!$B$BTake this note!Get me my mojo!]],
[[Argh! Tak těžko se mi mluví!$B$BVezmi tenhle vzkaz! Získej zpět moje mojo!]],
[[Read Warosh's Scroll.Bring Warosh's Mojo to Warosh.]],
[[Přečti Waroshův svitek. Přines Waroshovo mojo Waroshovi.]])

add(7650, [[Enchanted Thorium Platemail: Volume II]],
[[The tome carries the mark of the Athenaeum.]],
[[Tato kniha nese znak Athenaea.]],
[[Return the book to its rightful owners.]],
[[Vrať knihu jejím právoplatným vlastníkům.]])

add(3141, [[Loramus]],
[[So you wish to battle demons? You would do well to listen to my tale. ]],
[[Takže chceš bojovat s démony? Uděláš dobře, když vyslechneš můj příběh. ]],
[[Listen to Loramus Thalipedes tell his story.]],
[[Vyslechni příběh Loramuse Thalipedese.]])

add(7651, [[Enchanted Thorium Platemail: Volume III]],
[[The tome carries the mark of the Athenaeum.]],
[[Tato kniha nese znak Athenaea.]],
[[Return the book to its rightful owners.]],
[[Vrať knihu jejím právoplatným vlastníkům.]])

add(7498, [[Garona: A Study on Stealth and Treachery]],
[[The tome carries the mark of the Athenaeum.]],
[[Tato kniha nese znak Athenaea.]],
[[Return the book to its rightful owners.]],
[[Vrať knihu jejím právoplatným vlastníkům.]])

add(3564, [[Andron's Payment to Jediga]],
[[Here... take... <hic> this to Jediga. Good luck to ya!]],
[[Tady... vezmi... <škyt> tohle Jedize. Hodně štěstí!]],
[[Deliver Andron's Note to Jediga in Azshara.]],
[[Doruč Andronův vzkaz Jedize v Azshaře.]])

add(8552, [[The Monogrammed Sash]],
[[This fine sash has the letters "HS" embroidered along its hem.]],
[[Na lemu této jemné šerpy jsou vyšita písmena „HS“.]],
[[Return the Monogrammed Sash to its owner.]],
[[Vrať šerpu s monogramem jejímu majiteli.]])

add(7504, [[Holy Bologna: What the Light Won't Tell You]],
[[The tome carries the mark of the Athenaeum.]],
[[Tato kniha nese znak Athenaea.]],
[[Return the book to its rightful owners.]],
[[Vrať knihu jejím právoplatným vlastníkům.]])

add(7886, [[Talismans of Merit]],
[[You have proven your value to our efforts in Warsong Gulch. Continue to aid the cause and bring me more talismans of merit. Do this, and you will earn even more of our trust.]],
[[Prokázal jsi svou cenu v našem úsilí ve Warsong Gulch. Pokračuj v podpoře naší věci a přines mi další talismany zásluh. Tím si získáš ještě větší naši důvěru.]],
[[You obtained a Silverwing Talisman of Merit for your last task, talk to me again, and you gain your reward.]],
[[Za svůj poslední úkol jsi získal Silverwing Talisman of Merit. Promluv se mnou znovu a dostaneš odměnu.]])

add(7921, [[Talismans of Merit]],
[[You have proven your value to our efforts in Warsong Gulch. Continue to aid the cause and bring me more talismans of merit. Do this, and you will earn even more of our trust.]],
[[Prokázal jsi svou cenu v našem úsilí ve Warsong Gulch. Pokračuj v podpoře naší věci a přines mi další talismany zásluh. Tím si získáš ještě větší naši důvěru.]],
[[You obtained a Silverwing Talisman of Merit for your last task, talk to me again, and you gain your reward.]],
[[Za svůj poslední úkol jsi získal Silverwing Talisman of Merit. Promluv se mnou znovu a dostaneš odměnu.]])

add(5126, [[Lorax's Tale]],
[[The Satyr paces about and talks to himself. Do you wish to question him?]],
[[Satyr přechází sem a tam a mluví sám se sebou. Chceš se ho vyptat?]],
[[Speak with Lorax. Listen to what he has to say.]],
[[Promluv si s Loraxem a vyslechni, co ti chce říct.]])

add(1943, [[Speak with Deino]],
[[The troll mage Deino has need of your assistance, $N.She resides in Orgrimmar, in the Darkbriar Lodge.]],
[[Trollí mág Deino potřebuje tvou pomoc, $N. Žije v Orgrimmaru v Darkbriar Lodge.]],
[[Speak with Deino.]],
[[Promluv si s Deino.]])

add(2702, [[Heroes of Old]],
[[You have honored me with your nobility and heroism, $N.$B$BYou have also honored them...]],
[[Poctil jsi mě svou ušlechtilostí a hrdinstvím, $N.$B$BA poctil jsi i je...]],
[[Speak to Corporal Thund Splithoof.]],
[[Promluv si s Corporalem Thundem Splithoofem.]])

add(6566, [[What the Wind Carries]],
[[It is good to see you again, $N. The wind carries with it news from the Eastern Kingdom.$B$BSit, listen. ]],
[[Rád tě znovu vidím, $N. Vítr přináší zprávy z Eastern Kingdoms.$B$BPosaď se a poslouchej. ]],
[[Listen to Thrall.]],
[[Vyslechni Thralla.]])

add(5742, [[Redemption]],
[[You have worked hard, friend. Rest your weary bones and allow me to properly introduce myself.]],
[[Tvrdě jsi pracoval, příteli. Nech své unavené tělo odpočinout a dovol mi, abych se ti řádně představil.]],
[[Listen to what Tirion Fordring has to say.]],
[[Vyslechni, co ti chce Tirion Fordring říct.]])

add(3462, [[Squire Maltrake]],
[[Speak with my envoy, Squire Maltrake. He will further instruct you as to the use of the Torch of Retribution.]],
[[Promluv si s mým vyslancem, Squirem Maltrakem. Vysvětlí ti další použití Pochodně odplaty.]],
[[Speak with Squire Maltrake.]],
[[Promluv si se Squirem Maltrakem.]])

add(7508, [[The Forging of Quel'Serrar]],
[[If you wish to take on this task, present Lydros with the dull blade.]],
[[Pokud se chceš tohoto úkolu ujmout, ukaž Lydrosovi tupou čepel.]],
[[Give the Dull and Flat Elven Blade to Lorekeeper Lydros.]],
[[Předej tupou a plochou elfí čepel Lorekeeperu Lydrosovi.]])

add(7496, [[Celebrating Good Times]],
[[Seek out Major Mattingly in the Valley of Heroes, $N. He will be expecting you...]],
[[Vyhledej Majora Mattinglyho ve Valley of Heroes, $N. Bude tě očekávat...]],
[[Seek out Major Mattingly in the Valley of Heroes.]],
[[Vyhledej Majora Mattinglyho ve Valley of Heroes.]])

add(3453, [[The Torch of Retribution]],
[[Give me a moment to combine the pieces and apply the necessary enchantments.]],
[[Dej mi chvilku, abych spojil jednotlivé části a použil potřebná očarování.]],
[[Wait for Kalaran Windblade to complete the Torch of Retribution.]],
[[Počkej, až Kalaran Windblade dokončí Pochodeň odplaty.]])

add(3702, [[The Smoldering Ruins of Thaurissan]],
[[Would you like to hear a brief history of the Dark Iron dwarves?]],
[[Chceš si poslechnout stručné dějiny trpaslíků Dark Iron?]],
[[Listen to Royal Historian Archesonus recant the history of Thaurissan.]],
[[Vyslechni Royal Historiana Archesonuse, jak vypráví historii Thaurissanu.]])

add(5465, [[Soulbound Keepsake]],
[[Return to Marduke with the keepsake, $N. He will instruct you in its use.]],
[[Vrať se s památkou k Mardukovi, $N. Vysvětlí ti, jak ji použít.]],
[[Return to Magistrate Marduke in Caer Darrow. Show him the Soulbound Keepsake.]],
[[Vrať se k Magistratu Mardukovi v Caer Darrow a ukaž mu památku spoutanou s duší.]])

add(3914, [[Linken's Sword]],
[[After a strong flash of light, you are able to pick up the sword again. It has been transformed!]],
[[Po silném záblesku světla můžeš meč znovu zvednout. Proměnil se!]],
[[Deliver Linken's Superior Sword to Linken in Un'Goro Crater.]],
[[Doruč Linkenův vylepšený meč Linkenovi v Un'Goro Crater.]])

add(4361, [[The Bearer of Bad News]],
[[You must take this information back to King Magni, $N. He will know what to do!]],
[[Musíš tyto informace odnést zpět králi Magnimu, $N. On bude vědět, co dělat!]],
[[Return to Ironforge and deliver the bad news to King Magni Bronzebeard.]],
[[Vrať se do Ironforge a doruč špatné zprávy králi Magnimu Bronzebeardovi.]])

add(7782, [[The Lord of Blackrock]],
[[Go to the Valley of Heroes and speak with Field Marshal Afrasiabi.]],
[[Jdi do Valley of Heroes a promluv si s Field Marshalem Afrasiabim.]],
[[Venture to the Valley of Heroes in Stormwind City and speak with Field Marshal Afrasiabi.]],
[[Vydej se do Valley of Heroes ve Stormwind City a promluv si s Field Marshalem Afrasiabim.]])

add(2661, [[Delivery for Marin]],
[[Here's the Violet Powder, $N. Take it to Marin and tell him he owes me a favor!]],
[[Tady je fialový prášek, $N. Dones ho Marinovi a řekni mu, že mi dluží laskavost!]],
[[Sprinkle wants to you take the Violet Powder to Marin Noggenfogger in Gadgetzan.]],
[[Sprinkle chce, abys donesl fialový prášek Marinovi Noggenfoggerovi do Gadgetzanu.]])

add(3569, [[Seeping Corruption]],
[[Give this to Thersa. Perhaps it will cure her... perhaps not. We really won't know until after she drinks it.]],
[[Dej to Therse. Možná ji to vyléčí... možná ne. Dokud to nevypije, nezjistíme to.]],
[[Give Cuely's Elixir to Thersa Windsong in Undercity.]],
[[Dej Cuelyho elixír Therse Windsong v Undercity.]])

add(7784, [[The Lord of Blackrock]],
[[Seek out High Overlord Saurfang in the Valley of Strength.]],
[[Vyhledej High Overlorda Saurfanga ve Valley of Strength.]],
[[Speak with High Overlord Saurfang in Orgrimmar. He stands waiting for you in the Valley of Strength.]],
[[Promluv si s High Overlordem Saurfangem v Orgrimmaru. Čeká na tebe ve Valley of Strength.]])

add(7785, [[Examine the Vessel]],
[[Examine the vessel of his rebirth, mortal. It is from this that the Windseeker shall be reborn!]],
[[Prozkoumej nádobu jeho znovuzrození, smrtelníku. Z ní se Windseeker zrodí znovu!]],
[[Examine the Vessel of Rebirth and return it to Highlord Demitrian.]],
[[Prozkoumej Vessel of Rebirth a vrať ji Highlordu Demitrianovi.]])

add(4966, [[Protect Kanati Greycloud]],
[[But, there may be more centaur than I thought, I ask you, $n, to fight with me against these vile assassins.]],
[[Jenže těch kentaurů může být víc, než jsem čekal. Prosím tě, $n, bojuj po mém boku proti těm odporným vrahům.]],
[[Protect Kanati Greycloud from the centaur attack.]],
[[Ochraň Kanatiho Greyclouda před útokem kentaurů.]])

add(4786, [[The Completed Robe]],
[[I will put the robe together for you now. It will take but a few moments. Do not go far.]],
[[Teď ti róbu dokončím. Zabere to jen chvilku. Nechoď daleko.]],
[[Wait for Menara Voidrender to complete your robe and then speak to her again.]],
[[Počkej, až Menara Voidrender dokončí tvou róbu, a potom s ní znovu promluv.]])

add(2701, [[Heroes of Old]],
[[Please, take from this a relic of old. We no longer have a use for the item.$B$BMay it serve you well in your fight against the legion.]],
[[Prosím, vezmi si z toho jednu dávnou relikvii. My už pro ni nemáme využití.$B$BAť ti dobře poslouží v boji proti Legii.]],
[[Open the chest and claim your reward.]],
[[Otevři truhlu a vyzvedni si odměnu.]])

add(2943, [[Return to Troyas]],
[[Here it is, $N. Please, take care of my book.$B$BNow, hurry along. I'm sure Troyas is eager for your return.]],
[[Tady je, $N. Prosím, dávej na mou knihu pozor.$B$BTeď pospěš. Jsem si jistý, že Troyas už netrpělivě čeká na tvůj návrat.]],
[[Deliver the book to Troyas Moonbreeze in Feathermoon Stronghold.]],
[[Doruč knihu Troyasovi Moonbreeze ve Feathermoon Stronghold.]])

add(8575, [[Azuregos's Magical Ledger]],
[[You cannot understand a single word on this ledger. You don't even know what language it is written in!]],
[[Z této knihy nerozumíš jedinému slovu. Ani nevíš, v jakém jazyce je napsaná!]],
[[Deliver Azuregos's Magical Ledger to Narain Soothfancy in Tanaris.]],
[[Doruč Azuregosovu magickou účetní knihu Narainovi Soothfancymu v Tanarisu.]])

add(7491, [[For All To See]],
[[Overlord Runthak awaits your arrival in the Valley of Strength.$B$B<Thrall salutes you.>$B$BDo not keep your public waiting, hero.]],
[[Overlord Runthak očekává tvůj příchod ve Valley of Strength.$B$B<Thrall ti zasalutuje.>$B$BNenechávej své publikum čekat, hrdino.]],
[[Seek out Overlord Runthak in the Valley of Strength.]],
[[Vyhledej Overlorda Runthaka ve Valley of Strength.]])

add(4023, [[A Taste of Flame]],
[[You seek out the Flight? Present to me proof of your worth, mortal.]],
[[Hledáš letku? Dokaž mi svou hodnotu, smrtelníku.]],
[[Show Cyrus Therepentous proof of your worth.$B$BYou have a feeling that Cyrus already knows that you are unworthy.]],
[[Ukaž Cyrusovi Therepentousovi důkaz své hodnoty.$B$BMáš pocit, že Cyrus už stejně ví, že nejsi hoden.]])

add(8741, [[The Champion Returns]],
[[The keeper awaits your return, $N. Take the green scepter shard to Anachronos at the Caverns of Time.]],
[[Strážce očekává tvůj návrat, $N. Dones zelený úlomek žezla Anachronosovi do Caverns of Time.]],
[[Take the Green Scepter Shard to Anachronos at the Caverns of Time in Tanaris.]],
[[Dones Green Scepter Shard Anachronosovi do Caverns of Time v Tanarisu.]])

add(4022, [[A Taste of Flame]],
[[The flight is aware of your work in the Searing Gorge.$B$BShow it to me, $r. The molt, imbecile.]],
[[Letka ví o tom, cos vykonal v Searing Gorge.$B$BUkaž mi to, $r. Tu svlečenou kůži, hlupáku.]],
[[Show Cyrus Therepentous the Black Dragonflight Molt you received from Kalaran Windblade.]],
[[Ukaž Cyrusovi Therepentousovi Black Dragonflight Molt, který jsi dostal od Kalarana Windbladea.]])

add(3367, [[Suntara Stones]],
[[<Dorius groans.>$B$BI'm badly injured, $r. Feel... light headed... World spinning... Bleeding... internally.$B$BI must get back to Ironforge. Help me, $N.]],
[[<Dorius zasténá.>$B$BJsem těžce zraněný, $r. Točí se mi... hlava... všechno se točí... krvácím... uvnitř.$B$BMusím se dostat zpět do Ironforge. Pomoz mi, $N.]],
[[Help Dorius get back to Ironforge.]],
[[Pomoz Doriusovi dostat se zpět do Ironforge.]])

add(8383, [[Remember Alterac Valley!]],
[[The Battle in Alterac Valley rages on, $N! Have you done your part as of late, $N?]],
[[Bitva v Alterac Valley zuří dál, $N! Přiložil jsi v poslední době ruku k dílu, $N?]],
[[Bring 3 Alterac Valley Marks of Honor to an Alliance Brigadier General outside the battlegrounds.]],
[[Přines 3 Alterac Valley Marks of Honor aliančnímu Brigadier Generalovi před bojištěm.]])

add(4186, [[The True Masters]],
[[I am going to empower you as an acting deputy of Stormwind, $N.$B$BReturn to Magistrate Solomon in Lakeshire and deliver this decree.]],
[[Udělím ti pravomoci dočasného zástupce Stormwindu, $N.$B$BVrať se k Magistratu Solomonovi v Lakeshire a doruč mu tento výnos.]],
[[Take Bolvar's Decree to Magistrate Solomon in Lakeshire.]],
[[Dones Bolvarův výnos Magistratu Solomonovi v Lakeshire.]])

add(8183, [[The Heart of Hakkar]],
[[The Heart of Hakkar burns from within.Although the Soulflayer is defeated, the kernel of his power yet remains in this cursed organ.]],
[[Hakkarovo srdce žhne zevnitř. Přestože byl Soulflayer poražen, jádro jeho moci v tomto prokletém orgánu stále přetrvává.]],
[[Bring the Heart of Hakkar to Molthor on Yojamba Isle.]],
[[Přines Hakkarovo srdce Molthorovi na Yojamba Isle.]])

add(7224, [[Enemy Booty]],
[[When you fight the enemy, gather the scraps of their armor and bring them to me.I'll use those scraps to make armor for our own troops!]],
[[Když bojuješ s nepřítelem, sbírej úlomky jeho zbroje a nos mi je. Použiji je k výrobě zbroje pro naše vlastní vojáky!]],
[[Bring 20 Armor Scraps to Smith Regzar in Frostwolf Village.]],
[[Přines 20 Armor Scraps kováři Regzarovi ve Frostwolf Village.]])

add(3565, [[Xylem's Payment to Jediga]],
[[What is it? Oh yes, your payment. Of course.$B$BTake this and be off with you. I'm sure Jediga is awaiting oh so patiently for your return.]],
[[Co je? Ach ano, tvoje platba. Samozřejmě.$B$BVezmi si to a běž. Jsem si jistý, že Jediga na tvůj návrat čeká opravdu nesmírně trpělivě.]],
[[Deliver Xylem's Note to Jediga in Azshara.]],
[[Doruč Xylemův vzkaz Jedize v Azshaře.]])

add(4442, [[Purified!]],
[[Using the water of Elune, I will attempt to purify the flute. We must end this suffering...$B$BMay Elune guide my hands and heart.$B$BSpeak with me again in a moment.]],
[[Pomocí vody Elune se pokusím flétnu očistit. Musíme toto utrpení ukončit...$B$BAť Elune vede mé ruce i srdce.$B$BZa chvíli se mnou znovu promluv.]],
[[Speak to Eridan again in a moment.]],
[[Za chvíli znovu promluv s Eridanem.]])

add(1447, [[The Missing Diplomat]],
[[Yeah, you're obviously not the smartest $c to come into Stormwind, but you're about to be one of the dumbest to never leave.$b$bHave you met me friends?]],
[[Jo, očividně nejsi nejchytřejší $c, co kdy přišel do Stormwindu, ale brzy budeš jeden z nejhloupějších, kteří už nikdy neodejdou.$b$bUž ses seznámil s mými přáteli?]],
[[Defeat Dashel Stonefist in Stormwind.]],
[[Poraz Dashela Stonefista ve Stormwindu.]])

add(3507, [[Betrayed]],
[[Return to Belgrom in Orgrimmar. He will want to see her head for himself! We'll return there shortly.$B$BAh, this is indeed a good day. Thank you for your help, $N.]],
[[Vrať se k Belgromovi do Orgrimmaru. Bude chtít její hlavu vidět na vlastní oči! My se tam brzy vrátíme také.$B$BAch, tohle je vskutku dobrý den. Děkuji za pomoc, $N.]],
[[Speak to Belgrom Rockmaul in Orgrimmar.]],
[[Promluv si s Belgromem Rockmaulem v Orgrimmaru.]])

add(3122, [[Return to Witch Doctor Uzer'i]],
[[Here are the herbs, $N. Take them to Witch Doctor Uzer'i.$B$BPlease let him know that I am satisfied with the shrunken head.]],
[[Tady jsou byliny, $N. Dones je Witch Doctoru Uzer'imu.$B$BŘekni mu prosím, že jsem s tou scvrklou hlavou spokojený.]],
[[Deliver Neeru's Herb Pouch to Witch Doctor Uzer'i in Feralas.]],
[[Doruč Neeruův váček s bylinami Witch Doctoru Uzer'imu ve Feralasu.]])

add(4810, [[Return to Tinkee]],
[[Ok, everything is prepared and packed and ready for transport!Good luck in your journey, and make sure you tell Tinkee that she owes me!]],
[[Dobře, všechno je připravené, zabalené a nachystané k přepravě! Hodně štěstí na cestě a nezapomeň Tinkee říct, že mi něco dluží!]],
[[Bring Felnok's Package to Tinkee Steamboil in the Burning Steppes.]],
[[Dones Felnokův balík Tinkee Steamboil v Burning Steppes.]])

add(7490, [[Victory for the Horde]],
[[You have accomplished the impossible. The brood mother of the Black Dragonflight lies dead at your feet. Take her head and present it to your Warchief.]],
[[Dokázal jsi nemožné. Matka rodu Black Dragonflight leží mrtvá u tvých nohou. Vezmi její hlavu a předlož ji svému Warchiefovi.]],
[[Take the Head of Onyxia to Thrall in Orgrimmar.]],
[[Dones hlavu Onyxie Thrallovi do Orgrimmaru.]])

add(1420, [[Report to Helgrum]],
[[I wrote a fresh report for Helgrum in Stonard.Bring it to him.$B$BAnd if you consider yourself an outrunner, then don't lose your way.Or fall to an enemy.]],
[[Sepsal jsem nové hlášení pro Helgruma ve Stonardu. Dones mu ho.$B$BA pokud se považuješ za outrunnera, neztrať cestu. A nepadni do rukou nepřítele.]],
[[Bring Neeka's Report to Helgrum the Swift in Stonard.]],
[[Dones Neekino hlášení Helgrumovi the Swift ve Stonardu.]])

add(8447, [[Waking Legends]],
[[The waters of Lake Elune'ara should dissolve the nightmares engulfing this object. Give me a moment to perform the cleansing, $N.]],
[[Vody Lake Elune'ara by měly rozpustit noční můry obklopující tento předmět. Dej mi chvilku, abych provedl očistu, $N.]],
[[Wait for Keeper Remulos at the Moonglade to cleanse the Nightmare Engulfed Object.]],
[[Počkej, až Keeper Remulos v Moonglade očistí Nightmare Engulfed Object.]])

add(4223, [[The True Masters]],
[[<Magistrate Solomon sighs.>$B$BYou must return to the Burning Steppes, $N. As a deputy of Stormwind, you will be required to report to Marshal Maxwell. Good luck.]],
[[<Magistrate Solomon si povzdechne.>$B$BMusíš se vrátit do Burning Steppes, $N. Jako zástupce Stormwindu se musíš hlásit Marshalovi Maxwellovi. Hodně štěstí.]],
[[Speak with Marshal Maxwell in the Burning Steppes.]],
[[Promluv si s Marshalem Maxwellem v Burning Steppes.]])

add(2942, [[The Morrow Stone]],
[[The moment the artifact is removed from the Monolith, you feel the energy in the Stave of Equinex begin to fade.]],
[[V okamžiku, kdy je artefakt vyjmut z Monolitu, ucítíš, jak energie ve Stave of Equinex začíná slábnout.]],
[[Return the Sparkling Stone and the Stave of Equinex to Troyas Moonbreeze in Feathermoon Stronghold. ]],
[[Vrať Sparkling Stone a Stave of Equinex Troyasovi Moonbreeze ve Feathermoon Stronghold. ]])

add(9332, [[Stealing Darnassus's Flame]],
[[This flame, stolen from the shores of Teldrassil, floods you with warmth. This raw power is foreign to you, but the Talespinner might know more...]],
[[Tento plamen, ukradený na březích Teldrassilu, tě zaplavuje teplem. Tato syrová moc je ti cizí, ale Talespinner by o ní mohl vědět víc...]],
[[Return the Flame of Darnassus to the Festival Talespinner.]],
[[Vrať Flame of Darnassus Festival Talespinnerovi.]])

add(1374, [[Khan Jehn]],
[[The earth speaks to me, and it says that the Magram grow weak.Now it is time to kill their Khan!$B$BBring me the head of the Magram Khan, Jehn!]],
[[Země ke mně promlouvá a říká, že Magramové slábnou. Teď je čas zabít jejich Khana!$B$BPřines mi hlavu magramského Khana Jehna!]],
[[Bring the Khan Jehn's Head to Uthek the Wise in the Gelkis Village in Desolace.]],
[[Přines hlavu Khana Jehna Uthek the Wise do Gelkis Village v Desolace.]])

add(9324, [[Stealing Orgrimmar's Flame]],
[[This flame, stolen from the heart of Orgrimmar itself, floods you with warmth. This raw power is foreign to you, but the Loremaster might know more...]],
[[Tento plamen, ukradený přímo ze srdce Orgrimmaru, tě zaplavuje teplem. Tato syrová moc je ti cizí, ale Loremaster by o ní mohl vědět víc...]],
[[Return the Flame of Orgrimmar to the Festival Loremaster.]],
[[Vrať Flame of Orgrimmar Festival Loremasterovi.]])

add(1324, [[The Missing Diplomat]],
[[What?! You come here accusing me of allying with the Defias, and think I'll just stand here while you insult me?! Something tells me you've had this coming for a long time.]],
[[Cože?! Přijdeš sem a obviníš mě ze spolčení s Defias a myslíš si, že tu budu jen stát a nechám se urážet?! Něco mi říká, že sis o to už dlouho koledoval.]],
[[Defeat Private Hendel in Dustwallow Marsh.]],
[[Poraz Private Hendela v Dustwallow Marsh.]])

add(3402, [[The Undermarket]],
[[I want you to personally deliver the news of Kovic's defeat to Vizzklick in Gadgetzan. He will be so happy to hear that Kovic is dead that I'm certain he'll give you some grand reward.]],
[[Chci, abys zprávu o Kovicově porážce osobně doručil Vizzklickovi do Gadgetzanu. Bude tak rád, že je Kovic mrtvý, že ti určitě dá pořádnou odměnu.]],
[[Speak with Vizzklick in Gadgetzan.]],
[[Promluv si s Vizzklickem v Gadgetzanu.]])

add(8521, [[The Alliance Needs More Silk Bandages!]],
[[It is very kind of you to offer to help me again $c. It looks like we've collected $2082w silk bandages, so we'll need more.]],
[[Je od tebe velmi laskavé, že mi chceš znovu pomoci, $c. Zdá se, že jsme nasbírali $2082w hedvábných obvazů, takže budeme potřebovat další.]],
[[Bring 20 silk bandages to Nurse Stonefield at the airfield in Dun Morogh.]],
[[Přines 20 hedvábných obvazů Nurse Stonefield na letiště v Dun Morogh.]])

add(8982, [[Tracing the Source]],
[[We must find who the supplier is. I noticed Apothecary Katrina with a bottle of the perfume tucked in her pack. She told me that she purchased it from Norman, the innkeeper.]],
[[Musíme zjistit, kdo je dodavatel. Všiml jsem si, že Apothecary Katrina měla v brašně lahvičku toho parfému. Řekla mi, že ho koupila od hostinského Normana.]],
[[Speak with Innkeeper Norman in the Undercity.]],
[[Promluv si s Innkeeperem Normanem v Undercity.]])

add(9330, [[Stealing Stormwind's Flame]],
[[This flame, stolen from the heart of Stormwind itself, floods you with warmth. This raw power is foreign to you, but the Talespinner might know more...]],
[[Tento plamen, ukradený přímo ze srdce Stormwindu, tě zaplavuje teplem. Tato syrová moc je ti cizí, ale Talespinner by o ní mohl vědět víc...]],
[[Return the Flame of Stormwind to the Festival Talespinner.]],
[[Vrať Flame of Stormwind Festival Talespinnerovi.]])

add(9331, [[Stealing Ironforge's Flame]],
[[This flame, stolen from the heart of Ironforge itself, floods you with warmth. This raw power is foreign to you, but the Talespinner might know more...]],
[[Tento plamen, ukradený přímo ze srdce Ironforge, tě zaplavuje teplem. Tato syrová moc je ti cizí, ale Talespinner by o ní mohl vědět víc...]],
[[Return the Flame of Ironforge to the Festival Talespinner.]],
[[Vrať Flame of Ironforge Festival Talespinnerovi.]])

add(7462, [[The Treasure of the Shen'dralar]],
[[In the library, Athenaeum, you will find an ancient chest hidden beneath the stairway. Take from it that which you desire.]],
[[V knihovně Athenaeum najdeš pod schodištěm ukrytou prastarou truhlu. Vezmi si z ní to, po čem toužíš.]],
[[Return to the Athenaeum and find the Treasure of the Shen'dralar. Claim your reward!]],
[[Vrať se do Athenaea, najdi poklad Shen'dralar a vyzvedni si svou odměnu!]])

add(7877, [[The Treasure of the Shen'dralar]],
[[In the library, Athenaeum, you will find an ancient chest hidden beneath the stairway. Take from it that which you desire.]],
[[V knihovně Athenaeum najdeš pod schodištěm ukrytou prastarou truhlu. Vezmi si z ní to, po čem toužíš.]],
[[Return to the Athenaeum and find the Treasure of the Shen'dralar. Claim your reward!]],
[[Vrať se do Athenaea, najdi poklad Shen'dralar a vyzvedni si svou odměnu!]])

add(2662, [[Noggenfogger Elixir]],
[[Now, to mix this powder in with the dew.$B$BCome back and talk to me in a minute... after I have perfected the fabulous Noggenfogger Elixir!]],
[[Teď smíchám tenhle prášek s rosou.$B$BVrať se za minutu... až dokončím báječný Noggenfoggerův elixír!]],
[[Marin Noggenfogger wants you to speak to him again after he creates his elixir.]],
[[Marin Noggenfogger chce, abys s ním znovu promluvil, až dokončí svůj elixír.]])

add(9325, [[Stealing Thunder Bluff's Flame]],
[[This flame, stolen from the shaman of Thunder Bluff, floods you with warmth. This raw power is foreign to you, but the Loremaster might know more...]],
[[Tento plamen, ukradený šamanům Thunder Bluffu, tě zaplavuje teplem. Tato syrová moc je ti cizí, ale Loremaster by o ní mohl vědět víc...]],
[[Return the Flame of Thunder Bluff to the Festival Loremaster.]],
[[Vrať Flame of Thunder Bluff Festival Loremasterovi.]])

add(7495, [[Victory for the Alliance]],
[[You have accomplished the impossible. The brood mother of the Black Dragonflight lies dead at your feet. Take her head and present it to the Highlord.]],
[[Dokázal jsi nemožné. Matka rodu Black Dragonflight leží mrtvá u tvých nohou. Vezmi její hlavu a předlož ji Highlordovi.]],
[[Take the Head of Onyxia to Highlord Bolvar Fordragon in Stormwind.]],
[[Dones hlavu Onyxie Highlordu Bolvaru Fordragonovi do Stormwindu.]])

add(8227, [[Nat's Measuring Tape]],
[[Amongst the shattered fishing lures and tackle is a rolled, silken measuring tape.Attached to the tape is a label that reads:$B$B"Nat Pagle, Dustwallow Marsh."]],
[[Mezi rozbitými návnadami a rybářským náčiním leží svinutý hedvábný měřicí pás. Je na něm štítek s nápisem:$B$B„Nat Pagle, Dustwallow Marsh.“]],
[[Return Nat's Measuring Tape to Nat Pagle in Dustwallow Marsh.]],
[[Vrať Natův měřicí pás Natovi Pagleovi v Dustwallow Marsh.]])

add(9326, [[Stealing the Undercity's Flame]],
[[This flame, stolen from the ruins above the Undercity, floods you with warmth. This raw power is foreign to you, but the Loremaster might know more...]],
[[Tento plamen, ukradený z ruin nad Undercity, tě zaplavuje teplem. Tato syrová moc je ti cizí, ale Loremaster by o ní mohl vědět víc...]],
[[Return the Flame of the Undercity to the Festival Loremaster.]],
[[Vrať Flame of the Undercity Festival Loremasterovi.]])

add(1423, [[The Lost Supplies]],
[[This barrel is small yet sturdy.Its seams are sealed with a yellow, pungent wax.Stamped on the bottom of the barrel are the words:$B$BQUARTERMASTER LUNGERTZ$B$BNETHERGARDE KEEP]],
[[Tento sud je malý, ale pevný. Jeho spoje jsou utěsněny žlutým, pronikavě páchnoucím voskem. Na dně sudu je vyraženo:$B$BQUARTERMASTER LUNGERTZ$B$BNETHERGARDE KEEP]],
[[Bring the Lost Supplies to Quartermaster Lungertz.]],
[[Dones ztracené zásoby Quartermasteru Lungertzovi.]])

add(8387, [[Invaders of Alterac Valley]],
[[The battle for Alterac rages on! You must return to Alterac Valley and once more drive the invaders out of Frostwolf territory, $N!]],
[[Bitva o Alterac zuří dál! Musíš se vrátit do Alterac Valley a znovu vyhnat vetřelce z území Frostwolf, $N!]],
[[Bring 3 Alterac Valley Marks of Honor to a Horde Warbringer outside the battlegrounds.]],
[[Přines 3 Alterac Valley Marks of Honor hordskému Warbringerovi před bojištěm.]])

add(2874, [[Deliver to MacKinley]],
[[Thanks again for your help, $N.Here's a bottle of Steamwheedle bilge rum.Take it to MacKinley and he can finally put to rest his crazy beliefs about Booty Bay booze.]],
[[Ještě jednou díky za pomoc, $N. Tady je láhev Steamwheedle bilge rumu. Dones ji MacKinleymu, ať konečně pustí z hlavy své bláznivé představy o alkoholu z Booty Bay.]],
[[Bring Stoley's Bottle to "Sea Wolf" MacKinley in Booty Bay.]],
[[Dones Stoleyho láhev „Sea Wolf“ MacKinleymu v Booty Bay.]])

add(3626, [[Return to the Blasted Lands]],
[[The hour of redemption is near, $N. You must return to the Blasted Lands with your new-found weaponry and speak with the Fallen Hero of the Horde to receive your final objective.]],
[[Hodina vykoupení se blíží, $N. Musíš se se svou nově získanou výzbrojí vrátit do Blasted Lands a promluvit si s padlým hrdinou Hordy, který ti dá poslední úkol.]],
[[Return to the Fallen Hero of the Horde.]],
[[Vrať se k padlému hrdinovi Hordy.]])

add(7787, [[Rise, Thunderfury!]],
[[You have defeated the Wind Seeker. Take the dormant blade and force the lying wretch, Demitrian, to use the materials you provided for his betrayal to wake Thunderfury.]],
[[Porazil jsi Wind Seekera. Vezmi nečinnou čepel a přinuť toho prolhaného bídáka Demitriana, aby materiály, které jsi mu kvůli jeho zradě poskytl, použil k probuzení Thunderfury.]],
[[Present the Dormant Wind Kissed Blade to Highlord Demitrian.]],
[[Předlož Dormant Wind Kissed Blade Highlordu Demitrianovi.]])

add(1392, [[Noboru the Cudgel]],
[[Noboru has plagued the Draenei of the Harborage for months, and his cudgel is a symbol of the brutality they have suffered at the hands of the lost ones.]],
[[Noboru sužuje Draenei z Harborage už celé měsíce a jeho kyj je symbolem brutality, kterou trpěli z rukou ztracených.]],
[[Bring Noboru's Cudgel to the leader of The Harborage in the Swamp of Sorrows.]],
[[Přines Noborův kyj vůdci Harborage ve Swamp of Sorrows.]])

add(8784, [[Secrets of the Qiraji]],
[[You have discovered an ancient Qiraji artifact! Perhaps one of the dragons near the entrance of the temple would have a use for this relic.]],
[[Objevil jsi prastarý artefakt Qiraji! Možná by pro tuto relikvii našel využití některý z draků poblíž vstupu do chrámu.]],
[[Take the Ancient Qiraji Artifact to the dragons hiding near the entrance of the temple.]],
[[Dones Ancient Qiraji Artifact drakům ukrývajícím se poblíž vstupu do chrámu.]])

add(8493, [[The Alliance Needs More Copper Bars!]],
[[Back again $c? Outstanding! We still need more stacks of copper bars if you can procure them for the Ahn'Qiraj war effort.Will you help us out?]],
[[Zase zpátky, $c? Výborně! Pro válečné úsilí v Ahn'Qiraj stále potřebujeme další hromady měděných prutů, pokud je dokážeš sehnat. Pomůžeš nám?]],
[[Bring 20 copper bars to Sergeant Stonebrow at the airfield in Dun Morogh.]],
[[Přines 20 měděných prutů Sergeantovi Stonebrowovi na letiště v Dun Morogh.]])

add(3566, [[Rise, Obsidion!]],
[[It... It... It was all a trap.$B$BForgive... me.$B$BKill the bastard... Kill him for us... for Thorius.]],
[[Byla... byla... to všechno past.$B$BOdpusť... mi.$B$BZabij toho parchanta... Zabij ho za nás... za Thoriuse.]],
[[Slay Lathoric the Black and Obsidion, and return to Thorius in Ironforge with the Head of Lathoric the Black and the Heart of Obsidion. ]],
[[Zabij Lathorica the Black a Obsidiona a vrať se k Thoriusovi do Ironforge s hlavou Lathorica the Black a srdcem Obsidiona. ]])

add(5265, [[The Argent Hold]],
[[Through the years the Argent Hold has remained locked. None have been worthy to reach inside and take from it the power of the Argent Dawn - until today.$B$BThe Argent Hold is now open to you, $N.]],
[[Argent Hold zůstával po celé roky uzamčen. Nikdo nebyl hoden sáhnout dovnitř a převzít moc Argent Dawn — až do dneška.$B$BArgent Hold je ti nyní otevřen, $N.]],
[[Open the Argent Hold and claim your reward.]],
[[Otevři Argent Hold a vyzvedni si svou odměnu.]])

add(7847, [[Return to Primal Torntusk]],
[[Return to my mate, Primal Torntusk at Revantusk Village. Tell her that I am coming home! She is sure to reward you.]],
[[Vrať se k mé družce Primal Torntusk do Revantusk Village. Řekni jí, že se vracím domů! Určitě tě odmění.]],
[[Elder Torntusk at Jintha'alor wants you to return to Primal Torntusk at Revantusk Village with news of his rescue.]],
[[Elder Torntusk v Jintha'alor chce, abys se vrátil k Primal Torntusk v Revantusk Village se zprávou o jeho záchraně.]])

add(1953, [[Return to the Marsh]],
[[It is time, $N, for you to speak with Tabetha... the hermit of Dustwallow Marsh.She will instruct you on the creation of a powerful mage's implement.$B$BTabetha's shack lies deep in Dustwallow Marsh, west of Theramore.]],
[[Je čas, $N, abys promluvil s Tabethou... poustevnicí z Dustwallow Marsh. Naučí tě vyrobit mocný mágův nástroj.$B$BTabethina chatrč leží hluboko v Dustwallow Marsh, západně od Theramore.]],
[[Speak with Tabetha.]],
[[Promluv si s Tabethou.]])

add(8802, [[The Savior of Kalimdor]],
[[To the Caverns of Time you go, $G Lord:Lady; $N. Anachronos awaits your return. Give him the eye of C'Thun as he will undoubtedly wish to place it in his master's collection.]],
[[Vydej se do Caverns of Time, $G pane:paní; $N. Anachronos očekává tvůj návrat. Dej mu oko C'Thuna; bezpochyby ho bude chtít uložit do sbírky svého pána.]],
[[Take the Eye of C'Thun to Anachronos at the Caverns of Time.]],
[[Dones oko C'Thuna Anachronosovi do Caverns of Time.]])

add(5464, [[Menethil's Gift]],
[[The soul of the fallen clings to that which represents its former life and transforms the item into a soulbound keepsake. You pick the item up and place it in your pack.]],
[[Duše padlého se upíná k tomu, co představuje jeho dřívější život, a promění předmět v památku spoutanou s duší. Zvedneš ji a uložíš do svého vaku.]],
[[Take the Soulbound Keepsake to Leonid Barthalomew in Eastern Plaguelands.]],
[[Dones památku spoutanou s duší Leonidu Barthalomewovi v Eastern Plaguelands.]])

add(8351, [[Bor Wishes to Speak]],
[[Now that you can disguise yourself as a ruling member of the Twilight Council, I am certain Bor Wildmane will want to speak with you.Go see him, and prepare yourself for a very difficult mission...]],
[[Teď, když se dokážeš převléci za vysoce postaveného člena Twilight Councilu, jsem si jistý, že s tebou Bor Wildmane bude chtít mluvit. Vyhledej ho a připrav se na velmi obtížný úkol...]],
[[Speak with Bor Wildmane in Cenarion Hold.]],
[[Promluv si s Borem Wildmanem v Cenarion Hold.]])

add(1388, [[Nothing But The Truth]],
[[Everything is proceeding according to plan, $n. I want you to give this truth serum to Deathstalker Zraedus and he'll show you how to administer it.... properly.$b$bHaha!]],
[[Všechno jde podle plánu, $n. Chci, abys toto sérum pravdy předal Deathstalkeru Zraedusovi. Ukáže ti, jak ho podat... správným způsobem.$b$bHaha!]],
[[Give Faustin's Truth Serum to Deathstalker Zraedus at Beggar's Haunt.]],
[[Dej Faustinovo sérum pravdy Deathstalkeru Zraedusovi v Beggar's Haunt.]])

add(3562, [[Magatha's Payment to Jediga]],
[[Take this note to Jediga. Tell her the payment will be here for her when she returns. And tell her I am pleased with her work.$B$BGo swiftly, $N. Tell your master I will be awaiting her here.]],
[[Dones tento vzkaz Jedize. Řekni jí, že odměna tu na ni bude čekat, až se vrátí. A řekni jí, že jsem s její prací spokojená.$B$BPospěš, $N. Řekni své paní, že na ni budu čekat tady.]],
[[Deliver Magatha's Note to Jediga in Azshara.]],
[[Doruč Magathin vzkaz Jedize v Azshaře.]])

add(8349, [[Bor Wildmane]],
[[Now that you have a medallion and can summon an Abyssal Duke, speak with Bor Wildmane.He will set you on a task against the Abyssal Council.$B$BGood luck, $N.And if you ever need more medallions, return to me.]],
[[Teď, když máš medailon a dokážeš vyvolat Abyssal Dukea, promluv si s Borem Wildmanem. Pošle tě na úkol proti Abyssal Councilu.$B$BHodně štěstí, $N. A pokud budeš někdy potřebovat další medailony, vrať se za mnou.]],
[[Speak with Bor Wildmane in Cenarion Hold.]],
[[Promluv si s Borem Wildmanem v Cenarion Hold.]])

add(7783, [[The Lord of Blackrock]],
[[The old feeling returns. The welcome pangs of victory reverberate throughout your being. Before you lies the monolithic, battle scarred head of Nefarian. Return it to your Warchief, champion.]],
[[Starý pocit se vrací. Tvým tělem znovu prostupuje vítané zachvění vítězství. Před tebou leží obrovská, bojem zjizvená hlava Nefariana. Dones ji svému Warchiefovi, šampione.]],
[[Return the Head of Nefarian to Thrall in Orgrimmar.]],
[[Dones hlavu Nefariana Thrallovi do Orgrimmaru.]])

add(2978, [[The Gordunni Scroll]],
[[Picking up the soiled scroll, you notice that it seems to be depicting some sort of meeting or ceremony. Rok Orhan would be interested in this scroll, and what it might mean to the Gordunni.]],
[[Když zvedneš zašpiněný svitek, všimneš si, že zřejmě znázorňuje jakési setkání nebo obřad. Rok Orhan by se o něj i o jeho význam pro Gordunni mohl zajímat.]],
[[Bring the Gordunni Scroll to Rok Orhan in Camp Mojache.]],
[[Přines Gordunnijský svitek Roku Orhanovi do Camp Mojache.]])

add(2937, [[Summoning Shadra]],
[[Take his parchment, and read it at the altar of Shadra'Alor, deep within the witherbark realm in the Hinterlands.This will summon Shadra the spider god.]],
[[Vezmi jeho pergamen a přečti jej u oltáře Shadra'Alor hluboko na území Witherbark v Hinterlands. Tím vyvoláš pavoučí bohyni Shadru.]],
[[Defeat Shadra at the altar of Shadra'Alor, then bring her venom to Apothecary Lydon in Tarren Mill.]],
[[Poraz Shadru u oltáře Shadra'Alor a potom přines její jed Apothecary Lydonovi v Tarren Mill.]])

add(2933, [[Venom Bottles]],
[[These bottles hold a vile, green venom.$B$BConsidering the number of bottles in this village, the Witherbarks must deem it very important.Perhaps an apothecary in nearby Tarren Mill would like a sample.]],
[[Tyto lahvičky obsahují odporný zelený jed.$B$BVzhledem k množství lahviček v této vesnici ho Witherbarkové musí považovat za velmi důležitý. Možná by o vzorek měl zájem některý lékárník v nedalekém Tarren Mill.]],
[[Bring a Venom Bottle to an apothecary in Tarren Mill.]],
[[Přines lahvičku s jedem některému lékárníkovi v Tarren Mill.]])

add(1560, [[Tooga's Quest]],
[[I am so lost!$b$bMy wife, Torta, sent me out to fetch dinner and I must have taken a wrong turn somewhere.$b$bWould you be so kind as to lead me back to Torta? She's waiting for me just south of Steamwheedle Port.]],
[[Jsem úplně ztracený!$b$bMoje žena Torta mě poslala obstarat večeři a někde jsem musel špatně odbočit.$b$bByl bys tak hodný a dovedl mě zpět k Tortě? Čeká na mě kousek jižně od Steamwheedle Port.]],
[[Show Tooga the way back to his wife, Torta.]],
[[Ukaž Toogovi cestu zpět k jeho ženě Tortě.]])

add(5264, [[Lord Maxwell Tyrosus]],
[[I am about to bestow a great honor upon you, $N.$B$BLord Maxwell wishes to reward you for your service to the Argent Dawn!$B$BIt has been years since Maxwell has granted audience to outsiders.]],
[[Chystám se ti prokázat velkou čest, $N.$B$BLord Maxwell tě chce odměnit za tvou službu Argent Dawn!$B$BJe to už mnoho let, co Maxwell naposledy přijal někoho zvenčí.]],
[[Speak with Lord Maxwell Tyrosus. He is inside the church.]],
[[Promluv si s Lordem Maxwellem Tyrosem. Je uvnitř kostela.]])

add(8303, [[Anachronos]],
[[It is time, $N.$B$BI must apologize for keeping so much in secret. Enemies abound, even under our very noses. Please, read from this tome and learn. Take the knowledge I give to you and seek out our master.]],
[[Je čas, $N.$B$BMusím se omluvit, že jsem toho tolik držel v tajnosti. Nepřátelé jsou všude, dokonce přímo pod naším nosem. Prosím, přečti si tuto knihu a pouč se. Vezmi znalosti, které ti dávám, a vyhledej našeho mistra.]],
[[Seek out Anachronos at the Caverns of Time in Tanaris.]],
[[Vyhledej Anachronose v Caverns of Time v Tanarisu.]])

add(1323, [[The Black Shield]],
[[Oh, I think I might have dropped too much acid onto the shield. Let me just rub a little...$b$bHm, kind of hard to read, but it looks like the name Mosarn. Never heard of him. Maybe Krog knows. Krog knows many people.]],
[[Ach, myslím, že jsem na štít nalil příliš mnoho kyseliny. Jen to trochu otřu...$b$bHm, špatně se to čte, ale vypadá to na jméno Mosarn. Nikdy jsem o něm neslyšel. Možná ho zná Krog. Krog zná spoustu lidí.]],
[[Talk with Krog in Brackenwall Village.]],
[[Promluv si s Krogem v Brackenwall Village.]])

add(6032, [[Sacred Cloth]],
[[Although the people of Timbermaw delight in the feel of runecloth, it is not sacred to us.But mooncloth is sacred.$B$BBring me a small supply of this holy cloth, and I will teach you a secret fashioning technique. ]],
[[Lid Timbermaw má rád dotek runeclothu, ale pro nás není posvátný. Mooncloth však posvátný je.$B$BPřines mi malé množství této svaté látky a naučím tě tajnou výrobní techniku. ]],
[[Bring 2 Mooncloth to Meilosh in Timbermaw Hold.]],
[[Přines 2 Mooncloth Meiloshovi v Timbermaw Hold.]])

add(8317, [[Kitchen Assistance]],
[[That recipe sure will come in handy.I'd better get to work so I can have some smoked desert dumplings ready for today.I could use a hand in making some, I'll make it worth your while.]],
[[Ten recept se určitě bude hodit. Raději se pustím do práce, abych měl na dnešek připravené uzené pouštní knedlíčky. Pomocná ruka by se mi při jejich přípravě hodila a dobře se ti odměním.]],
[[Calandrath at Cenarion Hold needs a batch of 10 Smoked Desert Dumplings.]],
[[Calandrath v Cenarion Hold potřebuje várku 10 Smoked Desert Dumplings.]])

add(2989, [[The Altar of Zul]],
[[Sharpbeak was not with the Witherbark trolls.Perhaps the Vilebranch trolls took him.Go to the Altar of Zul on the western edge of Vilebranch territory and search for the gryphon child. ]],
[[Sharpbeak nebyl u trollů Witherbark. Možná ho unesli trollové Vilebranch. Vydej se k Altar of Zul na západním okraji území Vilebranch a hledej mládě gryfona. ]],
[[Check the top of the Altar of Zul, then return to Gryphon Master Talonaxe.]],
[[Prohledej vrchol Altar of Zul a potom se vrať ke Gryphon Masteru Talonaxeovi.]])

add(8417, [[A Troubled Spirit]],
[[In the Blasted Lands, there is a troubled spirit who was once a great hero of the horde.A warrior's honor does not die with the body, and it would serve you well to speak with him.]],
[[V Blasted Lands přebývá neklidný duch, který býval velkým hrdinou Hordy. Čest válečníka neumírá s jeho tělem a prospělo by ti s ním promluvit.]],
[[Speak with the Fallen Hero of the Horde at the entrance to the Blasted Lands.]],
[[Promluv si s padlým hrdinou Hordy u vstupu do Blasted Lands.]])

add(4321, [[Making Sense of It]],
[[The information you have given me about the pylons is very interesting...$B$BGive me a moment to do some calculations, $N. Speak to me again in a moment and I should be able to give you the answer we have been looking for.]],
[[Informace, které jsi mi dal o pylonech, jsou velmi zajímavé...$B$BDej mi chvíli na pár výpočtů, $N. Za okamžik se mnou promluv znovu a měl bych mít odpověď, kterou hledáme.]],
[[Speak with J.D. Collie in a moment.]],
[[Za chvíli znovu promluv s J.D. Collie.]])

add(1321, [[The Black Shield]],
[[Hmm... I don't see anything out of the ordinary with this shield. We should have Do'gol, the blacksmith, take a look at it, and see if he can tell us more about it, but I wouldn't hold out hope...]],
[[Hmm... Na tomhle štítu nevidím nic neobvyklého. Měli bychom ho ukázat kováři Do'golovi a zjistit, jestli nám o něm řekne víc, ale moc bych si od toho nesliboval...]],
[[Show the Blackened Iron Shield to Do'gol in Brackenwall Village.]],
[[Ukaž Blackened Iron Shield Do'golovi v Brackenwall Village.]])

add(1703, [[Mathiel]],
[[I made a copy of my notes on the techniques I learned while making your armor, and need them sent to the blacksmith Mathiel.He lives in Darnassus which is quite a long way off, but I'm sure he'll be very grateful to learn what I've learned.]],
[[Udělala jsem kopii svých poznámek o technikách, které jsem se naučila při výrobě tvé zbroje, a potřebuji je poslat kováři Mathielovi. Žije v Darnassusu, což je pořádný kus cesty, ale jsem si jistá, že za mé poznatky bude velmi vděčný.]],
[[Bring Furen's Notes to Mathiel.]],
[[Dones Furenovy poznámky Mathielovi.]])

add(7564, [[Wildeyes]],
[[My servant, Gorzeeki, is an alchemist of some skill.He can prepare the ink I will need for your parchment.I gathered together the blood you acquired; take it to Gorzeeki so that he can begin his work.]],
[[Můj sluha Gorzeeki je docela schopný alchymista. Dokáže připravit inkoust, který budu potřebovat pro tvůj pergamen. Krev, kterou jsi získal, jsem dal dohromady; dones ji Gorzeekimu, aby mohl začít pracovat.]],
[[Bring the Case of Blood to Gorzeeki Wildeyes in the Burning Steppes.]],
[[Dones Case of Blood Gorzeekimu Wildeyesovi v Burning Steppes.]])

add(1375, [[Khan Shaka]],
[[You help the Magram, and I like you.Now, kill the Khan of the Gelkis!He is Khan Shaka, and I want his head!I want to stare at his head and laugh at him!]],
[[Pomáháš Magramům a to se mi líbí. Teď zabij Khana Gelkisů! Je to Khan Shaka a já chci jeho hlavu! Chci se na ni dívat a smát se mu!]],
[[Maintain your reputation with the Magram, and bring the Head of Khan Shaka to Warug in the Magram Village in Desolace.]],
[[Udrž si reputaci u Magramů a přines hlavu Khana Shaky Warugovi do Magram Village v Desolace.]])

add(1273, [[Questioning Reethe]],
[[It took a long time, but I found Reethe. He hide good for a human.$b$bOgron worried that he might be crazy after so much time in swamp. You come with me for we go get answers from him.]],
[[Trvalo to dlouho, ale našel jsem Reetha. Na člověka se schovával dobře.$b$bOgron má strach, že po tak dlouhé době v bažině zešílel. Pojď se mnou, získáme z něj odpovědi.]],
[[Go with Ogron to speak with Reethe, then return to Krog in Brackenwall Village.]],
[[Jdi s Ogronem promluvit s Reethem a potom se vrať ke Krogovi do Brackenwall Village.]])

add(7781, [[The Lord of Blackrock]],
[[The old feeling returns. The welcome pangs of victory reverberate throughout your being. Before you lies the monolithic, battle scarred head of Nefarian. Return it to your Highlord, champion.]],
[[Starý pocit se vrací. Tvým tělem znovu prostupuje vítané zachvění vítězství. Před tebou leží obrovská, bojem zjizvená hlava Nefariana. Dones ji svému Highlordovi, šampione.]],
[[Return the Head of Nefarian to Highlord Bolvar Fordragon in Stormwind.]],
[[Dones hlavu Nefariana Highlordu Bolvaru Fordragonovi do Stormwindu.]])

add(8411, [[Mastering the Elements]],
[[Welcome, $c.You bring me the elements and then we do the talkin'.$b$bThe fire, the air, the water, and the earth I be needin' before I trust ya, mon.I gots to know you be knowledgeable.]],
[[Vítej, $c. Přines mi elementy a pak si promluvíme.$b$bNež ti budu věřit, potřebuju oheň, vzduch, vodu a zemi, kámo. Musím vědět, že tomu rozumíš.]],
[[Bring the elements earth, air, fire and water to Bath'rah the Windwatcher.]],
[[Přines elementy země, vzduchu, ohně a vody Bath'rahovi the Windwatcher.]])

add(2755, [[Joys of Omosh]],
[[Orokk is not crying, $N. Soot is in eye.$B$B<Orokk wipes a tear away.>$B$BThere is one last Omosh family secret Orokk will teach you. Orokk will die happy, thanks to $N.$B$BLearn Omosh dance of joy and then you learn fist of iron!]],
[[Orokk nebrečí, $N. Jen má saze v oku.$B$B<Orokk si utře slzu.>$B$BOrokk tě naučí poslední tajemství rodiny Omosh. Díky $N může Orokk zemřít šťastný.$B$BNauč se radostný tanec Omosh a potom se naučíš železnou pěst!]],
[[Watch and learn the Omosh Dance of Joy.]],
[[Sleduj a nauč se Omosh Dance of Joy.]])

add(7121, [[The Quartermaster]],
[[$N, our quartermaster charged me to direct new recruits to him.He needs supplies from caches stored in the mines of Alterac, and he'll probably send you to get them.$B$BFollow the road.You'll find our quartermaster to the west.]],
[[$N, náš quartermaster mě pověřil, abych k němu posílal nové rekruty. Potřebuje zásoby ze skrýší v dolech Alteracu a nejspíš tě pro ně pošle.$B$BJdi po cestě. Najdeš našeho quartermastera na západě.]],
[[Speak with the Stormpike Quartermaster.]],
[[Promluv si se Stormpike Quartermasterem.]])

add(8415, [[Chillwind Point]],
[[Commander Ashlam Valorfist has sent out a call for a paladin of your purity and valor, $n.You can find him at Chillwind Camp in the southern part of the Western Plaguelands.Seek him and aid in his cause for the Light!]],
[[Commander Ashlam Valorfist hledá paladina tvé čistoty a statečnosti, $n. Najdeš ho v Chillwind Camp v jižní části Western Plaguelands. Vyhledej ho a pomoz mu v jeho boji za Světlo!]],
[[Speak to Commander Ashlam Valorfist at Chillwind Camp.]],
[[Promluv si s Commanderem Ashlamem Valorfistem v Chillwind Camp.]])

add(8977, [[Return to Deliana]],
[[It's been great working with you, $N.Here is the finished product.$B$BI hope it helps you in your current endeavors.And hey, if you don't mind, help spread the word.I wouldn't mind having more customers!]],
[[Bylo skvělé s tebou pracovat, $N. Tady je hotový výrobek.$B$BDoufám, že ti pomůže v tom, čemu se právě věnuješ. A jestli ti to nevadí, roznes o mně dobré slovo. Pár dalších zákazníků by se hodilo!]],
[[Bring the Extra-Dimensional Ghost Revealerto Deliana in Ironforge.]],
[[Dones Extra-Dimensional Ghost Revealer Delianě v Ironforge.]])

add(8800, [[Cenarion Battlegear]],
[[As you complete the tasks you're assigned in the war you'll want to talk to Vargus, the blacksmith.Show him any badges you've earned along the way. He'll provide you with gear to match your level of commitment to our cause.]],
[[Až budeš plnit úkoly, které ti ve válce přidělí, promluv si s kovářem Vargusem. Ukaž mu odznaky, které cestou získáš. Poskytne ti výbavu odpovídající tomu, jak moc ses zasloužil o naši věc.]],
[[Talk to Vargus at Cenarion Hold in Silithus.]],
[[Promluv si s Vargusem v Cenarion Hold v Silithusu.]])

add(5164, [[Catalogue of the Wayward]],
[[A finer instrument of justice, Haleh could not have chosen. Read from the catalogue of the wayward and be enlightened.$B$BShould you persist... should you do what is asked of you... should you survive... a hero you will make.]],
[[Haleh si nemohla vybrat lepší nástroj spravedlnosti. Čti z katalogu zbloudilých a nech se poučit.$B$BPokud vytrváš... pokud uděláš, co se po tobě žádá... pokud přežiješ... stane se z tebe hrdina.]],
[[Read from the Catalogue of the Wayward.]],
[[Přečti si Katalog zbloudilých.]])

add(1713, [[The Summoning]],
[[I am ready to perform the ritual to summon Cyclonian.When he is summoned, you must defeat him and take his whirlwind heart.This I will use to instill a weapon with Cyclonian's power.$B$B$N, are you ready to face the wind lord?]],
[[Jsem připraven provést rituál k vyvolání Cycloniana. Až se objeví, musíš ho porazit a vzít mu srdce víru. To použiji k naplnění zbraně Cyclonianovou mocí.$B$B$N, jsi připraven čelit pánovi větru?]],
[[Bring the Whirlwind Heart to Bath'rah Windwatcher.]],
[[Přines Whirlwind Heart Bath'rahovi Windwatcherovi.]])

add(8233, [[A Simple Request]],
[[Lord Jorach Ravenholdt has requested your presence.The matter is secret, and I cannot say any more.$b$bRavenholdt Manor is located in the Hillsbrad Foothills -- look for a path in the mountains northwest of Durnhold Keep.]],
[[Lord Jorach Ravenholdt si vyžádal tvou přítomnost. Záležitost je tajná a víc ti říct nemohu.$b$bRavenholdt Manor leží v Hillsbrad Foothills — hledej stezku v horách severozápadně od Durnhold Keep.]],
[[Speak with Lord Jorach Ravenholdt in Ravenholdt Manor.]],
[[Promluv si s Lordem Jorachem Ravenholdtem v Ravenholdt Manor.]])

add(8978, [[Return to Mokvar]],
[[It's been great working with you, $N.Here is the finished product.$B$BI hope it helps you in your current endeavors.And hey, if you don't mind, help spread the word.I wouldn't mind having more customers!]],
[[Bylo skvělé s tebou pracovat, $N. Tady je hotový výrobek.$B$BDoufám, že ti pomůže v tom, čemu se právě věnuješ. A jestli ti to nevadí, roznes o mně dobré slovo. Pár dalších zákazníků by se hodilo!]],
[[Return to Mokvar in Orgrimmar with the Extra-Dimensional Ghost Revealer.]],
[[Vrať se k Mokvarovi do Orgrimmaru s Extra-Dimensional Ghost Revealerem.]])

add(8302, [[The Hand of the Righteous]],
[[Choose your deputies wisely, mortal. Each time you return with your task complete, a new deputy you will be allowed to choose.$B$BWith that said, I require more of the carapace fragments. Waste no time!]],
[[Vybírej své zástupce moudře, smrtelníku. Pokaždé, když se vrátíš se splněným úkolem, budeš si moci zvolit dalšího.$B$BA teď k věci: potřebuji další úlomky krunýřů. Neztrácej čas!]],
[[Collect 200 Silithid Carapace Fragments and return to Baristolth.]],
[[Nasbírej 200 Silithid Carapace Fragments a vrať se k Baristolthovi.]])

add(3002, [[The Gordunni Orb]],
[[Although I know my enemy well, I am a warrior, $N. I cannot begin to tell you what this orb is capable of.$B$BI know of a mage in Orgrimmar that will be able to tell us more about the orb. Take it to him. ]],
[[Ačkoli svého nepřítele dobře znám, jsem válečník, $N. Nedokážu ani odhadnout, čeho je tahle koule schopná.$B$BZnám v Orgrimmaru mága, který nám o ní dokáže říct víc. Dones mu ji. ]],
[[Bring the Gordunni Orb to Uthel'nay in the Darkbriar Lodge in Orgrimmar.]],
[[Dones Gordunnijskou kouli Uthel'nayovi do Darkbriar Lodge v Orgrimmaru.]])

add(8416, [[Inert Scourgestones]],
[[The evil has been purged from the stones, $n.$b$bI am aware of Commander Ashlam's plans, and he will require only a single inert stone.Bring it to him so we may bathe the Scourge in righteous fire.]],
[[Zlo bylo z kamenů očištěno, $n.$b$bZnám plány Commandera Ashlama a bude potřebovat jen jeden nečinný kámen. Dones mu ho, abychom mohli Scourge zahalit do spravedlivého ohně.]],
[[Bring the Inert Scourgestone to Commander Ashlan Valorfist in Chillwind Point.]],
[[Dones Inert Scourgestone Commanderovi Ashlanovi Valorfistovi do Chillwind Point.]])

add(1319, [[The Black Shield]],
[[I'm sorry I can't be of much help, $n, but I can refer you to someone who would be. Caz Twosprocket, one of our best blacksmiths, works the forge at the smithy.$b$bTake the shield to him, and see what he can tell you.]],
[[Mrzí mě, že ti moc nepomůžu, $n, ale můžu tě poslat za někým, kdo by mohl. Caz Twosprocket, jeden z našich nejlepších kovářů, pracuje u výhně v kovárně.$b$bDones mu štít a zjisti, co ti o něm dokáže říct.]],
[[Show the Blackened Iron Shield to Caz Twosprocket in Theramore.]],
[[Ukaž Blackened Iron Shield Cazu Twosprocketovi v Theramore.]])

add(8512, [[The Alliance Needs More Light Leather!]],
[[Good to see you again $N. It does appear that we need more light leather for the creation of the various war materiel. If you could bring me a stack of ten that would be just perfect.]],
[[Rád tě zase vidím, $N. Zdá se, že pro výrobu různého válečného materiálu potřebujeme další lehkou kůži. Kdybys mi přinesl deset kusů, bylo by to ideální.]],
[[Bring 10 light leather to Bonnie Stoneflayer at the airfield in Dun Morogh.]],
[[Přines 10 kusů lehké kůže Bonnie Stoneflayer na letiště v Dun Morogh.]])

add(7223, [[Armor Scraps]],
[[Battles rage constantly in Alterac Valley, and the supplies we get from Ironforge are not enough to outfit our experienced troops.$B$BIf you find armor scraps from the battlefield, aid the war effort and bring those scraps to me!]],
[[V Alterac Valley neustále zuří boje a zásoby z Ironforge nestačí k vybavení našich zkušených vojáků.$B$BPokud na bojišti najdeš úlomky zbroje, podpoř válečné úsilí a přines mi je!]],
[[Bring 20 Armor Scraps to Murgot Deepforge in Dun Baldar.]],
[[Přines 20 Armor Scraps Murgotu Deepforgeovi v Dun Baldar.]])

add(8587, [[Return to Narain]],
[[I'm a goblin of my word, kid. Here's your 500 pound chicken.$B$BWhat a gnome wants with a 500 pound chicken, I'll never know...$B$B<Dirge grumbles something unintelligible.>$B$BProbably to sleep in it... Dirty gnomes...]],
[[Jsem goblin, který drží slovo, prcku. Tady máš své pětisetlibrové kuře.$B$BCo chce gnóm s pětisetlibrovým kuřetem, to se asi nikdy nedozvím...$B$B<Dirge si něco nesrozumitelně zamumlá.>$B$BNejspíš v něm chce spát... Špinaví gnómové...]],
[[Deliver the 500 Pound Chicken to Narain Soothfancy in Tanaris.]],
[[Doruč 500 Pound Chicken Narainovi Soothfancymu v Tanarisu.]])

add(8527, [[The Alliance Needs More Roast Raptor!]],
[[Hi again $c. I can tell you're very excited about all of this. So I suppose you want to bring me another twenty roast raptor. Great. Well you do that. I guess I'll see you when you get back.]],
[[Zdravím znovu, $c. Je vidět, že tě tohle všechno opravdu nadchlo. Takže mi asi chceš přinést dalších dvacet pečených raptorů. Skvělé. Udělej to a uvidíme se, až se vrátíš.]],
[[Bring 20 roast raptor to Sarah Sadwhistle at the airfield in Dun Morogh.]],
[[Přines 20 pečených raptorů Sarah Sadwhistle na letiště v Dun Morogh.]])

add(9026, [[Tracing the Source]],
[[We've got to find the source. I've seen a lot more people than usual - guards included - going in and out of The Gilded Rose. Talk to Allison. If she's selling them, she can tell you where they came from.]],
[[Musíme najít zdroj. Všiml jsem si, že do The Gilded Rose chodí mnohem víc lidí než obvykle, včetně stráží. Promluv s Allison. Pokud je prodává, může ti říct, odkud pocházejí.]],
[[Speak with Innkeeper Allison at The Gilded Rose in Stormwind's Trade District.]],
[[Promluv si s Innkeeper Allison v The Gilded Rose v Trade Districtu Stormwindu.]])

add(4133, [[Vivian Lagrave]],
[[Shadowmaster Vivian Lagrave is in need of your services.She is in the Badlands, in the orcish outpost of Kargath, pursuing rumors of a certain brew made by the Dark Iron dwarves of Blackrock Depths.$B$BSpeak with Vivian.She awaits you.]],
[[Shadowmaster Vivian Lagrave potřebuje tvé služby. Je v Badlands, v orčím táboře Kargath, kde prověřuje zvěsti o jistém nápoji vyráběném trpaslíky Dark Iron z Blackrock Depths.$B$BPromluv si s Vivian. Čeká na tebe.]],
[[Speak with Shadowmaster Vivian Lagrave in Kargath.]],
[[Promluv si se Shadowmaster Vivian Lagrave v Kargathu.]])

add(4881, [[Assassination Plot]],
[[The Tauren, Kanati Greycloud is bold to set up a hunting camp in Thousand Needles. We must kill him to rid this hunting camp and all who may follow him. We will converge at the small post Southwest of the Great Lift.]],
[[Tauren Kanati Greycloud je dost drzý na to, aby si v Thousand Needles založil lovecký tábor. Musíme ho zabít, abychom se zbavili jeho tábora i všech, kteří by ho mohli následovat. Sejdeme se u malého stanoviště jihozápadně od Great Lift.]],
[[Warn Kanati Greycloud at Whitereach Post of the plot to kill him.]],
[[Varuj Kanatiho Greyclouda ve Whitereach Post před plánem na jeho zabití.]])

add(4128, [[Ragnar Thunderbrew]],
[[Ho, $n.I heard that Ragnar Thunderbrew is steaming mad about someone stealing his ale.He's looking for stalwart adventurers, and willing to pay plenty.$B$BTalk to Ragnar if you're interested.He's at the Thunderbrew Distillery in Kharanos, in Dun Morogh.]],
[[Hej, $n. Slyšel jsem, že Ragnar Thunderbrew zuří, protože mu někdo ukradl pivo. Hledá odolné dobrodruhy a je ochoten dobře zaplatit.$B$BPokud tě to zajímá, promluv si s Ragnarem. Je v Thunderbrew Distillery v Kharanosu v Dun Morogh.]],
[[Speak with Ragnar Thunderbrew.]],
[[Promluv si s Ragnarem Thunderbrewem.]])

add(8932, [[Just Compensation]],
[[You kept your word and brought the device built by Mux.I believe a reward is in order if I'm to keep you interested in saving my skin.Bring me an ordinary belt and a set of gloves that you wish to upgrade.]],
[[Dodržel jsi slovo a přinesl zařízení, které vyrobil Mux. Myslím, že si zasloužíš odměnu, pokud tě mám dál motivovat k záchraně mé kůže. Přines mi obyčejný opasek a pár rukavic, které chceš vylepšit.]],
[[Bring a Magister's Belt and a set of Magister's Gloves to Deliana in Ironforge.]],
[[Přines Magister's Belt a Magister's Gloves Delianě v Ironforge.]])

add(2903, [[The Battle Plans]],
[[With the battle plans of the gnolls discovered, all that now remains is to bring the plans back to Hadoken Swiftstrider in Camp Mojache.Perhaps he or someone there can make further sense of what the gnolls are up to.]],
[[Když jsi objevil bitevní plány gnollů, zbývá už jen odnést je Hadokenu Swiftstriderovi do Camp Mojache. Možná on nebo někdo tam pochopí, co gnollové chystají.]],
[[Bring the Woodpaw Battle Plans to Hadoken Swiftstrider in Camp Mojache.]],
[[Přines Woodpaw Battle Plans Hadokenu Swiftstriderovi do Camp Mojache.]])

add(8254, [[Cenarion Aid]],
[[It is the way of the divine to help those in need.The how is insignificant -- only the why matters.$b$bThe Cenarion Circle has such a need.Speak with Ogtinc to lend aid to their plight.He resides atop the cliffs to the northeast of the Ruins of Eldarath in Azshara.]],
[[Cestou božského je pomáhat těm, kteří to potřebují. Jak, to není podstatné — důležité je proč.$b$bCenarion Circle takovou pomoc potřebuje. Promluv si s Ogtincem a pomoz jim v jejich nesnázích. Žije na vrcholu útesů severovýchodně od Ruins of Eldarath v Azshaře.]],
[[Seek out Ogtinc in Azshara.]],
[[Vyhledej Ogtince v Azshaře.]])

add(7492, [[Camp Mojache]],
[[Talo Thornhoof, a Tauren elder in Feralas, sends a request for aid.He offered few details, but he did say that he needs agents for a matter both delicate... and dire.$B$BServe the Horde, $N.Go to Camp Mojache in Feralas and speak with Talo.]],
[[Talo Thornhoof, taurení stařešina ve Feralasu, žádá o pomoc. Uvedl jen málo podrobností, ale řekl, že potřebuje agenty pro záležitost citlivou... a zároveň naléhavou.$B$BSluž Hordě, $N. Vydej se do Camp Mojache ve Feralasu a promluv si s Talem.]],
[[Speak with Talo Thornhoof at Camp Mojache in Feralas.]],
[[Promluv si s Talem Thornhoofem v Camp Mojache ve Feralasu.]])

add(1282, [[They Call Him Smiling Jim]],
[[I can't help it if I feel sorry for ol' Jim there. He wasn't always like that. Ran an inn out in the marsh for a while, wonderful place.$b$bLook, I don't really want to talk about it. Bring it up with Captain Vimes if you really have to.]],
[[Nemůžu si pomoct, je mi starého Jima líto. Nebýval vždycky takový. Nějakou dobu vedl hostinec v bažině, nádherné místo.$b$bPodívej, opravdu o tom nechci mluvit. Jestli musíš, zeptej se Captaina Vimese.]],
[[Speak with Captain Garran Vimes in Theramore.]],
[[Promluv si s Captainem Garranem Vimesem v Theramore.]])

add(8500, [[The Alliance Needs More Thorium Bars!]],
[[It is so good to see you again $N. I hope that you've been doing well. It's true that we are still in need of thorium bars. If you have them to spare I am collecting them for the Ahn'Qiraj war effort.]],
[[Je skvělé tě znovu vidět, $N. Doufám, že se ti daří. Je pravda, že stále potřebujeme thoriové pruty. Pokud máš nějaké nazbyt, sbírám je pro válečné úsilí v Ahn'Qiraj.]],
[[Bring 20 thorium bars to Dame Twinbraid at the airfield in Dun Morogh.]],
[[Přines 20 thoriových prutů Dame Twinbraid na letiště v Dun Morogh.]])

add(3129, [[Weapons of Spirit]],
[[Imbuing the muisek into the weapons is a difficult process. Now that I have all of the required materials and the muisek of the creatures that you captured, I may begin. Please wait; I will return in a moment.]],
[[Vtělit muisek do zbraní je obtížný proces. Teď, když mám všechny potřebné materiály i muisek tvorů, které jsi zajal, mohu začít. Prosím počkej; za chvíli se vrátím.]],
[[Witch Doctor Uzer'i wants you to wait for a moment while he prepares the weapons.]],
[[Witch Doctor Uzer'i chce, abys chvíli počkal, než připraví zbraně.]])

add(8313, [[Sharing the Knowledge]],
[[While the recipe for cooking sandworm meat is legible, it contains references to herbs and spices you've never heard of.Calandrath might have enough knowledge of the plants that grow in the desert to make sense of it.]],
[[Recept na přípravu masa písečných červů je sice čitelný, ale zmiňuje byliny a koření, o kterých jsi nikdy neslyšel. Calandrath možná ví o pouštních rostlinách dost na to, aby mu recept dával smysl.]],
[[Bring the Torn Recipe Page to Calandrath at the inn in Cenarion Hold.]],
[[Přines Torn Recipe Page Calandrathovi do hostince v Cenarion Hold.]])

add(5154, [[The Annals of Darrowshire]],
[[To save Joseph Redpath, we must first discover his past.We can learn this in the Annals of Darrowshire, a book held in the city hall of Andorhal.$B$BBring me that book.We can then learn Joseph's fate, and with luck... change it!]],
[[Abychom zachránili Josepha Redpatha, musíme nejprve zjistit jeho minulost. Ta je zaznamenána v Letopisech Darrowshire, knize uložené na radnici v Andorhalu.$B$BPřines mi tu knihu. Pak zjistíme Josephův osud a s trochou štěstí... ho změníme!]],
[[Bring the Annals of Darrowshire to Chromie in Andorhal.]],
[[Přines Letopisy Darrowshire Chromie v Andorhalu.]])

add(3913, [[A Grave Situation]],
[[If you return to the graveyard, $N, you will find a gravestone there... Not just any gravestone; this one will stand out from the others. Secrets lie within it.$B$BPush on the stone, and you will learn of these secrets...]],
[[Když se vrátíš na hřbitov, $N, najdeš tam náhrobek... Ne jen tak ledajaký; tenhle bude mezi ostatními nápadný. Skrývá tajemství.$B$BZatlač na kámen a ta tajemství poznáš...]],
[[Resurrect, then look for the gravestone that Gaeriyan told you to find.]],
[[Oživ se a potom najdi náhrobek, o kterém ti řekl Gaeriyan.]])

add(4976, [[Returning the Cleansed Orb]],
[[Take the cleansed orb back to Menara in Ratchet, $N. Give her my regards and be safe. I truly hope you are able to withstand the temptation and corruption that is sure to come as you follow your path.$B$BGood luck.]],
[[Dones očištěnou kouli zpět Menaře v Ratchetu, $N. Pozdravuj ji ode mě a dávej na sebe pozor. Opravdu doufám, že odoláš pokušení a zkaženosti, které tě na tvé cestě jistě čekají.$B$BHodně štěstí.]],
[[Return the Cleansed Infernal Orb to Menara Voidrender in the Barrens.]],
[[Vrať Cleansed Infernal Orb Menaře Voidrender v Barrens.]])

add(5103, [[Hot Fiery Death]],
[[The only thing that remains of this human are some charred bones. He seems to have died within arms reach of what he was after - unfired plate gauntlets.$B$BPerhaps you should grab the gauntlets and get out of the fire?]],
[[Z tohoto člověka zbylo jen několik ohořelých kostí. Zdá se, že zemřel na dosah toho, po čem šel — nevypálených plátových rukavic.$B$BMožná bys měl rukavice popadnout a dostat se z ohně?]],
[[Someone in this world must know what to do with these gauntlets. Good luck!]],
[[Někdo na tomto světě určitě ví, co s těmito rukavicemi dělat. Hodně štěstí!]])

add(8931, [[Just Compensation]],
[[You kept your word and brought the device built by Mux.I believe a reward is in order if I'm to keep you interested in saving my skin.Bring me an ordinary belt and a set of gloves that you wish to upgrade.]],
[[Dodržel jsi slovo a přinesl zařízení, které vyrobil Mux. Myslím, že si zasloužíš odměnu, pokud tě mám dál motivovat k záchraně mé kůže. Přines mi obyčejný opasek a pár rukavic, které chceš vylepšit.]],
[[Bring a Beaststalker's Belt and a set of Beaststalker's Gloves to Deliana in Ironforge.]],
[[Přines Beaststalker's Belt a Beaststalker's Gloves Delianě v Ironforge.]])

add(4841, [[Pacify the Centaur]],
[[$N, I entreat you to hunt these centaur down. They shall feel the wrath of our revenge. Attack the centaur camp to the north of Freewind Post!Let wrath guide your hand!]],
[[$N, žádám tě, abys tyto kentaury dopadl. Pocítí hněv naší pomsty. Zaútoč na jejich tábor severně od Freewind Post! Ať tvou ruku vede hněv!]],
[[Kill 12 Galak Scouts, 10 Galak Wranglers, and 6 Galak Windchasers, and then return to Cliffwatcher Longhorn in Freewind Post.]],
[[Zabij 12 Galak Scouts, 10 Galak Wranglers a 6 Galak Windchasers a potom se vrať ke Cliffwatcheru Longhornovi ve Freewind Post.]])

add(7507, [[Foror's Compendium]],
[[You have uncovered something of great importance. This book is unlike any that you have seen.$B$BIt would appear as if someone or something has managed to shatter the seal of Athenaeum. The text within is garbled and barely legible.]],
[[Objevil jsi něco velmi důležitého. Tato kniha se nepodobá ničemu, co jsi kdy viděl.$B$BVypadá to, jako by někdo nebo něco dokázalo prolomit pečeť Athenaea. Text uvnitř je zkomolený a sotva čitelný.]],
[[Return Foror's Compendium of Dragon Slaying to the Athenaeum.]],
[[Vrať Fororovo kompendium zabíjení draků do Athenaea.]])

add(9003, [[Saving the Best for Last]],
[[That's an amazing story, $N! You have my thanks, and the heartfelt gratitude of all who were involved. Now maybe I'll be able to sleep at night with both eyes shut.$B$BAs to your reward, I believe I have a few things that you'll really enjoy.]],
[[To je neuvěřitelný příběh, $N! Máš mé díky i upřímnou vděčnost všech zúčastněných. Teď snad budu v noci konečně spát se zavřenýma oběma očima.$B$BCo se týče odměny, myslím, že tu mám pár věcí, které tě opravdu potěší.]],
[[Give Deliana your Devout Crown and Devout Robe.]],
[[Dej Delianě svůj Devout Crown a Devout Robe.]])

add(1320, [[The Black Shield]],
[[Ah, I almost missed this... The leather strap on the back must have burned off, but it seems like it was made to fit a large person. I'd guess a tauren, actually.$b$bThat's about all I can tell you. Tell Captain Vimes I'm sorry I couldn't be of more help.]],
[[Ach, tohohle jsem si málem nevšiml... Kožený řemen na zadní straně musel shořet, ale podle všeho byl štít vyroben pro někoho velkého. Tipoval bych taurena.$b$bTo je asi všechno, co ti k tomu dokážu říct. Řekni Captainu Vimesovi, že mě mrzí, že jsem nepomohl víc.]],
[[Speak with Captain Garran Vimes in Theramore.]],
[[Promluv si s Captainem Garranem Vimesem v Theramore.]])

add(1422, [[Threat From the Sea]],
[[While I begin work on your weapon, why don't you talk to Katar? He mentioned needing help with patrols along the beach, and I'd rather see you keep your wits and weapons prepared instead of getting drunk with some of the other louses I share this camp with.]],
[[Zatímco začnu pracovat na tvé zbrani, promluv si s Katarem. Říkal, že potřebuje pomoct s hlídkami podél pobřeží, a raději tě uvidím s čistou hlavou a připravenou zbraní než opilého s ostatními budižkničemy z tábora.]],
[[Speak to Katar in the Swamp of Sorrows.]],
[[Promluv si s Katarem ve Swamp of Sorrows.]])

add(7123, [[Speak with our Quartermaster]],
[[$N, the Frostwolf Quartermaster is looking for recruits, for tasks that lead into the mines of Alterac Valley.Speak with him; he will tell you more.$B$BFollow the road west into the bunker, then take the west exit and you'll find our quartermaster.]],
[[$N, Frostwolf Quartermaster hledá rekruty pro úkoly vedoucí do dolů Alterac Valley. Promluv si s ním; řekne ti víc.$B$BJdi po cestě na západ do bunkru, pak vyjdi západním východem a quartermastera najdeš.]],
[[Speak with the Frostwolf Quartermaster.]],
[[Promluv si s Frostwolf Quartermasterem.]])

add(8506, [[The Alliance Needs More Purple Lotus!]],
[[Welcome back $c. Our collection grows, but even now we have a need for additional purple lotus. If it is still within your power to gather more of the herb, I entreat you to do so and return them to me here.]],
[[Vítej zpět, $c. Naše zásoby rostou, ale stále potřebujeme další Purple Lotus. Pokud ještě dokážeš tuto bylinu sbírat, prosím udělej to a vrať se s ní sem.]],
[[Bring 20 purple lotus to Master Nightsong at the airfield in Dun Morogh.]],
[[Přines 20 Purple Lotus Masteru Nightsongovi na letiště v Dun Morogh.]])

add(2993, [[Return to the Hinterlands]],
[[Sharpbeak is held in a cage, high on a cliff at the top of Jintha'Alor in the Hinterlands.The key to this cage is possessed by the high priestess of the Vilebranch trolls, Vile Priestess Hexx.$B$BThere.I have done my part.I bid you fortune on your quest, $N.]],
[[Sharpbeak je držen v kleci vysoko na útesu na vrcholu Jintha'Alor v Hinterlands. Klíč od klece má velekněžka trollů Vilebranch, Vile Priestess Hexx.$B$BTak. Já jsem svou část udělal. Přeji ti na cestě štěstí, $N.]],
[[Speak with Gryphon Master Talonaxe.]],
[[Promluv si s Gryphon Masterem Talonaxem.]])

add(8999, [[Saving the Best for Last]],
[[That's an amazing story, $N! You have my thanks, and the heartfelt gratitude of all who were involved. Now maybe I'll be able to sleep at night with both eyes shut.$B$BAs to your reward, I believe I have a few things that you'll really enjoy.]],
[[To je neuvěřitelný příběh, $N! Máš mé díky i upřímnou vděčnost všech zúčastněných. Teď snad budu v noci konečně spát se zavřenýma oběma očima.$B$BCo se týče odměny, myslím, že tu mám pár věcí, které tě opravdu potěší.]],
[[Give Deliana your Wildheart Cowl and Wildheart Vest.]],
[[Dej Delianě svůj Wildheart Cowl a Wildheart Vest.]])

add(9005, [[Saving the Best for Last]],
[[That's an amazing story, $N! You have my thanks, and the heartfelt gratitude of all who were involved. Now maybe I'll be able to sleep at night with both eyes shut.$B$BAs to your reward, I believe I have a few things that you'll really enjoy.]],
[[To je neuvěřitelný příběh, $N! Máš mé díky i upřímnou vděčnost všech zúčastněných. Teď snad budu v noci konečně spát se zavřenýma oběma očima.$B$BCo se týče odměny, myslím, že tu mám pár věcí, které tě opravdu potěší.]],
[[Give Deliana your Dreadmist Mask and Dreadmist Robe.]],
[[Dej Delianě svůj Dreadmist Mask a Dreadmist Robe.]])

add(4907, [[Tinkee Steamboil]],
[[Hi, $N.Remember Tinkee Steamboil?Well, she remembers you!She sent me a message to keep an eye out for you, because... she needs your help again.I think it has something to do with her studies on dragons.$B$BYou should speak to her in the Burning Steppes, at the Flame Crest.]],
[[Ahoj, $N. Pamatuješ si Tinkee Steamboil? Ona si pamatuje tebe! Poslala mi zprávu, ať tě vyhlížím, protože... znovu potřebuje tvou pomoc. Myslím, že to má něco společného s jejím studiem draků.$B$BPromluv si s ní v Burning Steppes u Flame Crest.]],
[[Speak with Tinkee Steamboil.]],
[[Promluv si s Tinkee Steamboil.]])

add(5942, [[Hidden Treasures]],
[[Daddy told me to give you this key.He said it opens a chest out back behind the house.$B$BHe also wanted me to thank you.Did you do a favor for him?Did you tell him you found my doll?$B$BWell here's the key.And thank you $N.Thank you!You're a very nice $gman:lady;!]],
[[Tatínek mi řekl, abych ti dal tenhle klíč. Prý otevírá truhlu za domem.$B$BTaké ti chtěl poděkovat. Udělal jsi pro něj něco? Řekl jsi mu, že jsi našel mou panenku?$B$BTak tady je klíč. A děkuju, $N. Děkuju! Jsi moc hodný $gmuž:žena;!]],
[[Bring Joseph's Key to Joseph's Chest.]],
[[Dones Josephův klíč k Josephově truhle.]])

add(1284, [[Suspicious Hoofprints]],
[[Rows of hoofprints lead away from the still-smoking skeleton of the Shady Rest Inn. There are at least a few visible impressions, with more rows of prints almost imperceptible in the soft mud of the marsh.]],
[[Řady stop kopyt vedou pryč od stále doutnající kostry hostince Shady Rest Inn. Několik otisků je dobře viditelných a další řady jsou v měkkém bahně bažiny téměř neznatelné.]],
[[Report about the suspicious prints at the Shady Rest Inn to Captain Garran Vimes in Theramore.]],
[[Podej Captainu Garranu Vimesovi v Theramore zprávu o podezřelých stopách u Shady Rest Inn.]])

add(2602, [[Infallible Mind]],
[[Your focused concentration has dwindled so soon? More research must be done!$B$BOh yes, the price remains the same, $N. Venture forth into the blasted lands and return to me with ten brains from the redstone and two vulture gizzards.]],
[[Tvé soustředění už tak brzy ochablo? Musíme udělat další výzkum!$B$BAno, cena zůstává stejná, $N. Vydej se do Blasted Lands a vrať se s deseti mozky redstone bazilišků a dvěma supími žaludky.]],
[[Bring ten Basilisk Brains and two Vulture Gizzards to Bloodmage Lynnore.]],
[[Přines 10 Basilisk Brains a 2 Vulture Gizzards Bloodmage Lynnore.]])

add(9001, [[Saving the Best for Last]],
[[That's an amazing story, $N! You have my thanks, and the heartfelt gratitude of all who were involved. Now maybe I'll be able to sleep at night with both eyes shut.$B$BAs to your reward, I believe I have a few things that you'll really enjoy.]],
[[To je neuvěřitelný příběh, $N! Máš mé díky i upřímnou vděčnost všech zúčastněných. Teď snad budu v noci konečně spát se zavřenýma oběma očima.$B$BCo se týče odměny, myslím, že tu mám pár věcí, které tě opravdu potěší.]],
[[Give Deliana your Magister's Crown and Magister's Robes.]],
[[Dej Delianě svůj Magister's Crown a Magister's Robes.]])

add(9004, [[Saving the Best for Last]],
[[That's an amazing story, $N! You have my thanks, and the heartfelt gratitude of all who were involved. Now maybe I'll be able to sleep at night with both eyes shut.$B$BAs to your reward, I believe I have a few things that you'll really enjoy.]],
[[To je neuvěřitelný příběh, $N! Máš mé díky i upřímnou vděčnost všech zúčastněných. Teď snad budu v noci konečně spát se zavřenýma oběma očima.$B$BCo se týče odměny, myslím, že tu mám pár věcí, které tě opravdu potěší.]],
[[Give Deliana your Shadowcraft Cap and Shadowcraft Tunic.]],
[[Dej Delianě svůj Shadowcraft Cap a Shadowcraft Tunic.]])

add(9248, [[A Humble Offering]],
[[Ishnu-alah, $r. Show me proof of the demise of a Lord of the Abyssal Council and I shall reward you with an item that should aid you in your battles against the Qiraji.]],
[[Ishnu-alah, $r. Ukaž mi důkaz smrti jednoho Lorda Abyssal Councilu a odměním tě předmětem, který ti pomůže v bojích proti Qiraji.]],
[[Aurel Goldleaf at Cenarion Hold in Silithus wants you to bring her 1 Abyssal Scepter. You must also be Honored with the Cenarion Circle.]],
[[Aurel Goldleaf v Cenarion Hold v Silithusu chce, abys jí přinesl 1 Abyssal Scepter. Zároveň musíš mít u Cenarion Circle reputaci Honored.]])

add(8388, [[For Great Honor]],
[[Many brave fighters look up to you, $N. You continue to be an example for all in the fight against the Alliance. What news do you bring from your journeys?]],
[[Mnoho statečných bojovníků k tobě vzhlíží, $N. V boji proti Alianci jsi dál příkladem pro všechny. Jaké zprávy přinášíš ze svých cest?]],
[[Bring 3 Alterac Valley Marks of Honor, 3 Arathi Basin Marks of Honor and 3 Warsong Gulch Marks of Honor to a Horde Warbringer outside the battlegrounds.]],
[[Přines 3 Alterac Valley Marks of Honor, 3 Arathi Basin Marks of Honor a 3 Warsong Gulch Marks of Honor hordskému Warbringerovi před bojišti.]])

add(8734, [[Tyrande and Remulos]],
[[Tyrande will be notifed, mortal. Shan'do Stormrage has prepared me for this contingency.$B$BNow you must venture to the Moonglade and speak with Remulos. He will have further instruction as to the summoning of Eranikus.$B$BWe all wish you great luck.]],
[[Tyrande bude informována, smrtelníku. Shan'do Stormrage mě na tuto možnost připravil.$B$BTeď se musíš vydat do Moonglade a promluvit s Remulosem. Dá ti další pokyny k vyvolání Eranika.$B$BVšichni ti přejeme hodně štěstí.]],
[[Travel to the Moonglade and speak to Keeper Remulos. ]],
[[Vydej se do Moonglade a promluv si s Keeperem Remulosem. ]])

add(9006, [[Saving the Best for Last]],
[[That's an amazing story, $N! You have my thanks, and the heartfelt gratitude of all who were involved. Now maybe I'll be able to sleep at night with both eyes shut.$B$BAs to your reward, I believe I have a few things that you'll really enjoy.]],
[[To je neuvěřitelný příběh, $N! Máš mé díky i upřímnou vděčnost všech zúčastněných. Teď snad budu v noci konečně spát se zavřenýma oběma očima.$B$BCo se týče odměny, myslím, že tu mám pár věcí, které tě opravdu potěší.]],
[[Give Deliana your Helm of Valor and Breastplate of Valor.]],
[[Dej Delianě svůj Helm of Valor a Breastplate of Valor.]])

add(2867, [[Return to Feathermoon Stronghold]],
[[With the discovery of the strange gazebo in the heart of the Ruins of Solarsal, the time has come to return to Feathermoon Stronghold and report to General Shandris Feathermoon what has been discovered here.]],
[[Po objevení podivného altánu v srdci Ruins of Solarsal nastal čas vrátit se do Feathermoon Stronghold a podat General Shandris Feathermoon zprávu o tom, co jsi zde zjistil.]],
[[Return to Shandris Feathermoon in the Feathermoon Stronghold and report your findings.]],
[[Vrať se k Shandris Feathermoon do Feathermoon Stronghold a oznam jí své nálezy.]])

add(5385, [[The Remains of Trey Lightforge]],
[[You pick up the sack carefully and prepare to make your way back to Jessir Moonbow on the border of Felwood and Ashenvale. Hopefully the paladin will be given the proper respects once you've passed his remains on to his friends.]],
[[Opatrně zvedneš pytel a připravíš se na cestu zpět k Jessir Moonbow na hranici Felwoodu a Ashenvale. Snad se paladinovi dostane náležité úcty, až jeho ostatky předáš přátelům.]],
[[Return the Remains of Trey Lightforge to Jessir Moonbow in Felwood.]],
[[Vrať ostatky Treye Lightforge Jessir Moonbow ve Felwoodu.]])

add(9002, [[Saving the Best for Last]],
[[That's an amazing story, $N! You have my thanks, and the heartfelt gratitude of all who were involved. Now maybe I'll be able to sleep at night with both eyes shut.$B$BAs to your reward, I believe I have a few things that you'll really enjoy.]],
[[To je neuvěřitelný příběh, $N! Máš mé díky i upřímnou vděčnost všech zúčastněných. Teď snad budu v noci konečně spát se zavřenýma oběma očima.$B$BCo se týče odměny, myslím, že tu mám pár věcí, které tě opravdu potěší.]],
[[Give Deliana your Lightforge Helm and Lightforge Breastplate.]],
[[Dej Delianě svůj Lightforge Helm a Lightforge Breastplate.]])

add(2994, [[Saving Sharpbeak]],
[[We must save Sharpbeak!$B$BFight your way to the top of Jintha'Alor in the heart of Vilebranch territory, gain the key to Sharpbeak's cage from the vile Priestess Hexx, and then find and save Sharpbeak!]],
[[Musíme zachránit Sharpbeaka!$B$BProbojuj se na vrchol Jintha'Alor v srdci území Vilebranch, získej od odporné Priestess Hexx klíč od Sharpbeakovy klece a pak ho najdi a zachraň!]],
[[Fight to the top of Jintha'Alor, kill Vile Priestess Hexx for the key to Sharpbeak's cage, and save Sharpbeak.]],
[[Probojuj se na vrchol Jintha'Alor, zabij Vile Priestess Hexx, získej klíč od Sharpbeakovy klece a Sharpbeaka zachraň.]])

add(4492, [[Lost!]],
[[You've got to help me, $N! My friend, Ringo left earlier to explore the volcano to the south of here, and he has been gone way too long. I am really worried about him.$B$BDo you think you could find him? Why don't you take my canteen with you -- if you do find Ringo, I'm sure he'll need it!]],
[[Musíš mi pomoct, $N! Můj přítel Ringo se před časem vydal prozkoumat sopku jižně odsud a je pryč už příliš dlouho. Mám o něj opravdu strach.$B$BMyslíš, že ho dokážeš najít? Vezmi si mou čutoru — pokud Ringa najdeš, určitě ji bude potřebovat!]],
[[Find Ringo at Fire Plume Ridge.]],
[[Najdi Ringa na Fire Plume Ridge.]])

add(6627, [[Test of Lore]],
[[You have brought me the book, and now it is time for your question. Are you ready?$B$BTime is not an issue, $c, so do not feel pressured. You may take as long as you like to answer.]],
[[Přinesl jsi mi knihu a teď přišel čas na otázku. Jsi připraven?$B$BČas není problém, $c, takže se necít pod tlakem. Na odpověď máš tolik času, kolik potřebuješ.]],
[[Answer Braug Dimspirit's question successfully and then speak to him again. He will remain in Stonetalon Mountains when you are ready.]],
[[Správně odpověz na otázku Brauga Dimspirita a potom s ním znovu promluv. Až budeš připraven, zůstane ve Stonetalon Mountains.]])

add(8519, [[A Pawn on the Eternal Board]],
[[As you regain your composure and focus your gaze, you notice that something stirs within the crystal. Upon closer inspection, you realize that you are looking into the past... a memory... long forgotten.]],
[[Když znovu nabereš klid a zaostříš pohled, všimneš si, že se uvnitř krystalu něco hýbe. Při bližším pohledu si uvědomíš, že hledíš do minulosti... do dávno zapomenuté vzpomínky.]],
[[Learn all that you can of the past, then speak with Anachronos at the Caverns of Time in Tanaris.]],
[[Zjisti o minulosti vše, co můžeš, a potom promluv s Anachronosem v Caverns of Time v Tanarisu.]])

add(9000, [[Saving the Best for Last]],
[[That's an amazing story, $N! You have my thanks, and the heartfelt gratitude of all who were involved. Now maybe I'll be able to sleep at night with both eyes shut.$B$BAs to your reward, I believe I have a few things that you'll really enjoy.]],
[[To je neuvěřitelný příběh, $N! Máš mé díky i upřímnou vděčnost všech zúčastněných. Teď snad budu v noci konečně spát se zavřenýma oběma očima.$B$BCo se týče odměny, myslím, že tu mám pár věcí, které tě opravdu potěší.]],
[[Give Deliana your Beaststalker's Cap and Beaststalker's Tunic.]],
[[Dej Delianě svůj Beaststalker's Cap a Beaststalker's Tunic.]])

add(8514, [[The Alliance Needs More Medium Leather!]],
[[Yes $g sir : ma'am;, looks like we've collected $2063w pieces of medium leather to date. I know it's a lot to ask, but if you're still willing, I could use your help in attempting to put a dent in the rest of my quota.]],
[[Ano, $g pane : paní;, zatím jsme nasbírali $2063w kusů střední kůže. Vím, že toho žádám hodně, ale pokud ještě chceš pomoct, hodila by se mi tvá pomoc se zbytkem kvóty.]],
[[Bring 10 medium leather to Private Porter at the airfield in Dun Morogh.]],
[[Přines 10 kusů střední kůže Private Porterovi na letiště v Dun Morogh.]])

add(1322, [[The Black Shield]],
[[Hmmm, there's writing right here on the rim of the shield, but it's hard to read from all the burned stuff.$b$bI need acid to make it clear. Venom from the Darkfang spiders in the marsh would do good. Get me some of their sacs and I can clean this up.]],
[[Hmm, přímo na okraji štítu je nějaký nápis, ale přes všechny spáleniny se špatně čte.$b$bPotřebuji kyselinu, abych ho vyčistil. Jed z pavouků Darkfang v bažině by měl stačit. Přines mi několik jejich jedových váčků a dám to do pořádku.]],
[[Acquire 6 Acidic Venom Sacs for Do'gol in Brackenwall Village.]],
[[Získej 6 Acidic Venom Sacs pro Do'gola v Brackenwall Village.]])

add(1361, [[Regthar Deathgate]],
[[A warrior of the Horde, Regthar Deathgate, is recruiting agents for a mission into the land of Desolace.Speak with him if you wish to volunteer.He is stationed in the Barrens, in a series of bunkers west of the Crossroads.$B$BAnd sharpen your weapons.Desolace is a place torn by war.]],
[[Válečník Hordy Regthar Deathgate verbuje agenty pro misi do Desolace. Pokud se chceš přihlásit, promluv si s ním. Je v Barrens v řadě bunkrů západně od Crossroads.$B$BA nabrous si zbraně. Desolace je země rozervaná válkou.]],
[[Speak with Regthar Deathgate.]],
[[Promluv si s Regtharem Deathgatem.]])

add(2341, [[Necklace Recovery, Take 3]],
[[As Dran and Malton Droffers begin to squabble over their new salvage, half of the deal is now complete.A trip to the Badlands is now in order to finish things up, as Jarkal Mossmeld in Kargath might have a special reward waiting for you there.]],
[[Zatímco se Dran a Malton Droffersovi začínají hádat o nově získanou kořist, polovina dohody je splněna. Teď je potřeba cesta do Badlands, abys vše dokončil; Jarkal Mossmeld v Kargathu tam pro tebe možná má zvláštní odměnu.]],
[[Visit Jarkal Mossmeld in Kargath to see if he was successful.]],
[[Navštiv Jarkala Mossmelda v Kargathu a zjisti, zda uspěl.]])

add(8409, [[Ruined Kegs]],
[[The rotten eggs have been successfully placed inside the keg.Future batches of ale from the Southshore Inn are sure to be ruined!$B$BYou should now report back to Darkcaller Yanka at the Wickerman Festival in Tirisfal Glade and report your success.]],
[[Shnilá vejce byla úspěšně vložena do sudu. Budoucí várky piva z hostince v Southshore budou určitě zkažené!$B$BTeď se vrať k Darkcaller Yance na Wickerman Festival v Tirisfal Glade a oznam jí svůj úspěch.]],
[[Return to Darkcaller Yanka at the Wickerman Festival in Tirisfal Glade.]],
[[Vrať se k Darkcaller Yance na Wickerman Festival v Tirisfal Glade.]])

add(1427, [[Threat From the Sea]],
[[Before you take rest, speak to Tok'Kar again. While you were gone I believe he finished a few weapons. For your help here, he would offer one of them to you. You would do well to test its strength against the fish men when you are ready... but only to please me further.]],
[[Než si odpočineš, promluv znovu s Tok'Karem. Zatímco jsi byl pryč, myslím, že dokončil několik zbraní. Za tvou pomoc ti jednu nabídne. Až budeš připraven, bylo by dobré vyzkoušet její sílu proti rybím lidem... už jen proto, abys mě potěšil ještě víc.]],
[[Speak with Tok'Kar in the Swamp of Sorrows.]],
[[Promluv si s Tok'Karem ve Swamp of Sorrows.]])

add(5089, [[General Drakkisath's Command]],
[[From the corpse of the defeated serpent you uncover what appears to be a note of some importance: A letter from his superior, General Drakkisath, concerning protocol.$B$BYour instinct tells you that you should take it to Marshal Maxwell.]],
[[U těla poraženého hada najdeš zřejmě důležitý vzkaz: dopis od jeho nadřízeného, Generála Drakkisatha, týkající se protokolu.$B$BInstinkt ti říká, že bys ho měl odnést Marshalovi Maxwellovi.]],
[[Take General Drakkisath's Command to Marshal Maxwell in Burning Steppes.]],
[[Dones rozkaz Generála Drakkisatha Marshalovi Maxwellovi v Burning Steppes.]])

add(9235, [[Icebane Bracers]],
[[Thanks to you and Omarion (May he rest in peace), I am now able to create Icebane bracers. All you need to do is bring me the materials and pay a small crafting fee.]],
[[Díky tobě a Omarionovi — ať odpočívá v pokoji — teď dokážu vyrábět Icebane bracers. Stačí mi přinést materiály a zaplatit malý poplatek za výrobu.]],
[[Craftsman Wilhelm at Light's Hope Chapel in the Eastern Plaguelands wants 4 Frozen Runes, 12 Thorium Bars, 2 Arcanite Bars, 2 Essence of Water and 200 gold.]],
[[Craftsman Wilhelm v Light's Hope Chapel v Eastern Plaguelands chce 4 Frozen Runes, 12 Thorium Bars, 2 Arcanite Bars, 2 Essence of Water a 200 zlatých.]])

add(4451, [[The Key to Freedom]],
[[The small brass key looks simple enough.. The only thing that seems to make it stand out are some words scratched into the head of it:$B$B"Dark Iron Outhouse - Do Not Duplicate."$B$BYou have no idea what it means or what it will lead to.]],
[[Malý mosazný klíč vypadá docela obyčejně. Jediné, čím se odlišuje, je několik slov vyškrábaných na jeho hlavě:$B$B„Dark Iron Outhouse — nekopírovat.“$B$BNemáš tušení, co to znamená ani kam tě to zavede.]],
[[Search Searing Gorge and find a use for the Grimesilt Outhouse Key you have found.]],
[[Prohledej Searing Gorge a najdi využití pro Grimesilt Outhouse Key, který jsi našel.]])

add(5582, [[Healthy Dragon Scale]],
[[This is a scale shed from a plagued dragon hatchling.But unlike the other pocked, oozing scales on the infant beast, this rare scale is healthy and unmarred.$B$BBetina Bigglezink will want a sample of this to study.]],
[[Tuto šupinu shodilo nakažené dračí mládě. Na rozdíl od ostatních důlkovitých a mokvajících šupin na mladém tvorovi je tato vzácná šupina zdravá a nepoškozená.$B$BBetina Bigglezink bude chtít vzorek pro svůj výzkum.]],
[[Bring the Healthy Dragon Scale to Betina Bigglezink at the Light's Hope Chapel in Eastern Plaguelands.]],
[[Přines Healthy Dragon Scale Betině Bigglezink v Light's Hope Chapel v Eastern Plaguelands.]])

add(6147, [[Return to Nathanos]],
[[The Grand Crusader makes an unusual request. Hrm, regardless... what he asks will be done. Return to the Scarlet Bastion and notify him that the Oracle will be en route shortly.$B$BWe will take every precaution to ensure that she makes it to Stratholme unharmed.]],
[[Grand Crusader má neobvyklý požadavek. Hm, každopádně... co žádá, bude vykonáno. Vrať se do Scarlet Bastion a oznam mu, že Oracle bude brzy na cestě.$B$BUděláme vše pro to, aby se do Stratholme dostala bez úhony.]],
[[Return to Nathanos Blightcaller with the new information.]],
[[Vrať se k Nathanosovi Blightcallerovi s novými informacemi.]])

add(2882, [[Cuergo's Gold]],
[[This map shows a stretch of beach with a southern face.Below the map are words, elegantly written...$B$B$BSouth of Wheedle$BSouth of home$BFind a mast and flag and bones$BDig you there, if you be bold$BDig and claim Cuergo's gold!$BA key you'll need and a key you'll see$BThe men you face take blood as fee.]],
[[Tato mapa ukazuje úsek pobřeží obrácený k jihu. Pod mapou jsou elegantně napsaná slova...$B$B$BJižně od Wheedle$BJižně od domova$BNajdi stěžeň, vlajku a kosti$BKopec tam, pokud odvahu máš$BKopej a Cuergovo zlato získáš!$BKlíč budeš potřebovat a klíč spatříš$BMuži, kterým čelíš, krví si platí.]],
[[Find Cuergo's gold!]],
[[Najdi Cuergovo zlato!]])

add(2977, [[Return to Ironforge]],
[[You access the pedestal again; the platinum discs suddenly appear once more in your backpack.$B$BWith the knowledge of the stone watcher learned and the discs returned to your possession, the time has come to return to Ironforge and inform the Explorers' League of your discovery.]],
[[Znovu použiješ podstavec a platinové disky se náhle znovu objeví ve tvém batohu.$B$BTeď, když znáš tajemství kamenného strážce a disky máš opět u sebe, nastal čas vrátit se do Ironforge a informovat Explorers' League o svém objevu.]],
[[Speak with Historian Karnik in Ironforge.]],
[[Promluv si s Historianem Karnikem v Ironforge.]])

add(3845, [[It's a Secret to Everybody]],
[[ Grabbing onto it, you pull the pack back to the shore. Perhaps if you examine the items inside the pack, you might find out more about who it belongs to.$B$BThere are a few stray travelers at Marshal's Refuge. Perhaps you might find out more there.]],
[[ Chytíš vak a vytáhneš ho zpět na břeh. Když prozkoumáš věci uvnitř, možná zjistíš víc o tom, komu patří.$B$BV Marshal's Refuge se zdržuje několik pocestných. Možná tam zjistíš něco dalšího.]],
[[Examine the items inside the pack and bring them to their owner.]],
[[Prozkoumej věci uvnitř vaku a dones je jejich majiteli.]])

add(5202, [[A Strange Red Key]],
[[The small red key seems to be made of some kind of bone material. It is heavy in your hand, but appears very fragile. Why would a member of the Shadow Council have such a thing? Perhaps there is something within Jaedenar that this strange key unlocks.]],
[[Malý červený klíč vypadá, jako by byl vyroben z jakési kosti. V ruce je těžký, ale působí velmi křehce. Proč by člen Shadow Councilu něco takového měl? Možná je v Jaedenaru něco, co tento podivný klíč odemyká.]],
[[Search through Jaedenar to discover what the Blood Red Key is used for.]],
[[Prohledej Jaedenar a zjisti, k čemu slouží Blood Red Key.]])

for id, entry in pairs(entries) do
    if A.QuestEntries[id] == nil then A.QuestEntries[id] = entry end
end

A.QuestTitleTranslations = A.QuestTitleTranslations or {}
local titles = {
    ["A Grave Situation"] = "Hrobová situace",
    ["A Humble Offering"] = "Skromná oběť",
    ["A Pawn on the Eternal Board"] = "Pěšec na věčné šachovnici",
    ["A Simple Request"] = "Jednoduchá žádost",
    ["A Strange Red Key"] = "Podivný červený klíč",
    ["A Tale of Sorrow"] = "Příběh žalu",
    ["A Taste of Flame"] = "Ochutnávka plamene",
    ["A Troubled Spirit"] = "Neklidný duch",
    ["Anachronos"] = "Anachronos",
    ["Andron's Payment to Jediga"] = "Andronova platba pro Jedigu",
    ["Armor Scraps"] = "Úlomky zbroje",
    ["Assassination Plot"] = "Plán atentátu",
    ["Azuregos's Magical Ledger"] = "Azuregosova magická účetní kniha",
    ["Becoming a Parent"] = "Stát se rodičem",
    ["Betrayed"] = "Zrazen",
    ["Bor Wildmane"] = "Bor Wildmane",
    ["Bor Wishes to Speak"] = "Bor chce mluvit",
    ["Camp Mojache"] = "Camp Mojache",
    ["Catalogue of the Wayward"] = "Katalog zbloudilých",
    ["Celebrating Good Times"] = "Oslava dobrých časů",
    ["Cenarion Aid"] = "Pomoc Cenarionu",
    ["Cenarion Battlegear"] = "Cenarionská bojová výbava",
    ["Chillwind Point"] = "Chillwind Point",
    ["Codex of Defense"] = "Kodex obrany",
    ["Cuergo's Gold"] = "Cuergovo zlato",
    ["Deliver to MacKinley"] = "Doruč MacKinleymu",
    ["Delivery for Marin"] = "Zásilka pro Marina",
    ["Divine Retribution"] = "Božská odplata",
    ["Enchanted Thorium Platemail: Volume I"] = "Očarovaná thoriová zbroj: svazek I",
    ["Enchanted Thorium Platemail: Volume II"] = "Očarovaná thoriová zbroj: svazek II",
    ["Enchanted Thorium Platemail: Volume III"] = "Očarovaná thoriová zbroj: svazek III",
    ["Enemy Booty"] = "Kořist od nepřítele",
    ["Examine the Vessel"] = "Prozkoumej nádobu",
    ["Fall From Grace"] = "Pád z milosti",
    ["For All To See"] = "Ať to všichni vidí",
    ["For Great Honor"] = "Za velkou čest",
    ["Foror's Compendium"] = "Fororovo kompendium",
    ["Frost Shock and You"] = "Frost Shock a ty",
    ["Garona: A Study on Stealth and Treachery"] = "Garona: Studie o plížení a zradě",
    ["General Drakkisath's Command"] = "Rozkaz Generála Drakkisatha",
    ["Harnessing Shadows"] = "Ovládnutí stínů",
    ["Healthy Dragon Scale"] = "Zdravá dračí šupina",
    ["Heroes of Old"] = "Hrdinové dávných časů",
    ["Hidden Treasures"] = "Skryté poklady",
    ["Holy Bologna: What the Light Won't Tell You"] = "Svaté nesmysly: Co vám Světlo neřekne",
    ["Hot Fiery Death"] = "Žhavá ohnivá smrt",
    ["Icebane Bracers"] = "Icebane Bracers",
    ["Inert Scourgestones"] = "Nečinné Scourgestones",
    ["Infallible Mind"] = "Neomylná mysl",
    ["Invaders of Alterac Valley"] = "Vetřelci v Alterac Valley",
    ["It's a Secret to Everybody"] = "Je to tajemství pro všechny",
    ["Joys of Omosh"] = "Radosti Omoshe",
    ["Just Compensation"] = "Spravedlivá odměna",
    ["Khan Jehn"] = "Khan Jehn",
    ["Khan Shaka"] = "Khan Shaka",
    ["Kharan's Tale"] = "Kharanův příběh",
    ["Kitchen Assistance"] = "Pomoc v kuchyni",
    ["Linken's Sword"] = "Linkenův meč",
    ["Loramus"] = "Loramus",
    ["Lorax's Tale"] = "Loraxův příběh",
    ["Lord Maxwell Tyrosus"] = "Lord Maxwell Tyrosus",
    ["Lost!"] = "Ztracený!",
    ["Magatha's Payment to Jediga"] = "Magathina platba pro Jedigu",
    ["Making Sense of It"] = "Dát tomu smysl",
    ["Mark of Honor"] = "Znak cti",
    ["Mastering the Elements"] = "Ovládnutí elementů",
    ["Mathiel"] = "Mathiel",
    ["Menethil's Gift"] = "Menethilův dar",
    ["Nat's Measuring Tape"] = "Natův měřicí pás",
    ["Necklace Recovery, Take 3"] = "Záchrana náhrdelníku, potřetí",
    ["Noboru the Cudgel"] = "Noboru the Cudgel",
    ["Noggenfogger Elixir"] = "Noggenfoggerův elixír",
    ["Nothing But The Truth"] = "Nic než pravda",
    ["Pacify the Centaur"] = "Pacifikuj kentaury",
    ["Prayer to Elune"] = "Modlitba k Elune",
    ["Protect Kanati Greycloud"] = "Ochraň Kanatiho Greyclouda",
    ["Purified!"] = "Očištěno!",
    ["Questioning Reethe"] = "Výslech Reetha",
    ["Ragnar Thunderbrew"] = "Ragnar Thunderbrew",
    ["Redemption"] = "Vykoupení",
    ["Regthar Deathgate"] = "Regthar Deathgate",
    ["Remember Alterac Valley!"] = "Pamatuj na Alterac Valley!",
    ["Report to Helgrum"] = "Hlášení pro Helgruma",
    ["Return to Deliana"] = "Návrat k Delianě",
    ["Return to Feathermoon Stronghold"] = "Návrat do Feathermoon Stronghold",
    ["Return to Ironforge"] = "Návrat do Ironforge",
    ["Return to Mokvar"] = "Návrat k Mokvarovi",
    ["Return to Narain"] = "Návrat k Narainovi",
    ["Return to Nathanos"] = "Návrat k Nathanosovi",
    ["Return to Primal Torntusk"] = "Návrat k Primal Torntusk",
    ["Return to Tinkee"] = "Návrat k Tinkee",
    ["Return to Troyas"] = "Návrat k Troyasovi",
    ["Return to Witch Doctor Uzer'i"] = "Návrat k Witch Doctoru Uzer'imu",
    ["Return to the Blasted Lands"] = "Návrat do Blasted Lands",
    ["Return to the Hinterlands"] = "Návrat do Hinterlands",
    ["Return to the Marsh"] = "Návrat do bažin",
    ["Returning the Cleansed Orb"] = "Návrat s očištěnou koulí",
    ["Rise, Obsidion!"] = "Povstaň, Obsidione!",
    ["Rise, Thunderfury!"] = "Povstaň, Thunderfury!",
    ["Ruined Kegs"] = "Zkažené sudy",
    ["Sacred Cloth"] = "Posvátná látka",
    ["Saving Sharpbeak"] = "Záchrana Sharpbeaka",
    ["Saving the Best for Last"] = "To nejlepší nakonec",
    ["Secrets of the Qiraji"] = "Tajemství Qiraji",
    ["Seeping Corruption"] = "Prosakující zkaženost",
    ["Sharing the Knowledge"] = "Sdílení znalostí",
    ["Soulbound Keepsake"] = "Památka spoutaná s duší",
    ["Speak with Deino"] = "Promluv si s Deino",
    ["Speak with our Quartermaster"] = "Promluv s naším Quartermasterem",
    ["Squire Maltrake"] = "Squire Maltrake",
    ["Stealing Darnassus's Flame"] = "Krádež plamene Darnassusu",
    ["Stealing Ironforge's Flame"] = "Krádež plamene Ironforge",
    ["Stealing Orgrimmar's Flame"] = "Krádež plamene Orgrimmaru",
    ["Stealing Stormwind's Flame"] = "Krádež plamene Stormwindu",
    ["Stealing Thunder Bluff's Flame"] = "Krádež plamene Thunder Bluff",
    ["Stealing the Undercity's Flame"] = "Krádež plamene Undercity",
    ["Summoning Shadra"] = "Vyvolání Shadry",
    ["Suntara Stones"] = "Kameny Suntara",
    ["Suspicious Hoofprints"] = "Podezřelé stopy kopyt",
    ["Talismans of Merit"] = "Talismany zásluh",
    ["Test of Lore"] = "Zkouška vědomostí",
    ["The Alliance Needs More Copper Bars!"] = "Aliance potřebuje další měděné pruty!",
    ["The Alliance Needs More Light Leather!"] = "Aliance potřebuje další lehkou kůži!",
    ["The Alliance Needs More Medium Leather!"] = "Aliance potřebuje další střední kůži!",
    ["The Alliance Needs More Purple Lotus!"] = "Aliance potřebuje další Purple Lotus!",
    ["The Alliance Needs More Roast Raptor!"] = "Aliance potřebuje další pečené raptory!",
    ["The Alliance Needs More Silk Bandages!"] = "Aliance potřebuje další hedvábné obvazy!",
    ["The Alliance Needs More Thorium Bars!"] = "Aliance potřebuje další thoriové pruty!",
    ["The Altar of Zul"] = "Oltář Zul",
    ["The Annals of Darrowshire"] = "Letopisy Darrowshire",
    ["The Arcanist's Cookbook"] = "Kuchařka arkanisty",
    ["The Argent Hold"] = "Argent Hold",
    ["The Battle Plans"] = "Bitevní plány",
    ["The Bearer of Bad News"] = "Posel špatných zpráv",
    ["The Black Shield"] = "Černý štít",
    ["The Champion Returns"] = "Šampion se vrací",
    ["The Completed Robe"] = "Dokončená róba",
    ["The Emerald Dream..."] = "Smaragdový sen...",
    ["The Forging of Quel'Serrar"] = "Kování Quel'Serraru",
    ["The Gordunni Orb"] = "Gordunnijská koule",
    ["The Gordunni Scroll"] = "Gordunnijský svitek",
    ["The Greatest Race of Hunters"] = "Největší rasa lovců",
    ["The Hand of the Righteous"] = "Ruka spravedlivých",
    ["The Heart of Hakkar"] = "Hakkarovo srdce",
    ["The Key to Freedom"] = "Klíč ke svobodě",
    ["The Light and How To Swing It"] = "Světlo a jak jím vládnout",
    ["The Lord of Blackrock"] = "Pán Blackrocku",
    ["The Lost Supplies"] = "Ztracené zásoby",
    ["The Missing Diplomat"] = "Pohřešovaný diplomat",
    ["The Monogrammed Sash"] = "Šerpa s monogramem",
    ["The Morrow Stone"] = "Morrow Stone",
    ["The Quartermaster"] = "Quartermaster",
    ["The Remains of Trey Lightforge"] = "Ostatky Treye Lightforge",
    ["The Savior of Kalimdor"] = "Spasitel Kalimdoru",
    ["The Smoldering Ruins of Thaurissan"] = "Doutnající ruiny Thaurissanu",
    ["The Summoning"] = "Vyvolání",
    ["The Torch of Retribution"] = "Pochodeň odplaty",
    ["The Treasure of the Shen'dralar"] = "Poklad Shen'dralar",
    ["The True Masters"] = "Skuteční páni",
    ["The Undermarket"] = "Podzemní trh",
    ["They Call Him Smiling Jim"] = "Říkají mu Smiling Jim",
    ["Threat From the Sea"] = "Hrozba z moře",
    ["Tinkee Steamboil"] = "Tinkee Steamboil",
    ["Tooga's Quest"] = "Toogův úkol",
    ["Tracing the Source"] = "Po stopě zdroje",
    ["Tyrande and Remulos"] = "Tyrande a Remulos",
    ["Urok Doomhowl"] = "Urok Doomhowl",
    ["Venom Bottles"] = "Lahvičky s jedem",
    ["Victory for the Alliance"] = "Vítězství pro Alianci",
    ["Victory for the Horde"] = "Vítězství pro Hordu",
    ["Vivian Lagrave"] = "Vivian Lagrave",
    ["Waking Legends"] = "Probouzení legend",
    ["Weapons of Spirit"] = "Zbraně ducha",
    ["What the Wind Carries"] = "Co přináší vítr",
    ["Wildeyes"] = "Wildeyes",
    ["Xylem's Payment to Jediga"] = "Xylemova platba pro Jedigu",
}
for en, cs in pairs(titles) do
    if A.QuestTitleTranslations[en] == nil then A.QuestTitleTranslations[en] = cs end
end
