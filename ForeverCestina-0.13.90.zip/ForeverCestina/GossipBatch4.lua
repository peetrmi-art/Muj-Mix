-- Classic NPC/Gossip translations from persistent offline source pool.
-- Data-only batch for ForeverCestina 0.13.61; runtime logic remains unchanged.
local _, A = ...
A.GossipEntries = A.GossipEntries or {}
local E = A.GossipEntries
local function add(npc,en,cs)
 E[#E+1]={npc=npc,en=en,cs=cs}
end
-- source_id 901
add("Randal Hunter","I can teach you the finer points of Horse Riding, provided you have enough gold to cover the lesson!","Mohu tě naučit jemné umění jízdy na koni, pokud máš dost zlata na zaplacení lekce!")
-- source_id 902
add("Kar Stormsinger","I can teach you the finer points of Kodo Riding, provided you have enough gold to cover the lesson!","Mohu tě naučit jemné umění jízdy na kodo, pokud máš dost zlata na zaplacení lekce!")
-- source_id 903
add("Ultham Ironhorn","I can teach you the finer points of Ram Riding, provided you have enough gold to cover the lesson!","Mohu tě naučit jemné umění jízdy na beranovi, pokud máš dost zlata na zaplacení lekce!")
-- source_id 904
add("Xar'Ti","I can teach you the finer points of Raptor Riding, provided you have enough gold to cover the lesson!","Mohu tě naučit jemné umění jízdy na raptorovi, pokud máš dost zlata na zaplacení lekce!")
-- source_id 905
add("Velma Warnam","I can teach you the finer points of Skeletal Horse Riding, provided you have enough gold to cover the lesson!","Mohu tě naučit jemné umění jízdy na kostlivém koni, pokud máš dost zlata na zaplacení lekce!")
-- source_id 906
add("Jartsam","I can teach you the finer points of Tiger Riding, provided you have enough gold to cover the lesson!","Mohu tě naučit jemné umění jízdy na tygrovi, pokud máš dost zlata na zaplacení lekce!")
-- source_id 907
add("Kildar","I can teach you the finer points of Wolf Riding, provided you have enough gold to cover the lesson!","Mohu tě naučit jemné umění jízdy na vlkovi, pokud máš dost zlata na zaplacení lekce!")
-- source_id 908
add("Ander Germaine","I can tell just by the way you're standing that you're no warrior.  $B$BWhy don't you go do something safe, like read a book.","Už podle toho, jak stojíš, poznám, že nejsi žádný válečník.  $B$BProč nejdeš dělat něco bezpečného, třeba si číst knihu.")
add("Ilsa Corbin","I can tell just by the way you're standing that you're no warrior.  $B$BWhy don't you go do something safe, like read a book.","Už podle toho, jak stojíš, poznám, že nejsi žádný válečník.  $B$BProč nejdeš dělat něco bezpečného, třeba si číst knihu.")
add("Llane Beshere","I can tell just by the way you're standing that you're no warrior.  $B$BWhy don't you go do something safe, like read a book.","Už podle toho, jak stojíš, poznám, že nejsi žádný válečník.  $B$BProč nejdeš dělat něco bezpečného, třeba si číst knihu.")
add("Lyria Du Lac","I can tell just by the way you're standing that you're no warrior.  $B$BWhy don't you go do something safe, like read a book.","Už podle toho, jak stojíš, poznám, že nejsi žádný válečník.  $B$BProč nejdeš dělat něco bezpečného, třeba si číst knihu.")
add("Wu Shen","I can tell just by the way you're standing that you're no warrior.  $B$BWhy don't you go do something safe, like read a book.","Už podle toho, jak stojíš, poznám, že nejsi žádný válečník.  $B$BProč nejdeš dělat něco bezpečného, třeba si číst knihu.")
-- source_id 909
add("Eldrin","I can tell that your wardrobe is in dire need of care.","Podle mě tvůj šatník nutně potřebuje péči.")
-- source_id 910
add("Arnok","I can train you in First Aid techniques.","Mohu tě vycvičit v technikách první pomoci.")
add("Byancie","I can train you in First Aid techniques.","Mohu tě vycvičit v technikách první pomoci.")
add("Dannelor","I can train you in First Aid techniques.","Mohu tě vycvičit v technikách první pomoci.")
add("Fremal Doohickey","I can train you in First Aid techniques.","Mohu tě vycvičit v technikách první pomoci.")
add("Mary Edras","I can train you in First Aid techniques.","Mohu tě vycvičit v technikách první pomoci.")
add("Michelle Belle","I can train you in First Aid techniques.","Mohu tě vycvičit v technikách první pomoci.")
add("Nissa Firestone","I can train you in First Aid techniques.","Mohu tě vycvičit v technikách první pomoci.")
add("Nurse Neela","I can train you in First Aid techniques.","Mohu tě vycvičit v technikách první pomoci.")
add("Pand Stonebinder","I can train you in First Aid techniques.","Mohu tě vycvičit v technikách první pomoci.")
add("Rawrk","I can train you in First Aid techniques.","Mohu tě vycvičit v technikách první pomoci.")
add("Thamner Pol","I can train you in First Aid techniques.","Mohu tě vycvičit v technikách první pomoci.")
add("Vira Younghoof","I can train you in First Aid techniques.","Mohu tě vycvičit v technikách první pomoci.")
-- source_id 911
add("Wing Commander Vipore","I can't believe it... I was doing a routine recon mission over the central DMZ when all hell broke loose. I saw the Horde Wing Commander, Mulverick, take out both Ichman and Slidore! Anger took hold of me and I broke from my wing man and drove that bastard Mulverick down. Unfortunately, he clipped my gryphon before he crashed, forcing me down as well. I ended up captured by these savages.$B$BI have to get back to base! Help!","Nemůžu tomu uvěřit... Byl jsem na běžné průzkumné misi nad centrální DMZ, když se rozpoutalo peklo. Viděl jsem velitele letky Hordy Mulvericka, jak sestřelil Ichmana i Slidorea! Popadl mě vztek, odtrhl jsem se od svého wingmana a hnal toho bastarda Mulvericka k zemi. Bohužel ještě před pádem zasáhl mého gryfona a donutil mě přistát. Nakonec mě zajali tihle barbaři.$B$BMusím se dostat zpět na základnu! Pomoz mi!")
-- source_id 912
add("Deputy Rainer","I can't believe the officials in Stormwind, sending the bulk of our army abroad... when our home front is under so much pressure!$B$BWith thieves coming from Westfall and gnolls encroaching from from the east and west, it's a wonder Stormwind itself isn't besieged.","Nemůžu uvěřit těm úředníkům ve Stormwindu, kteří poslali většinu naší armády do zahraničí... když je naše vlastní území pod takovým tlakem!$B$BZe Westfallu přicházejí zloději a z východu i západu se sem tlačí gnollové. Je div, že samotný Stormwind ještě není v obležení.")
-- source_id 913
add("Morja","I can't find my pet frog, Jubjub.  She loves Dark Iron Ale, it's all she ever drinks, but can be so hard to get!  Now I'm out... and Jubjub must have run away to find more!$B$BI wish she would come back...","Nemůžu najít svou žábu Jubjub. Miluje Dark Iron Ale, nic jiného nepije, ale to pivo je tak těžké sehnat! Teď mi došlo... a Jubjub asi utekla hledat další!$B$BKéž by se vrátila...")
-- source_id 914
add("Tinkerwiz","I can't help ya'! You're ready to see someone who's been at it longer than I have! Let's see... you're an Alliance type, so you need to talk to Lilliam Sparkspindle in Stormwind.","S tímhle ti nepomůžu! Už potřebuješ někoho, kdo to dělá déle než já! Podívejme... jsi z Alliance, takže si musíš promluvit s Lilliam Sparkspindle ve Stormwindu.")
add("Twizwick Sprocketgrind","I can't help ya'! You're ready to see someone who's been at it longer than I have! Let's see... you're an Alliance type, so you need to talk to Lilliam Sparkspindle in Stormwind.","S tímhle ti nepomůžu! Už potřebuješ někoho, kdo to dělá déle než já! Podívejme... jsi z Alliance, takže si musíš promluvit s Lilliam Sparkspindle ve Stormwindu.")
-- source_id 915
add("Bengus Deepforge","I can't say enough about yer work, truly amazing things that ye can do with a hammer and an anvil. Now, don't be tellin anyone that I suggested ye go find a goblin to teach ye but that's exactly what I'm gonna do. Brikk Keencraft is his name, and last I heard he was operating a shop down in Booty bay.","O tvé práci nemůžu říct dost dobrého, s kladivem a kovadlinou dokážeš úžasné věci. A nikomu neříkej, že jsem ti poradil najít goblina, aby tě učil, ale přesně to udělám. Jmenuje se Brikk Keencraft a naposledy jsem slyšel, že má dílnu v Booty Bay.")
-- source_id 916
add("Roxxik","I can't teach what I don't know! If only there was someone else who knew more than I do... wait, there is! Go see Buzzek Bracketswing in Gadgetzan!","Nemůžu učit něco, co sám neumím! Kéž by tu byl někdo, kdo toho ví víc než já... počkat, je! Najdi Buzzeka Bracketswinga v Gadgetzanu!")
-- source_id 917
add("Krulmoo Fullmoon","I cannot aid you with further lessons: your skills have surpassed mine. Go and see the tauren Una in the northwestern shops of Thunder Bluff's central plateau. She offers more advanced training.","Další lekce už ti dát nemohu: tvé schopnosti překonaly mé. Vyhledej taurenskou Unu v severozápadních obchodech na centrální plošině Thunder Bluffu. Nabízí pokročilejší výcvik.")
-- source_id 918
add("Timothy Worthington","I cannot help you until you have learned more of the essentials. Come back to me when you are ready.","Nemohu ti pomoci, dokud si lépe neosvojíš základy. Vrať se, až budeš připraven.")
-- source_id 919
add("Tarn","I cannot help you with further training: your skill at working with leather rivals my own. You should speak with Una, over there. I will vouch for your skill if need be.","S dalším výcvikem ti už nepomohu: v práci s kůží se mi téměř vyrovnáš. Promluv si s Unou támhle. Pokud bude třeba, zaručím se za tvé schopnosti.")
-- source_id 920
add("Bena Winterhoof","I cannot in good conscience spend time training novices while our allies, the undead, are suffering so terribly. Please speak with Kray over there instead; he can help you for now.","Nemohu s čistým svědomím trávit čas výcvikem nováčků, když naši spojenci, nemrtví, tolik trpí. Promluv si místo toho s Krayem támhle; prozatím ti pomůže on.")
-- source_id 921
add("Mot Dawnstrider","I cannot teach you anything you don't already know. However, the knowledge of my father far surpasses my own. Go inside and speak to him. Good luck!","Nemohu tě naučit nic, co už neznáš. Znalosti mého otce však mé vlastní daleko převyšují. Jdi dovnitř a promluv si s ním. Hodně štěstí!")
-- source_id 922
add("Alenndaar Lapidaar","I cannot train a $c such as yourself.","Nemohu vycvičit někoho jako ty, $c.")
add("Ayanna Everstride","I cannot train a $c such as yourself.","Nemohu vycvičit někoho jako ty, $c.")
add("Danlaar Nightstride","I cannot train a $c such as yourself.","Nemohu vycvičit někoho jako ty, $c.")
add("Dazalar","I cannot train a $c such as yourself.","Nemohu vycvičit někoho jako ty, $c.")
add("Dorion","I cannot train a $c such as yourself.","Nemohu vycvičit někoho jako ty, $c.")
add("Jeen'ra Nightrunner","I cannot train a $c such as yourself.","Nemohu vycvičit někoho jako ty, $c.")
add("Jocaste","I cannot train a $c such as yourself.","Nemohu vycvičit někoho jako ty, $c.")
add("Kaerbrus","I cannot train a $c such as yourself.","Nemohu vycvičit někoho jako ty, $c.")
-- source_id 923
add("Captain Kromcrush","I cause you no trouble, boss.","Nedělám ti žádné potíže, šéfe.")
add("Gordok Brute","I cause you no trouble, boss.","Nedělám ti žádné potíže, šéfe.")
add("Gordok Bushwacker","I cause you no trouble, boss.","Nedělám ti žádné potíže, šéfe.")
add("Gordok Captain","I cause you no trouble, boss.","Nedělám ti žádné potíže, šéfe.")
add("Gordok Mage-Lord","I cause you no trouble, boss.","Nedělám ti žádné potíže, šéfe.")
add("Gordok Reaver","I cause you no trouble, boss.","Nedělám ti žádné potíže, šéfe.")
add("Gordok Warlock","I cause you no trouble, boss.","Nedělám ti žádné potíže, šéfe.")
-- source_id 924
add("Razor Hill Grunt","I could use a drink and some rest myself.  You'll find it right in the northwest corner of Razor Hill.  Say hi to Innkeeper Grosk for me.","Sám bych si dal něco k pití a trochu si odpočinul. Najdeš to přímo v severozápadním rohu Razor Hill. Pozdravuj ode mě hostinského Groska.")
-- source_id 925
add("Warlord Goretooth","I did not doubt you for even one second, $N.$B$BHere are your orders, $N. I know that you will not let me down.","Ani na vteřinu jsem o tobě nepochyboval, $N.$B$BTady jsou tvé rozkazy, $N. Vím, že mě nezklameš.")
-- source_id 926
add("Birgitte Cranston","I do not believe you possess the mental acuity to grasp the nature of portal magic.","Nevěřím, že máš dost duševní bystrosti, abys pochopil podstatu portálové magie.")
add("Elissa Dumas","I do not believe you possess the mental acuity to grasp the nature of portal magic.","Nevěřím, že máš dost duševní bystrosti, abys pochopil podstatu portálové magie.")
add("Larimaine Purdue","I do not believe you possess the mental acuity to grasp the nature of portal magic.","Nevěřím, že máš dost duševní bystrosti, abys pochopil podstatu portálové magie.")
add("Lexington Mortaim","I do not believe you possess the mental acuity to grasp the nature of portal magic.","Nevěřím, že máš dost duševní bystrosti, abys pochopil podstatu portálové magie.")
add("Milstaff Stormeye","I do not believe you possess the mental acuity to grasp the nature of portal magic.","Nevěřím, že máš dost duševní bystrosti, abys pochopil podstatu portálové magie.")
add("Thuul","I do not believe you possess the mental acuity to grasp the nature of portal magic.","Nevěřím, že máš dost duševní bystrosti, abys pochopil podstatu portálové magie.")
-- source_id 927
add("Phalanx","I do not enjoy conversation.","Konverzace mě nebaví.")
-- source_id 928
add("Aurius","I do not have much time in this world, but Light willing, it is time enough to fulfill my destiny.  When you face Baron Rivendare, I will be with you.","Na tomto světě už nemám mnoho času, ale dá-li Light, snad ho bude dost na naplnění mého osudu. Až se postavíš Baronu Rivendareovi, budu s tebou.")
-- source_id 929
add("Kary Thunderhorn","I do not have the knowledge you seek.","Znalosti, které hledáš, nemám.")
add("Lanka Farshot","I do not have the knowledge you seek.","Znalosti, které hledáš, nemám.")
add("Thotar","I do not have the knowledge you seek.","Znalosti, které hledáš, nemám.")
add("Urek Thunderhorn","I do not have the knowledge you seek.","Znalosti, které hledáš, nemám.")
add("Yaw Sharpmane","I do not have the knowledge you seek.","Znalosti, které hledáš, nemám.")
-- source_id 930
add("Malcomb Wynn","I do not have time to waste, stranger. State your business or be off!","Nemám čas nazbyt, cizinče. Řekni, co chceš, nebo odejdi!")
-- source_id 931
add("Krulmoo Fullmoon","I do not offer apprentice training. Look for the tauren Waldor in the Wailing Caverns, here in the Barrens. He can assist you with whatever you need.","Výcvik učňů neposkytuji. Najdi taurena Waldora ve Wailing Caverns tady v Barrens. Pomůže ti se vším, co potřebuješ.")
-- source_id 932
add("Alyissia","I do not see the warrior's spirit within you, child.  I have no teachings which would benefit a $c such as yourself.","Necítím v tobě ducha válečníka, dítě. Nemám žádné učení, které by někomu jako ty, $c, prospělo.")
add("Arias'ta Bladesinger","I do not see the warrior's spirit within you, child.  I have no teachings which would benefit a $c such as yourself.","Necítím v tobě ducha válečníka, dítě. Nemám žádné učení, které by někomu jako ty, $c, prospělo.")
add("Darnath Bladesinger","I do not see the warrior's spirit within you, child.  I have no teachings which would benefit a $c such as yourself.","Necítím v tobě ducha válečníka, dítě. Nemám žádné učení, které by někomu jako ty, $c, prospělo.")
add("Kyra Windblade","I do not see the warrior's spirit within you, child.  I have no teachings which would benefit a $c such as yourself.","Necítím v tobě ducha válečníka, dítě. Nemám žádné učení, které by někomu jako ty, $c, prospělo.")
add("Sildanair","I do not see the warrior's spirit within you, child.  I have no teachings which would benefit a $c such as yourself.","Necítím v tobě ducha válečníka, dítě. Nemám žádné učení, které by někomu jako ty, $c, prospělo.")
-- source_id 933
add("Decedra Willham","I do so enjoy sitting out here, listening to the sounds of the Great Sea.  Oh, what?  Yes, there is a ship that will take you to Menethil Harbor.  It docks here from time to time.","Tak rád tu sedím a poslouchám zvuky Great Sea. Cože? Ano, je tu loď, která tě odveze do Menethil Harbor. Čas od času tu kotví.")
-- source_id 934
add("Ken'jai","I do what me can to train you in the priestly ways, if that what you be here for.","Udělám, co bude v mých silách, abych tě naučil kněžským cestám, jestli právě proto přicházíš.")
add("Tai'jin","I do what me can to train you in the priestly ways, if that what you be here for.","Udělám, co bude v mých silách, abych tě naučil kněžským cestám, jestli právě proto přicházíš.")
add("Ur'kyo","I do what me can to train you in the priestly ways, if that what you be here for.","Udělám, co bude v mých silách, abych tě naučil kněžským cestám, jestli právě proto přicházíš.")
add("X'yera","I do what me can to train you in the priestly ways, if that what you be here for.","Udělám, co bude v mých silách, abych tě naučil kněžským cestám, jestli právě proto přicházíš.")
add("Zayus","I do what me can to train you in the priestly ways, if that what you be here for.","Udělám, co bude v mých silách, abych tě naučil kněžským cestám, jestli právě proto přicházíš.")
-- source_id 935
add("Smith Argus","I don't admit this lightly, but you are a far better smith than I am. If you want to learn more than my meager teachings then I suggest you seek out a Dwarf named Therum Deepforge in Stormwind. You will find him in the Dwarven District.","Nerad to přiznávám, ale jsi mnohem lepší kovář než já. Jestli se chceš naučit víc, než ti dokážu předat já, doporučuji vyhledat trpaslíka jménem Therum Deepforge ve Stormwindu. Najdeš ho v Dwarven District.")
-- source_id 936
add("Mountaineer Pebblebitty","I don't care to hear it, $N. Nope, no way are you going to be let into the Searing Gorge. Impossible. Not going to happen. How many times do I have to tell you - I can't let you in! Do you not speak common? Are you an orc in disguise? N-O. NO!$B$BIf I let you in, then I have to let everybody in. Pretty soon your close friends will want in, then their distant relatives, then their friends, and so on and so forth. The last time that happened... well, we won't talk about the last time it happened.","Nechci to slyšet, $N. Ne, ani náhodou tě do Searing Gorge nepustím. Nemožné. Nestane se to. Kolikrát ti to mám říkat - nemůžu tě tam pustit! Nerozumíš Common? Jsi snad ork v přestrojení? N-E. NE!$B$BKdybych pustil tebe, musel bych pustit každého. Brzy by tam chtěli tvoji blízcí přátelé, pak jejich vzdálení příbuzní, jejich přátelé a tak dál a tak dál. Minule, když se to stalo... no, o tom raději mluvit nebudeme.")
-- source_id 937
add("Lavinia Crowe","I don't get many visitors.  You're looking for something specific, yes?","Moc návštěv nemívám. Hledáš něco konkrétního, že?")
-- source_id 938
add("Maris Granger","I don't get too many Skinners in here looking for training, but I guess I could teach you something if you're ready.","Moc stahovačů kůží sem na výcvik nechodí, ale jestli jsi připraven, asi bych tě mohl něco naučit.")
-- source_id 939
add("Franklin Lloyd","I don't have time for idle gossip, I'm a professional!","Nemám čas na plané řeči, jsem profesionál!")
-- source_id 940
add("Jormund Stonebrow","I don't have time to babysit! Go talk to me assistant, Uthrar!","Nemám čas někoho vodit za ručičku! Promluv si s mým pomocníkem Uthrarem!")
-- source_id 941
add("Thunder Bluff Reveler","I don't know how these fireworks work, but they sure are pretty!","Nevím, jak tyhle ohňostroje fungují, ale jsou opravdu pěkné!")
-- source_id 942
add("Stormwind Guard","I don't know much about magic, but there's a mage named Zaldimar who is staying at the Lion's Pride Inn that could probably assist you.","O magii toho moc nevím, ale v Lion's Pride Inn pobývá mág jménem Zaldimar, který by ti nejspíš mohl pomoct.")
-- source_id 943
add("Razor Hill Grunt","I don't know of one of those around here.  Your best bet is to go to Orgrimmar to the north and speak to one of their grunts.","O ničem takovém tady nevím. Nejlepší bude jít na sever do Orgrimmaru a zeptat se některého z tamních gruntů.")
-- source_id 944
add("Advisor Belgrum","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Barim Jurgenstaad","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Brenwyn Wintersteel","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Bretta Goldfury","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Brohann Caskbelly","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Brombar Higgleby","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Bromiir Ormsen","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Brooke Stonebraid","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Bruuk Barleybeard","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Bryllia Ironbrand","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Chief Archaeologist Greywhisker","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Curator Thorius","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Demnul Farmountain","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Dinita Stonemantle","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Dolkin Craghelm","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Dolman Steelfury","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Durtham Greldon","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Edris Barleybeard","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Emrul Riknussun","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Furen Longbeard","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Gerrig Bonegrip","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Golnir Bouldertoe","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Grand Mason Marblesten","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Grenil Steelfury","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Gwenna Firebrew","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Gwina Stonebranch","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Harick Boulderdrum","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Hegnar Swiftaxe","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("High Explorer Magellas","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Hjoldir Stoneblade","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Ingrys Stonebrow","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Ironforge Guard","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Kaita Deepforge","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Kathrum Axehand","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Kelomir Ironhand","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Krom Stoutarm","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Librarian Mae Paledust","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Lyesa Steelbrow","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Lyon Mountainheart","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Maeva Snowbraid","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Mangorn Flinthammer","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Morgg Stormshot","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Muiredon Battleforge","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Muren Stormpike","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Myra Tyrngaarde","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Pilot Longbeard","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Poranna Snowbraid","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Prospector Stormpike","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Raena Flinthammer","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Roetten Stonehammer","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Sara Balloo","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Skolmin Goldfury","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Sognar Cliffbeard","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Thalgus Thunderfist","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Thief Catcher Farmountain","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Thief Catcher Shadowdelve","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Thief Catcher Thunderbrew","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Thulman Flintcrag","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Thurgrum Deepforge","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Tiza Battleforge","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Tormek Stoneriver","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Tymor","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Wilder Thistlenettle","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
add("Xiggs Fuselighter","I don't know what's come over me. My heart feels as hot as new steel.","Nevím, co to do mě vjelo. Srdce mi žhne jako čerstvě rozžhavená ocel.")
-- source_id 945
add("Ghak Healtouch","I don't suppose you're here to talk about my lovely Kali. Fine, then. Potions it is. Anyone ever tell ye you've got a one-track mind?","Předpokládám, že ses nepřišel bavit o mé půvabné Kali. Dobrá tedy. Lektvary. Řekl ti někdy někdo, že myslíš jen na jednu věc?")
-- source_id 946
add("Ian Strom","I don't think you want to learn anything I can teach. Might want to find a $c trainer to help you out.","Nemyslím, že se ode mě chceš učit něco, co umím. Raději si najdi trenéra pro $c, ten ti pomůže.")
add("Jorik Kerridan","I don't think you want to learn anything I can teach. Might want to find a $c trainer to help you out.","Nemyslím, že se ode mě chceš učit něco, co umím. Raději si najdi trenéra pro $c, ten ti pomůže.")
add("Lord Tony Romano","I don't think you want to learn anything I can teach. Might want to find a $c trainer to help you out.","Nemyslím, že se ode mě chceš učit něco, co umím. Raději si najdi trenéra pro $c, ten ti pomůže.")
add("Osborne the Night Man","I don't think you want to learn anything I can teach. Might want to find a $c trainer to help you out.","Nemyslím, že se ode mě chceš učit něco, co umím. Raději si najdi trenéra pro $c, ten ti pomůže.")
-- source_id 947
add("Shayis Steelfury","I don't train smiths with no skill, come back when you have something decent to show me.","Kováře bez dovedností necvičím. Vrať se, až mi budeš mít co pořádného ukázat.")
-- source_id 948
add("Anishar","I don't train your kind $c.","Takové jako ty, $c, necvičím.")
add("Erion Shadewhisper","I don't train your kind $c.","Takové jako ty, $c, necvičím.")
add("Gest","I don't train your kind $c.","Takové jako ty, $c, necvičím.")
add("Jannok Breezesong","I don't train your kind $c.","Takové jako ty, $c, necvičím.")
add("Kaplak","I don't train your kind $c.","Takové jako ty, $c, necvičím.")
add("Ormok","I don't train your kind $c.","Takové jako ty, $c, necvičím.")
add("Rwag","I don't train your kind $c.","Takové jako ty, $c, necvičím.")
add("Shenthul","I don't train your kind $c.","Takové jako ty, $c, necvičím.")
add("Syurna","I don't train your kind $c.","Takové jako ty, $c, necvičím.")
-- source_id 949
add("Frang","I don't train your kind $c.  Find your own trainer before you anger me.","Takové jako ty, $c, necvičím. Najdi si vlastního trenéra, než mě rozčílíš.")
add("Grezz Ragefist","I don't train your kind $c.  Find your own trainer before you anger me.","Takové jako ty, $c, necvičím. Najdi si vlastního trenéra, než mě rozčílíš.")
add("Malosh","I don't train your kind $c.  Find your own trainer before you anger me.","Takové jako ty, $c, necvičím. Najdi si vlastního trenéra, než mě rozčílíš.")
add("Sorek","I don't train your kind $c.  Find your own trainer before you anger me.","Takové jako ty, $c, necvičím. Najdi si vlastního trenéra, než mě rozčílíš.")
add("Tarshaw Jaggedscar","I don't train your kind $c.  Find your own trainer before you anger me.","Takové jako ty, $c, necvičím. Najdi si vlastního trenéra, než mě rozčílíš.")
-- source_id 950
add("Warlord Goretooth","I dream, $N... oh yes, I dream. In my dreams I die a thousand times in a thousand different ways. Some would call dreams such as mine nightmares. NOT I! In dreams I die in the thick of battle. For each single death of my own, ten thousand enemies of the Horde fall before me. It is glorious!","Sním, $N... ano, sním. Ve snech umírám tisíckrát tisíci různými způsoby. Někteří by takovým snům říkali noční můry. JÁ NE! Ve snech umírám v nejprudší bitvě. Za každou mou jedinou smrt padne deset tisíc nepřátel Hordy. Je to nádhera!")
-- source_id 951
add("Meridith the Mermaiden","I find the ocean floor to be very peaceful.","Mořské dno mi připadá velmi klidné.")
-- source_id 952
add("Arthur Moore","I first set up shop in the Magic Quarter, but it was pretty noisy there. This is a definite improvement, barring a few persistent students who still track me down, despite the fact that I've relocated.","Nejdřív jsem si otevřel dílnu v Magic Quarter, ale bylo tam dost hlučno. Tohle je rozhodně lepší, až na pár neodbytných studentů, kteří mě pořád dokážou najít, přestože jsem se přestěhoval.")
-- source_id 953
add("Jes'rimon","I give you warm greetin's, $c, as does the Shattered Hand.$B$BDo not look so surprised, $N. There be shadows even on the highest perches of Orgrimmar--somethin' must hide there. The Shattered Hand take that role willingly. Thrall, even in his good heart, acknowledge that the Hand be necessary to ensure orc and troll safety.$B$BBut you not here to talk 'bout my business, you here for somethin' else.","Vřele tě zdravím, $c, stejně jako Shattered Hand.$B$BNedívej se tak překvapeně, $N. I na nejvyšších bidlech Orgrimmaru jsou stíny--něco se v nich musí skrývat. Shattered Hand tuto roli přijímá dobrovolně. Dokonce i Thrall ve své dobrotě uznává, že Hand je nutná k zajištění bezpečí orků a trollů.$B$BAle kvůli mému podnikání tu nejsi, přišel jsi kvůli něčemu jinému.")
-- source_id 954
add("Zaetar's Spirit","I greet you, $r.","Zdravím tě, $r.")
-- source_id 955
add("Karus","I guarantee this bank's security with my own blood, is that good enough for you?","Bezpečnost této banky ručím vlastní krví, stačí ti to?")
add("Koma","I guarantee this bank's security with my own blood, is that good enough for you?","Bezpečnost této banky ručím vlastní krví, stačí ti to?")
add("Soran","I guarantee this bank's security with my own blood, is that good enough for you?","Bezpečnost této banky ručím vlastní krví, stačí ti to?")
-- source_id 956
add("Bodley","I guess it's all just about over, right $N? I'm going to miss you... it'll be pretty lonely up here without someone to talk to.$B$BBut that doesn't mean that you can't come back to see me in the future!","Takže je asi skoro po všem, viď $N? Budeš mi chybět... bez někoho na povídání tu bude dost osamělo.$B$BTo ale neznamená, že se za mnou v budoucnu nemůžeš vrátit!")
-- source_id 957
add("Orgrimmar Grunt","I guess someone needs to bandage us warriors up after the fighting.  Seek out Arnok at the Survival of the Fittest hut next to the Spirit Lodge in the Valley of Spirits.  Look up above and to the west of the Valley of Strength for a lake.  That's where he's at.","Asi nás válečníky po boji někdo musí obvazovat. Vyhledej Arnoka v chatrči Survival of the Fittest vedle Spirit Lodge ve Valley of Spirits. Podívej se nad Valley of Strength směrem na západ k jezeru. Tam ho najdeš.")
-- source_id 958
add("Sergeant Major Germaine","I guess that's that. We have all of the Arthas' Tears necessary. You might try asking around. One of these others is sure to have something that they still need collected for the war effort.","Tak to je asi všechno. Máme všechny Arthas' Tears, které jsme potřebovali. Zkus se poptat kolem. Někdo z ostatních určitě ještě potřebuje něco shromáždit pro válečné úsilí.")
-- source_id 959
add("Thrag Stonehoof","I guess the spirits like you better than me, I still have not heard their call but you seem to have gathered their lessons well. Go speak to Karn, he will be excited to see one who hears them as he does.","Asi tě mají duchové raději než mě. Já jejich volání pořád neslyším, ale ty sis jejich lekce zjevně dobře osvojil. Promluv si s Karnem, určitě bude nadšený, že vidí někoho, kdo je slyší stejně jako on.")
-- source_id 960
add("Deathguard Abraham","I guess your first exercise is going to be to mine your way down to the Undercity.  Heh, get it?  Mine... nevermind.  To get to the Undercity go to the rear of the Ruins of Lordaeron south of Brill, and take the elevator down.  Ask one of the Undercity Guardians there for further assistance.","Tak první cvičení bude asi prokopat si cestu do Undercity. Heh, chápeš? Prokopat... nic. Do Undercity se dostaneš tak, že půjdeš k zadní části Ruins of Lordaeron jižně od Brillu a sjedeš výtahem dolů. O další pomoc požádej některého z Undercity Guardians.")
add("Deathguard Bartholomew","I guess your first exercise is going to be to mine your way down to the Undercity.  Heh, get it?  Mine... nevermind.  To get to the Undercity go to the rear of the Ruins of Lordaeron south of Brill, and take the elevator down.  Ask one of the Undercity Guardians there for further assistance.","Tak první cvičení bude asi prokopat si cestu do Undercity. Heh, chápeš? Prokopat... nic. Do Undercity se dostaneš tak, že půjdeš k zadní části Ruins of Lordaeron jižně od Brillu a sjedeš výtahem dolů. O další pomoc požádej některého z Undercity Guardians.")
add("Deathguard Burgess","I guess your first exercise is going to be to mine your way down to the Undercity.  Heh, get it?  Mine... nevermind.  To get to the Undercity go to the rear of the Ruins of Lordaeron south of Brill, and take the elevator down.  Ask one of the Undercity Guardians there for further assistance.","Tak první cvičení bude asi prokopat si cestu do Undercity. Heh, chápeš? Prokopat... nic. Do Undercity se dostaneš tak, že půjdeš k zadní části Ruins of Lordaeron jižně od Brillu a sjedeš výtahem dolů. O další pomoc požádej některého z Undercity Guardians.")
add("Deathguard Cyrus","I guess your first exercise is going to be to mine your way down to the Undercity.  Heh, get it?  Mine... nevermind.  To get to the Undercity go to the rear of the Ruins of Lordaeron south of Brill, and take the elevator down.  Ask one of the Undercity Guardians there for further assistance.","Tak první cvičení bude asi prokopat si cestu do Undercity. Heh, chápeš? Prokopat... nic. Do Undercity se dostaneš tak, že půjdeš k zadní části Ruins of Lordaeron jižně od Brillu a sjedeš výtahem dolů. O další pomoc požádej některého z Undercity Guardians.")
add("Deathguard Dillinger","I guess your first exercise is going to be to mine your way down to the Undercity.  Heh, get it?  Mine... nevermind.  To get to the Undercity go to the rear of the Ruins of Lordaeron south of Brill, and take the elevator down.  Ask one of the Undercity Guardians there for further assistance.","Tak první cvičení bude asi prokopat si cestu do Undercity. Heh, chápeš? Prokopat... nic. Do Undercity se dostaneš tak, že půjdeš k zadní části Ruins of Lordaeron jižně od Brillu a sjedeš výtahem dolů. O další pomoc požádej některého z Undercity Guardians.")
add("Deathguard Gavin","I guess your first exercise is going to be to mine your way down to the Undercity.  Heh, get it?  Mine... nevermind.  To get to the Undercity go to the rear of the Ruins of Lordaeron south of Brill, and take the elevator down.  Ask one of the Undercity Guardians there for further assistance.","Tak první cvičení bude asi prokopat si cestu do Undercity. Heh, chápeš? Prokopat... nic. Do Undercity se dostaneš tak, že půjdeš k zadní části Ruins of Lordaeron jižně od Brillu a sjedeš výtahem dolů. O další pomoc požádej některého z Undercity Guardians.")
add("Deathguard Lawrence","I guess your first exercise is going to be to mine your way down to the Undercity.  Heh, get it?  Mine... nevermind.  To get to the Undercity go to the rear of the Ruins of Lordaeron south of Brill, and take the elevator down.  Ask one of the Undercity Guardians there for further assistance.","Tak první cvičení bude asi prokopat si cestu do Undercity. Heh, chápeš? Prokopat... nic. Do Undercity se dostaneš tak, že půjdeš k zadní části Ruins of Lordaeron jižně od Brillu a sjedeš výtahem dolů. O další pomoc požádej některého z Undercity Guardians.")
add("Deathguard Lundmark","I guess your first exercise is going to be to mine your way down to the Undercity.  Heh, get it?  Mine... nevermind.  To get to the Undercity go to the rear of the Ruins of Lordaeron south of Brill, and take the elevator down.  Ask one of the Undercity Guardians there for further assistance.","Tak první cvičení bude asi prokopat si cestu do Undercity. Heh, chápeš? Prokopat... nic. Do Undercity se dostaneš tak, že půjdeš k zadní části Ruins of Lordaeron jižně od Brillu a sjedeš výtahem dolů. O další pomoc požádej některého z Undercity Guardians.")
add("Deathguard Morris","I guess your first exercise is going to be to mine your way down to the Undercity.  Heh, get it?  Mine... nevermind.  To get to the Undercity go to the rear of the Ruins of Lordaeron south of Brill, and take the elevator down.  Ask one of the Undercity Guardians there for further assistance.","Tak první cvičení bude asi prokopat si cestu do Undercity. Heh, chápeš? Prokopat... nic. Do Undercity se dostaneš tak, že půjdeš k zadní části Ruins of Lordaeron jižně od Brillu a sjedeš výtahem dolů. O další pomoc požádej některého z Undercity Guardians.")
add("Deathguard Mort","I guess your first exercise is going to be to mine your way down to the Undercity.  Heh, get it?  Mine... nevermind.  To get to the Undercity go to the rear of the Ruins of Lordaeron south of Brill, and take the elevator down.  Ask one of the Undercity Guardians there for further assistance.","Tak první cvičení bude asi prokopat si cestu do Undercity. Heh, chápeš? Prokopat... nic. Do Undercity se dostaneš tak, že půjdeš k zadní části Ruins of Lordaeron jižně od Brillu a sjedeš výtahem dolů. O další pomoc požádej některého z Undercity Guardians.")
add("Deathguard Royann","I guess your first exercise is going to be to mine your way down to the Undercity.  Heh, get it?  Mine... nevermind.  To get to the Undercity go to the rear of the Ruins of Lordaeron south of Brill, and take the elevator down.  Ask one of the Undercity Guardians there for further assistance.","Tak první cvičení bude asi prokopat si cestu do Undercity. Heh, chápeš? Prokopat... nic. Do Undercity se dostaneš tak, že půjdeš k zadní části Ruins of Lordaeron jižně od Brillu a sjedeš výtahem dolů. O další pomoc požádej některého z Undercity Guardians.")
add("Deathguard Terrence","I guess your first exercise is going to be to mine your way down to the Undercity.  Heh, get it?  Mine... nevermind.  To get to the Undercity go to the rear of the Ruins of Lordaeron south of Brill, and take the elevator down.  Ask one of the Undercity Guardians there for further assistance.","Tak první cvičení bude asi prokopat si cestu do Undercity. Heh, chápeš? Prokopat... nic. Do Undercity se dostaneš tak, že půjdeš k zadní části Ruins of Lordaeron jižně od Brillu a sjedeš výtahem dolů. O další pomoc požádej některého z Undercity Guardians.")
-- source_id 961
add("Stormwind Guard","I had a bad encounter with some of the Defias around here recently, but Michelle Belle fixed me up pretty well.  Check with her in the Lion's Pride Inn and see if she'll teach you.","Nedávno jsem měl nepříjemné setkání s několika Defias, ale Michelle Belle mě dala docela dobře dohromady. Zajdi za ní do Lion's Pride Inn a zeptej se, jestli tě něco nenaučí.")
-- source_id 962
add("Franclorn Forgewright","I had no choice, or so I thought. I would endure the destruction of Thaurissan and stand by the side of my king and his people.$B$BUnder the control of Ragnaros, King Dagran Thaurissan tore out the heart of this mountain and erected Blackrock Spire. We worked tirelessly to build a dwarven city mightier than any city or fortress that came before... or would come after.","Neměl jsem na výběr, nebo jsem si to alespoň myslel. Vydržím zkázu Thaurissanu a zůstanu po boku svého krále a jeho lidu.$B$BPod vládou Ragnarose vyrval král Dagran Thaurissan srdce této hory a vztyčil Blackrock Spire. Neúnavně jsme pracovali na vybudování trpasličího města mocnějšího než kterékoliv město či pevnost před ním... nebo po něm.")
-- source_id 963
add("Teldrassil Sentinel","I had the pleasure of seeing Kyra Windblade in combat once.  Considering what I witnessed, I am confident she will train you well.  Look for her at the Inn in Dolanaar.","Jednou jsem měl to potěšení vidět Kyru Windblade v boji. Podle toho, čeho jsem byl svědkem, tě určitě vycvičí dobře. Hledej ji v hostinci v Dolanaaru.")
-- source_id 964
add("Caer Darrow Guardsman","I have a lot of pent up anger and hostility. Just give me a reason, guttersnipe.","Mám v sobě hodně nahromaděného vzteku a nepřátelství. Dej mi jen důvod, pobudo.")
add("Caer Darrow Horseman","I have a lot of pent up anger and hostility. Just give me a reason, guttersnipe.","Mám v sobě hodně nahromaděného vzteku a nepřátelství. Dej mi jen důvod, pobudo.")
-- source_id 965
add("Great-father Winter","I have a pretty good idea what ol' Greatfather Winter's gonna be doing when this shift is over.  I got a bottle of Winter Veil cheer right here in my bag, and I intend to get to the bottom of it.","Mám docela jasnou představu, co bude starý Greatfather Winter dělat, až tahle směna skončí. V brašně mám láhev zimního veselí a hodlám ji vypít až do dna.")
add("Greatfather Winter","I have a pretty good idea what ol' Greatfather Winter's gonna be doing when this shift is over.  I got a bottle of Winter Veil cheer right here in my bag, and I intend to get to the bottom of it.","Mám docela jasnou představu, co bude starý Greatfather Winter dělat, až tahle směna skončí. V brašně mám láhev zimního veselí a hodlám ji vypít až do dna.")
-- source_id 966
add("Orcish Orphan","I have a rock in my nose.","Mám kámen v nose.")
-- source_id 967
add("Ralo'shan the Eternal Watcher","I have been slain a hundred times. I always wake here, alive. Some say I am cursed and others...","Byl jsem zabit stokrát. Vždy se probudím tady, živý. Někteří říkají, že jsem prokletý, a jiní...")
-- source_id 968
add("Huntsman Leopold","I have discovered a use for the carapace of the crypt fiend and its various body parts. I am able to fashion an extremely light and very deadly set of armor by combining the fragments with some of the desecrated magical armors lost in Naxxramas.","Objevil jsem využití pro krunýř crypt fienda i různé části jeho těla. Spojením těchto úlomků s některými znesvěcenými magickými zbrojemi ztracenými v Naxxramasu dokážu vytvořit nesmírně lehkou a velmi smrtící sadu zbroje.")
-- source_id 969
add("Guzzling Patron","I have duty in an hour, but until then... bottom's up!","Za hodinu mám službu, ale do té doby... na zdraví!")
-- source_id 970
add("Zap Farflinger","I have just completed a new dimensional imploder that will make me rich beyond my wildest goblin dreams!   All I need to do is get a skilled Goblin Engineer to build a dimensional ripper that connects to it and try it!","Právě jsem dokončil nový dimensional imploder, který ze mě udělá boháče i podle těch nejdivočejších gobliních snů! Stačí už jen najít šikovného Goblin Engineera, který postaví dimensional ripper, propojí ho s tímhle a vyzkouší ho!")
-- source_id 971
add("Sylvanna Forestmoon","I have learned much of potions over the long years, $N, and that knowledge is at your disposal. You have only to ask.","Za ta dlouhá léta jsem se o lektvarech naučil mnoho, $N, a všechny ty znalosti máš k dispozici. Stačí se zeptat.")
-- source_id 972
add("Sayge","I have long known you'd seek me out, $N.$B$BEvery sentient being in this world is driven by the choices they make.  Choices begat further choices, and these in turn make someone who they are.  This is where your fortune is drawn from - who you are, and the choices you make.$B$BAre you ready to discover where your fortune lies?","Dlouho jsem věděl, že mě vyhledáš, $N.$B$BKaždou vnímající bytost na tomto světě ženou vpřed rozhodnutí, která činí. Jedna volba plodí další a ty pak utvářejí, kým člověk je. Odtud se odvíjí tvůj osud - z toho, kým jsi, a z voleb, které činíš.$B$BJsi připraven zjistit, kam tě tvůj osud vede?")
-- source_id 973
add("Ormak Grimshot","I have much knowledge to impress upon you, $c. You must learn to hunt with honor.","Mám mnoho znalostí, které ti musím předat, $c. Musíš se naučit lovit se ctí.")
-- source_id 974
add("Doctor Marsh","I have no more knowledge to bestow upon you. Go through the archway and down the ramp to the southeast, and talk to Doctor Herbert Halsey. He is a Forsaken who can teach you more advanced techniques.","Už ti nemám co dalšího předat. Projdi obloukem a sejdi po rampě na jihovýchod, pak si promluv s doktorem Herbertem Halseym. Je to Forsaken, který tě může naučit pokročilejší techniky.")
-- source_id 975
add("Maximillion","I have no time to waste on the likes of you $c.","Nemám čas ztrácet s někým jako ty, $c.")
add("Richard Kerwin","I have no time to waste on the likes of you $c.","Nemám čas ztrácet s někým jako ty, $c.")
add("Rupert Boch","I have no time to waste on the likes of you $c.","Nemám čas ztrácet s někým jako ty, $c.")
-- source_id 976
add("Kamari","I have nothing more to teach you. Talk to Karolek if you wish to further your leatherworking skills.","Už tě nemám co naučit. Jestli chceš své Leatherworking schopnosti dál zlepšovat, promluv si s Karolekem.")
-- source_id 977
add("Arathandris Silversky","I have observed four different kinds of plants that have been affected by the corruption: the songflower, the windblossom, the whipper root, and the night dragon plant.  The songflower and windblossom are common plants in Felwood, while the whipper root and night dragon are seen less frequently.  All are a vital part of Felwood's ecosystem.","Pozoroval jsem čtyři různé druhy rostlin zasažené nákazou: songflower, windblossom, whipper root a night dragon. Songflower a windblossom jsou ve Felwoodu běžné, zatímco whipper root a night dragon se vyskytují méně často. Všechny jsou důležitou součástí ekosystému Felwoodu.")
add("Maybess Riverbreeze","I have observed four different kinds of plants that have been affected by the corruption: the songflower, the windblossom, the whipper root, and the night dragon plant.  The songflower and windblossom are common plants in Felwood, while the whipper root and night dragon are seen less frequently.  All are a vital part of Felwood's ecosystem.","Pozoroval jsem čtyři různé druhy rostlin zasažené nákazou: songflower, windblossom, whipper root a night dragon. Songflower a windblossom jsou ve Felwoodu běžné, zatímco whipper root a night dragon se vyskytují méně často. Všechny jsou důležitou součástí ekosystému Felwoodu.")
-- source_id 978
add("Timothy Worthington","I have outfitted kings. With the proper training, you can too.","Vybavoval jsem krále. Se správným výcvikem to můžeš dokázat také.")
-- source_id 979
add("Skorn Whitecloud","I have run through these plains for many, many seasons.  And I have hunted great beasts.  And I had never been bested... until I faced Ghost Howl.$B$BLong ago, the massive wolf was an ally to the tauren and fought bravely against the Burning Legion.  But he was wounded savagely by a demon, and the tear in his flesh never healed.  Eventually... it drove Ghost Howl mad.$B$BNow he roams the plains in agony, seeking an end to his pain.  To my shame, when we fought I lacked the strength to slay him...","Běhal jsem těmito pláněmi mnoho a mnoho období. A lovil jsem veliké šelmy. Nikdo mě nikdy nepřemohl... dokud jsem nestanul proti Ghost Howlovi.$B$BDávno byl ten obrovský vlk spojencem taurenů a statečně bojoval proti Burning Legion. Jeden démon ho však strašlivě zranil a rána na jeho těle se nikdy nezhojila. Nakonec... dohnala Ghost Howla k šílenství.$B$BNyní se v bolesti toulá pláněmi a hledá konec svého utrpení. K mé hanbě jsem při našem boji neměl sílu ho zabít...")
-- source_id 980
add("Janice Felstone","I have so much to do... so much before the plague comes...","Mám toho tolik na práci... tolik věcí, než přijde mor...")
-- source_id 981
add("Arei","I have suffered, but now I can feel it slowly fading from me. I feel... free.","Trpěl jsem, ale teď cítím, jak to ze mě pomalu mizí. Cítím se... svobodný.")
-- source_id 982
add("Archmage Angela Dosantos","I have tracked the various fragments of the staff across this world and in doing so, discovered Kel'Thuzad's plans to reform the staff. He has already collected several of the staff's fragments - which are being held by his most trusted lieutenants.$B$BI cannot emphasize enough the importance of keeping the greatstaff of the Guardian out of Kel'Thuzad's grasp. Frankly, I do not know what the result would be, other than a catastrophe of epic proportion.","Vystopoval jsem různé fragmenty hole po celém tomto světě a přitom odhalil Kel'Thuzadovy plány na její znovusložení. Už shromáždil několik fragmentů hole - drží je jeho nejvěrnější poručíci.$B$BNedokážu dost zdůraznit, jak důležité je udržet greatstaff Guardiana mimo Kel'Thuzadův dosah. Upřímně nevím, jaké by byly následky, kromě katastrofy epických rozměrů.")
-- source_id 983
add("Dwukk","I hear one comment about waterfowl, and you will be eating through a tube.","Jestli uslyším jedinou poznámku o vodním ptactvu, budeš jíst hadičkou.")
-- source_id 984
add("Razor Hill Grunt","I hear that the trolls in Sen'jin Village have a potion maker named Miao'zan.  Look there.","Slyšel jsem, že trollové v Sen'jin Village mají výrobce lektvarů jménem Miao'zan. Hledej tam.")
-- source_id 985
add("Deathguard Abraham","I hear that they have a Mining Trainer in the Undercity.  All you have to do to get there is head south out of town and go to the back of the Ruins of Lordaeron.  Then take the elevator down into the Undercity itself and ask an Undercity Guardian for further directions.","Slyšel jsem, že v Undercity mají Mining Trainera. Stačí vyrazit z města na jih k zadní části Ruins of Lordaeron. Pak sjeď výtahem dolů do samotného Undercity a o další cestu se zeptej některého z Undercity Guardians.")
add("Deathguard Bartholomew","I hear that they have a Mining Trainer in the Undercity.  All you have to do to get there is head south out of town and go to the back of the Ruins of Lordaeron.  Then take the elevator down into the Undercity itself and ask an Undercity Guardian for further directions.","Slyšel jsem, že v Undercity mají Mining Trainera. Stačí vyrazit z města na jih k zadní části Ruins of Lordaeron. Pak sjeď výtahem dolů do samotného Undercity a o další cestu se zeptej některého z Undercity Guardians.")
add("Deathguard Burgess","I hear that they have a Mining Trainer in the Undercity.  All you have to do to get there is head south out of town and go to the back of the Ruins of Lordaeron.  Then take the elevator down into the Undercity itself and ask an Undercity Guardian for further directions.","Slyšel jsem, že v Undercity mají Mining Trainera. Stačí vyrazit z města na jih k zadní části Ruins of Lordaeron. Pak sjeď výtahem dolů do samotného Undercity a o další cestu se zeptej některého z Undercity Guardians.")
add("Deathguard Cyrus","I hear that they have a Mining Trainer in the Undercity.  All you have to do to get there is head south out of town and go to the back of the Ruins of Lordaeron.  Then take the elevator down into the Undercity itself and ask an Undercity Guardian for further directions.","Slyšel jsem, že v Undercity mají Mining Trainera. Stačí vyrazit z města na jih k zadní části Ruins of Lordaeron. Pak sjeď výtahem dolů do samotného Undercity a o další cestu se zeptej některého z Undercity Guardians.")
add("Deathguard Dillinger","I hear that they have a Mining Trainer in the Undercity.  All you have to do to get there is head south out of town and go to the back of the Ruins of Lordaeron.  Then take the elevator down into the Undercity itself and ask an Undercity Guardian for further directions.","Slyšel jsem, že v Undercity mají Mining Trainera. Stačí vyrazit z města na jih k zadní části Ruins of Lordaeron. Pak sjeď výtahem dolů do samotného Undercity a o další cestu se zeptej některého z Undercity Guardians.")
add("Deathguard Gavin","I hear that they have a Mining Trainer in the Undercity.  All you have to do to get there is head south out of town and go to the back of the Ruins of Lordaeron.  Then take the elevator down into the Undercity itself and ask an Undercity Guardian for further directions.","Slyšel jsem, že v Undercity mají Mining Trainera. Stačí vyrazit z města na jih k zadní části Ruins of Lordaeron. Pak sjeď výtahem dolů do samotného Undercity a o další cestu se zeptej některého z Undercity Guardians.")
add("Deathguard Lawrence","I hear that they have a Mining Trainer in the Undercity.  All you have to do to get there is head south out of town and go to the back of the Ruins of Lordaeron.  Then take the elevator down into the Undercity itself and ask an Undercity Guardian for further directions.","Slyšel jsem, že v Undercity mají Mining Trainera. Stačí vyrazit z města na jih k zadní části Ruins of Lordaeron. Pak sjeď výtahem dolů do samotného Undercity a o další cestu se zeptej některého z Undercity Guardians.")
add("Deathguard Lundmark","I hear that they have a Mining Trainer in the Undercity.  All you have to do to get there is head south out of town and go to the back of the Ruins of Lordaeron.  Then take the elevator down into the Undercity itself and ask an Undercity Guardian for further directions.","Slyšel jsem, že v Undercity mají Mining Trainera. Stačí vyrazit z města na jih k zadní části Ruins of Lordaeron. Pak sjeď výtahem dolů do samotného Undercity a o další cestu se zeptej některého z Undercity Guardians.")
add("Deathguard Morris","I hear that they have a Mining Trainer in the Undercity.  All you have to do to get there is head south out of town and go to the back of the Ruins of Lordaeron.  Then take the elevator down into the Undercity itself and ask an Undercity Guardian for further directions.","Slyšel jsem, že v Undercity mají Mining Trainera. Stačí vyrazit z města na jih k zadní části Ruins of Lordaeron. Pak sjeď výtahem dolů do samotného Undercity a o další cestu se zeptej některého z Undercity Guardians.")
add("Deathguard Mort","I hear that they have a Mining Trainer in the Undercity.  All you have to do to get there is head south out of town and go to the back of the Ruins of Lordaeron.  Then take the elevator down into the Undercity itself and ask an Undercity Guardian for further directions.","Slyšel jsem, že v Undercity mají Mining Trainera. Stačí vyrazit z města na jih k zadní části Ruins of Lordaeron. Pak sjeď výtahem dolů do samotného Undercity a o další cestu se zeptej některého z Undercity Guardians.")
add("Deathguard Royann","I hear that they have a Mining Trainer in the Undercity.  All you have to do to get there is head south out of town and go to the back of the Ruins of Lordaeron.  Then take the elevator down into the Undercity itself and ask an Undercity Guardian for further directions.","Slyšel jsem, že v Undercity mají Mining Trainera. Stačí vyrazit z města na jih k zadní části Ruins of Lordaeron. Pak sjeď výtahem dolů do samotného Undercity a o další cestu se zeptej některého z Undercity Guardians.")
add("Deathguard Terrence","I hear that they have a Mining Trainer in the Undercity.  All you have to do to get there is head south out of town and go to the back of the Ruins of Lordaeron.  Then take the elevator down into the Undercity itself and ask an Undercity Guardian for further directions.","Slyšel jsem, že v Undercity mají Mining Trainera. Stačí vyrazit z města na jih k zadní části Ruins of Lordaeron. Pak sjeď výtahem dolů do samotného Undercity a o další cestu se zeptej některého z Undercity Guardians.")
-- source_id 986
add("Brave Cloudmane","I hear that they have a Mining Trainer in Thunder Bluff to the north.  Take the road out of the village and when you get there ride the elevator to the top of the rise.  Any of the Bluffwatchers should be able to help you from there.","Slyšel jsem, že v Thunder Bluffu na severu mají Mining Trainera. Vydej se po cestě z vesnice a až dorazíš, vyjeď výtahem na vrchol plošiny. Odtud ti poradí kterýkoliv Bluffwatcher.")
add("Brave Darksky","I hear that they have a Mining Trainer in Thunder Bluff to the north.  Take the road out of the village and when you get there ride the elevator to the top of the rise.  Any of the Bluffwatchers should be able to help you from there.","Slyšel jsem, že v Thunder Bluffu na severu mají Mining Trainera. Vydej se po cestě z vesnice a až dorazíš, vyjeď výtahem na vrchol plošiny. Odtud ti poradí kterýkoliv Bluffwatcher.")
add("Brave Dawneagle","I hear that they have a Mining Trainer in Thunder Bluff to the north.  Take the road out of the village and when you get there ride the elevator to the top of the rise.  Any of the Bluffwatchers should be able to help you from there.","Slyšel jsem, že v Thunder Bluffu na severu mají Mining Trainera. Vydej se po cestě z vesnice a až dorazíš, vyjeď výtahem na vrchol plošiny. Odtud ti poradí kterýkoliv Bluffwatcher.")
add("Brave Ironhorn","I hear that they have a Mining Trainer in Thunder Bluff to the north.  Take the road out of the village and when you get there ride the elevator to the top of the rise.  Any of the Bluffwatchers should be able to help you from there.","Slyšel jsem, že v Thunder Bluffu na severu mají Mining Trainera. Vydej se po cestě z vesnice a až dorazíš, vyjeď výtahem na vrchol plošiny. Odtud ti poradí kterýkoliv Bluffwatcher.")
add("Brave Leaping Deer","I hear that they have a Mining Trainer in Thunder Bluff to the north.  Take the road out of the village and when you get there ride the elevator to the top of the rise.  Any of the Bluffwatchers should be able to help you from there.","Slyšel jsem, že v Thunder Bluffu na severu mají Mining Trainera. Vydej se po cestě z vesnice a až dorazíš, vyjeď výtahem na vrchol plošiny. Odtud ti poradí kterýkoliv Bluffwatcher.")
add("Brave Rainchaser","I hear that they have a Mining Trainer in Thunder Bluff to the north.  Take the road out of the village and when you get there ride the elevator to the top of the rise.  Any of the Bluffwatchers should be able to help you from there.","Slyšel jsem, že v Thunder Bluffu na severu mají Mining Trainera. Vydej se po cestě z vesnice a až dorazíš, vyjeď výtahem na vrchol plošiny. Odtud ti poradí kterýkoliv Bluffwatcher.")
add("Brave Rockhorn","I hear that they have a Mining Trainer in Thunder Bluff to the north.  Take the road out of the village and when you get there ride the elevator to the top of the rise.  Any of the Bluffwatchers should be able to help you from there.","Slyšel jsem, že v Thunder Bluffu na severu mají Mining Trainera. Vydej se po cestě z vesnice a až dorazíš, vyjeď výtahem na vrchol plošiny. Odtud ti poradí kterýkoliv Bluffwatcher.")
add("Brave Strongbash","I hear that they have a Mining Trainer in Thunder Bluff to the north.  Take the road out of the village and when you get there ride the elevator to the top of the rise.  Any of the Bluffwatchers should be able to help you from there.","Slyšel jsem, že v Thunder Bluffu na severu mají Mining Trainera. Vydej se po cestě z vesnice a až dorazíš, vyjeď výtahem na vrchol plošiny. Odtud ti poradí kterýkoliv Bluffwatcher.")
add("Brave Swiftwind","I hear that they have a Mining Trainer in Thunder Bluff to the north.  Take the road out of the village and when you get there ride the elevator to the top of the rise.  Any of the Bluffwatchers should be able to help you from there.","Slyšel jsem, že v Thunder Bluffu na severu mají Mining Trainera. Vydej se po cestě z vesnice a až dorazíš, vyjeď výtahem na vrchol plošiny. Odtud ti poradí kterýkoliv Bluffwatcher.")
add("Brave Wildrunner","I hear that they have a Mining Trainer in Thunder Bluff to the north.  Take the road out of the village and when you get there ride the elevator to the top of the rise.  Any of the Bluffwatchers should be able to help you from there.","Slyšel jsem, že v Thunder Bluffu na severu mají Mining Trainera. Vydej se po cestě z vesnice a až dorazíš, vyjeď výtahem na vrchol plošiny. Odtud ti poradí kterýkoliv Bluffwatcher.")
-- source_id 987
add("Dun Morogh Mountaineer","I hear there's a shop up in Ironforge run by the gnomes that specializes in alchemy.  You should go have a look.","Slyšel jsem, že nahoře v Ironforge mají gnómové obchod specializovaný na alchymii. Měl by ses tam podívat.")
add("Ironforge Mountaineer","I hear there's a shop up in Ironforge run by the gnomes that specializes in alchemy.  You should go have a look.","Slyšel jsem, že nahoře v Ironforge mají gnómové obchod specializovaný na alchymii. Měl by ses tam podívat.")
add("Mounted Ironforge Mountaineer","I hear there's a shop up in Ironforge run by the gnomes that specializes in alchemy.  You should go have a look.","Slyšel jsem, že nahoře v Ironforge mají gnómové obchod specializovaný na alchymii. Měl by ses tam podívat.")
-- source_id 988
add("Grim Patron","I heard that a noble among the water elementals, Hydraxis, wages war with the servants of fire.  Let's hope he loses!","Slyšel jsem, že jeden z urozených vodních elementálů, Hydraxis, vede válku se služebníky ohně. Doufejme, že prohraje!")
-- source_id 989
add("Jemma Quikswitch","I heard the new Henweigh 6000 will be rolling off the assembly line soon. I can barely contain my excitement!","Slyšel jsem, že z výrobní linky brzy sjede nový Henweigh 6000. Sotva dokážu skrýt své nadšení!")
-- source_id 990
add("Wing Commander Slidore","I heard their mocking laughter as my gryphon crashed and burned, $c.$B$B\"Slidore, you stink!\" They shouted.$B$BNobody talks to Slidore that way! Help me get out of here so that I can show them who the real stinker is!","Slyšel jsem jejich posměšný smích, když se můj gryfon zřítil a shořel, $c.$B$B\"Slidore, smrdíš!\" křičeli.$B$BNikdo nebude takhle mluvit se Slidorem! Pomoz mi odsud, abych jim ukázal, kdo je tady skutečný smraďoch!")
-- source_id 991
add("Goblin Pit Crewman","I heard they were going to try to blow up the gnome's car in the next race!  True or not, I'd stand clear of their pit area.","Slyšel jsem, že se v příštím závodě pokusí vyhodit do vzduchu auto gnómů! Ať je to pravda nebo ne, držel bych se dál od jejich boxů.")
-- source_id 992
add("Guard Mol'dar","I heard you was dead... well, you won't be easy to make dead after this!","Slyšel jsem, že jsi mrtvý... no, po tomhle už tě nebude tak snadné zabít!")
-- source_id 993
add("Selina Dourman","I highly recommend that you visit Sayge to get your fortune told. I know, I know... he's a gnoll.  But he's a very special gnoll with the power to divine your future!$B$BAnd we are constantly expanding the faire with all manner of new attractions!","Vřele doporučuji navštívit Saygea a nechat si vyložit osud. Já vím, já vím... je to gnoll. Ale je to velmi zvláštní gnoll, který dokáže předpovědět tvou budoucnost!$B$BA veletrh neustále rozšiřujeme o všechny možné nové atrakce!")
-- source_id 994
add("Pusillin","I hold the key to lands of free! Chase me and you'll see!","Držím klíč k zemím svobody! Chyť mě a uvidíš!")
-- source_id 995
add("Thelman Slatefist","I hope that you are here to go to Alterac Valley $N.  We can use all o' the help that we can get.","Doufám, že jsi tu kvůli Alterac Valley, $N. Každá pomoc se nám hodí.")
-- source_id 996
add("Keras Wolfheart","I hope that you're here to help us take back Arathi Basin from The Defilers.  What do you say $N?","Doufám, že jsi tady, abys nám pomohl získat Arathi Basin zpět od The Defilers. Co říkáš, $N?")
-- source_id 997
add("Tannysa","I hope that your interruption is for a good cause, I was in the middle of some important work.","Doufám, že mě rušíš z dobrého důvodu. Byl jsem uprostřed důležité práce.")
-- source_id 998
add("Braenna Flintcrag","I hope the Light is with you, $N. Is there anything I can do for you today?","Doufám, že je Light s tebou, $N. Mohu pro tebe dnes něco udělat?")
add("Branstock Khalder","I hope the Light is with you, $N. Is there anything I can do for you today?","Doufám, že je Light s tebou, $N. Mohu pro tebe dnes něco udělat?")
add("High Priest Rohan","I hope the Light is with you, $N. Is there anything I can do for you today?","Doufám, že je Light s tebou, $N. Mohu pro tebe dnes něco udělat?")
add("Maxan Anvol","I hope the Light is with you, $N. Is there anything I can do for you today?","Doufám, že je Light s tebou, $N. Mohu pro tebe dnes něco udělat?")
add("Theodrus Frostbeard","I hope the Light is with you, $N. Is there anything I can do for you today?","Doufám, že je Light s tebou, $N. Mohu pro tebe dnes něco udělat?")
add("Toldren Deepiron","I hope the Light is with you, $N. Is there anything I can do for you today?","Doufám, že je Light s tebou, $N. Mohu pro tebe dnes něco udělat?")
-- source_id 999
add("Basil Frye","I hope to one day forge weapons and armor from the bones of my enemies.","Doufám, že jednoho dne budu kovat zbraně a zbroje z kostí svých nepřátel.")
-- source_id 1000
add("Bengus Deepforge","I hope ye didn't come all the way to the Great Forge just to stay warm. Speak up $g lad : lass;, tell me what it is I can do for ye?","Doufám, že jsi nepřišel až ke Great Forge jen proto, aby ses ohřál. Mluv, $g chlapče : děvče;, co pro tebe mohu udělat?")
-- source_id 1001
add("Gnome Pit Crewman","I installed a new device in our car's matrix regulometer.  That should increase its velocity quotient by a factor of no less than fifteen!","Do regulometru matice našeho auta jsem nainstaloval nové zařízení. To by mělo zvýšit jeho rychlostní koeficient nejméně patnáctkrát!")
-- source_id 1002
add("Warlord Gorchuk","I just received word on that. We currently have $2021w out of $2020w peacebloom, $2050w of $2051w firebloom, and $2054w out of $2055w purple lotus herbs requested.","Právě jsem o tom dostal zprávu. V současnosti máme $2021w z $2020w peacebloom, $2050w z $2051w firebloom a $2054w z požadovaných $2055w purple lotus.")
-- source_id 1003
add("Daryl Riknussun","I keep 'em fed, kid. Yep, Daryl Riknussun, at yer service.","Já je krmím, mladej. Jo, Daryl Riknussun, k službám.")
-- source_id 1004
add("Daera Brightspear","I kinnae help ye with trainin'. Ye should look fer a $c trainer.","S výcvikem ti nepomůžu. Měl by sis najít trenéra pro $c.")
add("Dargh Trueaim","I kinnae help ye with trainin'. Ye should look fer a $c trainer.","S výcvikem ti nepomůžu. Měl by sis najít trenéra pro $c.")
add("Einris Brightspear","I kinnae help ye with trainin'. Ye should look fer a $c trainer.","S výcvikem ti nepomůžu. Měl by sis najít trenéra pro $c.")
add("Grif Wildheart","I kinnae help ye with trainin'. Ye should look fer a $c trainer.","S výcvikem ti nepomůžu. Měl by sis najít trenéra pro $c.")
add("Olmin Burningbeard","I kinnae help ye with trainin'. Ye should look fer a $c trainer.","S výcvikem ti nepomůžu. Měl by sis najít trenéra pro $c.")
add("Regnus Thundergranite","I kinnae help ye with trainin'. Ye should look fer a $c trainer.","S výcvikem ti nepomůžu. Měl by sis najít trenéra pro $c.")
add("Thorfin Stoneshield","I kinnae help ye with trainin'. Ye should look fer a $c trainer.","S výcvikem ti nepomůžu. Měl by sis najít trenéra pro $c.")
add("Thorgas Grimson","I kinnae help ye with trainin'. Ye should look fer a $c trainer.","S výcvikem ti nepomůžu. Měl by sis najít trenéra pro $c.")
add("Ulfir Ironbeard","I kinnae help ye with trainin'. Ye should look fer a $c trainer.","S výcvikem ti nepomůžu. Měl by sis najít trenéra pro $c.")
-- source_id 1005
add("Snang","I know a few things, but I'm no expert. Lucky for you, Magar is. He's standing near the back of the shop. See if he can help you, but be careful not to rile him. He can be irritable.","Pár věcí znám, ale žádný odborník nejsem. Naštěstí pro tebe Magar ano. Stojí vzadu v obchodě. Zkus se zeptat jeho, ale dej pozor, ať ho nerozčílíš. Umí být podrážděný.")
-- source_id 1006
add("Mukdrak","I know a few things. You want me to show you?","Pár věcí znám. Chceš, abych ti je ukázal?")
-- source_id 1007
add("Xylinnia Starshine","I know many things, stranger, but your knowledge rivals my own. Enchanters who wish to hone their skills further are known to travel to the Tower of Azora, where an artisan named Kitta Firewind resides.","Vím mnoho věcí, cizinče, ale tvé znalosti se vyrovnají mým. Enchanters, kteří chtějí své schopnosti dál zdokonalovat, cestují do Tower of Azora, kde žije řemeslnice jménem Kitta Firewind.")
-- source_id 1008
add("Highlord Demitrian","I know much, listen and be educated, $r.","Vím toho hodně, poslouchej a uč se, $r.")
-- source_id 1009
add("Stormwind Guard","I know of a few people around here that practice a profession or two.  What profession do you have in mind?","Znám tu pár lidí, kteří provozují jedno či dvě povolání. Jaké povolání máš na mysli?")
-- source_id 1010
add("Raene Wolfrunner","I know these forests as if they were a part of me... But know that there is still much to be learned from them, and much danger still hidden.","Znám tyto lesy, jako by byly mou součástí... Ale věz, že se od nich stále máme mnoho co učit a stále v nich číhá mnoho nebezpečí.")
-- source_id 1011
add("Itharius","I know who you are, $N.  Fate and forces beyond that have brought you to me for a reason, and it is one I take no pleasure in being a part of.  There are many decisions you will make in the coming times, and I hope you are wise enough to make the correct ones.$B$BBelieve me, $r, when I tell you this - there are correct choices.","Vím, kdo jsi, $N. Osud a síly, které ho přesahují, tě ke mně přivedly z určitého důvodu, a není mi příjemné být jeho součástí. V nadcházejících časech učiníš mnoho rozhodnutí a doufám, že budeš dost moudrý na ta správná.$B$BVěř mi, $r, když ti říkám toto - správné volby existují.")
-- source_id 1012
add("Marvon Rivetseeker","I know, I know, I'm out here in the middle of nowhere!$B$BMy home is actually in Ratchet, but after crashing my zeppelin here, I thought I might as well start the research I came here to do!","Já vím, já vím, jsem tady úplně uprostřed ničeho!$B$BMůj domov je vlastně v Ratchetu, ale když jsem tu havaroval se svým zeppelinem, řekl jsem si, že rovnou začnu výzkum, kvůli kterému jsem sem přišel!")
-- source_id 1013
add("Elder Graveborn","I last saw Elder Meadowrun at the Weeping Cave in the Western Plaguelands.","Naposledy jsem viděl Elder Meadowrun ve Weeping Cave v Western Plaguelands.")
add("Elder Moonstrike","I last saw Elder Meadowrun at the Weeping Cave in the Western Plaguelands.","Naposledy jsem viděl Elder Meadowrun ve Weeping Cave v Western Plaguelands.")
add("Elder Snowcrown","I last saw Elder Meadowrun at the Weeping Cave in the Western Plaguelands.","Naposledy jsem viděl Elder Meadowrun ve Weeping Cave v Western Plaguelands.")
add("Elder Windrun","I last saw Elder Meadowrun at the Weeping Cave in the Western Plaguelands.","Naposledy jsem viděl Elder Meadowrun ve Weeping Cave v Western Plaguelands.")
-- source_id 1014
add("Eitrigg","I left. I would not remain with the Blackrock. No, the deaths of my children would not be in vain. I would not serve under an inept, power hungry maniac such as Rend.$B$BI took shelter in the woods of Lordaeron, living as a hermit near Hearthglen.","Odešel jsem. U Blackrocků bych nezůstal. Ne, smrt mých dětí nesměla být zbytečná. Nebudu sloužit neschopnému, mocichtivému šílenci, jako je Rend.$B$BUchýlil jsem se do lesů Lordaeronu a žil jako poustevník nedaleko Hearthglenu.")
-- source_id 1015
add("Mukdrak","I like to build stuff. Of course, I like to blow stuff up even more!","Rád stavím věci. Samozřejmě, ještě radši je vyhazuji do vzduchu!")
-- source_id 1016
add("Thrag Stonehoof","I listen and I listen but I don't hear these spirits that Karn speaks of.","Poslouchám a poslouchám, ale duchy, o kterých Karn mluví, neslyším.")
-- source_id 1017
add("Major Mattingly","I live only to serve our King.","Žiji jen proto, abych sloužil našemu králi.")
-- source_id 1018
add("Squire Maltrake","I live only to serve the master.","Žiji jen proto, abych sloužil pánovi.")
-- source_id 1019
add("Burth","I lived in Dire Maul for a little bit.  That was fun.  Really.","Chvíli jsem žil v Dire Maul. Byla to zábava. Opravdu.")
-- source_id 1020
add("Drakk Stonehand","I love a good challenge; don't you? Aye, of course ye do. An' that's why you're about to do exactly what I say.","Miluji dobrou výzvu; ty ne? Jistěže ano. A právě proto teď uděláš přesně to, co ti řeknu.")
-- source_id 1021
add("Thunder Bluff Reveler","I love the Lunar Festival!  It's a great place to let your hooves kick up dust!","Miluji Lunar Festival! Je to skvělé místo, kde můžeš nechat kopyta pořádně zvířit prach!")
-- source_id 1022
add("Grarnik Goodstitch","I made a lot of the things you see in the store. What do you think? Answer carefully, your life may depend on it.","Spoustu věcí, které v obchodě vidíš, jsem vyrobil já. Co na ně říkáš? Odpovídej opatrně, může na tom záviset tvůj život.")
add("Magar","I made a lot of the things you see in the store. What do you think? Answer carefully, your life may depend on it.","Spoustu věcí, které v obchodě vidíš, jsem vyrobil já. Co na ně říkáš? Odpovídej opatrně, může na tom záviset tvůj život.")
-- source_id 1023
add("Myriam Moonsinger","I mean you no harm. I am scouting the quilboar and taking notes of their activities. My people have noticed something odd--an emanation or darkness--coming from this area. I've come to investigate, and what I've found is very disturbing.$B$BThere seems to be an undead diplomat who is powerful in the ways of the arcane. I don't believe he's one of the Forsaken... I think it's worse.","Nechci ti ublížit. Provádím průzkum quilboarů a zaznamenávám jejich činnost. Můj lid si všiml něčeho podivného--jakéhosi vyzařování či temnoty--pocházející z této oblasti. Přišel jsem to prozkoumat a to, co jsem našel, je velmi znepokojivé.$B$BZdá se, že tu působí nemrtvý diplomat mocný v arcane magii. Nemyslím, že patří k Forsaken... obávám se, že je to něco horšího.")
-- source_id 1024
add("Tirion Fordring","I must apologize for not being entirely truthful with you in regards to my identity. I had to be certain that you could be trusted - few people would have selflessly lent assistance to an old and forgotten hermit.$B$BYou have proven yourself as one of those people: A person of integrity and honor.","Musím se omluvit, že jsem k tobě ohledně své identity nebyl úplně upřímný. Potřeboval jsem si být jistý, že ti lze věřit - málokdo by nezištně pomohl starému a zapomenutému poustevníkovi.$B$BDokázal jsi, že mezi takové lidi patříš: člověk se zásadami a ctí.")
-- source_id 1025
add("Kray","I must have broken hundreds of vials when I first began brewing potions. The glass was so fragile in my clumsy hands. I hope you are more cautious than I was.","Když jsem začínal vařit lektvary, rozbil jsem snad stovky lahviček. Sklo bylo v mých neohrabaných rukou tak křehké. Doufám, že budeš opatrnější než já.")
-- source_id 1026
add("Junior Apothecary Holland","I must have lived a charmed life, $N. To return to the world as a member of the Forsaken and the Apothecary Society... I couldn't have asked for a more suitable fate.","Musel jsem žít požehnaný život, $N. Vrátit se do světa jako člen Forsaken a Apothecary Society... vhodnější osud jsem si nemohl přát.")
-- source_id 1027
add("Grizzlowe","I must say, Booty Bay has the best Clam Chowder to be had anywhere in the South Seas. Oh, not interested in cuisine eh? Well then let me be the first to welcome you to the berth of the Maiden's Fancy, the finest passenger ship to travel between the Eastern Kingdoms and Kalimdor. She's due back for another trip to Ratchet soon, so make yourself comfortable till she arrives.","Musím říct, že Booty Bay má nejlepší Clam Chowder v celých South Seas. Ach, kuchyně tě nezajímá? Nuže, dovol mi tě jako první přivítat u kotviště Maiden's Fancy, nejlepší osobní lodi plující mezi Eastern Kingdoms a Kalimdorem. Brzy se vrátí na další cestu do Ratchetu, tak se do té doby pohodlně usaď.")
-- source_id 1028
add("Burth","I need a second head like I need to lose my first one.","Druhou hlavu potřebuji asi stejně jako přijít o tu první.")
-- source_id 1029
add("Centaur Pariah","I need no home to know I still have a place in this world, $c. The tribes will see... all of them. They fight amongst one another, and for what? Scraps left over by vultures... lands infested by the Legion... bah!$B$BThe centaur should be proud of their heritage--it is just as noble as any Night elf's or orc's--it is time we started acting like it!","Nepotřebuji domov, abych věděl, že na tomto světě stále mám své místo, $c. Kmeny uvidí... všechny. Bojují mezi sebou, a kvůli čemu? Kvůli zbytkům, které po sobě nechali supi... kvůli zemím zamořeným Legion... pche!$B$BCentauři by měli být hrdí na své dědictví--je stejně vznešené jako dědictví kteréhokoliv Night elfa či orka--je načase, abychom se tak začali chovat!")
-- source_id 1030
add("Morridune","I once followed the ways of the Twilight's Hammer. Obsessed with reviving the Old Gods, I journeyed deep into this lair to try to draw power from the cursed beast, Aku'mai!$b$bAfter witnessing the sacrifice of countless innocents, I came to my senses.$b$bI was trapped but now I am free! But so far from my homeland of Khaz Modan!$b$bBrave adventurer, I offer you passage to a very special land in return for slaying Aku'mai. If you wish, I can port you to the city of Darnassus.","Kdysi jsem následoval cestu Twilight's Hammer. Posedlý oživením Old Gods jsem se vydal hluboko do tohoto doupěte, abych se pokusil čerpat moc z prokleté bestie Aku'mai!$b$bKdyž jsem viděl obětování bezpočtu nevinných, konečně jsem přišel k rozumu.$b$bByl jsem uvězněn, ale teď jsem volný! Jenže jsem tak daleko od své domoviny Khaz Modan!$b$bStatečný dobrodruhu, nabízím ti cestu do velmi zvláštní země výměnou za zabití Aku'mai. Pokud chceš, mohu tě portovat do města Darnassus.")
-- source_id 1031
add("Ironforge Guard","I once heard ol' Grimnur say he fished up a sword.  Or was it a swordfish?  Damn that Grimnur, he's told so many fish tales I can't remember which is which.  Well, why don't you go see him over in The Forlorn Cavern and have him tell you what it was.","Jednou jsem slyšel starého Grimnura říkat, že vytáhl na udici meč. Nebo to byl mečoun? Zatracený Grimnur, navykládal tolik rybářských historek, že už nevím, co bylo co. Tak za ním zajdi do The Forlorn Cavern a nech si od něj povědět, co to vlastně bylo.")
-- source_id 1032
add("Ogunaro Wolfrunner","I only make my mounts available to those who are considered exalted to Orgrimmar and the Orcish race.  Go prove yourself to us, and I'll make my mighty wolves available for your inspection.","Své mounty nabízím pouze těm, kteří jsou u Orgrimmaru a orkské rasy považováni za exalted. Dokaž nám svou oddanost a zpřístupním ti své mocné vlky.")
-- source_id 1033
add("Aayndia Floralwind","I only teach students who have already mastered the basics. You must seek out the night elf Darianna in the Craftsmen's Terrace of Darnassus. Her skills will be a perfect complement to yours.","Učím jen studenty, kteří už zvládli základy. Musíš vyhledat night elfku Dariannu v Craftsmen's Terrace v Darnassusu. Její schopnosti dokonale doplní ty tvé.")
-- source_id 1034
add("Hahrana Ironhide","I only wish I had more students like you. Not many will venture so far into enemy territory. I salute your courage.","Kéž bych měl víc studentů jako ty. Málokdo se odváží tak hluboko na nepřátelské území. Vzdávám hold tvé odvaze.")
-- source_id 1035
add("Ironforge Guard","I overheard Regnus Thundergranite in the Hall of Arms bragging about a new trophy for his den the other day.  If yer looking for training from a skilled hunter, Regnus is the one to see.","Nedávno jsem zaslechl Regnuse Thundergranitea v Hall of Arms chlubit se novou trofejí do svého doupěte. Jestli hledáš výcvik od zkušeného lovce, Regnus je ten pravý.")
-- source_id 1036
add("Vaelastrasz the Corrupt","I perform one final service. I pray it is sufficient...","Vykonám poslední službu. Modlím se, aby to stačilo...")
-- source_id 1037
add("Field Marshal Snowfall","I received an update on that just a moment ago. It looks like out of $2061w light leather needed, we have $2060w. As for the others, the report indicated that we've gathered $2063w of $2064w medium leather, and $2069w out of our $2071w thick leather quota.","Před chvílí jsem dostal aktuální zprávu. Zdá se, že z potřebných $2061w light leather máme $2060w. Co se týče ostatních, podle hlášení jsme shromáždili $2063w z $2064w medium leather a $2069w z naší kvóty $2071w thick leather.")
-- source_id 1038
add("Darnassus Sentinel","I received the majority of my weapons training from Ilyenia Moonfire in the Warrior's Terrace.  You would do well to seek her out if you desire to learn the use of a new weapon.","Většinu výcviku se zbraněmi jsem získal od Ilyenie Moonfire ve Warrior's Terrace. Pokud se chceš naučit používat novou zbraň, dobře uděláš, když ji vyhledáš.")
-- source_id 1039
add("Malyfous Darkhammer","I reckon that the odds of obtaining such a piece would be a one in a million! A once in a lifetime skin! Even the most disciplined artisans of the craft would no doubt fail several hundred times in the process of skinning the beast before a pristine sample was recovered.","Řekl bych, že šance získat takový kus je jedna ku milionu! Kůže, kterou člověk získá jednou za život! I ti nejukázněnější mistři řemesla by při stahování té bestie bezpochyby několikasetkrát selhali, než by získali dokonalý exemplář.")
-- source_id 1040
add("Telonis","I regret to say that I cannot aid you, $gnoble sir:gentle lady;, until you learn more of working with leather. Speak with Faldron or Darianna here instead. They can teach you the skill you require.","S lítostí musím říct, že ti nemohu pomoci, $gurozený pane:ctěná paní;, dokud se v práci s kůží nenaučíš víc. Promluv si místo toho s Faldronem nebo Dariannou tady. Naučí tě dovednosti, kterou potřebuješ.")
-- source_id 1041
add("Haggrum Bloodfist","I remember when my brother and I would camp alone in the Azshara wilderness. Look at it now.","Pamatuji si, jak jsme s bratrem tábořili sami v divočině Azshary. Podívej se na ni teď.")
-- source_id 1042
add("Great Bear Spirit","I represent the strength which bolsters you as a young druid.  You have come to me to learn this strength, young one, and I will teach this to you.  I will teach you all that is the spirit bear, provided you will listen and understand.$B$BIn order to know what it means to draw upon my spirit, you need to understand the importance of the strength of the body, as well as the strength of the heart.","Představuji sílu, která tě podpírá jako mladého druida. Přišel jsi ke mně, abys tuto sílu poznal, mladý, a já tě jí naučím. Naučím tě všemu, čím je duch medvěda, pokud budeš naslouchat a chápat.$B$BAby sis uvědomil, co znamená čerpat z mého ducha, musíš pochopit význam síly těla stejně jako síly srdce.")
-- source_id 1043
add("Therum Deepforge","I said ye had the blood of a blacksmith in ye, and I was right. Go to Ironforge, to The Great Forge, and find yerself a Dwarven smith by the name of Bengus Deepforge. My teacher, and one of the greatest smiths I've ever known.","Říkal jsem, že v tobě koluje krev kováře, a měl jsem pravdu. Jdi do Ironforge, do The Great Forge, a najdi trpasličího kováře jménem Bengus Deepforge. Byl mým učitelem a patří k nejlepším kovářům, jaké jsem kdy znal.")
-- source_id 1044
add("Wharfmaster Lozgil","I see some interesting characters come and go here at the port. Watch yourself, $N. It's never clear who to trust, what with all of the shady activity that goes on here...","Tady v přístavu vídám přicházet a odcházet zajímavé postavy. Dávej na sebe pozor, $N. Při všem tom pochybném dění tady člověk nikdy neví, komu může věřit...")
-- source_id 1045
add("Saru Steelfury","I see you know more of the secret of steel than I do. That is good, for it is meant to be taken. Now you must travel to the jungle south of the human lands, to the goblin city of Booty Bay. There you will find a Goblin named Brikk Keencraft. I do not like Goblins but his knowledge of the secret of steel is unmatched by any I know of.","Vidím, že tajemství oceli znáš lépe než já. To je dobře, protože má být předáváno dál. Teď musíš odcestovat do džungle jižně od lidských zemí, do gobliního města Booty Bay. Tam najdeš goblina jménem Brikk Keencraft. Gobliny nemám rád, ale jeho znalost tajemství oceli je nepřekonatelná.")
-- source_id 1046
add("Aedis Brom","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Alyssa Griffith","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Bryan Cross","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Christoph Faral","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("David Langston","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Donyal Tovald","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Elly Langston","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Erika Tate","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Gerik Koen","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Heinrich Stone","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Jenn Langston","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Jillian Tanner","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Kendor Kabonka","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Lenny \"Fingers\" McCoy","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Mayda Thane","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Milton Sheaf","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Nikova Raskol","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Officer Areyn","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Ol' Beasley","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Osric Strang","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Seoman Griffith","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
add("Wilhelm Strang","I sell only the best gear, tested and true. And the prices are set, so if you want to haggle then go find a Goblin.","Prodávám jen nejlepší vybavení, prověřené a spolehlivé. A ceny jsou pevné, takže jestli chceš smlouvat, najdi si goblina.")
-- source_id 1047
add("Alexandra Bolero","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Allan Hafgan","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Angus Stern","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Ardwyn Cailen","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Argos Nightwhisper","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Caretaker Folsom","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Charys Yserian","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Collin Mauren","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Connor Rivers","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Darian Singh","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Duncan Cullen","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Erich Lohan","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Evan Larson","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Janey Anship","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Jessara Cordell","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Karlee Chaddis","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Kelly Grant","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Kimberly Grant","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Lisan Pierce","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Maria Lumere","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Morris Lawry","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Owen Vaughn","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Shailiea","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Shellene","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Suzanne","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
add("Wynne Larson","I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.","Prodávám jen to nejlepší arcane vybavení, vyrobené řemeslníky a mágy tady ve Stormwindu.")
-- source_id 1048
add("Durnan Furcutter","I sell the finest cloth and leather garb this side of the valley!","Prodávám nejlepší látkové a kožené oděvy široko daleko!")
-- source_id 1049
add("Marduk Blackpool","I sense a disturbance, lurking around you...","Cítím kolem tebe číhat jakési narušení...")
-- source_id 1050
add("Mai'Lahii","I should find some hired help; I don't like sitting here all day selling fish supplies. I'd much rather go fishing, and then sell supplies.","Měl bych si najmout pomocníka; nebaví mě celý den sedět tady a prodávat rybářské potřeby. Mnohem raději bych šel rybařit a pak prodával zásoby.")
-- source_id 1051
add("Mountaineer Pebblebitty","I shouldn't even be telling you this but if you can make it past all the critters and beasties in Badlands, you might be able to make it to Searing Gorge.$B$BYes, the Badlands. There's some type of back road the orcs paved near Kargath. Just goes to show you what kind of fools we're dealing with here! A backdoor to hell? What were they thinking?","Neměl bych ti to vůbec říkat, ale pokud se přes všechny potvory a bestie v Badlands dostaneš živý, možná zvládneš dojít až do Searing Gorge.$B$BAno, přes Badlands. Nedaleko Kargathu je nějaká zadní cesta, kterou vydláždili orkové. Jen to ukazuje, s jakými hlupáky máme tu čest! Zadní vchod do pekla? Co si mysleli?")
-- source_id 1052
add("Guard Slip'kik","I show you how smart I am, boss!  You be extra smart with mighty magic mojo now!$B$BUm... maybe Slip'kik use magic on self. Dat would be good idea...","Ukážu ti, jak chytrý jsem, šéfe! Ty budeš extra chytrý s mocným magickým mojo!$B$BEhm... možná Slip'kik použít magii na sebe. To být dobrý nápad...")
-- source_id 1053
add("Franclorn Forgewright","I stood by and watched the corruption of Ragnaros seep through the hearts and minds of the Dark Iron nation. This once honorable race, driven to madness... to evil.$B$BWhen the construction of the Spire was complete, my will to live amongst my people gave way. I passed as a hero of the new nation of Dark Iron. This tomb was placed here - at the entrance to the city I planned and built - in honor of my efforts.","Stál jsem stranou a sledoval, jak Ragnarosova zkaženost proniká do srdcí a myslí národa Dark Iron. Tato kdysi čestná rasa byla dohnána k šílenství... ke zlu.$B$BKdyž byla stavba Spire dokončena, má vůle žít mezi svým lidem se vytratila. Zemřel jsem jako hrdina nového národa Dark Iron. Tato hrobka byla postavena zde - u vstupu do města, které jsem naplánoval a vybudoval - na počest mého úsilí.")
-- source_id 1054
add("Earthcaller Franzahl","I study the known and unknown elements of our world.","Studuji známé i neznámé elementy našeho světa.")
-- source_id 1055
add("Khur Hornstriker","I supply the Hold with various relics required for spellcasting as well as other alchemical reagents.","Zásobuji Hold různými relikviemi potřebnými ke spellcastingu i dalšími alchymistickými reagenty.")
-- source_id 1056
add("Archibald","I suppose you are here to be trained in the use of a new weapon?  Make it fast, I'm very busy!","Předpokládám, že jsi tady kvůli výcviku v používání nové zbraně? Tak rychle, mám spoustu práce!")
-- source_id 1057
add("Shen'dralar Zealot","I suspect that the imps are stealing knowledge.","Mám podezření, že impové kradou znalosti.")
-- source_id 1058
add("Pratt McGrubben","I swear... if Quint tries to plant one more fishing grub on me, I'm going to hack down his tree with my not-so-rusty sword.","Přísahám... jestli mi Quint ještě jednou podstrčí rybářskou larvu, pokácím jeho strom svým ne-zas-tak-rezavým mečem.")
-- source_id 1059
add("Healer Longrunner","I thank you for your inquiry, but I already have all of the wool bandages necessary for the war effort. I suggest that you ask around though; there are many here that could probably still use your aid.","Děkuji za nabídku, ale už mám všechny wool bandages potřebné pro válečné úsilí. Doporučuji se ale poptat kolem; je tu mnoho lidí, kteří by tvou pomoc ještě mohli potřebovat.")
-- source_id 1060
add("Mankrik","I thank you, $N. Your dedication to my plea gives rest to my lost wife's spirit, and for that I could never repay you enough.$B$BI cannot say that my hatred will ever cease for the quilboar, but it is satiated for now.$B$BNow I must begin to rebuild my life.","Děkuji ti, $N. Tvé odhodlání vyslyšet mou prosbu dopřává klid duchu mé ztracené ženy a za to se ti nikdy nebudu moci dost odvděčit.$B$BNemohu říct, že by má nenávist ke quilboarům někdy zmizela, ale prozatím je utišena.$B$BTeď musím začít znovu budovat svůj život.")
-- source_id 1061
add("Elder Grimtotem","I think Elder Splitrock has traveled to Mauradon in the Desolace.","Myslím, že Elder Splitrock odcestoval do Mauradonu v Desolace.")
add("Elder Mistwalker","I think Elder Splitrock has traveled to Mauradon in the Desolace.","Myslím, že Elder Splitrock odcestoval do Mauradonu v Desolace.")
-- source_id 1062
add("Hilary","I think my necklace fell in the lake.  My daddy got it for me, and he's gonna be mad now.","Myslím, že mi náhrdelník spadl do jezera. Dostal jsem ho od tatínka a teď se bude zlobit.")
-- source_id 1063
add("Rayne","I think not. Rimblat has already proven that new life can grow from the sundered earth. Now we must find a way to reproduce and, more importantly, sustain the growth.$B$BWhile I am here, I am also offering my services to adventurers entering Naxxramas.","To si nemyslím. Rimblat už dokázal, že na rozervané zemi může vyrůst nový život. Teď musíme najít způsob, jak tento růst zopakovat a hlavně udržet.$B$BKdyž už jsem tady, nabízím také své služby dobrodruhům vstupujícím do Naxxramasu.")
-- source_id 1064
add("Hammered Patron","I think Plugger filled one of his kegs too much.  It looks like it's about to blow!","Myslím, že Plugger naplnil jeden ze svých sudů až moc. Vypadá, že každou chvíli vybuchne!")
add("Ribbly's Crony","I think Plugger filled one of his kegs too much.  It looks like it's about to blow!","Myslím, že Plugger naplnil jeden ze svých sudů až moc. Vypadá, že každou chvíli vybuchne!")
-- source_id 1065
add("Stormwind Guard","I think you'll have better luck looking in Stormwind.  Ask a guard up there and they'll point you in the right direction.","Myslím, že větší štěstí budeš mít ve Stormwindu. Zeptej se tam nějakého strážného a ukáže ti správný směr.")
-- source_id 1066
add("Thotar","I train and guide young hunters in the traditions passed down many generations.","Cvičím a vedu mladé lovce podle tradic předávaných po mnoho generací.")
-- source_id 1067
add("Alenndaar Lapidaar","I train hunters in the ways and traditions of our ancestors.","Cvičím lovce v cestách a tradicích našich předků.")
add("Danlaar Nightstride","I train hunters in the ways and traditions of our ancestors.","Cvičím lovce v cestách a tradicích našich předků.")
add("Kary Thunderhorn","I train hunters in the ways and traditions of our ancestors.","Cvičím lovce v cestách a tradicích našich předků.")
-- source_id 1068
add("Brother Benjamin","I trust the Light is with you, $N. Is there something that I can I help you with?","Věřím, že Light je s tebou, $N. Mohu ti s něčím pomoci?")
add("Brother Joshua","I trust the Light is with you, $N. Is there something that I can I help you with?","Věřím, že Light je s tebou, $N. Mohu ti s něčím pomoci?")
add("High Priestess Laurena","I trust the Light is with you, $N. Is there something that I can I help you with?","Věřím, že Light je s tebou, $N. Mohu ti s něčím pomoci?")
add("Priestess Anetta","I trust the Light is with you, $N. Is there something that I can I help you with?","Věřím, že Light je s tebou, $N. Mohu ti s něčím pomoci?")
add("Priestess Josetta","I trust the Light is with you, $N. Is there something that I can I help you with?","Věřím, že Light je s tebou, $N. Mohu ti s něčím pomoci?")
-- source_id 1069
add("Quartermaster Lewis","I try to keep Sentinel Hill stocked, and that's not easy with all the action we see.","Snažím se udržovat Sentinel Hill dobře zásobený a při všem tom ruchu, který tu zažíváme, to není snadné.")
-- source_id 1070
add("Stormwind Guard","I usually leave that sort of thing to the gnomes.  If you want to take up the profession, I'm sure you could find some gnomes hanging out in Stormwind that would train you.","Takové věci obvykle nechávám na gnómech. Jestli se chceš tomuto povolání věnovat, určitě ve Stormwindu najdeš nějaké gnómy, kteří tě vycvičí.")
-- source_id 1071
add("Wing Commander Ichman","I was shot down by that reckless fool, Mulverick. I fear that if I do not make it back to base, all will be lost! Mulverick and his squad of War Riders must be stopped!","Sestřelil mě ten bezohledný hlupák Mulverick. Obávám se, že pokud se nevrátím na základnu, všechno bude ztraceno! Mulverick a jeho jednotka War Riders musí být zastaveni!")
-- source_id 1072
add("Lady Jaina Proudmoore","I welcome you to Theramore, $N.$B$BI apologize for being abrupt and not having a lot of time to exchange pleasantries, but my city must come first. Too many things threaten our way of life and the sanctity of the Alliance. I must stay ever vigilant against forces outside of our control if I'm to ensure my people remain safe and happy.$B$BPerhaps we'll have more time to speak later.","Vítám tě v Theramore, $N.$B$BOmlouvám se za svou strohost a za to, že nemám moc času na zdvořilosti, ale moje město musí být na prvním místě. Příliš mnoho věcí ohrožuje náš způsob života a nedotknutelnost Alliance. Musím zůstat stále ostražitý vůči silám mimo naši kontrolu, pokud chci zajistit, aby můj lid zůstal v bezpečí a spokojený.$B$BSnad budeme mít později více času si promluvit.")
-- source_id 1073
add("Greta Mosshoof","I welcome you, $N. And the Emerald Circle welcomes you.$B$BHopefully together we can help rejuventate and protect this once-mighty forest. Many forces seek to destroy it from without... and within.$B$BDo not be persuaded by the power here--it will only corrupt you, like it has this entire land.","Vítám tě, $N. A Emerald Circle tě také vítá.$B$BSnad společně dokážeme pomoci obnovit a chránit tento kdysi mocný les. Mnoho sil se ho snaží zničit zvenčí... i zevnitř.$B$BNenech se zlákat zdejší mocí--jen tě zkazí, stejně jako zkazila celou tuto zemi.")
-- source_id 1074
add("Josef Gregorian","I will instruct you when the time is right... that time is not now. You have much more to learn first!","Budu tě učit, až nastane správný čas... a ten čas není teď. Nejprve se toho musíš naučit mnohem víc!")
-- source_id 1075
add("Neeru Fireblade","I will make it known to you. You are obviously already proving yourself in our ranks to become a lieutenant so quickly. Perhaps you can return to me later and I will have tasks for you. The council adores those skilled in the arcane, but servants of all kinds are always welcome, no matter their profession.","Dám ti to vědět. Zjevně už ve svých řadách prokazuješ svou hodnotu, když ses tak rychle stal lieutenantem. Možná se ke mně později vrať a budu pro tebe mít úkoly. Rada zbožňuje ty, kteří ovládají arcane, ale služebníci všeho druhu jsou vždy vítáni bez ohledu na povolání.")
-- source_id 1076
add("Draz'Zilb","I will never call Brackenwall Village my home. To do so is to give up hope of reclaiming our rightful lands.","Brackenwall Village nikdy nenazvu svým domovem. Znamenalo by to vzdát se naděje na znovuzískání zemí, které nám právem patří.")
-- source_id 1077
add("Remorseful Highborne","I will not forrrget what you have done...$B$BPleassse, leave meee...","Nezapomenu, co jsi udělal...$B$BProsssím, nech měee...")
-- source_id 1078
add("Snang","I will teach you what I can.","Naučím tě, co budu moci.")
-- source_id 1079
add("Lalina Summermoon","I will teach you what I can. Each lesson is a gift from the Goddess herself. Use her gifts wisely, and you shall not falter.","Naučím tě, co budu moci. Každá lekce je darem samotné Goddess. Používej její dary moudře a nezakolísáš.")
-- source_id 1080
add("Fallen Hero of the Horde","I wish it were true, $N, but it will take more than you alone to overcome the forces of Razelikh and his subordinates.$B$BGather a suitable group of adventurers and would-be heroes and free my men of their eternal torture! Eighteen stones you must shatter.$B$BFight hard and die with honor, $N.","Kéž by to byla pravda, $N, ale k překonání sil Razelikha a jeho podřízených bude potřeba víc než jen ty.$B$BShromáždi vhodnou skupinu dobrodruhů a rádoby hrdinů a osvoboď mé muže od jejich věčného utrpení! Musíš rozbít osmnáct kamenů.$B$BBojuj tvrdě a zemři se ctí, $N.")
-- source_id 1081
add("Tog Rustsprocket","I wish the snow would just all melt away. It's always getting my robe wet and messing up everything!","Kéž by všechen ten sníh už roztál. Pořád mi promáčí róbu a všechno kazí!")
-- source_id 1082
add("Winter Reveler","I wish you a happy holiday, friend!","Přeji ti šťastné svátky, příteli!")
-- source_id 1083
add("Deek Fizzlebizz","I would be delighted to aid you in the commencement of your pursuit! Let me grab my spinner and we'll get started...","Velmi rád ti pomohu na začátku tvého snažení! Jen vezmu svůj spinner a můžeme začít...")
-- source_id 1084
add("Grondal Moonbreeze","I would be happy to take you under my wing. Let us begin.","Rád tě vezmu pod svá křídla. Začněme.")
-- source_id 1085
add("Ansekhwa","I would be honored to train you in the use of the weapons that I have mastered should you have the ability to learn within you.","Bude mi ctí vycvičit tě v používání zbraní, které jsem sám ovládl, pokud máš schopnosti potřebné k jejich naučení.")
-- source_id 1086
add("Buzzek Bracketswing","I would never turn away someone who's ready to train with me. Unfortunately, you're not! You've still got a ways to go kid!","Nikdy bych neodmítl někoho, kdo je připraven se mnou trénovat. Bohužel ty připraven nejsi! Ještě máš před sebou kus cesty, mladej!")
-- source_id 1087
add("Innkeeper Allison","I would suggest looking in the Cathedral of Light in Cathedral Square.","Doporučil bych hledat v Cathedral of Light na Cathedral Square.")
add("Innkeeper Heather","I would suggest looking in the Cathedral of Light in Cathedral Square.","Doporučil bych hledat v Cathedral of Light na Cathedral Square.")
add("Innkeeper Janene","I would suggest looking in the Cathedral of Light in Cathedral Square.","Doporučil bych hledat v Cathedral of Light na Cathedral Square.")
add("Stormwind City Guard","I would suggest looking in the Cathedral of Light in Cathedral Square.","Doporučil bych hledat v Cathedral of Light na Cathedral Square.")
add("Stormwind City Patroller","I would suggest looking in the Cathedral of Light in Cathedral Square.","Doporučil bych hledat v Cathedral of Light na Cathedral Square.")
add("Vikki Lonsav","I would suggest looking in the Cathedral of Light in Cathedral Square.","Doporučil bych hledat v Cathedral of Light na Cathedral Square.")
-- source_id 1088
add("Lorax","I would teach him how to demon forge in exchange for his soul. The soul of a Blackrock orc is worth very little but in these trying times, a soul, any soul, is better than none at all.","Výměnou za jeho duši bych ho naučil démonické kování. Duše Blackrock orka má jen malou cenu, ale v těchto těžkých časech je jakákoli duše lepší než žádná.")
-- source_id 1089
add("Bronk Guzzlegear","I would train ye if I could, but ye need the services of someone a bit more... what's the word? Brainy! Look for Trixie Quickswitch in Ironforge. Tell 'er Bronk sent ye!","Vycvičil bych tě, kdybych mohl, ale potřebuješ služby někoho trochu víc... jak se to říká? Chytrého! Hledej Trixie Quickswitch v Ironforge. Řekni jí, že tě posílá Bronk!")
-- source_id 1090
add("Acolyte Dellis","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Adair Gilroy","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Advisor Belgrum","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Aedis Brom","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Agustus Moulaine","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Aldric Moore","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Algernon","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Allan Hafgan","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Andrew Brownell","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Andrew Hartwell","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Andron Gant","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Andrus","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Angus Stern","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Apothecary Lycanus","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Argos Nightwhisper","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Aristan Mottar","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Asoran","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Aturk the Anvil","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Auld Stonespire","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Barim Jurgenstaad","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Barkeep Morag","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Baros Alexston","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Belgrom Rockmaul","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Ben Trias","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Benijah Fenner","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Bethor Iceshard","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Billibub Cogspinner","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Bingus","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Bishop DeLavey","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Bishop Farthing","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Bluffwatcher","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Bombus Finespindle","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Borstan","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Borya","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Bounty Hunter Kolark","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Boyle","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Brohann Caskbelly","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Brombar Higgleby","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Bromiir Ormsen","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Brother Cassius","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Brother Crowley","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Brother Kristoff","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Brother Sarno","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Bruuk Barleybeard","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Bryan Cross","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Burbik Gearspanner","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Caretaker Folsom","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Caynrus","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Cazul","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Cedric Stumpel","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Chardryn","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Charles Seaton","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Chemist Cuely","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Chemist Fuely","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Chief Archaeologist Greywhisker","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Christoph Faral","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Collin Mauren","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Connor Rivers","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Crildor","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Curator Thorius","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Cyridan","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Cyroen","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Daniel Bartlett","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Darian Singh","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("David Langston","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Davitt Hickson","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Delgo Ragetotem","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Demnul Farmountain","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Dolkin Craghelm","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Dolman Steelfury","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Donyal Tovald","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Doyo'da","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Dran Droffers","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Duncan Cullen","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Durtham Greldon","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Duthorian Rall","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Edrick Killian","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Elki","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Elling Trias","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Emrul Riknussun","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Erich Lohan","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Etu Ragetotem","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Evan Larson","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Evert Sorisam","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Eyahn Eagletalon","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Ezekiel Graves","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Fenstad Argyle","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Fillius Fizzlespinner","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Francis Eliot","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Frederick Stover","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Furen Longbeard","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Fyldan","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Galthuk","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Ganoosh","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Gazin Tenorm","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Gearcutter Cogspinner","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Geoffrey Hartwell","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Gerik Koen","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Gerrig Bonegrip","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Glorandiir","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Gnoarn","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Godrick Farsan","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Golnir Bouldertoe","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Goma","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Gothard Winslow","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Gotri","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Grand Mason Marblesten","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Gregory Ardus","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Grenil Steelfury","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Grod","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Gunther Weller","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Hagrus","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Handor","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Hank the Hammer","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Harick Boulderdrum","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Harlan Bagley","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Hegnar Swiftaxe","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Heinrich Stone","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Hewa","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("High Explorer Magellas","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Hjoldir Stoneblade","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Hogor Thunderhoof","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Horthus","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Hunter Ragetotem","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Hunter Sagewind","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Hunter Thunderhorn","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Innkeeper Allison","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Innkeeper Heather","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Innkeeper Janene","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Ironforge Guard","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Jareth Wildwoods","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Jeremiah Payson","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Jin'sora","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("John Turner","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Jonathan Chambers","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Jorah Annison","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Jorgen","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Joseph Moore","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Kard Ragetotem","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Kareth","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Kathrum Axehand","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Keeper Bel'dugur","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Keldran","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Keldric Boucher","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Kelomir Ironhand","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Kendor Kabonka","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Kieran","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Klockmort Spannerspan","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Kor'geld","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Kor'ghan","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Kor'jus","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Koru","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Kozish","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Krathok Moltenfist","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Krom Stoutarm","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Kurm Stonehoof","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Kuruk","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Lago Blackwrench","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Lenny \"Fingers\" McCoy","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Lomac Gearstrip","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Louis Warren","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Lucian Fenner","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Lyon Mountainheart","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Magenius","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Mahu","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Malton Droffers","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Mangorn Flinthammer","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Master Apothecary Faranell","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Master Mechanic Castpipe","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Mathiel","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Mayda Thane","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Mazen Mac'Nadir","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Mennet Carkad","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Milton Sheaf","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Morgan Pestle","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Morgg Stormshot","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Morgum","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Morris Lawry","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Muiredon Battleforge","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Muragus","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Muren Stormpike","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Mythidan","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Mythrin'dir","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Naal Mistrunner","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Nathaniel Steenwick","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Nicholas Atwood","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Officer Brady","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Officer Jaxon","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Officer Pomeroy","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Ohanko","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Ol' Beasley","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Ollanus","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Orgrimmar Grunt","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Orm Stonehoof","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Orokk Omosh","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Osric Strang","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Outfitter Eric","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Owen Vaughn","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Ox","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Patrick Garrett","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Pilot Longbeard","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Pithwick","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Prospector Stormpike","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Raleigh Andrean","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Reginald Grimsford","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Rekkul","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Rellian Greenspyre","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Richard Van Brunt","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Riley Walker","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Rilli Greasygob","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Robert Gossom","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Roberto Pupellyverbos","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Roetten Stonehammer","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Ronald Burch","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Saenorion","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Sage Truthseeker","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Salazar Bloch","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Samuel Van Brunt","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Sarin Starlight","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Sarlek","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Sarok","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Scout Stronghand","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Scout Tharr","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Searn Firewarder","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Seeker Cromwell","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Seeker Nahr","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Seoman Griffith","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Sheldon Von Croy","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Shoma","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Silas Zimmer","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Skolmin Goldfury","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Sognar Cliffbeard","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Sraaz","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Stormwind City Guard","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Stormwind City Patroller","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Tah Winterhoof","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Talaelar","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Talvash del Kissel","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Tamar","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Tamaro","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Tand","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Taur Stonehoof","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Thaddeus Webb","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Thalgus Thunderfist","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Therzok","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Thief Catcher Farmountain","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Thief Catcher Shadowdelve","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Thief Catcher Thunderbrew","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Thomas Miller","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Thomas Mordan","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Thurgrum Deepforge","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Thurman Mullby","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Timothy Weldon","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Topper McNabb","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Tor'phan","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Tormek Stoneriver","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Trak'gen","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Turian","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Tymor","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Tynnus Venomsprout","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Ukra'nor","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Ulthir","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Vaean","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Veren Tallstrider","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Victor Bartholomew","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Vikki Lonsav","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Voloren","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Walter Ellingson","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Wilder Thistlenettle","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Wilhelm Strang","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Xan'tish","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Xanis Flameweaver","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Xen'to","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Xiggs Fuselighter","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Yldan","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Zane Bradford","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Zangen Stonehoof","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Zazo","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Zendo'jian","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
add("Zor Lonetree","I'd like you better if you would apply some perfume.","Měl bych tě raději, kdybys použil trochu parfému.")
-- source_id 1091
add("Jemma Quikswitch","I'd love to teach you! Show my sister she's not the only one who knows a thing or two about engineering...","Moc rád tě budu učit! Ukaž mé sestře, že není jediná, kdo něco ví o Engineeringu...")
-- source_id 1092
add("Abigail Sawyer","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Adrian Bartlett","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Alaindia","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Alexandra Bolero","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Alyssa Griffith","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Anadyia","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Apothecary Katrina","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Apothecary Vallia","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Ardwyn Cailen","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Ariyell Skyshadow","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Bimble Longberry","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Binny Springblade","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Bluffwatcher","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Brenwyn Wintersteel","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Bretta Goldfury","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Brooke Stonebraid","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Bryllia Ironbrand","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Carla Granger","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Catherine Leland","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Charys Yserian","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Chepi","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Chloe Curthas","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Clarice Foster","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Colara Dean","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Cylania","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Darnassus Sentinel","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Dendrythis","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Dinita Stonemantle","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Ealyshia Dewwhisper","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Edna Mullby","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Edris Barleybeard","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Elaine Trias","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Elanaria","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Eleanor Rusk","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Elenia Haydon","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Elizabeth Van Talen","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Ellandrieth","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Elly Langston","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Elynna","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Erika Tate","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Faelyssa","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Fela","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Felicia Doan","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Felika","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Fyr Mistrunner","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Fyrenna","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Genavie Callow","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Gillian Moore","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Ginny Longberry","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Gorina","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Gracina Spiritmight","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Grunt Mojka","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Gwenna Firebrew","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Gwina Stonebranch","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Hannah Akeley","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Helena Atwood","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Hepzibah Sedgewick","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Huntress Leafrunner","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Huntress Ravenoak","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Huntress Skymane","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Ingrys Stonebrow","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Innkeeper Allison","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Innkeeper Heather","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Innkeeper Janene","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Jaeana","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Janey Anship","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Jenn Langston","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Jessara Cordell","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Jillian Tanner","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Julia Gallina","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Jyn Stonehoof","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Kaga Mistrunner","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Kaita Deepforge","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Kaja","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Karlee Chaddis","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Katis","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Katrina Alliestar","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Kelly Grant","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Kimberly Grant","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Kiro","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Kithas","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Kuna Thunderhorn","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Kyra Boucher","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Kyrai","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Landria","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Lara Moore","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Lauren Newcomb","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Librarian Mae Paledust","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Lina Stover","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Lisan Pierce","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Lisbeth Schneider","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Lissyphus Finespindle","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Lizbeth Cromwell","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Lotherias","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Lucille Castleton","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Lyesa Steelbrow","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Maeva Snowbraid","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Mani Winterhoof","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Marda Weller","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Maria Lumere","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Marla Fowler","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Mattie Alred","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Melea","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Merelyssa","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Millie Gregorian","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Mirelle Tremayne","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Myra Tyrngaarde","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Nan Mistrunner","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Nara Wildmane","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Nata Dawnstrider","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Nida Winterhoof","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Nightmare","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Nikova Raskol","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Officer Areyn","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Olvia","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Oran Snakewrithe","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Orgrimmar Grunt","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Pakwa","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Pawe Mistrunner","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Poranna Snowbraid","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Priestess A'moora","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Prynne","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Raena Flinthammer","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Rema Schneider","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Sana","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Sara Balloo","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Sarah Killian","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Scout Manslayer","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Seeker Thompson","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Selina Pickman","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Sergeant Ba'sha","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Sewa Mistrunner","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Shadi Mistrunner","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Shailiea","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Shan'ti","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Shankys","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Sharlindra","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Shellene","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Sheza Wildmane","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Shim'la","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Shimra","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Shoni the Shilent","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Shylenai","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Sister Aquinne","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Soolie Berryfizz","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Stephanie Turner","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Stormwind City Guard","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Stormwind City Patroller","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Sumi","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Sunn Ragetotem","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Sura Wildmane","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Susan Tillinghast","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Suzanne","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Suzetta Gallina","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Sydney Upton","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Tagain","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Tansy Puddlefizz","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Tawny Grisette","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Theresa Moulaine","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Thulman Flintcrag","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Thyn'tel Bladeweaver","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Tilli Thistlefuzz","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Tiza Battleforge","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Treshala Fallowbrook","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Velora Nitely","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Vikki Lonsav","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Vinasia","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Winifred Kerwin","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Wynne Larson","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
add("Zeal'aya","I'd talk to you if you smelled better. Cologne would be nice.","Promluvil bych si s tebou, kdybys lépe voněl. Kolínská by nebyla špatná.")
-- source_id 1093
add("Undercity Guardian","I'd talk to you if you smelled better. How about cologne? Maybe perfume?","Promluvil bych si s tebou, kdybys lépe voněl. Co třeba kolínská? Nebo parfém?")
-- source_id 1094
add("Brawn","I'd train you if I could, but you're too much for me. Tell you what: go talk to the tauren Una in the northwestern shops of Thunder Bluff's central plateau. She's got some real talent.","Vycvičil bych tě, kdybych mohl, ale už na mě moc umíš. Udělej tohle: promluv si s taurenskou Unou v severozápadních obchodech na centrální plošině Thunder Bluffu. Ta má skutečný talent.")
-- source_id 1095
add("Stormwind Guard","I'd wager Keryn Sylvius knows the type you're looking for. The company Keryn keeps is less than honorable. She usually hangs out in the Lion's Pride Inn.","Vsadil bych se, že Keryn Sylvius zná typ lidí, které hledáš. Společnost, ve které se Keryn pohybuje, není zrovna čestná. Obvykle se zdržuje v Lion's Pride Inn.")
-- source_id 1096
add("Ysida Harmon","I'll be fine for now, don't worry about me.  I'll find a way out of here once I've performed some cleansing rituals in this room.  Foul magic taints this place, $N.","Zatím budu v pořádku, neboj se o mě. Najdu si cestu ven, až v této místnosti dokončím několik očistných rituálů. Toto místo je poskvrněno odpornou magií, $N.")
-- source_id 1097
add("Umi Rumplesnicker","I'll get the last laugh... they'll see! Oh, hi $c, I didn't see you there.","Já se budu smát poslední... oni uvidí! Ach, ahoj $c, nevšiml jsem si tě.")
-- source_id 1098
add("Hammered Patron","I'll take a pint of Dark Iron ale.  Oh, you're not the $gwaiter:waitress;?","Dám si pintu Dark Iron ale. Ach, ty nejsi $gčíšník:servírka;?")
add("Ribbly's Crony","I'll take a pint of Dark Iron ale.  Oh, you're not the $gwaiter:waitress;?","Dám si pintu Dark Iron ale. Ach, ty nejsi $gčíšník:servírka;?")
-- source_id 1099
add("Frankal Stonebridge","I'll tell you 'then what.' She went runnin' straight for the hive. And you know what's crazier? Not a single damned bug got in her way or tried to stop her. She ran through them all as if she'd been best friends with 'em for centuries.","Řeknu ti, co bylo dál. Běžela rovnou k úlu. A víš, co je ještě šílenější? Ani jediný zatracený brouk se jí nepostavil do cesty ani se ji nepokusil zastavit. Proběhla mezi nimi, jako by s nimi byla po staletí nejlepší kamarádka.")
-- source_id 1100
add("Mountaineer Pebblebitty","I'll tell you what. Since you fancy yourself the hero type, if you can make your way through the Badlands to the Searing Gorge and bring me back something to prove your heroics, I'll see what I can do about getting you a key.$B$BIn the southeasternmost corner of Searing Gorge is a lady almost as tough as me, Margol the Rager. Maybe you should investigate.","Řeknu ti co. Když si o sobě myslíš, že jsi hrdina, probojuj se přes Badlands do Searing Gorge a přines mi něco, co tvé hrdinství dokáže. Pak uvidím, co se dá dělat s tím klíčem.$B$BV nejjihovýchodnějším koutě Searing Gorge je dáma skoro stejně drsná jako já, Margol the Rager. Možná by ses po ní měl podívat.")
-- source_id 1101
add("Eldrin","I'm a simple man who knows a few things about tailoring, but you need more assistance than I can provide. I have heard of a Night Elf who is quite an accomplished tailor. He resides in Stormwind, in the Magic District.","Jsem prostý člověk, který něco málo ví o Tailoringu, ale ty potřebuješ větší pomoc, než ti mohu nabídnout. Slyšel jsem o jednom Night Elfovi, který je velmi schopný krejčí. Žije ve Stormwindu, v Magic District.")
-- source_id 1102
add("Betty Quin","I'm afraid I have nothing to teach to someone with your experience. But you haven't reached the end of the road yet. Speak to Lucan Cordell, behind the counter there. He'll guide you through the next phase of your journey.","Obávám se, že někoho s tvými zkušenostmi už nemám co učit. Ale konec cesty to ještě není. Promluv si s Lucanem Cordellem za tamtím pultem. Provede tě další etapou.")
-- source_id 1103
add("High Inquisitor Fairbanks","I'm afraid that the blade which you hold in your hands is beyond saving. The hatred runs too deep. But do not lose hope, $c. Where one chapter has ended, a new one begins.$B$BFind his son - a more devout and pious man you may never meet. It is rumored that he is able to build the Ashbringer anew, without requiring the old, tainted blade.","Obávám se, že čepel, kterou držíš v rukou, už zachránit nelze. Nenávist v ní zakořenila příliš hluboko. Ale neztrácej naději, $c. Kde jedna kapitola skončila, začíná nová.$B$BNajdi jeho syna - zbožnějšího a oddanějšího muže možná nikdy nepotkáš. Říká se, že dokáže Ashbringer vytvořit znovu, aniž by potřeboval starou, poskvrněnou čepel.")
-- source_id 1104
add("Stormpike Emissary","I'm afraid ye would not survive long in Alterac Valley, $c.  Come back and see us when you have a few more seasons under your belt.","Obávám se, že v Alterac Valley bys dlouho nepřežil, $c. Vrať se, až budeš mít za sebou ještě pár sezón.")
-- source_id 1105
add("Tinkerwiz","I'm afraid you're out of my league, friend! You should go see Nogg in Orgrimmar, he'll take you to the next level!","Obávám se, že už jsi nad mé síly, příteli! Měl bys zajít za Noggem do Orgrimmaru, ten tě posune dál!")
add("Twizwick Sprocketgrind","I'm afraid you're out of my league, friend! You should go see Nogg in Orgrimmar, he'll take you to the next level!","Obávám se, že už jsi nad mé síly, příteli! Měl bys zajít za Noggem do Orgrimmaru, ten tě posune dál!")
-- source_id 1106
add("Alamar Grimm","I'm afraid your darkness quotient isn't sufficient enough for me to bother talking to you any further.  Move along please.","Obávám se, že tvůj podíl temnoty není dostatečný, abych se s tebou dál obtěžoval. Prosím, pokračuj dál.")
add("Briarthorn","I'm afraid your darkness quotient isn't sufficient enough for me to bother talking to you any further.  Move along please.","Obávám se, že tvůj podíl temnoty není dostatečný, abych se s tebou dál obtěžoval. Prosím, pokračuj dál.")
add("Grol'dar","I'm afraid your darkness quotient isn't sufficient enough for me to bother talking to you any further.  Move along please.","Obávám se, že tvůj podíl temnoty není dostatečný, abych se s tebou dál obtěžoval. Prosím, pokračuj dál.")
add("Mirket","I'm afraid your darkness quotient isn't sufficient enough for me to bother talking to you any further.  Move along please.","Obávám se, že tvůj podíl temnoty není dostatečný, abych se s tebou dál obtěžoval. Prosím, pokračuj dál.")
add("Thistleheart","I'm afraid your darkness quotient isn't sufficient enough for me to bother talking to you any further.  Move along please.","Obávám se, že tvůj podíl temnoty není dostatečný, abych se s tebou dál obtěžoval. Prosím, pokračuj dál.")
-- source_id 1107
add("Rohan the Assassin","I'm as sane as the next guy, $g fella:lady;. Believe what you will, but I AM capable of fashioning this armor. If you're interested, maybe we can make a deal. The sooner I can get out of the assassination business, the better.","Jsem stejně příčetný jako kdokoli jiný, $g chlape:dámo;. Věř si čemu chceš, ale JÁ tuhle zbroj opravdu dokážu vyrobit. Jestli máš zájem, možná se můžeme dohodnout. Čím dřív budu moct skončit s řemeslem nájemného vraha, tím lépe.")
-- source_id 1108
add("Yelmak","I'm busy, $N. Tell Whuut to handle whatever it is. That young pup has been stewing all day long. He spends much more time like that, and he's going to hurt something.","Mám práci, $N. Řekni Whuutovi, ať se postará o cokoli, co potřebuješ. Ten mladý zelenáč je celý den jako na trní. Jestli v tom bude pokračovat, ještě něčemu ublíží.")
-- source_id 1109
add("Eitrigg","I'm certain you will. Perhaps one day you could deliver a message to an old friend of mine. I hear he still wanders those woods.$B$B<Eitrigg bows his head for a moment, as if in prayer.>$B$BSo Rend, yes... Rend and his brother Maim ruled the Spire, in constant conflict with the Dark Iron dwarves. They managed to displace the dwarves in the upper portion of the city, but only after the dragons came and only after the death of Maim.","Jsem si jistý, že ano. Možná bys jednoho dne mohl doručit zprávu mému starému příteli. Slyšel jsem, že se stále toulá těmi lesy.$B$B<Eitrigg na okamžik skloní hlavu, jako by se modlil.>$B$BTakže Rend, ano... Rend a jeho bratr Maim vládli Spire a neustále bojovali s Dark Iron dwarves. Podařilo se jim vytlačit trpaslíky z horní části města, ale až poté, co přišli draci, a až po Maimově smrti.")
-- source_id 1110
add("Dispatch Commander Metz","I'm far too busy to be playing 'guess the smell' with you, $r. State your business or get out of my sight!","Mám příliš mnoho práce na to, abych si s tebou hrál na 'hádej vůni', $r. Řekni, co chceš, nebo mi zmiz z očí!")
-- source_id 1111
add("Darnassus Sentinel","I'm flattered, but really I'm not interested... What?  You want to know where to learn enchanting?  Oh, how embarrassing!  Well, you should...  I'm sure you could... go see, um...  Taladan!  Yes, see Taladan over in the Craftsmen's Terrace!","Lichotí mi to, ale opravdu nemám zájem... Cože? Chceš vědět, kde se učí Enchanting? Ach, jak trapné! No, měl bys... určitě bys mohl... zajít za, ehm... Taladanem! Ano, za Taladanem v Craftsmen's Terrace!")
-- source_id 1112
add("Ranshalla","I'm getting ready to travel up the ridge, $N. I could use some help -- would you like to come with me?","Chystám se vyrazit nahoru po hřebeni, $N. Hodila by se mi pomoc -- chceš jít se mnou?")
-- source_id 1113
add("Gorkas","I'm going to stay here until I catch a 68 Pound Grouper!  You on the other hand want to fly off somewhere, am I right?","Zůstanu tady, dokud nechytím 68 Pound Grouper! Ty ale chceš naopak někam odletět, mám pravdu?")
-- source_id 1114
add("Yelmak","I'm honored to meet you, $N, but your skill at potions is greater than my own. Go see Doctor Herbert Halsey, an undead in the Apothecarium of the Undercity. He can help you from now on.","Je mi ctí tě poznat, $N, ale tvé umění s lektvary je větší než moje. Vyhledej doktora Herberta Halseye, nemrtvého v Apothecariu v Undercity. Odteď ti může pomoci on.")
-- source_id 1115
add("Victor Ward","I'm just a student myself, really. Rhiannon's the expert. She's standing by the crates over there. You can learn a lot from her.","Sám jsem vlastně jen student. Rhiannon je odbornice. Stojí tamhle u beden. Můžeš se od ní hodně naučit.")
-- source_id 1116
add("Finbus Geargrind","I'm never too busy to speak to a stranger! Almost never, anyway...","Na rozhovor s cizincem nejsem skoro nikdy příliš zaneprázdněný! Skoro nikdy...")
-- source_id 1117
add("Doctor Marsh","I'm not amused by your audacity in coming to me for training. Go through the archway and down the ramp to the southeast, and talk to Doctor Martin Felben. He is a Forsaken who can teach you the basics.","Tvá drzost, že za mnou přicházíš pro výcvik, mě vůbec nebaví. Projdi obloukem a sejdi po rampě na jihovýchod, pak si promluv s doktorem Martinem Felbenem. Je to Forsaken, který tě může naučit základy.")
-- source_id 1118
add("Drakk Stonehand","I'm not here to teach babes fresh out of the cradle. Ye've nowhere near the amount of skill I require in my students. In fact, ye're a sad figure of a $glad:lass;, an' I'll thank ye not to stand there jibber-jabberin' at me.","Nejsem tady od toho, abych učil děcka čerstvě vytažená z kolébky. Nemáš ani zdaleka dost dovedností na to, abych tě přijal mezi své studenty. Vlastně jsi dost žalostný $gchlapec:dívka;, a budu ti vděčný, když tu přede mnou přestaneš tlachat.")
-- source_id 1119
add("Finkle Einhorn","I'm not out of the belly of this beast for more than two minutes and someone is already asking me about my bathroom behavior??? $G Mister:Missy;, I'd have smacked you silly for that question had you not been the one to rescue me!$B$BAnyhow! I'm grateful for the assistance. Maybe I can pay you back?","Nejsem venku z břicha té bestie ani dvě minuty a už se mě někdo ptá na moje záchodové návyky??? $G Pane:Slečno;, za takovou otázku bych ti jednu vrazil, kdybys nebyl tím, kdo mě zachránil!$B$BKaždopádně! Jsem za pomoc vděčný. Třeba ti to můžu nějak oplatit?")
-- source_id 1120
add("Arthur Moore","I'm pleased to say that your talents have outpaced my own. Go away now. Err, try the tauren Una in the northwestern shops of Thunder Bluff's central plateau. She's very skilled, I assure you.","S potěšením říkám, že tvé schopnosti už překonaly mé. Teď běž pryč. Ehm, zkus taurenskou Unu v severozápadních obchodech na centrální plošině Thunder Bluffu. Je velmi schopná, to ti zaručuji.")
-- source_id 1121
add("Skuerto","I'm sick of sittin' in this hole. I hope whatever sorry pencil-pusher is holdin' up Danath's return gets a punch in the jimmies.","Už mě nebaví sedět v téhle díře. Doufám, že ten ubohý kancelářský krysa, co zdržuje Danathův návrat, dostane pořádně do koulí.")
-- source_id 1122
add("Bengus Deepforge","I'm sorry $g lad : lass; but ye just don't have the foundation to learn what I have to teach. But don't fret, go speak with my student Rotgath, he'll help ye out.","Promiň, $g chlapče : děvče;, ale nemáš potřebné základy k tomu, abys pochopil, co tě mohu naučit. Ale netrap se, promluv si s mým studentem Rotgathem, ten ti pomůže.")
-- source_id 1123
add("Zjolnir","I'm sorry $g mon : sis;, but I won't be sellin' my raptors to someone who hasn't proven themselves to be exalted to the Darkspear tribe.  When ya make a stand and show yourself to be no less than exalted to us, then I'll make my raptors available to ya.","Promiň, $g brachu : sestro;, ale své raptory neprodám nikomu, kdo u Darkspear tribe neprokázal, že je exalted. Až se postavíš za nás a ukážeš, že pro nás nejsi nic míň než exalted, zpřístupním ti své raptory.")
-- source_id 1124
add("Alchemist Narett","I'm sorry, $N, but I have no time to spend on novices. You want someone closer to your own skill level. Try the night elf Milla Fairancora, in the Craftsmen's Terrace of Darnassus.","Promiň, $N, ale nemám čas věnovat se nováčkům. Potřebuješ někoho bližšího své úrovni schopností. Zkus night elfku Millu Fairancoru v Craftsmen's Terrace v Darnassusu.")
add("Kylanna","I'm sorry, $N, but I have no time to spend on novices. You want someone closer to your own skill level. Try the night elf Milla Fairancora, in the Craftsmen's Terrace of Darnassus.","Promiň, $N, ale nemám čas věnovat se nováčkům. Potřebuješ někoho bližšího své úrovni schopností. Zkus night elfku Millu Fairancoru v Craftsmen's Terrace v Darnassusu.")
-- source_id 1125
add("Smith Argus","I'm sorry, I'm a bit busy right now making horseshoes for Verner Osgood in Lakeshire.","Promiň, teď mám trochu moc práce s výrobou podkov pro Vernera Osgooda v Lakeshire.")
-- source_id 1126
add("Smokey LaRue","I'm what you call a capitalist, $r.","Jsem něco, čemu říkáte kapitalista, $r.")
-- source_id 1127
add("Rimblat Earthshatter","I've been expec...$B$B<Rimblat coughs.>$B$BExcuse me, old habit. I am Rimblat of the Earthen Ring.","Čekal jsem tě...$B$B<Rimblat zakašle.>$B$BOmlouvám se, starý zvyk. Jsem Rimblat z Earthen Ring.")
-- source_id 1128
add("Lady Hoteshem","I've been expecting you $N.  Are you ready to assist us in Arathi Basin?","Čekal jsem tě, $N. Jsi připraven nám pomoci v Arathi Basin?")
-- source_id 1129
add("Human Orphan","I've been to Ironforge before.  It smells funny there.","V Ironforge už jsem byl. Divně to tam smrdí.")
-- source_id 1130
add("Buzzek Bracketswing","I've been working on a way to transport oil underground between major cities, but everyone tells me it's a pipe dream.","Pracuji na způsobu, jak mezi velkými městy přepravovat ropu pod zemí, ale všichni mi říkají, že je to jen sen o potrubí.")
-- source_id 1131
add("Otho Moji'ko","I've got all the cooking supplies you'll ever need, mon!","Mám všechny kuchařské zásoby, které kdy budeš potřebovat, mon!")
-- source_id 1132
add("Caer Darrow Guardsman","I've got my eye on you, $r.","Mám tě na očích, $r.")
add("Caer Darrow Horseman","I've got my eye on you, $r.","Mám tě na očích, $r.")
-- source_id 1133
add("Jaxin Chong","I've got plenty of great recipes for you to take a look at, and at discounted prices, too!","Mám spoustu skvělých receptů, na které se můžeš podívat, a ještě k tomu za zvýhodněné ceny!")
-- source_id 1134
add("Argent Medic","I've got too much to do and not enough time to do it in, $r! Please, get out of my way.","Mám příliš mnoho práce a příliš málo času, $r! Prosím, uhni mi z cesty.")
-- source_id 1135
add("Argent Medic","I've got too much to do and not enough time to do it in, $r! Please, get out of my way.$B$BIf you're infected with the maggot slime or ghoul rot, I might be able to help you.","Mám příliš mnoho práce a příliš málo času, $r! Prosím, uhni mi z cesty.$B$BJestli jsi nakažený maggot slime nebo ghoul rot, možná ti budu umět pomoct.")
-- source_id 1136
add("Byancie","I've heard it said that Deneb Walker, holed up in Stromgarde, has a book that is sure to help improve your First Aid techniques.","Slyšel jsem, že Deneb Walker, který se ukrývá ve Stromgarde, má knihu, která ti určitě pomůže zlepšit techniky First Aid.")
add("Dannelor","I've heard it said that Deneb Walker, holed up in Stromgarde, has a book that is sure to help improve your First Aid techniques.","Slyšel jsem, že Deneb Walker, který se ukrývá ve Stromgarde, má knihu, která ti určitě pomůže zlepšit techniky First Aid.")
add("Fremal Doohickey","I've heard it said that Deneb Walker, holed up in Stromgarde, has a book that is sure to help improve your First Aid techniques.","Slyšel jsem, že Deneb Walker, který se ukrývá ve Stromgarde, má knihu, která ti určitě pomůže zlepšit techniky First Aid.")
add("Michelle Belle","I've heard it said that Deneb Walker, holed up in Stromgarde, has a book that is sure to help improve your First Aid techniques.","Slyšel jsem, že Deneb Walker, který se ukrývá ve Stromgarde, má knihu, která ti určitě pomůže zlepšit techniky First Aid.")
add("Nissa Firestone","I've heard it said that Deneb Walker, holed up in Stromgarde, has a book that is sure to help improve your First Aid techniques.","Slyšel jsem, že Deneb Walker, který se ukrývá ve Stromgarde, má knihu, která ti určitě pomůže zlepšit techniky First Aid.")
add("Shaina Fuller","I've heard it said that Deneb Walker, holed up in Stromgarde, has a book that is sure to help improve your First Aid techniques.","Slyšel jsem, že Deneb Walker, který se ukrývá ve Stromgarde, má knihu, která ti určitě pomůže zlepšit techniky First Aid.")
add("Thamner Pol","I've heard it said that Deneb Walker, holed up in Stromgarde, has a book that is sure to help improve your First Aid techniques.","Slyšel jsem, že Deneb Walker, který se ukrývá ve Stromgarde, má knihu, která ti určitě pomůže zlepšit techniky First Aid.")
-- source_id 1137
add("Miner Cromwell","I've heard that the last of the preparations are being shipped over to Silithus and should arrive in under a day. I don't want to see one of those bugs burrowing through into my mine, so I hope that someone is taking the time to assemble that Scepter of the Shifting Sands so the gong can be rung, the gates opened and the war finally begun.","Slyšel jsem, že poslední přípravy se převážejí do Silithusu a měly by dorazit za méně než den. Nechci vidět, jak se některý z těch brouků prohrabe do mého dolu, takže doufám, že někdo dává dohromady Scepter of the Shifting Sands, aby mohl zaznít gong, otevřít se brány a konečně začít válka.")
-- source_id 1138
add("Miner Cromwell","I've heard that the preparations are being shipped over to Silithus and should all arrive in under $2113w days. I don't want to see one of those bugs burrowing through into my mine, so I hope that someone is taking the time to assemble that Scepter of the Shifting Sands so the gong can be rung, the gates opened and the war finally begun.","Slyšel jsem, že přípravy se převážejí do Silithusu a všechny by měly dorazit za méně než $2113w dní. Nechci vidět, jak se některý z těch brouků prohrabe do mého dolu, takže doufám, že někdo dává dohromady Scepter of the Shifting Sands, aby mohl zaznít gong, otevřít se brány a konečně začít válka.")
-- source_id 1139
add("Stormwind Guard","I've heard that there's a dwarf in Stormwind who has achieved some fame for his hunting skill.  Maybe you should go see if he could help you.","Slyšel jsem, že ve Stormwindu je trpaslík, který se proslavil svými loveckými schopnostmi. Možná by ses za ním měl podívat, jestli by ti nepomohl.")
-- source_id 1140
add("Razor Hill Grunt","I've seen a troll named Lau'Tiki fishing down south at the Darkspear Strand.  That's just on the outskirts of Sen'jin Village.","Viděl jsem trolla jménem Lau'Tiki rybařit jižně u Darkspear Strand. Je to hned na okraji Sen'jin Village.")
-- source_id 1141
add("Loh'atu","I've seen terrible things happen to the furbolg over the last few years--they were victims on many fronts. But it's unclear to me what's become of this tribe. Are they corrupted by the same plague that's touched Felwood? Or perhaps they are simply angry at what's happened to their once peaceful people and now seek to defend themselves. Either way, most of them appear hostile to those who come into the area.","Za posledních pár let jsem viděl, jak furbolgové zažili strašné věci--stali se obětí na mnoha frontách. Není mi ale jasné, co se s tímto kmenem stalo. Zkazil je stejný mor, který zasáhl Felwood? Nebo jsou prostě jen rozzlobení kvůli tomu, co postihlo jejich kdysi mírumilovný lid, a teď se snaží bránit? Ať je to jakkoli, většina z nich se zdá být nepřátelská vůči každému, kdo do oblasti vstoupí.")
-- source_id 1142
add("Warden Haro","I, like many others, came to aid my fellow druids when the war started.$B$BNow that the Gates of Ahn'Qiraj are open, I've realized that much work still remains to be done.  I've decided to stay in Silithus and do my best to help the cause, $N.","Stejně jako mnoho dalších jsem přišel pomoci svým druidským druhům, když začala válka.$B$BTeď, když jsou Gates of Ahn'Qiraj otevřené, jsem si uvědomil, že je stále třeba udělat mnoho práce. Rozhodl jsem se zůstat v Silithusu a udělat vše, co budu moci, abych pomohl naší věci, $N.")
-- source_id 1143
add("Fariel Starsong","I, like my brother, honor those who honor their ancestors.  It brings me great joy to share my crafting secrets to disciples of the Lunar Festival!","Stejně jako můj bratr si vážím těch, kteří ctí své předky. Dělá mi velikou radost sdílet svá řemeslnická tajemství s učedníky Lunar Festivalu!")
-- source_id 1144
add("Awbee","I... I am badly injured...","Já... jsem těžce zraněný...")
-- source_id 1145
add("Vaelastrasz the Corrupt","I... I have failed, $N. The Lord of Bla... The Lord of Blackrock is too powerful. He consumed my energy with... with ease. I turn... I... kill me... you must... you must kill me.","Já... selhal jsem, $N. Lord of Bla... Lord of Blackrock je příliš mocný. Vysál mou energii s... s lehkostí. Měním se... já... zabij mě... musíš... musíš mě zabít.")
-- source_id 1146
add("Linken","I... I'm not really sure how I got here...$B$BI seem to remember traveling... a raft...$B$B","Já... vlastně vůbec nevím, jak jsem se sem dostal...$B$BVzpomínám si, že jsem cestoval... vor...$B$B")
-- source_id 1147
add("Teldrassil Sentinel","If a bank is what you desire, then your travels take you to the heart of Darnassus.  There you will find storage for your treasures.","Jestli hledáš banku, tvá cesta tě zavede do srdce Darnassusu. Tam najdeš úložiště pro své poklady.")
-- source_id 1148
add("Teldrassil Sentinel","If a hunter is whom you seek, then it is Dazalar that you should visit.  He can usually be found just outside the Inn in Dolanaar.","Jestli hledáš lovce, měl bys navštívit Dazalara. Obvykle ho najdeš hned před hostincem v Dolanaaru.")
-- source_id 1149
add("Orcish Orphan","If a turtle doesn't have a shell, is he homeless or naked?","Když želva nemá krunýř, je bezdomovec, nebo nahá?")
-- source_id 1150
add("Argent Emissary","If additional support is not soon sent to the Burning Steppes, I fear the Scourge will establish a base of operations there. If you can, you should go there to aid the defenders.$B$BNumber of Necropolises remaining: $2281W","Pokud do Burning Steppes brzy nedorazí další posily, obávám se, že si tam Scourge zřídí základnu. Pokud můžeš, měl bys tam vyrazit a pomoci obráncům.$B$BZbývající počet Necropolises: $2281W")
add("Argent Messenger","If additional support is not soon sent to the Burning Steppes, I fear the Scourge will establish a base of operations there. If you can, you should go there to aid the defenders.$B$BNumber of Necropolises remaining: $2281W","Pokud do Burning Steppes brzy nedorazí další posily, obávám se, že si tam Scourge zřídí základnu. Pokud můžeš, měl bys tam vyrazit a pomoci obráncům.$B$BZbývající počet Necropolises: $2281W")
-- source_id 1151
add("Grim Patron","If Hydraxis recruits more in his war, then it might shift the balance of power...","Jestli Hydraxis získá do své války další spojence, mohlo by to změnit rovnováhu sil...")
-- source_id 1152
add("Niby the Almighty","If I am to teach you the secrets of summoning an infernal servant, you must destroy Kroshius and bring me the infernal core from his burning remains. This, however, is not as easy as it sounds. Kroshius has all but burned out completely. You must reignite his corpse and raise him from the rubble. To do this, however, you must gather some components from other demonic entities.$B$BMy imp, Impsy, shall set you on your way.","Pokud tě mám naučit tajemství přivolání infernal sluhy, musíš zničit Kroshiuse a přinést mi infernal core z jeho hořících ostatků. Není to však tak snadné, jak to zní. Kroshius už téměř úplně vyhasl. Musíš znovu zapálit jeho mrtvolu a pozvednout ho z trosek. K tomu však budeš muset získat několik součástí z jiných démonických bytostí.$B$BMůj imp Impsy ti ukáže, jak začít.")
-- source_id 1153
add("Azuregos","If I did not know better I would think that you were mocking me, mortal; but yes, that is mostly correct. You may remain fully clothed.","Kdybych nevěděl své, myslel bych si, že se mi vysmíváš, smrtelníku; ale ano, většinou je to správně. Můžeš zůstat úplně oblečený.")
add("Spirit of Azuregos","If I did not know better I would think that you were mocking me, mortal; but yes, that is mostly correct. You may remain fully clothed.","Kdybych nevěděl své, myslel bych si, že se mi vysmíváš, smrtelníku; ale ano, většinou je to správně. Můžeš zůstat úplně oblečený.")
-- source_id 1154
add("Orgrimmar Reveler","If I didnt know better, I'd say this party was organized by orcs!","Kdybych to nevěděl lépe, řekl bych, že tuhle párty organizovali orkové!")
-- source_id 1155
add("Guchie Jinglepocket","If I had some chestnuts, you'd better believe I'd have them roasting over an open fire.  Mmmm!","Kdybych měl nějaké kaštany, rozhodně bych je opékal nad otevřeným ohněm. Mmmm!")
add("Jaycrue Copperpinch","If I had some chestnuts, you'd better believe I'd have them roasting over an open fire.  Mmmm!","Kdybych měl nějaké kaštany, rozhodně bych je opékal nad otevřeným ohněm. Mmmm!")
add("Kaymard Copperpinch","If I had some chestnuts, you'd better believe I'd have them roasting over an open fire.  Mmmm!","Kdybych měl nějaké kaštany, rozhodně bych je opékal nad otevřeným ohněm. Mmmm!")
add("Khole Jinglepocket","If I had some chestnuts, you'd better believe I'd have them roasting over an open fire.  Mmmm!","Kdybych měl nějaké kaštany, rozhodně bych je opékal nad otevřeným ohněm. Mmmm!")
add("Macey Jinglepocket","If I had some chestnuts, you'd better believe I'd have them roasting over an open fire.  Mmmm!","Kdybych měl nějaké kaštany, rozhodně bych je opékal nad otevřeným ohněm. Mmmm!")
add("Penney Copperpinch","If I had some chestnuts, you'd better believe I'd have them roasting over an open fire.  Mmmm!","Kdybych měl nějaké kaštany, rozhodně bych je opékal nad otevřeným ohněm. Mmmm!")
add("Seersa Copperpinch","If I had some chestnuts, you'd better believe I'd have them roasting over an open fire.  Mmmm!","Kdybych měl nějaké kaštany, rozhodně bych je opékal nad otevřeným ohněm. Mmmm!")
add("Wulmort Jinglepocket","If I had some chestnuts, you'd better believe I'd have them roasting over an open fire.  Mmmm!","Kdybych měl nějaké kaštany, rozhodně bych je opékal nad otevřeným ohněm. Mmmm!")
-- source_id 1156
add("Snarl","If I prove myself to Saru he will have no choice but to let me fight for one of his daughters. Then we will see who is sneering.","Když se před Saruem osvědčím, nebude mít na výběr a dovolí mi bojovat o jednu ze svých dcer. Pak uvidíme, kdo se bude posmívat.")
-- source_id 1157
add("Arthur Moore","If I taught novices, there'd be a lot more students visiting me, and things would get noisy. Go talk to Dan Golthas over there. He's a little intense, but he means well, and he's a decent teacher.","Kdybych učil nováčky, chodilo by za mnou mnohem víc studentů a byl by tu hluk. Promluv si s Danem Golthasem támhle. Je trochu intenzivní, ale myslí to dobře a je to slušný učitel.")
-- source_id 1158
add("Lavinia Crowe","If I wasn't stuck here day in and day out, I would have attained the mastery required to train the likes of you! Unfortunately that's not the case. Go talk to Hgarth at the Sun Rock Retreat in the Stonetalon Mountains.","Kdybych tu nebyl každý den uvázaný, dávno bych dosáhl mistrovství potřebného k výcviku takových jako ty! Bohužel se tak nestalo. Promluv si s Hgarthem v Sun Rock Retreat v Stonetalon Mountains.")
-- source_id 1159
add("Goblin Pit Crewman","If I were you, I'd buy a goblin race voucher.  Rooting for the other team is a waste of time.","Být tebou, koupím si goblin race voucher. Fandit druhému týmu je ztráta času.")
-- source_id 1160
add("Brave Cloudmane","If it is the way of the Warrior that you crave then you must seek out Krang Stonehoof.  You will find him in the southeast corner of the village at his training circle, often instructing his other students.","Jestli toužíš následovat cestu Warrior, musíš vyhledat Kranga Stonehoofa. Najdeš ho v jihovýchodním rohu vesnice na jeho cvičišti, kde často učí své další studenty.")
add("Brave Darksky","If it is the way of the Warrior that you crave then you must seek out Krang Stonehoof.  You will find him in the southeast corner of the village at his training circle, often instructing his other students.","Jestli toužíš následovat cestu Warrior, musíš vyhledat Kranga Stonehoofa. Najdeš ho v jihovýchodním rohu vesnice na jeho cvičišti, kde často učí své další studenty.")
add("Brave Dawneagle","If it is the way of the Warrior that you crave then you must seek out Krang Stonehoof.  You will find him in the southeast corner of the village at his training circle, often instructing his other students.","Jestli toužíš následovat cestu Warrior, musíš vyhledat Kranga Stonehoofa. Najdeš ho v jihovýchodním rohu vesnice na jeho cvičišti, kde často učí své další studenty.")
add("Brave Ironhorn","If it is the way of the Warrior that you crave then you must seek out Krang Stonehoof.  You will find him in the southeast corner of the village at his training circle, often instructing his other students.","Jestli toužíš následovat cestu Warrior, musíš vyhledat Kranga Stonehoofa. Najdeš ho v jihovýchodním rohu vesnice na jeho cvičišti, kde často učí své další studenty.")
add("Brave Leaping Deer","If it is the way of the Warrior that you crave then you must seek out Krang Stonehoof.  You will find him in the southeast corner of the village at his training circle, often instructing his other students.","Jestli toužíš následovat cestu Warrior, musíš vyhledat Kranga Stonehoofa. Najdeš ho v jihovýchodním rohu vesnice na jeho cvičišti, kde často učí své další studenty.")
add("Brave Rainchaser","If it is the way of the Warrior that you crave then you must seek out Krang Stonehoof.  You will find him in the southeast corner of the village at his training circle, often instructing his other students.","Jestli toužíš následovat cestu Warrior, musíš vyhledat Kranga Stonehoofa. Najdeš ho v jihovýchodním rohu vesnice na jeho cvičišti, kde často učí své další studenty.")
add("Brave Rockhorn","If it is the way of the Warrior that you crave then you must seek out Krang Stonehoof.  You will find him in the southeast corner of the village at his training circle, often instructing his other students.","Jestli toužíš následovat cestu Warrior, musíš vyhledat Kranga Stonehoofa. Najdeš ho v jihovýchodním rohu vesnice na jeho cvičišti, kde často učí své další studenty.")
add("Brave Strongbash","If it is the way of the Warrior that you crave then you must seek out Krang Stonehoof.  You will find him in the southeast corner of the village at his training circle, often instructing his other students.","Jestli toužíš následovat cestu Warrior, musíš vyhledat Kranga Stonehoofa. Najdeš ho v jihovýchodním rohu vesnice na jeho cvičišti, kde často učí své další studenty.")
add("Brave Swiftwind","If it is the way of the Warrior that you crave then you must seek out Krang Stonehoof.  You will find him in the southeast corner of the village at his training circle, often instructing his other students.","Jestli toužíš následovat cestu Warrior, musíš vyhledat Kranga Stonehoofa. Najdeš ho v jihovýchodním rohu vesnice na jeho cvičišti, kde často učí své další studenty.")
add("Brave Wildrunner","If it is the way of the Warrior that you crave then you must seek out Krang Stonehoof.  You will find him in the southeast corner of the village at his training circle, often instructing his other students.","Jestli toužíš následovat cestu Warrior, musíš vyhledat Kranga Stonehoofa. Najdeš ho v jihovýchodním rohu vesnice na jeho cvičišti, kde často učí své další studenty.")
-- source_id 1161
add("Goblin Pit Crewman","If it weren't for that cursed, gnomish luck, they'd never win a race!","Nebýt toho prokletého gnómského štěstí, nikdy by žádný závod nevyhráli!")
-- source_id 1162
add("Gnome Pit Crewman","If it weren't for the goblins' inconceivable, dumb luck, they'd crash their car during every race!","Nebýt nepochopitelného, hloupého štěstí goblinů, havarovali by s autem při každém závodě!")
-- source_id 1163
add("Grim Patron","If it weren't for the Grim Guzzler, I'd probably spend my free time pulling the wings off dragon whelps.","Nebýt Grim Guzzleru, nejspíš bych volný čas trávil trháním křídel dračím mláďatům.")
-- source_id 1164
add("Grim Patron","If it weren't for the Grim Guzzler, I'd spend my free time pulling the wings off dragon whelps.","Nebýt Grim Guzzleru, trávil bych volný čas trháním křídel dračím mláďatům.")
-- source_id 1165
add("Smith Slagtree","If it's broke, Slagtree can fix it!","Když je něco rozbité, Slagtree to opraví!")
-- source_id 1166
add("Springspindle Fizzlegear","If my calculations are correct, the wheel will soon be obsolete!","Pokud jsou mé výpočty správné, kolo bude brzy zastaralé!")
-- source_id 1167
add("Human Orphan","If overalls are held up by the snaps at the top, then why do they have belt loops?","Když lacláče drží přezky nahoře, proč mají poutka na pásek?")
-- source_id 1168
add("Krog","If Reethe is somehow involved with the burning of the Shady Rest Inn, you'll have to find him and get some answers out of him.$b$bI sent Ogron to track him down. He was headed off to the southeast. Meet up with Ogron and then go find Reethe.","Jestli má Reethe něco společného s vypálením Shady Rest Inn, budeš ho muset najít a dostat z něj odpovědi.$b$bPoslal jsem Ogrona, aby ho vystopoval. Zamířil na jihovýchod. Setkej se s Ogronem a pak Reetha najděte.")
-- source_id 1169
add("Grunt Maug","If someone has put together the magic scepter of the sands then the war with the bugs will be soon. I relish it, $c! The last of our war goods are on their way to Silithus and should be there within $2113w days. Go and bring honor to the Horde!","Jestli už někdo složil magické Scepter of the Sands, válka s brouky brzy začne. Těším se na ni, $c! Poslední zásoby pro naši válku jsou na cestě do Silithusu a měly by tam být do $2113w dní. Jdi a přines Hordě čest!")
-- source_id 1170
add("Grunt Maug","If someone has put together the magic scepter of the sands then the war with the bugs will be soon. I relish it, $c! The last of our war goods are on their way to Silithus and should be there within a day. Go and bring honor to the Horde!","Jestli už někdo složil magické Scepter of the Sands, válka s brouky brzy začne. Těším se na ni, $c! Poslední zásoby pro naši válku jsou na cestě do Silithusu a měly by tam být do jednoho dne. Jdi a přines Hordě čest!")
-- source_id 1171
add("Vizzklick","If tailoring is your thing, Vizzklick will most definitely have your supplies. Take a look around, $N, and let me know if you wish to purchase something!","Jestli je Tailoring tvoje věc, Vizzklick bude určitě mít všechno, co potřebuješ. Rozhlédni se, $N, a dej mi vědět, pokud chceš něco koupit!")
-- source_id 1172
add("Nogg","If there were just a few more hours in a day...","Kdyby měl den jen o pár hodin víc...")
-- source_id 1173
add("Innkeeper Grosk","If we are to make these new lands ours then we must have places to rest our battle weary bodies. Lay your axe by the fire and share the stories of your mighty battles.","Jestli si máme tyto nové země přivlastnit, musíme mít místa, kde si naše bojem unavená těla odpočinou. Polož sekeru k ohni a poděl se o příběhy ze svých mocných bitev.")
add("Innkeeper Gryshka","If we are to make these new lands ours then we must have places to rest our battle weary bodies. Lay your axe by the fire and share the stories of your mighty battles.","Jestli si máme tyto nové země přivlastnit, musíme mít místa, kde si naše bojem unavená těla odpočinou. Polož sekeru k ohni a poděl se o příběhy ze svých mocných bitev.")
add("Innkeeper Jayka","If we are to make these new lands ours then we must have places to rest our battle weary bodies. Lay your axe by the fire and share the stories of your mighty battles.","Jestli si máme tyto nové země přivlastnit, musíme mít místa, kde si naše bojem unavená těla odpočinou. Polož sekeru k ohni a poděl se o příběhy ze svých mocných bitev.")
add("Innkeeper Karakul","If we are to make these new lands ours then we must have places to rest our battle weary bodies. Lay your axe by the fire and share the stories of your mighty battles.","Jestli si máme tyto nové země přivlastnit, musíme mít místa, kde si naše bojem unavená těla odpočinou. Polož sekeru k ohni a poděl se o příběhy ze svých mocných bitev.")
add("Innkeeper Kaylisk","If we are to make these new lands ours then we must have places to rest our battle weary bodies. Lay your axe by the fire and share the stories of your mighty battles.","Jestli si máme tyto nové země přivlastnit, musíme mít místa, kde si naše bojem unavená těla odpočinou. Polož sekeru k ohni a poděl se o příběhy ze svých mocných bitev.")
add("Innkeeper Shul'kar","If we are to make these new lands ours then we must have places to rest our battle weary bodies. Lay your axe by the fire and share the stories of your mighty battles.","Jestli si máme tyto nové země přivlastnit, musíme mít místa, kde si naše bojem unavená těla odpočinou. Polož sekeru k ohni a poděl se o příběhy ze svých mocných bitev.")
add("Innkeeper Thulbek","If we are to make these new lands ours then we must have places to rest our battle weary bodies. Lay your axe by the fire and share the stories of your mighty battles.","Jestli si máme tyto nové země přivlastnit, musíme mít místa, kde si naše bojem unavená těla odpočinou. Polož sekeru k ohni a poděl se o příběhy ze svých mocných bitev.")
-- source_id 1174
add("Dun Morogh Mountaineer","If ye ask me, I think Grif spends a little too much time with the animals.  Still, nobody else knows the hunter's path quite like he does.  Look for him outside the smithy in Kharanos.","Jestli se mě ptáš, Grif tráví se zvířaty trochu moc času. Ale cestu lovce nikdo nezná tak dobře jako on. Hledej ho před kovárnou v Kharanosu.")
add("Ironforge Mountaineer","If ye ask me, I think Grif spends a little too much time with the animals.  Still, nobody else knows the hunter's path quite like he does.  Look for him outside the smithy in Kharanos.","Jestli se mě ptáš, Grif tráví se zvířaty trochu moc času. Ale cestu lovce nikdo nezná tak dobře jako on. Hledej ho před kovárnou v Kharanosu.")
add("Mounted Ironforge Mountaineer","If ye ask me, I think Grif spends a little too much time with the animals.  Still, nobody else knows the hunter's path quite like he does.  Look for him outside the smithy in Kharanos.","Jestli se mě ptáš, Grif tráví se zvířaty trochu moc času. Ale cestu lovce nikdo nezná tak dobře jako on. Hledej ho před kovárnou v Kharanosu.")
-- source_id 1175
add("Dun Morogh Mountaineer","If ye need to get yer hands on some guild creation papers ye'll have to head up to Ironforge and visit the Ironforge Visitor's Center.","Jestli potřebuješ získat papíry k založení guildy, budeš muset vyrazit do Ironforge a navštívit Ironforge Visitor's Center.")
add("Ironforge Mountaineer","If ye need to get yer hands on some guild creation papers ye'll have to head up to Ironforge and visit the Ironforge Visitor's Center.","Jestli potřebuješ získat papíry k založení guildy, budeš muset vyrazit do Ironforge a navštívit Ironforge Visitor's Center.")
add("Mounted Ironforge Mountaineer","If ye need to get yer hands on some guild creation papers ye'll have to head up to Ironforge and visit the Ironforge Visitor's Center.","Jestli potřebuješ získat papíry k založení guildy, budeš muset vyrazit do Ironforge a navštívit Ironforge Visitor's Center.")
-- source_id 1176
add("Dun Morogh Mountaineer","If ye're looking to learn the profession of leatherworking, ye're gonna need to travel to Ironforge.  I hear there's a nice shop near the Great Forge where ye can learn the profession.","Jestli se chceš naučit Leatherworking, budeš muset odcestovat do Ironforge. Slyšel jsem, že poblíž Great Forge je dobrý obchod, kde se tomuto povolání můžeš naučit.")
add("Ironforge Mountaineer","If ye're looking to learn the profession of leatherworking, ye're gonna need to travel to Ironforge.  I hear there's a nice shop near the Great Forge where ye can learn the profession.","Jestli se chceš naučit Leatherworking, budeš muset odcestovat do Ironforge. Slyšel jsem, že poblíž Great Forge je dobrý obchod, kde se tomuto povolání můžeš naučit.")
add("Mounted Ironforge Mountaineer","If ye're looking to learn the profession of leatherworking, ye're gonna need to travel to Ironforge.  I hear there's a nice shop near the Great Forge where ye can learn the profession.","Jestli se chceš naučit Leatherworking, budeš muset odcestovat do Ironforge. Slyšel jsem, že poblíž Great Forge je dobrý obchod, kde se tomuto povolání můžeš naučit.")
-- source_id 1177
add("Ironforge Guard","If yer of need of an Inn, The Stonefire Inn is where ye should be.  Ye'll find it just to the left of the entrance to Ironforge if ye be coming, or to the right if ye be going.  $B$BOh, and if yer going that way, then tell them to have a tankard ready for me.","Jestli potřebuješ hostinec, The Stonefire Inn je přesně to místo. Najdeš ho hned nalevo od vstupu do Ironforge, pokud přicházíš, nebo napravo, pokud odcházíš. $B$BA když už půjdeš tím směrem, řekni jim, ať pro mě připraví korbel.")
-- source_id 1178
add("Ironforge Guard","If yer thinking about forming a guild, then ye'll need to put it past Jondor Steelbrow o'er in the Ironforge Visitor's Center.  Just head southeast from the gates of Ironforge to see him.","Jestli přemýšlíš o založení guildy, budeš to muset projednat s Jondorem Steelbrowem v Ironforge Visitor's Center. Najdeš ho jihovýchodně od bran Ironforge.")
-- source_id 1179
add("Malyfous Darkhammer","If you actually brought me the hide of the beast? Well... Let me show you...","Ty jsi opravdu přinesl kůži té bestie? No... dovol mi něco ti ukázat...")
-- source_id 1180
add("Faldron","If you are here for further training, you have overestimated my abilities. Have a word with Telonis over there; he can help you.","Jestli jsi přišel pro další výcvik, přecenil jsi mé schopnosti. Promluv si s Telonisem támhle; ten ti pomůže.")
-- source_id 1181
add("Peter Galen","If you are here to hunt dragons, be my guest.  Where should I send my condolences?","Jestli jsi přišel lovit draky, posluž si. Kam mám poslat kondolenci?")
-- source_id 1182
add("Arch Druid Fandral Staghelm","If you are here to waste my time, then you are wasting the time of the Cenarion Circle as a whole.  For your sake, let us hope that you are not foolish enough to be doing just that.","Jestli jsi sem přišel plýtvat mým časem, plýtváš časem celého Cenarion Circle. Ve svém vlastním zájmu doufej, že nejsi tak hloupý, abys právě tohle dělal.")
-- source_id 1183
add("Innkeeper Allison","If you are looking to become a great cook, venture over to the Pig and Whistle Tavern in Old Town and talk to Stephen Ryback. That man knows how to cook up a rack of ribs like no other.\n\nMan... now you got me hungry for some of his famous ribs. Don't count on him teaching you that recipe though!","Jestli se chceš stát skvělým kuchařem, vydej se do Pig and Whistle Tavern v Old Town a promluv si se Stephenem Rybackem. Ten člověk umí připravit žebírka jako nikdo jiný.\n\nČlověče... teď jsi mi na jeho slavných žebírkách udělal chuť. Ale nepočítej s tím, že tě ten recept naučí!")
add("Innkeeper Heather","If you are looking to become a great cook, venture over to the Pig and Whistle Tavern in Old Town and talk to Stephen Ryback. That man knows how to cook up a rack of ribs like no other.\n\nMan... now you got me hungry for some of his famous ribs. Don't count on him teaching you that recipe though!","Jestli se chceš stát skvělým kuchařem, vydej se do Pig and Whistle Tavern v Old Town a promluv si se Stephenem Rybackem. Ten člověk umí připravit žebírka jako nikdo jiný.\n\nČlověče... teď jsi mi na jeho slavných žebírkách udělal chuť. Ale nepočítej s tím, že tě ten recept naučí!")
add("Innkeeper Janene","If you are looking to become a great cook, venture over to the Pig and Whistle Tavern in Old Town and talk to Stephen Ryback. That man knows how to cook up a rack of ribs like no other.\n\nMan... now you got me hungry for some of his famous ribs. Don't count on him teaching you that recipe though!","Jestli se chceš stát skvělým kuchařem, vydej se do Pig and Whistle Tavern v Old Town a promluv si se Stephenem Rybackem. Ten člověk umí připravit žebírka jako nikdo jiný.\n\nČlověče... teď jsi mi na jeho slavných žebírkách udělal chuť. Ale nepočítej s tím, že tě ten recept naučí!")
add("Stormwind City Guard","If you are looking to become a great cook, venture over to the Pig and Whistle Tavern in Old Town and talk to Stephen Ryback. That man knows how to cook up a rack of ribs like no other.\n\nMan... now you got me hungry for some of his famous ribs. Don't count on him teaching you that recipe though!","Jestli se chceš stát skvělým kuchařem, vydej se do Pig and Whistle Tavern v Old Town a promluv si se Stephenem Rybackem. Ten člověk umí připravit žebírka jako nikdo jiný.\n\nČlověče... teď jsi mi na jeho slavných žebírkách udělal chuť. Ale nepočítej s tím, že tě ten recept naučí!")
add("Stormwind City Patroller","If you are looking to become a great cook, venture over to the Pig and Whistle Tavern in Old Town and talk to Stephen Ryback. That man knows how to cook up a rack of ribs like no other.\n\nMan... now you got me hungry for some of his famous ribs. Don't count on him teaching you that recipe though!","Jestli se chceš stát skvělým kuchařem, vydej se do Pig and Whistle Tavern v Old Town a promluv si se Stephenem Rybackem. Ten člověk umí připravit žebírka jako nikdo jiný.\n\nČlověče... teď jsi mi na jeho slavných žebírkách udělal chuť. Ale nepočítej s tím, že tě ten recept naučí!")
add("Vikki Lonsav","If you are looking to become a great cook, venture over to the Pig and Whistle Tavern in Old Town and talk to Stephen Ryback. That man knows how to cook up a rack of ribs like no other.\n\nMan... now you got me hungry for some of his famous ribs. Don't count on him teaching you that recipe though!","Jestli se chceš stát skvělým kuchařem, vydej se do Pig and Whistle Tavern v Old Town a promluv si se Stephenem Rybackem. Ten člověk umí připravit žebírka jako nikdo jiný.\n\nČlověče... teď jsi mi na jeho slavných žebírkách udělal chuť. Ale nepočítej s tím, že tě ten recept naučí!")
-- source_id 1184
add("Innkeeper Allison","If you are looking to become a mighty paladin, there is no better teacher then Lord Grayson Shadowbreaker. He can be found in the Cathedral of Light in Cathedral Square.","Jestli se chceš stát mocným paladinem, lepšího učitele než Lorda Graysona Shadowbreakera nenajdeš. Najdeš ho v Cathedral of Light na Cathedral Square.")
add("Innkeeper Heather","If you are looking to become a mighty paladin, there is no better teacher then Lord Grayson Shadowbreaker. He can be found in the Cathedral of Light in Cathedral Square.","Jestli se chceš stát mocným paladinem, lepšího učitele než Lorda Graysona Shadowbreakera nenajdeš. Najdeš ho v Cathedral of Light na Cathedral Square.")
add("Innkeeper Janene","If you are looking to become a mighty paladin, there is no better teacher then Lord Grayson Shadowbreaker. He can be found in the Cathedral of Light in Cathedral Square.","Jestli se chceš stát mocným paladinem, lepšího učitele než Lorda Graysona Shadowbreakera nenajdeš. Najdeš ho v Cathedral of Light na Cathedral Square.")
add("Stormwind City Guard","If you are looking to become a mighty paladin, there is no better teacher then Lord Grayson Shadowbreaker. He can be found in the Cathedral of Light in Cathedral Square.","Jestli se chceš stát mocným paladinem, lepšího učitele než Lorda Graysona Shadowbreakera nenajdeš. Najdeš ho v Cathedral of Light na Cathedral Square.")
add("Stormwind City Patroller","If you are looking to become a mighty paladin, there is no better teacher then Lord Grayson Shadowbreaker. He can be found in the Cathedral of Light in Cathedral Square.","Jestli se chceš stát mocným paladinem, lepšího učitele než Lorda Graysona Shadowbreakera nenajdeš. Najdeš ho v Cathedral of Light na Cathedral Square.")
add("Vikki Lonsav","If you are looking to become a mighty paladin, there is no better teacher then Lord Grayson Shadowbreaker. He can be found in the Cathedral of Light in Cathedral Square.","Jestli se chceš stát mocným paladinem, lepšího učitele než Lorda Graysona Shadowbreakera nenajdeš. Najdeš ho v Cathedral of Light na Cathedral Square.")
-- source_id 1185
add("Rayne","If you are one that prefers to hunt in the outdoor world, both Felwood's treants and Un'Goro's lashers are an excellent source of fronds.$B$BIf you are more of a risk-taker, the eastern and western wings of Dire Maul will provide you with a nearly limitless supply of savage fronds.","Pokud raději lovíš venku v otevřeném světě, treanti ve Felwoodu i lashers v Un'Goro jsou výborným zdrojem fronds.$B$BJestli máš raději větší riziko, východní a západní křídlo Dire Maul ti nabídnou téměř neomezenou zásobu savage fronds.")
-- source_id 1186
add("Xylinnia Starshine","If you are seeking a truly rewarding pursuit, then a life of enchanting is for you!","Pokud hledáš opravdu výnosné povolání, život Enchantera je pro tebe!")
-- source_id 1187
add("Goblin Pit Crewman","If you ask me, I think the goblins are a shoe in.  We have the tools, and we have the talent!","Podle mě jsou goblini jasní favoriti. Máme nástroje a máme talent!")
-- source_id 1188
add("Nat Pagle","If you ask me, the best part about fishing is its slow pace.  It gives one time to think, to reflect on past events and to plan for future ones.$B$BOh, and it's also a great excuse to drink.  Heavily.","Podle mě je nejlepší na rybaření jeho pomalé tempo. Člověk má čas přemýšlet, ohlédnout se za minulými událostmi a plánovat ty budoucí.$B$BA také je to skvělá výmluva k pití. Hodně pití.")
-- source_id 1189
add("Darnassus Sentinel","If you desire to form a fellowship then it is the guild master, Lysheana, that you must see.  You will find her in the Craftsmen's Terrace in the northeastern section of Darnassus.","Jestli chceš založit společenství, musíš navštívit guild masterku Lysheanu. Najdeš ji v Craftsmen's Terrace v severovýchodní části Darnassusu.")
-- source_id 1190
add("Brave Cloudmane","If you desire to learn the ways of Herbalism then it is to Thunder Bluff that you must go.  Follow the road north out of Bloodhoof Village and take the elevator to the top of the rise.  You can ask a Bluffwatcher there for further assistance.","Pokud se chceš naučit Herbalism, musíš do Thunder Bluffu. Vydej se po cestě na sever z Bloodhoof Village a vyjeď výtahem na vrchol plošiny. O další pomoc se můžeš zeptat některého Bluffwatchera.")
add("Brave Darksky","If you desire to learn the ways of Herbalism then it is to Thunder Bluff that you must go.  Follow the road north out of Bloodhoof Village and take the elevator to the top of the rise.  You can ask a Bluffwatcher there for further assistance.","Pokud se chceš naučit Herbalism, musíš do Thunder Bluffu. Vydej se po cestě na sever z Bloodhoof Village a vyjeď výtahem na vrchol plošiny. O další pomoc se můžeš zeptat některého Bluffwatchera.")
add("Brave Dawneagle","If you desire to learn the ways of Herbalism then it is to Thunder Bluff that you must go.  Follow the road north out of Bloodhoof Village and take the elevator to the top of the rise.  You can ask a Bluffwatcher there for further assistance.","Pokud se chceš naučit Herbalism, musíš do Thunder Bluffu. Vydej se po cestě na sever z Bloodhoof Village a vyjeď výtahem na vrchol plošiny. O další pomoc se můžeš zeptat některého Bluffwatchera.")
add("Brave Ironhorn","If you desire to learn the ways of Herbalism then it is to Thunder Bluff that you must go.  Follow the road north out of Bloodhoof Village and take the elevator to the top of the rise.  You can ask a Bluffwatcher there for further assistance.","Pokud se chceš naučit Herbalism, musíš do Thunder Bluffu. Vydej se po cestě na sever z Bloodhoof Village a vyjeď výtahem na vrchol plošiny. O další pomoc se můžeš zeptat některého Bluffwatchera.")
add("Brave Leaping Deer","If you desire to learn the ways of Herbalism then it is to Thunder Bluff that you must go.  Follow the road north out of Bloodhoof Village and take the elevator to the top of the rise.  You can ask a Bluffwatcher there for further assistance.","Pokud se chceš naučit Herbalism, musíš do Thunder Bluffu. Vydej se po cestě na sever z Bloodhoof Village a vyjeď výtahem na vrchol plošiny. O další pomoc se můžeš zeptat některého Bluffwatchera.")
add("Brave Rainchaser","If you desire to learn the ways of Herbalism then it is to Thunder Bluff that you must go.  Follow the road north out of Bloodhoof Village and take the elevator to the top of the rise.  You can ask a Bluffwatcher there for further assistance.","Pokud se chceš naučit Herbalism, musíš do Thunder Bluffu. Vydej se po cestě na sever z Bloodhoof Village a vyjeď výtahem na vrchol plošiny. O další pomoc se můžeš zeptat některého Bluffwatchera.")
add("Brave Rockhorn","If you desire to learn the ways of Herbalism then it is to Thunder Bluff that you must go.  Follow the road north out of Bloodhoof Village and take the elevator to the top of the rise.  You can ask a Bluffwatcher there for further assistance.","Pokud se chceš naučit Herbalism, musíš do Thunder Bluffu. Vydej se po cestě na sever z Bloodhoof Village a vyjeď výtahem na vrchol plošiny. O další pomoc se můžeš zeptat některého Bluffwatchera.")
add("Brave Strongbash","If you desire to learn the ways of Herbalism then it is to Thunder Bluff that you must go.  Follow the road north out of Bloodhoof Village and take the elevator to the top of the rise.  You can ask a Bluffwatcher there for further assistance.","Pokud se chceš naučit Herbalism, musíš do Thunder Bluffu. Vydej se po cestě na sever z Bloodhoof Village a vyjeď výtahem na vrchol plošiny. O další pomoc se můžeš zeptat některého Bluffwatchera.")
add("Brave Swiftwind","If you desire to learn the ways of Herbalism then it is to Thunder Bluff that you must go.  Follow the road north out of Bloodhoof Village and take the elevator to the top of the rise.  You can ask a Bluffwatcher there for further assistance.","Pokud se chceš naučit Herbalism, musíš do Thunder Bluffu. Vydej se po cestě na sever z Bloodhoof Village a vyjeď výtahem na vrchol plošiny. O další pomoc se můžeš zeptat některého Bluffwatchera.")
add("Brave Wildrunner","If you desire to learn the ways of Herbalism then it is to Thunder Bluff that you must go.  Follow the road north out of Bloodhoof Village and take the elevator to the top of the rise.  You can ask a Bluffwatcher there for further assistance.","Pokud se chceš naučit Herbalism, musíš do Thunder Bluffu. Vydej se po cestě na sever z Bloodhoof Village a vyjeď výtahem na vrchol plošiny. O další pomoc se můžeš zeptat některého Bluffwatchera.")
-- source_id 1191
add("Mathrengyl Bearwalker","If you desire, in addition to training, I have it within my power to erase the knowledge of your talents from your mind.  Be warned that every time you undergo this procedure the more difficult it is to perform, and therefore the more expensive it becomes.","Pokud chceš, kromě výcviku mám také moc vymazat z tvé mysli znalost tvých talentů. Měj na paměti, že s každým opakováním je tento zákrok obtížnější, a proto také dražší.")
-- source_id 1192
add("Jhordy Lapforge","If you figure out any way to improve the device let me know!","Jestli přijdeš na způsob, jak zařízení vylepšit, dej mi vědět!")
-- source_id 1193
add("Milli Featherwhistle","If you have come looking for the gift of fast and safe mobility, then you have arrived at your destination!  This year's model of the new Mechano-striders have recently arrived, and I am ready to show you all they have to offer!","Jestli hledáš dar rychlé a bezpečné dopravy, dorazil jsi na správné místo! Právě dorazily letošní modely nových Mechano-striders a jsem připraven ukázat ti vše, co nabízejí!")
-- source_id 1194
add("Molthor","If you have come to save the world then you have come to the right place. The faceless one - the Blood God, Hakkar - has been brought back into our world!","Jestli jsi přišel zachránit svět, jsi na správném místě. Faceless one - Blood God Hakkar - byl přiveden zpět do našeho světa!")
-- source_id 1195
add("Sergeant Umala","If you have more thick leather, I'm sorry but you've come too late. We have all that we need, but before you go would you check with the others here? There's likely someone that still needs your help with their own collecting.","Jestli máš další thick leather, je mi líto, ale přišel jsi pozdě. Máme vše, co potřebujeme, ale než odejdeš, zeptej se ostatních tady. Někdo z nich ještě určitě potřebuje pomoc se svou sbírkou.")
-- source_id 1196
add("Lucan Cordell","If you have what it takes, I will be happy to show you the way.","Jestli na to máš, rád ti ukážu cestu.")
-- source_id 1197
add("Chief Sharpclaw","If you heard that all of the Horde and Alliance collections have been completed, then you heard right, $c. All of the goods for the war that we gathered and prepared are in the process of being sent to Cenarion Hold in Silithus, with less than $2113w days until the last of it arrives there. After that I suppose we'll just have to wait and see who assembles that scepter to ring the gong with, which will open the gates to Ahn'Qiraj and herald the war.","Jestli jsi slyšel, že všechny sbírky Hordy i Alliance byly dokončeny, slyšel jsi správně, $c. Všechno válečné zboží, které jsme shromáždili a připravili, se právě posílá do Cenarion Holdu v Silithusu a do příjezdu posledních zásilek zbývá méně než $2113w dní. Pak už budeme muset jen čekat, kdo složí to scepter, zazvoní na gong, otevře brány Ahn'Qiraj a zahájí válku.")
add("Master Sergeant Maclure","If you heard that all of the Horde and Alliance collections have been completed, then you heard right, $c. All of the goods for the war that we gathered and prepared are in the process of being sent to Cenarion Hold in Silithus, with less than $2113w days until the last of it arrives there. After that I suppose we'll just have to wait and see who assembles that scepter to ring the gong with, which will open the gates to Ahn'Qiraj and herald the war.","Jestli jsi slyšel, že všechny sbírky Hordy i Alliance byly dokončeny, slyšel jsi správně, $c. Všechno válečné zboží, které jsme shromáždili a připravili, se právě posílá do Cenarion Holdu v Silithusu a do příjezdu posledních zásilek zbývá méně než $2113w dní. Pak už budeme muset jen čekat, kdo složí to scepter, zazvoní na gong, otevře brány Ahn'Qiraj a zahájí válku.")
-- source_id 1198
add("Chief Sharpclaw","If you heard that all of the Horde and Alliance collections have been completed, then you heard right, $c. All of the goods for the war that we gathered and prepared are in the process of being sent to Cenarion Hold in Silithus, with less than a day until the last of it arrives there. After that I suppose we'll just have to wait and see who assembles that scepter to ring the gong with, which will open the gates to Ahn'Qiraj and herald the war.","Jestli jsi slyšel, že všechny sbírky Hordy i Alliance byly dokončeny, slyšel jsi správně, $c. Všechno válečné zboží, které jsme shromáždili a připravili, se právě posílá do Cenarion Holdu v Silithusu a do příjezdu posledních zásilek zbývá méně než jeden den. Pak už budeme muset jen čekat, kdo složí to scepter, zazvoní na gong, otevře brány Ahn'Qiraj a zahájí válku.")
-- source_id 1199
add("Billibub Cogspinner","If you insert tab A into slot B then of course it's going to go BOOM! Here, let me show you what I have and then you can ask Lilliam about how to put it together so it doesn't blow up.","Když zasuneš jazýček A do otvoru B, tak to samozřejmě udělá BUM! Tady, ukážu ti, co mám, a pak se můžeš Lilliam zeptat, jak to sestavit, aby to nevybuchlo.")
add("Shoni the Shilent","If you insert tab A into slot B then of course it's going to go BOOM! Here, let me show you what I have and then you can ask Lilliam about how to put it together so it doesn't blow up.","Když zasuneš jazýček A do otvoru B, tak to samozřejmě udělá BUM! Tady, ukážu ti, co mám, a pak se můžeš Lilliam zeptat, jak to sestavit, aby to nevybuchlo.")
-- source_id 1200
add("Professor Thaddeus Paleo","If you manage to complete a deck of Beasts cards you will be rewarded with a Greater Darkmoon card of the Blue Dragon.   This is very useful in restoring of magical energies.","Pokud se ti podaří dokončit balíček Beasts cards, dostaneš jako odměnu Greater Darkmoon card of the Blue Dragon. Je velmi užitečná při obnovování magické energie.")
