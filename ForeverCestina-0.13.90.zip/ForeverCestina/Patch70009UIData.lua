-- UI labels introduced/confirmed by WoW Forever build 70009.
local _, A = ...
local E = A.UIEntries

table.insert(E, {"Use Compact Action Bar", "Použít kompaktní akční lištu"})
table.insert(E, {"Fixed Party Targeting", "Pevné zaměřování členů skupiny"})
table.insert(E, {"Swap Target Modifier Sides", "Prohodit strany modifikátorů cílení"})

-- Blizzard's September 24 notes used "Target" in these labels, while build
-- 70009 can render the newer "Targeting" wording. Keep both exact variants;
-- exact matching prevents either entry from affecting unrelated UI text.
table.insert(E, {"Swap Friendly Target Action Sides", "Prohodit strany akcí pro přátelský cíl"})
table.insert(E, {"Swap Hostile Target Action Sides", "Prohodit strany akcí pro nepřátelský cíl"})
table.insert(E, {"Swap Friendly Targeting Action Sides", "Prohodit strany akcí pro přátelský cíl"})
table.insert(E, {"Swap Hostile Targeting Action Sides", "Prohodit strany akcí pro nepřátelský cíl"})

-- Exact help-text variants observed in the current UI / current CVar descriptions.
-- These are presentation-only dictionary entries; no CVar or setting value is changed.
table.insert(E, {"Enables a more compact action bar layout, that only displays the currently active bar.", "Zapne kompaktnější rozložení akčních lišt, které zobrazuje pouze právě aktivní lištu."})
table.insert(E, {"If enabled, target specific party members with the dpad rather than using directional targeting", "Po zapnutí vybírá směrový kříž konkrétní členy skupiny místo směrového zaměřování."})
table.insert(E, {"Swaps the friendly and hostile target modifiers.", "Prohodí modifikátory pro přátelské a nepřátelské cíle."})
table.insert(E, {"Swaps the dpad and face button actions when holding the friendly target modifier.", "Prohodí akce směrového kříže a hlavních tlačítek při držení modifikátoru přátelského cíle."})
table.insert(E, {"Swaps the dpad and face button actions when holding the hostile target modifier.", "Prohodí akce směrového kříže a hlavních tlačítek při držení modifikátoru nepřátelského cíle."})
table.insert(E, {"Swaps the directional pad and face button actions when holding the friendly target modifier.", "Prohodí akce směrového kříže a hlavních tlačítek při držení modifikátoru přátelského cíle."})
table.insert(E, {"Swaps the directional pad and face button actions when holding the hostile target modifier.", "Prohodí akce směrového kříže a hlavních tlačítek při držení modifikátoru nepřátelského cíle."})

-- Additional exact help-text variants rendered by build 70009.
-- Keep these as full-string matches only; do not loosen Settings scanning.
table.insert(E, {"While in a party, target specific party members with the directional pad rather than using it for directional targeting. One button becomes dedicated to party member 1, another for party member 2, and so on.", "Ve skupině můžeš směrovým křížem přímo vybírat konkrétní členy místo směrového zaměřování. Jedno tlačítko je vyhrazené pro člena skupiny 1, další pro člena 2 a tak dále."})

-- Exact wording published for the September 24 Gamepad options. The client can
-- use these descriptions or the shorter CVar-style variants above.
table.insert(E, {"Replaces the normal gamepad action bar layout with one that only shows the currently active action bar at any given time.", "Nahradí běžné rozložení akčních lišt gamepadu rozložením, které vždy zobrazuje jen právě aktivní akční lištu."})
table.insert(E, {"While in a non-raid party, rather than having the directional pad act as directions in the party interface, each button on the directional pad is assigned to a specific party member.", "V běžné skupině mimo raid nebude směrový kříž sloužit jako směry v rozhraní skupiny; každé jeho tlačítko bude přiřazeno konkrétnímu členovi skupiny."})
table.insert(E, {"Swaps sides of the friendly and hostile targeting modifiers, putting friendly targeting on the right and hostile on the left.", "Prohodí strany modifikátorů přátelského a nepřátelského cílení: přátelské cílení bude vpravo a nepřátelské vlevo."})
table.insert(E, {"Swaps the directional pad and face button actions when using the friendly targeting modifier.", "Při použití modifikátoru přátelského cílení prohodí akce směrového kříže a hlavních tlačítek."})
table.insert(E, {"Swaps the directional pad and face button actions when using the hostile targeting modifier.", "Při použití modifikátoru nepřátelského cílení prohodí akce směrového kříže a hlavních tlačítek."})
