-- Temporary bounded observation of the reported minimap quest tooltip.
-- No native text, font, geometry, tooltip data, quest APIs or settings are changed.
local _, A = ...
local limit, captures, attempts = 6, 0, 0
local hookedUpdate, hookedSetter, queued, elapsed = false, false, false, 0
local seen = {}
local function public(value)
 return A.Accessible(value)
end
local function text(value)
 if public(value) and type(value)=='string' then return value:sub(1,1200) end
end
local function number(value)
 if A.PublicNumber(value) then return value end
end
local function call(obj,key,...)
 if not public(obj) or not obj then return end
 local fn=obj[key]
 if not public(fn) or type(fn)~='function' then return end
 local ok,result=pcall(fn,obj,...)
 if ok and public(result) then return result end
end
local function capture(route)
 if not A.DB or captures>=limit or attempts>=120 then return end
 attempts=attempts+1
 local tip=_G.GameTooltip
 if not tip or call(tip,'IsForbidden')==true then return end
 local name=text(call(tip,'GetName'))
 local count=number(call(tip,'NumLines'))
 if not name or not count or count<1 or count>500 or count%1~=0 then return end
 local rows,parts={},{}
 for i=1,math.min(count,8) do
  local left=text(call(_G[name..'TextLeft'..i],'GetText'))
  local right=text(call(_G[name..'TextRight'..i],'GetText'))
  rows[i]={left=left,right=right}
  parts[#parts+1]=(left or '<unavailable>')..'\t'..(right or '')
 end
 local signature=table.concat(parts,'\n')
 if seen[signature] then return end
 seen[signature]=true;captures=captures+1
 local sample={route=route,tooltip=name,count=count,rows=rows}
 local owner=call(tip,'GetOwner')
 sample.owner=text(call(owner,'GetName'))
 sample.ownerIsUIParent=owner==_G.UIParent
 local info=call(tip,'GetProcessingTooltipInfo')
 if type(info)=='table' then
  sample.getter=text(info.getterName)
  sample.getterArgsAvailable=public(info.getterArgs) and type(info.getterArgs)=='table'
  local data=info.tooltipData
  if public(data) and type(data)=='table' then
   sample.dataType=number(data.type)
   local lines=data.lines
   if public(lines) and type(lines)=='table' then
    sample.input={}
    for i=1,8 do
     local row=lines[i]
     if not public(row) or type(row)~='table' then break end
     sample.input[i]={left=text(row.leftText),right=text(row.rightText),index=number(row.lineIndex),kind=number(row.type)}
    end
   end
  end
 end
 sample.questAPI={count=type(C_QuestLog and C_QuestLog.GetNumQuestLogEntries)=='function',info=type(C_QuestLog and C_QuestLog.GetInfo)=='function'}
 if sample.questAPI.count and sample.questAPI.info then
  local ok,n=pcall(C_QuestLog.GetNumQuestLogEntries)
  if ok and number(n) and n>=0 and n<=500 then
   sample.questCount=n;sample.quests={}
   for i=1,math.min(n,50) do
    local success,row=pcall(C_QuestLog.GetInfo,i)
    if success and public(row) and type(row)=='table' then
     local id=number(row.questID)
     if id and id>0 then
      local entry=A.QuestEntries and A.QuestEntries[id]
      sample.quests[#sample.quests+1]={id=id,title=text(row.title),dictionaryTitle=entry and text(entry.title)}
     end
    end
   end
  end
 end
 A.DB.minimapDiagnostic=A.DB.minimapDiagnostic or {version=A.Version,samples={}}
 local report=A.DB.minimapDiagnostic
 report.samples[#report.samples+1]=sample
end
local function observe(route)
 if captures>=limit or attempts>=120 then return end
 local now=GetTime and GetTime()
 if not number(now) or now<elapsed then return end
 elapsed=now+0.4
 pcall(capture,route)
 -- Compare one final render turn without starting a repeating timer.
 if C_Timer and C_Timer.After and not queued then
  queued=true
  C_Timer.After(0,function()
   queued=false
   local owner=call(_G.GameTooltip,'GetOwner')
   if owner==_G.UIParent and call(_G.GameTooltip,'IsShown') then pcall(capture,route..':deferred') end
  end)
 end
end
local function install(event)
 if not hookedUpdate and type(_G.Minimap_OnUpdate)=='function' then
  hooksecurefunc('Minimap_OnUpdate',function() observe('Minimap_OnUpdate') end)
  hookedUpdate=true
 end
 local tip=_G.GameTooltip
 if not hookedSetter and tip and type(tip.SetMinimapMouseover)=='function' then
  hooksecurefunc(tip,'SetMinimapMouseover',function() observe('SetMinimapMouseover') end)
  hookedSetter=true
 end
 if A.DB then
  if event=='PLAYER_LOGIN' then A.DB.minimapDiagnostic={version=A.Version,samples={}} end
  A.DB.minimapDiagnostic=A.DB.minimapDiagnostic or {version=A.Version,samples={}}
  A.DB.minimapDiagnostic.updateHook=hookedUpdate
  A.DB.minimapDiagnostic.setterHook=hookedSetter
 end
end
local frame=CreateFrame('Frame')
frame:RegisterEvent('ADDON_LOADED');frame:RegisterEvent('PLAYER_LOGIN')
frame:SetScript('OnEvent',function(_,event) pcall(install,event) end)
pcall(install)
