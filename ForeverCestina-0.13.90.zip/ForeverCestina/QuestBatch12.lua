local _, A = ...
-- Additive quest translations: 200 previously untranslated quest IDs present in the Forever quest dataset.
-- English source strings are kept verbatim; exact-match runtime leaves changed client variants in English rather than applying a stale translation.
local entries = {}

local function add(id, title, enDesc, csDesc, enObj, csObj)
    local e = { title = title }
    if enDesc and enDesc ~= "" then e.description = {enDesc, csDesc} end
    if enObj and enObj ~= "" then e.objectives = {enObj, csObj} end
    entries[id] = e
end

add(708, "The Black Box",
[[The surface of this metallic black box is heavily pitted, as if it had been immersed in acid - it must have been sitting in the giant condor's stomach for a long time.$B$BTurning the box over, a symbol is found stamped on its bottom.Below the symbol are the words:$B$B"Engine #19 - Ironforge Siege Brigade"]],
[[Povrch této kovové černé skříňky je silně naleptaný, jako by byla ponořena v kyselině — v žaludku obřího kondora musela ležet velmi dlouho.$B$BKdyž skříňku obrátíš, na spodní straně najdeš vyražený symbol. Pod ním stojí:$B$B„Motor č. 19 — Ironforge Siege Brigade“]],
[[Take the Corroded Black Box to the Hall of Arms in Ironforge.]],
[[Dones zkorodovanou černou skříňku do Hall of Arms v Ironforge.]])

add(709, "Solution to Doom",
[[Oh my!Oh my!There is a doom approaching.Mark me!A doom!$B$BNo, I cannot speak of it...cannot utter their names or they may hear me!But if we learn, yes, if we learn more of them...then maybe we can learn how to foil them!$B$BMaybe.$B$BGo into Uldaman.No!I said it!You must find...find the tablet of...Ryun'eh.Yes, find it!And don't make me speak that name again!$B$BIt is deep in that place, in an ancient chest.That's where it hides...in a chest crafted before the works of any dwarf.]],
[[Ach běda! Blíží se zkáza. Pamatuj má slova! Zkáza!$B$BNe, nesmím o tom mluvit... nesmím vyslovit jejich jména, jinak mě uslyší! Ale když se něco dozvíme, ano, když o nich zjistíme víc... možná přijdeme na to, jak je zastavit!$B$BMožná.$B$BVstup do Uldamanu. Ne! Už jsem to řekl! Musíš najít... tabulku... Ryun'eh. Ano, najdi ji! A nenuť mě to jméno vyslovit znovu!$B$BJe hluboko uvnitř, v prastaré truhle. Tam se skrývá... v truhle vyrobené dávno před díly kteréhokoli trpaslíka.]],
[[Bring the Tablet of Ryun'eh to Theldurin the Lost.]],
[[Přines tabulku Ryun'eh Theldurinovi the Lost.]])

add(710, "Study of the Elements: Rock",
[[Here in the Badlands I've stopped to work on my latest project: my shackles of elemental binding.$B$BWhen complete, they will allow mages to summon even more powerful elementals for use in even greater capacities. To start things off, I need small stone shards to test some of my newest offensive spells along with a few gizmos I've pieced together.$B$BThe shards are easily collected from the lesser rock elementals to the west of here. Could you bring me some?]],
[[Tady v Badlands jsem se zastavil, abych pracoval na svém nejnovějším projektu: poutech pro spoutání elementálů.$B$BAž budou hotová, umožní mágům vyvolávat ještě mocnější elementály a využívat je k mnohem náročnějším úkolům. Pro začátek potřebuji malé kamenné střepy, na kterých otestuji několik svých nejnovějších útočných kouzel a pár udělátek, která jsem sestavil.$B$BStřepy snadno získáš z menších skalních elementálů západně odsud. Přineseš mi nějaké?]],
[[Find 10 Small Stone Shards and bring them to Lotwil Veriatus in the Badlands.]],
[[Najdi 10 malých kamenných střepů a přines je Lotwilu Veriatusovi v Badlands.]])

add(711, "Study of the Elements: Rock",
[[$N, you've already proven more able than all my apprentices combined.$B$BThe next parts I need require a little more strength. Large stone slabs can be found on rock elementals if you're careful enough. Their bodies are stronger and larger, and therefore more prone to having pieces large enough for my tests. You can find them further west of here or southeast along the mountains' edges.$B$BTake your time; I'll need a while to test these smaller pieces you brought me.]],
[[$N, už jsi prokázal větší schopnosti než všichni moji učedníci dohromady.$B$BDalší součásti, které potřebuji, vyžadují trochu víc síly. Pokud budeš opatrný, můžeš na skalních elementálech najít velké kamenné desky. Jejich těla jsou větší a pevnější, takže se v nich častěji nacházejí kusy dost velké pro mé pokusy. Najdeš je dál na západ nebo jihovýchodně podél okrajů hor.$B$BNespěchej; testování těch menších kusů, které jsi přinesl, mi chvíli potrvá.]],
[[Bring 3 Large Stone Slabs to Lotwil Veriatus in the Badlands.]],
[[Přines 3 velké kamenné desky Lotwilu Veriatusovi v Badlands.]])

add(712, "Study of the Elements: Rock",
[[$N, there's one more part I need from the elementals here in the Badlands: the bracers of rock binding from the greater rock elementals. By my calculations, those bracers should be enough to gauge the strength of my own shackles.$B$BMy attempts at scrying the greater rock elementals showed a group of them southwest of here, near some ogres if I recall.$B$BBring me 5 of their bracers just so I have extras. Servo's notorious for misplacing my reagents and research.]],
[[$N, od zdejších elementálů v Badlands potřebuji ještě jednu věc: nátepníky skalního spoutání z větších skalních elementálů. Podle mých výpočtů by měly stačit k posouzení síly mých vlastních pout.$B$BPři věštění jsem zahlédl skupinu větších skalních elementálů jihozápadně odsud, tuším poblíž nějakých ogrů.$B$BPřines mi 5 jejich nátepníků, ať mám pár kusů navíc. Servo je proslulý tím, že ztrácí moje reagencie i výzkumné materiály.]],
[[Bring 5 Bracers of Rock Binding to Lotwil Veriatus in the Badlands.]],
[[Přines 5 nátepníků skalního spoutání Lotwilu Veriatusovi v Badlands.]])

add(713, "Coolant Heads Prevail",
[[Let me tell you something about Frost Oil: nothing can keep an engine or gears from overheating quite like it.$B$BIts cooling properties are extraordinary, and its longevity as a lubricant without equal. That's not all: it also aids in retaining enchantments on magical items.$B$BI need a vial of it to increase the magical capacity of my shackles and make them powerful enough to stop our summoned friend from killing us all.$B$BBro'kin, a goblin friend of mine, can teach you to make it. He's in Alterac.]],
[[Povím ti něco o mrazivý olej: nic nedokáže zabránit přehřátí motoru nebo ozubených kol tak dobře jako tenhle olej.$B$BJeho chladicí vlastnosti jsou mimořádné a jako mazivo vydrží bezkonkurenčně dlouho. A to není všechno: pomáhá také udržet očarování na magických předmětech.$B$BPotřebuji jednu lahvičku, abych zvýšil magickou kapacitu svých pout a učinil je dost silnými, aby náš vyvolaný přítel nezabil nás všechny.$B$BMůj gobliní přítel Bro'kin tě může naučit, jak ho vyrobit. Je v Alteracu.]],
[[Find Frost Oil and bring it to Lotwil Veriatus in Badlands.]],
[[Sežeň mrazivý olej a přines ho Lotwilu Veriatusovi v Badlands.]])

add(714, "Gyro... What?",
[[$N, you've done your job well beyond all standards.$B$B<Lotwil's obviously distracted by his work.>$B$BIf we ever meet in Kharanos, feel free to come apply for work.$B$BWhoops! Quick, grab the... yes, that. Thanks.$B$BNow I just need one more thing. It's a small part, but rather crucial, I'm afraid: a gyrochronatom.$B$BIf you could just go grab one and bring it to me, I should be ready to complete this.]],
[[$N, svou práci jsi zvládl daleko nad všechna očekávání.$B$B<Lotwil je očividně zcela zabrán do práce.>$B$BKdybychom se někdy potkali v Kharanosu, klidně se u mě ucházej o práci.$B$BJejda! Rychle, chyť... ano, tohle. Díky.$B$BTeď potřebuji už jen jednu věc. Je to malá součástka, ale obávám se, že naprosto zásadní: gyrochronatom.$B$BKdyž mi jeden seženeš a přineseš, měl bych být připraven všechno dokončit.]],
[[Bring a Gyrochronatom to Lotwil Veriatus in the Badlands.]],
[[Přines Lotwilu Veriatusovi v Badlands jeden gyrochronatom.]])

add(715, "Liquid Stone",
[[I'm thinking those items you acquired for Lotwil are going to be the least of our worries, $N. On the other hand, you've proven more than adept at the sciences Lotwil holds sacred, so how about helping me out?$B$BI need an invisibility potion and a healing potion; both might come in handy real soon if he pulls this off.$B$BIn return, I'll give you this recipe for a potion I've been developing while learning from Lotwil. It's based on some of the research he's been doing here in the Badlands.]],
[[Mám pocit, že věci, které jsi pro Lotwila sehnal, budou brzy tím nejmenším z našich problémů, $N. Na druhou stranu jsi prokázal, že se v Lotwilových milovaných vědách docela vyznáš, tak co kdybys pomohl i mně?$B$BPotřebuji lektvar neviditelnosti a léčivý lektvar. Pokud se mu to opravdu podaří, oba se nám mohou už brzy hodit.$B$BNa oplátku ti dám recept na lektvar, který vyvíjím při učení u Lotwila. Vychází z části výzkumu, který tu v Badlands provádí.]],
[[Bring a Healing Potion and a Lesser Invisibility Potion to Lucien Tosselwrench in the Badlands.]],
[[Přines léčivý lektvar a slabší lektvar neviditelnosti Lucienu Tosselwrenchovi v Badlands.]])

add(716, "Stone Is Better than Cloth",
[[I know how cheap Lotwil can be, $N, so let me make you something for all your troubles. Maybe it'll even help protect you from the coming atrocity that is Lotwil's newest invention.$B$BI've been working with all the extra stones you collected for him, and I can make some nice bracers that you might want to use. They're enchanted, of course.$B$BI'll just need patterned bronze bracers crafted by a blacksmith so I can complete the bracers I'm making for you.]],
[[Vím, jaký dokáže být Lotwil skrblík, $N, takže ti za všechnu tu námahu něco vyrobím. Možná tě to dokonce ochrání před pohromou, která se chystá v podobě jeho nejnovějšího vynálezu.$B$BPracuji se všemi těmi přebytečnými kameny, které jsi pro něj nasbíral, a dokážu z nich udělat pěkné nátepníky, které by se ti mohly hodit. Samozřejmě očarované.$B$BK jejich dokončení potřebuji už jen vzorované bronzové nátepníky vyrobené kovářem.]],
[[Bring some Patterned Bronze Bracers to Lucien Tosselwrench in the Badlands.]],
[[Přines Lucienu Tosselwrenchovi v Badlands vzorované bronzové nátepníky.]])

add(717, "Tremors of the Earth",
[[It has become obvious that we cannot ensure that Blacklash and Hematus will remain imprisoned in Lethlor. That black dragons have taken up residence there, and that the ogres managed to steal the Sign indicates that more drastic measures will have to be taken.$b$bThe drakes' prison is maintained by three runestones that may only be retrieved using the Sign of the Earth. Those runestones can then be used to break the seal which imprisons them.$b$b$n... assure that their dreams are eternal.]],
[[Je zřejmé, že nedokážeme zaručit, aby Blacklash a Hematus zůstali v Lethloru uvězněni. Černí draci se tam usadili a ogrům se dokonce podařilo ukrást Znamení země. Budeme muset přistoupit k ráznějším opatřením.$b$bVězení draků udržují tři runové kameny, které lze získat pouze pomocí Znamení země. Těmito kameny pak můžeš prolomit pečeť, jež je drží uvězněné.$b$b$n... zajisti, aby jejich spánek byl věčný.]],
[[Use the Sign of the Earth to activate the Pillars of Amethyst, Opal, and Diamond and obtain the Runestones.$b$bPlace the runestones in the Seal of the Earth to free Blacklash and Hematus.$b$bSlay them and return Blacklash's Bindings, the Chains of Hematus, and the Sign of the Earth to Garek.]],
[[Pomocí Znamení země aktivuj Ametystový pilíř, Opal a Diamond a získej runové kameny.$b$bVlož runové kameny do Pečeť země a osvoboď Blacklashe a Hematuse.$b$bZabij je a přines Blacklashova pouta, Hematovy řetězy a Znamení země Garekovi.]])

add(718, "Mirages",
[[In our hurry to leave the Uldaman excavation site, we were forced to abandon many wagons and crates of supplies along the way. The local ogres from Camp Kosh have been on our abandoned equipment like vultures on a rotting corpse. Don't smell much better, either. Than the corpses, I mean.$b$bAnyways, they took the cart that was carrying all our weapons and such... so--well, this is a bit embarrassing--we haven't been able to get any food.$b$bWe're in a bit of a pickle here, suppose you could help us out?]],
[[Při spěšném odchodu z vykopávek v Uldamanu jsme museli cestou opustit spoustu vozů a beden se zásobami. Místní ogři z Camp Kosh se na naše vybavení vrhli jako supi na hnijící mrtvolu. A o moc lépe ani nevoní. Myslím než ty mrtvoly.$b$bKaždopádně odvezli vůz se všemi našimi zbraněmi a podobně... takže — je to trochu trapné — si teď nedokážeme opatřit ani jídlo.$b$bJsme tu v pěkné kaši. Pomohl bys nám?]],
[[Retrieve the Supply Crate for Sigrun Ironhew.]],
[[Získej bednu se zásobami pro Sigrun Ironhew.]])

add(719, "A Dwarf and His Tools",
[[Hey, $N. Be careful 'round here. There be Dark Iron dwarves all around--looked like the Shadowforge clan.$B$BThey just attacked the excavation site I was workin' at--killed nearly everyone there, including my boss Hammertoe. I barely escaped with me life.$B$BThe site's just to the north of here, and I'm tryin' to plan a way to get some of our supplies back, especially me lucky pick.$B$BThink you'd be up to helpin' me out some? One of those damned Dark Iron must have my pick! Could be anyone of them.]],
[[Hej, $N. Tady kolem buď opatrný. Všude jsou trpaslíci Dark Iron, podle všeho klan Shadowforge.$B$BPrávě napadli naleziště, kde jsem pracoval. Zabili skoro všechny, včetně mého šéfa Hammertoea. Já jsem jen tak tak vyvázl živý.$B$BNaleziště je kousek severně odsud a já se snažím vymyslet, jak získat zpět alespoň část zásob, hlavně svůj šťastný krumpáč.$B$BPomohl bys mi? Jeden z těch zatracených Dark Iron ho určitě má! Může to být kterýkoli z nich.]],
[[Find Ryedol's Lucky Pick and return it to Prospector Ryedol south of Hammertoe's Dig Site.]],
[[Najdi Ryedolův šťastný krumpáč a vrať ho Prospectoru Ryedolovi jižně od Hammertoe's Dig Site.]])

add(720, "A Sign of Hope",
[[<There is text roughly scribbled in chalk on the map.>$B$B"Ryedol, $BThey're taking me to Uldaman. Send help.$B-Hammertoe"]],
[[<Na mapě je křídou nahrubo načmáraný text.>$B$B„Ryedole,$Bvedou mě do Uldamanu. Pošli pomoc.$B— Hammertoe“]],
[[Find Prospector Ryedol and let him know Hammertoe Grez is alive.]],
[[Najdi Prospectora Ryedola a řekni mu, že Hammertoe Grez žije.]])

add(721, "A Sign of Hope",
[[$N, can ye find him? Can you find Hammertoe in Uldaman?$B$BIf those dirty Shadowforge are holdin' him hostage to figure out what he knows about the titan excavations, then all of Ironforge could be in huge trouble.$B$BFor a long time now those Dark Irons have been lookin' for magics to make more powerful golems. Hammertoe was doin' the same, of course, but only to stop them.$B$BThey're probably keepin' him alive until they learn what he knows.Ye've got to hurry if you're gonna save him!]],
[[$N, dokážeš ho najít? Najdeš Hammertoea v Uldamanu?$B$BJestli ho ti špinaví Shadowforge drží jako rukojmí, aby z něj vytáhli, co ví o vykopávkách titánů, může být celý Ironforge ve velkém nebezpečí.$B$BDark Iron už dlouho hledají magii, která by jim umožnila vyrábět mocnější golemy. Hammertoe dělal totéž, samozřejmě jen proto, aby je dokázal zastavit.$B$BNejspíš ho nechají naživu jen do chvíle, než z něj dostanou všechno, co ví. Jestli ho chceš zachránit, musíš si pospíšit!]],
[[Find Hammertoe Grez in Uldaman.]],
[[Najdi Hammertoea Greze v Uldamanu.]])

add(722, "Amulet of Secrets",
[[Ye're brave... <cough>... to come into Uldaman fer me, $c.$B$BIf ye're really here to help... ol' Hammertoe, then... <cough>... you'll need to find... me amulet.$B$BDeepshadow's got it... Magregan Deepshadow. He's 'round here... in the ruins fer sure. That amulet'll lead 'em... <cough>...right to the scrolls if he ain't stopped. It's up to you, $N. Please... get that amulet.$B$BThe scrolls will surely help the Dark Irons create even more powerful golems. I just know it. I can feel it in me bones.]],
[[Jsi statečný... <kašel>... že jsi kvůli mně přišel až do Uldamanu, $c.$B$BJestli jsi opravdu přišel pomoct... starému Hammertoeovi, pak... <kašel>... musíš najít... můj amulet.$B$BMá ho Deepshadow... Magregan Deepshadow. Určitě se potlouká někde tady... v ruinách. Ten amulet je dovede... <kašel>... přímo ke svitkům, pokud ho někdo nezastaví. Je to na tobě, $N. Prosím... získej ten amulet.$B$BSvitky Dark Ironům určitě pomohou vytvořit ještě mocnější golemy. Prostě to vím. Cítím to v kostech.]],
[[Find Hammertoe's Amulet and return it to him in Uldaman.]],
[[Najdi Hammertoeův amulet a vrať mu ho v Uldamanu.]])

add(723, "Prospect of Faith",
[[<Hammertoe holds his wounds and takes a moment to regain his composure before speaking again.>$B$BFind Ryedol, $N. Bring 'im me amulet. <cough cough> He'll... <cough> figure out what to do. He knows I was seeking the origins of our people, and he... <cough>... knows it was also my mission to stop the Shadowforge clan. They must not be allowed to find the scrolls... <cough>]],
[[<Hammertoe si drží rány a chvíli nabírá síly, než znovu promluví.>$B$BNajdi Ryedola, $N. Dones mu můj amulet. <kašel, kašel> On... <kašel> bude vědět, co dělat. Ví, že jsem pátral po původu našeho lidu, a... <kašel>... také ví, že mým úkolem bylo zastavit klan Shadowforge. Nesmějí najít ty svitky... <kašel>]],
[[Take Hammertoe's Amulet to Prospector Ryedol in the Badlands.]],
[[Dones Hammertoeův amulet Prospectoru Ryedolovi v Badlands.]])

add(724, "Prospect of Faith",
[[Okay, okay... who would know what to do?$B$BHistorian Karnik! That's it!$B$BHe's in Ironforge. He'll be able to help. He and Hammertoe were workin' together to find the lost artifacts in Uldaman.$B$BGuess the Shadowforge found out the two of them knew more than they were lettin' on.$B$BTell Karnik what's happened to Hammertoe and give him the amulet--he'll tell you what needs to be done next.]],
[[Dobře, dobře... kdo by mohl vědět, co dál?$B$BHistorian Karnik! To je ono!$B$BJe v Ironforge. Bude umět pomoct. S Hammertoeem společně hledali ztracené artefakty v Uldamanu.$B$BShadowforge zřejmě zjistili, že ti dva vědí víc, než dávali najevo.$B$BŘekni Karnikovi, co se stalo Hammertoeovi, a dej mu amulet. Poví ti, co musíš udělat dál.]],
[[Take Hammertoe's Amulet to Historian Karnik in Ironforge.]],
[[Dones Hammertoeův amulet Historianu Karnikovi do Ironforge.]])

add(725, "Passing Word of a Threat",
[[$N, run and find Advisor Belgrum as quickly as you can. Tell him what you've witnessed and ask him how he wants us to proceed. This note will explain more to him.$B$BIn the meantime, I will take the time to speak to Hammertoe's spirit. Maybe he knows something that will help us put a stop to those Shadowforge cretins' activities in the Badlands. We can only pray.]],
[[$N, co nejrychleji najdi Advisora Belgruma. Řekni mu, čeho jsi byl svědkem, a zeptej se, jak máme pokračovat. Tato zpráva mu vysvětlí další podrobnosti.$B$BMezitím se pokusím promluvit s Hammertoeovým duchem. Třeba ví něco, co nám pomůže zastavit činnost těch pitomců ze Shadowforge v Badlands. Nezbývá než doufat.]],
[[Find Advisor Belgrum and give him his note.]],
[[Najdi Advisora Belgruma a předej mu jeho zprávu.]])

add(726, "Passing Word of a Threat",
[[<Advisor Belgrum reaches the end of the note, and his eyes widen for a moment.>$B$BOch, these are evil tidings.$B$B$N, please return to Historian Karnik and tell him on the king's authority to act on this information swiftly and decisively. He must halt the Shadowforge's activities in the Badlands.]],
[[<Advisor Belgrum dočte zprávu a na okamžik vytřeští oči.>$B$BOch, to jsou zlé zprávy.$B$B$N, vrať se prosím k Historianu Karnikovi a jménem krále mu nařiď, aby na tyto informace reagoval rychle a rozhodně. Musí zastavit činnost Shadowforge v Badlands.]],
[[Speak to Historian Karnik.]],
[[Promluv s Historianem Karnikem.]])

add(727, "To Ironforge for Yagyin's Digest",
[[The Tablet tells much.But not enough!Not nearly enough!$B$BThere is a book, a digest that Yagyin wrote in ages past.The ... people I fled ... they keep this book in many places.And their most learned study it.It holds vast knowledge.Knowledge to protect us!$B$BGo to Gerrig Bonegrip.He is in a shop in Ironforge, in the Forlorn Cavern.Show him this sigil and he'll think you one of them.Ask him for Yagyin's Digest ... and bring it to me!]],
[[Tabulka toho říká mnoho. Ale ne dost! Ani zdaleka ne dost!$B$BExistuje kniha, souhrn, který Yagyin sepsal před dávnými věky. Ti... lidé, před nimiž jsem utekl... mají tuto knihu na mnoha místech. A jejich největší učenci ji studují. Ukrývá ohromné vědění. Vědění, které nás může ochránit!$B$BJdi za Gerrigem Bonegripem. Je v obchodě v Ironforge, ve Forlorn Cavern. Ukaž mu tuto pečeť a bude tě považovat za jednoho z nich. Požádej ho o Yagyinův spis... a přines mi ho!]],
[[Give the Sigil of the Hammer to Gerrig Bonegrip in the Forlorn Cavern of Ironforge.]],
[[Předej Pečeť kladiva Gerrigu Bonegripovi ve Forlorn Cavern v Ironforge.]])

add(728, "To the Undercity for Yagyin's Digest",
[[The tablet tells much.But not enough!Not nearly enough!$B$BThere is a book, a digest that Yagyin wrote in ages past.The... people I fled from... they keep this book in many places.And their most learned study it.It holds vast knowledge.Knowledge to protect us!$B$BGo to Keeper Bel'dugur in the Undercity of Lordaeron.Show him this sigil and he'll think you one of them.Ask him for Yagin's Digest...and bring it to me!]],
[[Tabulka toho říká mnoho. Ale ne dost! Ani zdaleka ne dost!$B$BExistuje kniha, souhrn, který Yagyin sepsal před dávnými věky. Ti... lidé, před nimiž jsem utekl... mají tuto knihu na mnoha místech. A jejich největší učenci ji studují. Ukrývá ohromné vědění. Vědění, které nás může ochránit!$B$BJdi za Keeperem Bel'dugurem do Undercity of Lordaeron. Ukaž mu tuto pečeť a bude tě považovat za jednoho z nich. Požádej ho o Yagyinův spis... a přines mi ho!]],
[[Bring the Sigil of the Hammer to Keeper Bel'dugur in the Undercity.]],
[[Přines Pečeť kladiva Keeperu Bel'dugurovi do Undercity.]])

add(732, "Tremors of the Earth",
[[I heard from Sigrun that you have been a great help to him. Perhaps I might enlist your help. I was sent here by my master, Krasus of the Kirin Tor, to put an end to the trouble brewing in Lethlor Ravine.$b$bI cannot divulge the exact nature of my assignment here or the tasks that I must undertake, but be assured it is of vital importance.$b$bA band of wandering ogres, sometimes seen near Camp Boff, stole an object called the Sign of the Earth; I must have it. Bring it to me, and I will tell you more.]],
[[Od Sigruna jsem slyšel, že jsi mu velmi pomohl. Možná bych mohl využít tvé služby i já. Můj mistr Krasus z Kirin Tor mě sem poslal, abych ukončil potíže, které se schylují v Lethlor Ravine.$b$bPřesnou povahu svého úkolu ani to, co musím vykonat, ti nemohu prozradit, ale věř, že jde o mimořádně důležitou věc.$b$bSkupina potulných ogrů, které lze občas spatřit poblíž Camp Boff, ukradla předmět zvaný Znamení země. Musím ho získat. Přines mi ho a povím ti víc.]],
[[Retrieve the Sign of the Earth for Garek.]],
[[Získej Znamení země pro Gareka.]])

add(733, "Scrounging",
[[It's going to be tough going here if I can't manage to scrounge up some materials to construct some defenses and other necessities. I've noticed that the ogres in the area seem to be well equipped with scrap metal. Maybe the stories of siege engines in the Badlands weren't so far off after all...$b$bAnyways, the Prospector's been getting worried about the state of our little camp, so I'd like to get working soon if I can.$b$bThe main ogre camp is at Dustbelch Grotto, a good trek to the west of here.]],
[[Jestli neseženu nějaký materiál na obranu a další nezbytnosti, budeme to tady mít těžké. Všiml jsem si, že místní ogři mají spoustu kovového šrotu. Možná tedy historky o obléhacích strojích v Badlands nebyly tak přehnané...$b$bProspector začíná mít obavy o stav našeho malého tábora, takže bych se rád co nejdřív pustil do práce.$b$bHlavní tábor ogrů je v Dustbelch Grotto, pořádný kus cesty západně odsud.]],
[[Get 7 pieces of Scrap Metal for Sigrun.]],
[[Sežeň pro Sigruna 7 kusů kovového šrotu.]])

add(734, "This Is Going to Be Hard",
[[Wonderful, wonderful.$B$B<Lotwil looks up at you for a moment before going back to his shackles.>$B$BGo speak to Lucien, $N. I need a cog #5. Bring it to me, will you?]],
[[Výborně, výborně.$B$B<Lotwil na tebe na okamžik pohlédne a pak se znovu skloní ke svým poutům.>$B$BZajdi za Lucienem, $N. Potřebuji ozubené kolo č. 5. Přineseš mi ho?]],
[[Speak to Lucien Tosselwrench in the Badlands.]],
[[Promluv s Lucienem Tosselwrenchem v Badlands.]])

add(735, "The Star, the Hand and the Heart",
[[Yagyin's Digest, eh?Are you starting a new chapter of us, somewhere?Never mind, it is not my place to ask.$B$BI will help you, for I have an extra copy.We must aid each other, yes?That is how we flourish.$B$BI require three items of power.Bring them to me and I will give you the digest.$B$BI will not speak their names.Ears may be on us.But here, I will write them down.]],
[[Yagyinův spis, hm? Zakládáš někde novou kapitulu našeho řádu? Ale nic, není mou věcí se ptát.$B$BPomohu ti, protože mám jednu kopii navíc. Musíme si přece navzájem pomáhat, ano? Jen tak můžeme prospívat.$B$BPotřebuji tři mocné předměty. Přines mi je a souhrn bude tvůj.$B$BJejich jména nevyslovím. Někdo by mohl naslouchat. Tady, raději ti je napíšu.]],
[[Return the items on the Bonegrip's Note to Gerrig Bonegrip in Ironforge.]],
[[Přines Gerrigu Bonegripovi v Ironforge předměty uvedené na Bonegripova poznámka.]])

add(736, "The Star, the Hand and the Heart",
[[You need Yagyin's Digest?Your plan, then, is to gather another flock?Of course it is...and of course I will help you, $gbrother:sister;.$B$BBut you must help me too.$B$BI require three items of power.Bring me these and the digest will be yours.$B$BI cannot utter the names of these items, but I will write them down.$B$BGet me the items on this list.If you can do that, then you are truly worthy of opening your own chapter of our order.]],
[[Potřebuješ Yagyinův spis? Chystáš se tedy shromáždit další skupinu? Samozřejmě... a samozřejmě ti pomohu, $gbratře:sestro;.$B$BAle ty musíš pomoci mně.$B$BPotřebuji tři mocné předměty. Přines mi je a souhrn bude tvůj.$B$BJejich jména nemohu vyslovit, ale napíšu ti je.$B$BPřines mi předměty z tohoto seznamu. Pokud to dokážeš, pak jsi opravdu hoden založit vlastní kapitulu našeho řádu.]],
[[Bring the items on Bel'dugur's Note to Keeper Bel'dugur in the Undercity.]],
[[Přines Keeperu Bel'dugurovi v Undercity předměty uvedené na Bel'dugurova poznámka.]])

add(737, "Forbidden Knowledge",
[[I have the digest for you, $N.I need not tell you to take great care with it.And to keep it far from unfriendly hands.$B$BThis book holds many truths...$B$B...And the truth can burn.]],
[[Mám pro tebe ten souhrn, $N. Nemusím ti snad říkat, že s ním musíš zacházet velmi opatrně a držet ho daleko od nepovolaných rukou.$B$BTato kniha ukrývá mnoho pravd...$B$B...a pravda může pálit.]],
[[Bring Yagyin's Digest to Theldurin.]],
[[Přines Yagyinův spis Theldurinovi.]])

add(738, "Find Agmond",
[[Prospector Agmond was in charge of our excavation sites in the Badlands, to the southwest.I say "was" because...well, I haven't heard from him in weeks.I need you to find Agmond so I can get his report.$B$BLast I heard Agmond was at the southernmost dig site in the Badlands--a tiny operation past the Angor Fortress.I'd start your search for him there.]],
[[Prospector Agmond měl na starosti naše vykopávky v Badlands na jihozápadě. Říkám „měl“, protože... už několik týdnů o něm nemám žádné zprávy. Potřebuji, abys Agmonda našel a přinesl mi jeho hlášení.$B$BNaposledy jsem slyšel, že byl na nejjižnějším nalezišti v Badlands, na malém pracovišti za Angor Fortress. Začal bych ho hledat tam.]],
[[Find Agmond.]],
[[Najdi Agmonda.]])

add(739, "Murdaloc",
[[Agmond's tracks lead from the west.It is easy to tell from the bloody smears across rock and sand that the dwarf crawled some distance.$B$BAnd here he died.$B$BUpon close inspection, the word "Murdaloc" is roughly scrawled in a patch of Badlands sandstone.$B$BScrawled next to Agmond's dead hand.]],
[[Agmondovy stopy vedou ze západu. Podle krvavých šmouh na kamenech a písku je zřejmé, že trpaslík urazil plazením pořádný kus cesty.$B$BA tady zemřel.$B$BPři bližším pohledu si všimneš, že v pískovci Badlands je hrubě vyškrábané slovo „Murdaloc“.$B$BHned vedle Agmondovy mrtvé ruky.]],
[[Slay Agmond's killer, Murdaloc.$B$BSlay 12 Stonevault Bonesnappers.$B$BReport to Prospector Ironband in Loch Modan.]],
[[Zabij Agmondova vraha Murdaloca.$B$BZabij 12 Stonevault Bonesnapperů.$B$BPodej hlášení Prospectoru Ironbandovi v Loch Modan.]])

add(762, "An Ambassador of Evil",
[[Ambassador Infernus was sent to Angor Fortress by Ragnaros himself to mind the Shadowforge seeking lost artifacts in Uldaman.$B$BIt has already meant tremendous casualties for our people, but it has obviously grown worse. I hesitate to guess how many artifacts they would be able to find and use against Ironforge.$B$BOur goal is simple, $c. Return to the Badlands and destroy Ambassador Infernus. Once the threat is eliminated, return to Advisor Belgrum with proof of your victory.$B$BIt is in your hands now.]],
[[Ambassadora Infernuse vyslal do Angor Fortress sám Ragnaros, aby dohlížel na Shadowforge při hledání ztracených artefaktů v Uldamanu.$B$BUž teď to našemu lidu způsobilo strašlivé ztráty a situace se očividně zhoršuje. Nechci ani pomyslet, kolik artefaktů by mohli najít a použít proti Ironforge.$B$BNáš cíl je prostý, $c. Vrať se do Badlands a znič Ambassadora Infernuse. Až hrozbu odstraníš, vrať se k Advisoru Belgrumovi s důkazem vítězství.$B$BTeď je to na tobě.]],
[[Kill Ambassador Infernus in Angor Fortress and bring proof of his death to Advisor Belgrum in Ironforge.]],
[[Zabij Ambassadora Infernuse v Angor Fortress a přines Advisoru Belgrumovi v Ironforge důkaz jeho smrti.]])

add(777, "This Is Going to Be Hard",
[[Okay, here you go.$B$BI'm going to be over here... behind cover.$B$BFeel free to join me.]],
[[Dobře, tady to máš.$B$BJá budu támhle... schovaný za krytem.$B$BKlidně se ke mně přidej.]],
[[Bring Cog #5 to Lotwil Veriatus.]],
[[Přines ozubené kolo č. 5 Lotwilu Veriatusovi.]])

add(778, "This Is Going to Be Hard",
[[Haha! Done! The shackles are done!$B$BIt's time, Lucien. It's time, Servo!$B$BAre you ready to bear witness to the perfect blend of alchemy, engineering, and the arcane, $N?$B$BI shall summon forth a powerful elemental now. This is a groundbreaking day for all of us.]],
[[Haha! Hotovo! Pouta jsou hotová!$B$BJe čas, Luciene. Je čas, Servo!$B$BJsi připraven stát se svědkem dokonalého spojení alchymie, inženýrství a magie, $N?$B$BTeď vyvolám mocného elementála. Pro nás všechny je to přelomový den.]],
[[Defeat the Fam'retor Guardian and bring Lotwil's Shackles of Elemental Binding back to Lotwil Veriatus.]],
[[Poraz Fam'retor Guardiana a vrať Lotwilova pouta živlového spoutání Lotwilu Veriatusovi.]])

add(782, "Broken Alliances",
[[From the Horde's alliance with the dragon Deathwing during the Second War, we know that two of his lieutenants, Blacklash and Hematus, were imprisoned within Lethlor Ravine far to the east. We must silence our depraved allies of old to restore honor to the Horde!$B$BWe hired Tho'grun and his band of ogre mercenaries to help us obtain the Sign of the Earth, a key needed to unlock the drakes' prison. Tho'grun betrayed us though, overwhelming us and taking it for himself. Go to Camp Boff and take it back!]],
[[Z dob spojenectví Hordy s drakem Deathwingem během Druhé války víme, že dva z jeho poručíků, Blacklash a Hematus, byli uvězněni v Lethlor Ravine daleko na východě. Abychom Hordě vrátili čest, musíme své zkažené někdejší spojence umlčet!$B$BNajali jsme Tho'gruna a jeho skupinu ogřích žoldnéřů, aby nám pomohli získat Znamení země, klíč potřebný k otevření dračího vězení. Tho'grun nás však zradil, přemohl a znamení si ponechal. Vydej se do Camp Boff a získej ho zpět!]],
[[Kill Boss Tho'grun and bring the Sign of the Earth to Gorn in Kargath.]],
[[Zabij Bosse Tho'gruna a přines Znamení země Gornovi do Kargathu.]])

add(793, "Broken Alliances",
[[The Seal of the Earth is held by three runestones, held in the Pillars of Diamond, Opal, and Amethyst in Lethlor Ravine. Using the Sign of the Earth, you will be able to remove the runestones and unlock the Seal of the Earth.$b$bBe wary though, $n, the black drakes Blacklash and Hematus are not to be trifled with. See them dead and return their bindings to me.$B$BTo reach the ravine, travel to the far eastern part of the Badlands.Be careful though, for the ravine is home to countless drakes.]],
[[Pečeť země drží tři runové kameny uložené v Diamantový pilíř, Opal a Amethyst v Lethlor Ravine. Pomocí Znamení země můžeš runové kameny vyjmout a odemknout pečeť.$b$bBuď ale opatrný, $n. Černí draci Blacklash a Hematus nejsou protivníci, které by bylo radno podcenit. Zabij je a přines mi jejich pouta.$B$BK rokli se dostaneš, když zamíříš do nejvýchodnější části Badlands. Dávej pozor, rokle je domovem nespočtu draků.]],
[[Use the Sign of the Earth to activate the Pillars of Diamond, Opal, and Amethyst and obtain the Runestones.$b$bPlace the runestones in the Seal of the Earth to free Blacklash and Hematus.$b$bSlay them and return Blacklash's Bindings, the Chains of Hematus, and the Sign of the Earth to Gorn.]],
[[Pomocí Znamení země aktivuj Diamantový pilíř, Opal a Amethyst a získej runové kameny.$b$bVlož runové kameny do Pečeť země a osvoboď Blacklashe a Hematuse.$b$bZabij je a přines Blacklashova pouta, Hematovy řetězy a Znamení země Gornovi.]])

add(813, "Finding the Antidote",
[[Venomtails are some of the deadliest scorpids in Durotar. It was unwise for Rhinag to hunt them without having some of the antidote with him, but right now, chastising is the last thing he needs.$B$BBring me a few venomtail poison sacs from any of the venomtails near the entrance of Orgrimmar and I'll make an antidote for him.$B$BMake haste, $N. One of our own needs your help.]],
[[Venomtailové patří k nejsmrtelnějším škorpiónům v Durotaru. Od Rhinaga nebylo moudré lovit je bez protijedu, ale teď opravdu není čas ho kárat.$B$BPřines mi několik jedových váčků z venomtailů poblíž vstupu do Orgrimmaru a připravím mu protijed.$B$BPospěš si, $N. Jeden z našich potřebuje tvou pomoc.]],
[[Bring 4 Venomtail Poison Sacs to Kor'ghan in Orgrimmar.]],
[[Přines Kor'ghanovi v Orgrimmaru 4 jedové váčky Venomtail.]])

add(822, "Chen's Empty Keg",
[[Good stuff, that stormstout, huh?$B$BI have another recipe that I learned from Chen. Would you be interested? It won't take long to make, and it might be useful if you plan on adventuring some more.$B$BBring me 5 lightning glands from any stormhide, 1 thunderhawk saliva gland from greater thunderhawks, and a kodo liver from any of the Barrens' kodos.$B$BLike I said, this stuff has kick; it's the trogg brew that I mentioned to you before.]],
[[Ten stormstout je dobrá věc, co?$B$BMám ještě jeden recept, který jsem se naučil od Chena. Máš zájem? Výroba nezabere dlouho a pokud chceš dál cestovat za dobrodružstvím, mohl by se ti hodit.$B$BPřines mi 5 bleskových žláz ze stormhidů, 1 slinnou žlázu greater thunderhawka a kodo játra z kteréhokoli koda v Barrens.$B$BJak jsem říkal, tahle věc má pořádný říz. Je to ten troggský nápoj, o kterém jsem se už zmiňoval.]],
[[Bring 5 Lightning Glands, 1 Thunderhawk Saliva Gland and 1 Kodo Liver to Brewmaster Drohn in Ratchet.]],
[[Přines Brewmasteru Drohnovi v Ratchet 5 bleskové žlázy, 1 slinná žláza thunderhawka a 1 játra koda.]])

add(824, "Je'neu of the Earthen Ring",
[[The Earthen Ring is a shamanistic group dedicated to studying and preserving the elements.They have forgotten more about crazy old gods, ancient legends and lore than most scholars will ever know.$B$BLucky for you, I know someone in the Earthen Ring here in Ashenvale.Head over to Zoram'gar Outpost on the coast of the Zoram Strand; show Je'neu Sancrea what you found.If anyone can figure out that globe's significance, it'd be him.]],
[[Earthen Ring je šamanská skupina zasvěcená studiu a ochraně živlů. O šílených starých bozích, dávných legendách a vědění už zapomněli víc, než se většina učenců kdy dozví.$B$BNaštěstí pro tebe znám jednoho člena Earthen Ring přímo tady v Ashenvale. Vydej se do Zoram'gar Outpost na pobřeží Zoram Strand a ukaž Je'neu Sancreovi, co jsi našel. Jestli někdo dokáže zjistit význam té koule, bude to on.]],
[[Bring the Befouled Water Globe to Je'neu Sancrea at Zoram'gar Outpost, Ashenvale.]],
[[Přines koule znečištěné vody Je'neu Sancreovi do Zoram'gar Outpost v Ashenvale.]])

add(836, "Rescue OOX-09/HL!",
[[The gnome's voice crackles once again from the robot:$B$B"I need to move OOX-09/HL to an open, safe place so it can begin a lengthy take-off procedure.It has built-in cloaking, but I need time on my end to make it operational again.Escort the robot from its current location to, let's say, the shoreline beyond Overlook Cliff!That should be a perfect place, and long enough, to get things online!"$B$B"Escort it safely to the shore, and then come talk to me in Booty Bay!Oglethorpe Obnoticus - out!"]],
[[Z robota znovu zapraská hlas gnóma:$B$B„Potřebuji dostat OOX-09/HL na otevřené a bezpečné místo, aby mohl zahájit zdlouhavou proceduru vzletu. Má zabudované maskování, ale potřebuji čas, abych ho znovu uvedl do provozu. Doprovod robota z jeho současné polohy třeba až na pobřeží za Overlook Cliff! To by mělo být ideální místo a cesta dost dlouhá na to, abych všechno zprovoznil!“$B$B„Doprovod ho bezpečně k pobřeží a pak za mnou přijď do Booty Bay! Oglethorpe Obnoticus — konec!“]],
[[Escort OOX-09/HL to the shoreline beyond Overlook Cliff, then report to Oglethorpe Obnoticus in Booty Bay.]],
[[Doprovod OOX-09/HL na pobřeží za Overlook Cliff a poté podej hlášení Oglethorpeovi Obnoticusovi v Booty Bay.]])

add(838, "Scholomance",
[[On the island of Caer Darrow lies Scholomance - a school that serves as a stronghold for the Scourge.Our enemy dwells within, safely allowed to pursue research that strengthens their power.A door bars the way, and try as we might no entry is to be had without a proper key.$B$BApothecary Dithers is well versed on Scholomance, and has an idea how to obtain a key.You have proved your value to me as someone who can get things done; I now entrust this task to you.Speak with him on this matter.]],
[[Na ostrově Caer Darrow stojí Scholomance — škola, která slouží jako pevnost Scourge. Náš nepřítel se uvnitř bezpečně věnuje výzkumu, jenž posiluje jeho moc. Cestu blokují dveře a bez správného klíče se dovnitř nedostaneme, ať se snažíme sebevíc.$B$BApothecary Dithers zná Scholomance velmi dobře a má představu, jak klíč získat. Prokázal jsi mi, že umíš dotahovat věci do konce, proto ti tento úkol svěřuji. Promluv s ním.]],
[[Speak with Apothecary Dithers at the Bulwark, Western Plaguelands.]],
[[Promluv s Apothecary Dithersem v Bulwarku ve Western Plaguelands.]])

add(841, "Another Power Source?",
[[Let me guess - you didn't get whatever world-ending, nefarious deed you were doing done in time.No wait, better still... you dropped it in the sand!Well, whatever the reason, I do have additional power sources I will sell to you.This time, however, it will cost you ten, YES TEN Wastewander Water Pouches!$B$BTimes are tough all around, $n, and power sources don't grow on trees!Hrm, but what if they did.Maybe we could MAKE a power source tree...]],
[[Nech mě hádat — nestihl jsi včas dokončit to své nekalé dílo, které mělo zničit svět. Ne, počkej, ještě lépe... upustil jsi to do písku! Ať už je důvod jakýkoli, mám další zdroje energie, které ti můžu prodat. Tentokrát tě to ale bude stát deset, ANO DESET měchy s vodou nomádů Wastewander!$B$BČasy jsou těžké pro všechny, $n, a zdroje energie nerostou na stromech! Hm... ale co kdyby rostly? Možná bychom mohli VYROBIT strom na zdroje energie...]],
[[Bring 10 Wastewander Water Pouches to Chief Engineer Bilgewhizzle in Gadgetzan in exchange for another power source.]],
[[Přines Chief Engineeru Bilgewhizzleovi v Gadgetzanu 10 měchy s vodou nomádů Wastewander výměnou za další zdroj energie.]])

add(847, "Guile of the Raptor",
[[This... this power.... Is this the power of the shamans that Tor'gan tried to show me? I must say, it is interesting. Tell Tor'gan that he has convinced me... for the time being. I will listen to what he has to say.]],
[[Ta... ta síla... Je tohle moc šamanů, kterou se mi Tor'gan snažil ukázat? Musím uznat, že je to zajímavé. Řekni Tor'ganovi, že mě přesvědčil... prozatím. Vyslechnu si, co mi chce říct.]],
[[Speak with Tor'gan.]],
[[Promluv s Tor'ganem.]])

add(857, "The Tear of the Moons",
[[The power was mine! In my very hands! And I want it back! Back I say!$b$bThose dirty excavators uncovered it... so beautiful it was. Deemed the Tear of the Moons, it was the first great discovery we made at Bael Modan.$b$bIt should have been mine! Mine I say!$b$bGeneral Twinbraid grew jealous of the power it gave me. He locked it away in the Keep. Called it cursed, he did! The fool!$b$bOthers wanted it and they had to be stopped! That bastard Twinbraid drove me off.$b$bNow I want it back. Back I say!]],
[[Ta moc byla moje! Držel jsem ji ve vlastních rukou! A chci ji zpátky! Zpátky, povídám!$b$bTi špinaví kopáči ji odkryli... byla nádherná. Říkali jí Slza měsíců a byla prvním velkým objevem, který jsme v Bael Modan učinili.$b$bMěla být moje! Moje, povídám!$b$bGeneral Twinbraid začal žárlit na moc, kterou mi dávala. Zamkl ji v pevnosti. Prohlásil ji za prokletou! Ten hlupák!$b$bChtěli ji i další a musel jsem je zastavit! Ten parchant Twinbraid mě vyhnal.$b$bTeď ji chci zpátky. Zpátky, povídám!]],
[[Feegly the Exiled wants you to retrieve for him the Tear of the Moons.]],
[[Feegly the Exiled chce, abys pro něj získal Slza měsíců.]])

add(864, "Return to Apothecary Zinge",
[["Here you go, the power source is safely removed and the data is preserved.Well, safe journeys and all that.Hope the nefarious science experiment worked out for you and all."$B$BThe goblin turns away from you to attend to the demands of the Gadgetzan Water Company.You secure the sealed testing kit for the journey back to the Undercity.Apothecary Zinge waits for you and the sealed field testing kit there.]],
[[„Tak, zdroj energie je bezpečně vyjmutý a data zůstala zachována. Tak šťastnou cestu a tak dále. Doufám, že ti ten nekalý vědecký pokus vyjde.“$B$BGoblin se od tebe odvrátí a začne se věnovat záležitostem Gadgetzan Water Company. Zabezpečíš zapečetěnou testovací sadu pro cestu zpět do Undercity. Apothecary Zinge tam čeká na tebe i na zapečetěnou polní testovací sadu.]],
[[Bring the Sealed Field Testing Kit to Apothecary Zinge in the Undercity.]],
[[Přines zapečetěná terénní testovací souprava Apothecary Zinge do Undercity.]])

add(910, "Down at the Docks",
[[I have heard tales of the mighty ships that sail between Ratchet and Booty Bay!That would be so cool to sail on the ocean and fight in many great sea battles.Maybe I will be a mighty Horde sailor when I grow up!Yeah!$B$BWould you take me to see the Ratchet docks, please?I promise I won't get into the water or cause any trouble - I just want to see the big boats and smell the salty sea water!Yeah!]],
[[Slyšel jsem příběhy o mocných lodích, které plují mezi Ratchet a Booty Bay! Bylo by úžasné plavit se po oceánu a bojovat ve velkých námořních bitvách. Až vyrostu, možná budu mocným námořníkem Hordy! Jo!$B$BVezmeš mě prosím podívat se do doků v Ratchet? Slibuju, že nevlezu do vody ani nebudu dělat potíže. Chci jen vidět velké lodě a cítit slaný mořský vzduch! Jo!]],
[[Take your ward to the docks of Ratchet in the Barrens.]],
[[Vezmi svého svěřence do doků v Ratchet v Barrens.]])

add(911, "Gateway to the Frontier",
[[They say that Ashenvale is the new frontier, and that the Mor'shan Rampart in the Barrens is the gateway to it.That would be so cool to be a pioneer, carving everything you need out of the untamed wilds!They say that this is where the Horde and Alliance will clash the most in the future, and I want to be there $N!$B$BWould you take me to the Mor'shan Rampart so I can see what the frontier looks like, please?I wanna see where the Horde is driving out those smelly night elves!]],
[[Říká se, že Ashenvale je nová hranice a Mor'shan Rampart v Barrens je její bránou. Bylo by úžasné být průkopníkem a získávat všechno potřebné z divoké přírody! Prý právě tady budou v budoucnu největší střety Hordy a Aliance, a já chci být u toho, $N!$B$BVezmeš mě prosím k Mor'shan Rampart, abych viděl, jak ta hranice vypadá? Chci vidět, odkud Horda vyhání ty smradlavé noční elfy!]],
[[Take your ward to the Mor'shan Rampart in the northern part of the Barrens, just before entering Ashenvale.]],
[[Vezmi svého svěřence k Mor'shan Rampart na severu Barrens, těsně před vstupem do Ashenvale.]])

add(915, "You Scream, I Scream...",
[[ICE CREAM!Oh please please please could you get me some ice cream?!Strawberry is my favorite flavor, and there's no better strawberry ice cream in the world than Tigule and Foror's Strawberry Ice Cream!It's my favorite ice cream in the whole wide world!$B$BI had it once a long time ago when I was at the Shimmering Flats race track, but I heard that they might be selling them in town now!Please?Pretty please?With Tigule and Foror's Strawberry Ice Cream on top??!?!]],
[[ZMRZLINA! Prosím, prosím, prosím, seženeš mi nějakou zmrzlinu?! Jahodová je moje nejoblíbenější a na světě není lepší jahodová zmrzlina než Tigule and Foror's Strawberry Ice Cream! Je to moje úplně nejoblíbenější zmrzlina!$B$BMěl jsem ji kdysi dávno na závodišti v Shimmering Flats, ale slyšel jsem, že ji teď možná prodávají i ve městě! Prosím? Opravdu moc prosím? S Tigule and Foror's Strawberry Ice Cream navrch??!?!]],
[[Get some Strawberry Ice Cream for your ward.The lad seems to prefer Tigule and Foror's brand ice cream.]],
[[Sežeň pro svého svěřence jahodovou zmrzlinu. Chlapec má nejraději značku Tigule and Foror's.]])

add(925, "Cairne's Hoofprint",
[[They say that Cairne Bloodhoof is one of the greatest heroes the Horde has ever seen.When I grow up, I wanna be a hero of the Horde too!$B$BDo you know Cairne, $N?Could you do me a favor, please?Could you get his hoofprint for me?I dunno how to ask him, and he'd probably be too busy for someone like me... but you!You're an adventurer just like he is!I bet he'd give you his hoofprint easy!$B$BPlease?]],
[[Říká se, že Cairne Bloodhoof je jeden z největších hrdinů, jaké kdy Horda měla. Až vyrostu, chci být taky hrdinou Hordy!$B$BZnáš Cairnea, $N? Uděláš mi prosím laskavost? Seženeš mi jeho otisk kopyta? Nevím, jak ho o to požádat, a na někoho jako já asi nebude mít čas... ale ty! Ty jsi dobrodruh stejně jako on! Tobě určitě otisk dá snadno!$B$BProsím?]],
[[Travel to Thunder Bluff to see about getting Cairne Bloodhoof's hoofprint for your ward.]],
[[Vydej se do Thunder Bluff a zkus pro svého svěřence získat otisk kopyta Cairnea Bloodhoofa.]])

add(936, "Assisting Arch Druid Runetotem",
[[Excuse me $c, but I'd like just a moment of your time if possible.$B$BThe Cenarion Circle in Thunder Bluff is most interested in seasoned adventurers such as yourself to lend them aid in a vital research project.While I do not know the specifics, I can inform you that none other than Hamuul Runetotem is spearheading this research.$B$BPlease - if you are interested, speak with him directly on the Elder Rise within Thunder Bluff proper.]],
[[Promiň, $c, mohl bych tě na chvíli zdržet?$B$BCenarion Circle v Thunder Bluff hledá zkušené dobrodruhy, jako jsi ty, kteří by pomohli s důležitým výzkumným projektem. Podrobnosti neznám, ale mohu ti říct, že výzkum vede samotný Hamuul Runetotem.$B$BPokud máš zájem, promluv s ním osobně na Elder Rise v Thunder Bluff.]],
[[Speak with Arch Druid Hamuul Runetotem in Thunder Bluff.]],
[[Promluv s Arch Druidem Hamuulem Runetotemem v Thunder Bluff.]])

add(939, "Flute of Xavaric",
[[You study the simple wooden flute you picked up after defeating Xavaric.$B$BThe knotted wood feels solid, but it seems as if the spirals and patterns in the surface begin to spin and move as you turn it over in your hands. Suddenly, you feel a sense of dread...$B$BYou shake your head, sure that your mind is playing tricks on you.$B$BIt's possible that other satyrs carry clues as to what you have found. Bring your findings to the druid, Eridan Bluewind, that lives in southern Felwood.]],
[[Prohlížíš si jednoduchou dřevěnou flétnu, kterou jsi našel po porážce Xavarica.$B$BSukovité dřevo působí pevně, ale když flétnu otáčíš v rukou, spirály a vzory na jejím povrchu se zdají vířit a pohybovat. Náhle tě přepadne silný pocit hrůzy...$B$BZavrtíš hlavou a přesvědčuješ se, že si s tebou jen zahrává mysl.$B$BMožná u sebe další satyrové nosí stopy, které objasní, co jsi našel. Přines své nálezy druidovi Eridanu Bluewindovi, který žije v jižním Felwoodu.]],
[[Bring the Flute of Xavaric and 5 Jadefire Felbind samples to Eridan Bluewind in southern Felwood.]],
[[Přines Xavaricova flétna a 5 vzorků Jadefire Felbind Eridanu Bluewindovi v jižním Felwoodu.]])

add(964, "Skeletal Fragments",
[[The key to Scholomance is called a Skeleton Key.It must be forged from the remains of a skeleton - several actually - and hardened by only the strongest of metals within a suitable mold.A signet of power from a being who naturally can open the portal to Scholomance will make the key ultimately function.$B$BFirst thing's first though, $N.We'll need skeletal fragments for the key's forging.Skeletons inside Andorhal should yield what we need, but the ones outside the walls might work too.]],
[[Klíč ke Scholomance se nazývá Skeleton Key. Musí být ukován z ostatků kostry — vlastně z několika koster — a vytvrzen tím nejpevnějším kovem ve vhodné formě. Teprve pečetidlo moci od bytosti, která dokáže portál do Scholomance přirozeně otevřít, dá klíči jeho skutečnou funkci.$B$BAle nejdřív to první, $N. Na vykování klíče potřebujeme kostěné úlomky. Kostlivci uvnitř Andorhalu by měli poskytnout, co potřebujeme, ale možná budou stačit i ti za hradbami.]],
[[Bring 15 Skeletal Fragments to Apothecary Dithers at the Bulwark, Western Plaguelands.]],
[[Přines 15 kostěných úlomků Apothecary Dithersovi do Bulwarku ve Western Plaguelands.]])

add(969, "Luck Be With You",
[[Ah, I can tell just by lookin' at ya -- you be wantin' to make a lucky charm. Mau'ari always knows!$B$BYou'll need ta travel to a place called Winterspring ta the north, far from da heat of Durotar.$B$BIn Winterspring, to da south. you'll find a canyon, an' giants made a' solid ice. The giants sometimes be carryin' dem, but ya can always gather da shards yerself from da canyon. These shards have a powerful reflective quality.$B$BBring back 10 frostmaul shards, and my lucky charm will be yours.]],
[[Ach, stačí se na tebe podívat — chceš si vyrobit talisman pro štěstí. Mau'ari vždycky všechno pozná!$B$BMusíš cestovat daleko na sever, do země zvané Winterspring, daleko od horka Durotaru.$B$BV jižní části Winterspring najdeš kaňon a obry z čistého ledu. Občas mají střepy u sebe, ale můžeš je také sesbírat přímo v kaňonu. Ty střepy mají silné odrazivé vlastnosti.$B$BPřines mi 10 frostmaulských střepů a můj talisman pro štěstí bude tvůj.]],
[[Collect 10 Frostmaul Shards for Witch Doctor Mau'ari in Orgrimmar.]],
[[Nasbírej 10 střepy Frostmaul pro Witch Doctor Mau'ari v Orgrimmaru.]])

add(974, "Finding the Source",
[[The hot springs here are a source of mystery to me. Where does the heat come from?$B$BLooking at how close the pools are to Fire Plume Ridge, I really wonder if the volcano might have something to do with it. I created a thermometer to take readings of the temperatures at the volcano, and I'd like to find the hottest part. It gives the measurements in degrees Kraklenheit!$B$BHere, take it, and take readings of the temperatures at the ridge whenever you see a hot spot!]],
[[Zdejší horké prameny jsou pro mě záhadou. Odkud se bere to teplo?$B$BKdyž vidím, jak blízko jsou jezírka k Fire Plume Ridge, napadá mě, zda za tím není sopka. Vyrobil jsem teploměr, který dokáže měřit teplotu u sopky, a rád bych našel její nejžhavější místo. Měří ve stupních Kraklenheita!$B$BTady ho máš. Kdykoli na hřebeni uvidíš horké místo, změř tam teplotu!]],
[[Krakle in Un'Goro Crater wants you to find the hottest area of Fire Plume Ridge.$B$BWhenever you find a hot spot, right click the thermometer to check the temperature. Keep looking until you find the hottest one.]],
[[Krakle v Un'Goro Crater chce, abys našel nejžhavější místo na Fire Plume Ridge.$B$BKdykoli najdeš horké místo, klikni pravým tlačítkem na teploměr a změř teplotu. Pokračuj, dokud nenajdeš nejžhavější místo.]])

add(975, "Cache of Mau'ari",
[[Now, before I give ya dis charm, I better explain how ta use it.$B$BIf you carry da charm with ya, you'll find dat certain items will drop from creatures ya fight. If you don't have da charm with you, you won't find them. Understand?$B$BYou'll know these special items by the name -- they be called E'ko. If you find any of these items, just bring dem to ol' Mau'ari, and she help ya out.$B$BWait here while I fix your charm.]],
[[Než ti ten talisman dám, raději ti vysvětlím, jak ho používat.$B$BKdyž ho budeš nosit u sebe, zjistíš, že z některých tvorů, se kterými bojuješ, mohou padat zvláštní předměty. Bez talismanu je nenajdeš. Rozumíš?$B$BPoznáš je podle jména — říká se jim E'ko. Pokud nějaké najdeš, přines je staré Mau'ari a ona ti pomůže.$B$BPočkej tady, než ti talisman připravím.]],
[[Speak to Witch Doctor Mau'ari again in a moment to receive the lucky charm.]],
[[Za chvíli znovu promluv s Witch Doctor Mau'ari a převezmi talisman pro štěstí.]])

add(977, "Are We There, Yeti?",
[[Now that I have what I need to cover the mechanical moving parts, I only need one other thing. Well, actually two. Two horns!$B$BThe ice thistle patriarchs and matriarchs have the largest horns, so of course, those are the ones I want. That type of yeti inhabits a cave to the southeast. There are plenty of them there; you shouldn't have any problem finding them.$B$BRemember, I only want the best looking ones -- no beat up or broken horns, please!]],
[[Teď, když mám materiál na zakrytí pohyblivých mechanických částí, potřebuji už jen jednu věc. Vlastně dvě. Dva rohy!$B$BPatriarchové a matriarchy Ice Thistle mají největší rohy, takže samozřejmě chci právě ty. Tento druh yettiho žije v jeskyni na jihovýchodě. Je jich tam spousta, takže je určitě snadno najdeš.$B$BA pamatuj, chci jen ty nejhezčí — žádné otlučené nebo zlomené rohy!]],
[[Collect 2 Pristine Yeti Horns for Umi Rumplesnicker in Everlook.]],
[[Nasbírej 2 nepoškozené yetti rohy pro Umi Rumplesnicker v Everlook.]])

add(978, "Moontouched Wildkin",
[[Wildkin feathers from the Hinterlands appear to contain traces of magical qualities. These powers... they don't seem to be wielded by the creatures, it's more like they are simply inherent to the species -- part of their very essence.$B$BDuring my studies, I heard that a large population of wildkin inhabit the snowy lands of Winterspring. Could these creatures have the same powers? Please help me find an answer, $N. Go to Winterspring and gather feathers that have dropped to the ground, then return to me.]],
[[Zdá se, že peří wildkinů z Hinterlands obsahuje stopy magie. Tuto moc však tvorové zřejmě vědomě neovládají. Spíš je jim vlastní, jako by byla součástí samotné podstaty jejich druhu.$B$BPři studiu jsem se dozvěděl, že v zasněženém Winterspring žije velká populace wildkinů. Mohou mít stejnou moc? Pomoz mi to zjistit, $N. Vydej se do Winterspring, nasbírej peří spadané na zem a vrať se ke mně.]],
[[Collect 10 Moontouched Feathers from Winterspring, then return to Erelas Ambersky in Rut'theran Village.]],
[[Nasbírej ve Winterspring 10 pera dotčená měsíčním svitem a poté se vrať k Erelasu Amberskymu do Rut'theran Village.]])

add(979, "Find Ranshalla",
[[Yes, yes, these feathers seem to hold the same magical enchantment that I noticed previously... While I am not certain what we might find, I urge you to continue searching for answers, $N.$B$BA colleague of mine recently traveled into Winterspring to observe the wildkin there, in their own habitat. Why don't you catch up with her and see what she has found?]],
[[Ano, ano, v tomhle peří je zřejmě stejné magické očarování, jakého jsem si všiml dříve... Nevím jistě, co zjistíme, ale naléhám na tebe, abys v pátrání pokračoval, $N.$B$BJedna moje kolegyně nedávno odcestovala do Winterspring pozorovat tamní wildkiny v jejich přirozeném prostředí. Najdi ji a zjisti, co objevila.]],
[[Find Ranshalla in eastern Winterspring.]],
[[Najdi Ranshallu ve východním Winterspring.]])

add(980, "The New Springs",
[[Now, I've heard about other hot springs in a place called Winterspring, far to the north of here. The strange thing is, there are no volcanoes anywhere near them. Interesting, I know.$B$BWell, if you want to find out more, you should head to Winterspring and speak to a friend of mine. Her name is Donova Snowden, and she is currently staying by the hot springs there.$B$BThanks again for helping me with my thermometer! See you later!]],
[[Slyšel jsem o dalších horkých pramenech v zemi jménem Winterspring, daleko na sever odtud. Zvláštní je, že poblíž nich nejsou žádné sopky. Zajímavé, že?$B$BChceš-li zjistit víc, vydej se do Winterspring a promluv s mou přítelkyní. Jmenuje se Donova Snowden a právě pobývá u tamních horkých pramenů.$B$BJeště jednou díky za pomoc s mým teploměrem! Tak zase někdy!]],
[[Travel to Winterspring and speak with Donova Snowden.]],
[[Vydej se do Winterspring a promluv s Donovou Snowden.]])

add(981, "The Tower of Althalaxx",
[[For all the work that you have done, you deserve to be well rewarded. Return to Delgren and tell him that Athrikus Narassin lies stilled by your hand, and the Cult of the Dark Strand is beaten and scattered.]],
[[Za všechnu práci, kterou jsi odvedl, si zasloužíš pořádnou odměnu. Vrať se k Delgrenovi a řekni mu, že Athrikus Narassin padl tvou rukou a Cult of the Dark Strand je poražen a rozehnán.]],
[[Talk to Delgren the Purifier at Maestra's Post.]],
[[Promluv s Delgrenem the Purifierem v Maestra's Post.]])

add(992, "Gadgetzan Water Survey",
[[We've got a position open for a temporary junior-grade surveyor in the Gadgetzan Water Company, if you're interested!$B$BWith the nomads seizing all our wells, we need to exploit more free sources of water!There is water to be had in the desert, but only to those smart enough to survey them first.$B$BTake this dowsing widget and tap a sample of the water by the pool near Sandsorrow Watch.It's right in sight of the trolls around there.Bring the tapped widget back to me when you're done!]],
[[V Gadgetzan Water Company máme volné místo dočasného mladšího průzkumníka, jestli máš zájem!$B$BNomádi nám obsadili všechny studny, takže musíme využít další volné zdroje vody! V poušti voda je, ale získají ji jen ti, kteří jsou dost chytří, aby ji nejdřív prozkoumali.$B$BVezmi tohle proutkařské udělátko a odeber vzorek vody u jezírka poblíž Sandsorrow Watch. Trollové ho mají přímo na očích. Až budeš hotov, přines mi naplněné zařízení zpět!]],
[[Use the untapped dowsing widget near the pool of water by Sandsorrow Watch.Once you have collected the sample, return the tapped dowsing widget to Senior Surveyor Fizzledowser in Gadgetzan.]],
[[Použij nenaplněné proutkařské zařízení u jezírka poblíž Sandsorrow Watch. Až odebereš vzorek, vrať naplněné zařízení Senior Surveyoru Fizzledowserovi v Gadgetzanu.]])

add(1000, "The New Frontier",
[[Attention, heroes!$B$BThe Cenarion Circle seeks able bodied individuals to assist them in exploring the vast new frontiers of Kalimdor!A forbidden wasteland of unimaginable dangers lies far to the west of Tanaris and Gadgetzan, and the Circle needs willing and honorable proxies to act in their stead.$B$BAll interested individuals should seek audience with the Cenarion Circle.Speak with the Arch Druid Hamuul Runetotem on the Elder's Rise of Thunder Bluff for more information!]],
[[Pozor, hrdinové!$B$BCenarion Circle hledá schopné jedince, kteří pomohou s průzkumem rozsáhlých nových končin Kalimdoru! Daleko na západ od Tanaris a Gadgetzanu leží zakázaná pustina plná nepředstavitelných nebezpečí a Circle potřebuje ochotné a čestné zástupce, kteří budou jednat jeho jménem.$B$BVšichni zájemci mají vyhledat Cenarion Circle. Další informace získáš od Arch Druida Hamuula Runetotema na Elder Rise v Thunder Bluff!]],
[[Speak with Arch Druid Hamuul Runetotem on the Elder Rise of Thunder Bluff about the Cenarion Circle's call to explore the frontiers of Kalimdor.]],
[[Promluv s Arch Druidem Hamuulem Runetotemem na Elder Rise v Thunder Bluff o výzvě Cenarion Circle k průzkumu nových končin Kalimdoru.]])

add(1004, "The New Frontier",
[[Attention, heroes!$B$BThe Cenarion Circle seeks able bodied individuals to assist them in exploring the vast new frontiers of Kalimdor!A forbidden wasteland of unimaginable dangers lies far to the west of Tanaris and Gadgetzan, and the Circle needs willing and honorable proxies to act in their stead.$B$BAll interested individuals should seek audience with the Cenarion Circle.Speak with the Arch Druid Hamuul Runetotem on the Elder's Rise of Thunder Bluff for more information!]],
[[Pozor, hrdinové!$B$BCenarion Circle hledá schopné jedince, kteří pomohou s průzkumem rozsáhlých nových končin Kalimdoru! Daleko na západ od Tanaris a Gadgetzanu leží zakázaná pustina plná nepředstavitelných nebezpečí a Circle potřebuje ochotné a čestné zástupce, kteří budou jednat jeho jménem.$B$BVšichni zájemci mají vyhledat Cenarion Circle. Další informace získáš od Arch Druida Hamuula Runetotema na Elder Rise v Thunder Bluff!]],
[[Speak with Arch Druid Hamuul Runetotem on the Elder Rise of Thunder Bluff about the Cenarion Circle's call to explore the frontiers of Kalimdor.]],
[[Promluv s Arch Druidem Hamuulem Runetotemem na Elder Rise v Thunder Bluff o výzvě Cenarion Circle k průzkumu nových končin Kalimdoru.]])

add(1011, "Forsaken Diseases",
[[The Forsaken, the undead arm of the Horde, have crept into Ashenvale, lurking at our ruins and our barrows.We believe their goal is to spread disease amongst the lands of the night elves.We must confirm this!$B$BThe Forsaken have a camp south of here, near the Dor'Danil Barrow Den, where they create poisons and diseases and place them in bottles.Fight your way into that camp and steal a bottle of disease.Return with such a bottle.I will test it and find its purpose.]],
[[Forsaken, nemrtvá část Hordy, pronikli do Ashenvale a číhají u našich ruin a mohyl. Domníváme se, že chtějí šířit nemoci po zemích nočních elfů. Musíme to potvrdit!$B$BJižně odsud, poblíž Dor'Danil Barrow Den, mají Forsaken tábor, kde vyrábějí jedy a nákazy a plní je do lahví. Probojuj se do tábora a jednu láhev s nákazou ukradni. Přines ji zpět. Otestuji ji a zjistím, k čemu slouží.]],
[[Bring a Bottle of Disease to Kayneth Stillwind in Forest Song.]],
[[Přines láhev nákazy Kaynethu Stillwindovi ve Forest Song.]])

add(1012, "Insane Druids",
[[When I struggled with the Forsaken's poisons, I had a vision.I had a vision of the druids in the Dor'danil Barrow Den, poisoned... murdered by the undead!They are now errant ghosts, severed from their bodies and driven mad.$B$BSo that the druids' spirits might some day find peace, you must enter the Dor'danil Barrow Den and destroy its once great leaders: Taneel Darkwood, Uthil Mooncall and Mavoris Cloudsbreak.$B$BDo this, then return to me.]],
[[Když jsem zápasil s jedy Forsaken, měl jsem vidění. Viděl jsem druidy v Dor'danil Barrow Den, otrávené... zavražděné nemrtvými! Teď jsou z nich bludní duchové, odtržení od svých těl a dohnaní k šílenství.$B$BAby jejich duše mohly jednou najít klid, musíš vstoupit do Dor'danil Barrow Den a zničit jeho někdejší velké vůdce: Taneela Darkwooda, Uthila Mooncalla a Mavorise Cloudsbreak.$B$BUdělej to a pak se ke mně vrať.]],
[[Kill the druids: Taneel Darkwood, Uthil Mooncall, Mavoris Cloudsbreak; then return to Kayneth Stillwind in Forest Song.]],
[[Zabij druidy Taneela Darkwooda, Uthila Mooncalla a Mavorise Cloudsbreak a potom se vrať ke Kaynethu Stillwindovi ve Forest Song.]])

add(1015, "The New Frontier",
[[Attention, heroes!$B$BThe Cenarion Circle seeks able bodied individuals to assist them in exploring the vast new frontiers of Kalimdor!A forbidden wasteland of unimaginable dangers lies far to the west of Tanaris and Gadgetzan, and the Circle needs willing and honorable proxies to act in their stead.$B$BAll interested individuals should seek audience with the Cenarion Circle.Speak with the Arch Druid in Darnassus, Fandral Staghelm, for more information!]],
[[Pozor, hrdinové!$B$BCenarion Circle hledá schopné jedince, kteří pomohou s průzkumem rozsáhlých nových končin Kalimdoru! Daleko na západ od Tanaris a Gadgetzanu leží zakázaná pustina plná nepředstavitelných nebezpečí a Circle potřebuje ochotné a čestné zástupce, kteří budou jednat jeho jménem.$B$BVšichni zájemci mají vyhledat Cenarion Circle. Další informace získáš od Arch Druida Fandrala Staghelma v Darnassus!]],
[[Speak with Arch Druid Fandral Staghelm at the Cenarion Enclave of Darnassus about the Cenarion Circle's call to explore the frontiers of Kalimdor.]],
[[Promluv s Arch Druidem Fandralem Staghelmem v Cenarion Enclave v Darnassus o výzvě Cenarion Circle k průzkumu nových končin Kalimdoru.]])

add(1018, "The New Frontier",
[[Attention, heroes!$B$BThe Cenarion Circle seeks able bodied individuals to assist them in exploring the vast new frontiers of Kalimdor!A forbidden wasteland of unimaginable dangers lies far to the west of Tanaris and Gadgetzan, and the Circle needs willing and honorable proxies to act in their stead.$B$BAll interested individuals should seek audience with the Cenarion Circle.Speak with the Arch Druid Hamuul Runetotem on the Elder's Rise of Thunder Bluff for more information!]],
[[Pozor, hrdinové!$B$BCenarion Circle hledá schopné jedince, kteří pomohou s průzkumem rozsáhlých nových končin Kalimdoru! Daleko na západ od Tanaris a Gadgetzanu leží zakázaná pustina plná nepředstavitelných nebezpečí a Circle potřebuje ochotné a čestné zástupce, kteří budou jednat jeho jménem.$B$BVšichni zájemci mají vyhledat Cenarion Circle. Další informace získáš od Arch Druida Hamuula Runetotema na Elder Rise v Thunder Bluff!]],
[[Speak with Arch Druid Hamuul Runetotem on the Elder Rise of Thunder Bluff about the Cenarion Circle's call to explore the frontiers of Kalimdor.]],
[[Promluv s Arch Druidem Hamuulem Runetotemem na Elder Rise v Thunder Bluff o výzvě Cenarion Circle k průzkumu nových končin Kalimdoru.]])

add(1019, "The New Frontier",
[[Attention, heroes!$B$BThe Cenarion Circle seeks able bodied individuals to assist them in exploring the vast new frontiers of Kalimdor!A forbidden wasteland of unimaginable dangers lies far to the west of Tanaris and Gadgetzan, and the Circle needs willing and honorable proxies to act in their stead.$B$BAll interested individuals should seek audience with the Cenarion Circle.Speak with the Arch Druid in Darnassus, Fandral Staghelm, for more information!]],
[[Pozor, hrdinové!$B$BCenarion Circle hledá schopné jedince, kteří pomohou s průzkumem rozsáhlých nových končin Kalimdoru! Daleko na západ od Tanaris a Gadgetzanu leží zakázaná pustina plná nepředstavitelných nebezpečí a Circle potřebuje ochotné a čestné zástupce, kteří budou jednat jeho jménem.$B$BVšichni zájemci mají vyhledat Cenarion Circle. Další informace získáš od Arch Druida Fandrala Staghelma v Darnassus!]],
[[Speak with Arch Druid Fandral Staghelm at the Cenarion Enclave of Darnassus about the Cenarion Circle's call to explore the frontiers of Kalimdor.]],
[[Promluv s Arch Druidem Fandralem Staghelmem v Cenarion Enclave v Darnassus o výzvě Cenarion Circle k průzkumu nových končin Kalimdoru.]])

add(1021, "Vile Satyr! Dryads in Danger!",
[[Listen, I don't know who you are, but I need your help. My sisters went to take back the Branch of Cenarius from the satyr. They said they'd be back soon, but it's been two whole days!$B$B$n, you have to find them! They were looking for the ruins of a night elf temple in Xavian to the northeast. I don't know what to think. Look for Anilia, she was leading them on the search.]],
[[Poslouchej, nevím, kdo jsi, ale potřebuji tvou pomoc. Mé sestry se vydaly vzít satyrům zpět Cenariova větev. Říkaly, že budou brzy zpátky, ale už jsou pryč celé dva dny!$B$B$n, musíš je najít! Hledaly ruiny chrámu nočních elfů v Xavianu na severovýchodě. Nevím, co si mám myslet. Najdi Aniliu, vedla jejich výpravu.]],
[[Find Anilia in Xavian.]],
[[Najdi Aniliu v Xavianu.]])

add(1022, "The Howling Vale",
[[Though we have put many resources and much effort into driving the remaining demons from the Felwood to the north, our successes have been few. We have been able to keep much of the demonic presence from Ashenvale.$b$bTo the north, near the Felwood border, the ruined shrine of Mel'Thandris has been overtaken by mysterious wolf-men. Their chilling calls have led the area to be known as the Howling Vale. The Tome of Mel'Thandris kept at the shrine may shed some light on why these wolf-men have come.]],
[[Přestože jsme věnovali mnoho prostředků a úsilí vyhánění zbývajících démonů z Felwoodu na severu, úspěchů bylo málo. Alespoň se nám podařilo držet většinu démonických sil mimo Ashenvale.$b$bNa severu poblíž hranice s Felwoodem obsadili zničenou svatyni Mel'Thandris záhadní vlčí lidé. Jejich děsivé vytí dalo celé oblasti jméno Howling Vale. svazek Mel'Thandrise uložený ve svatyni by mohl objasnit, proč sem tito tvorové přišli.]],
[[Go to the Howling Vale and study the Tome of Mel'Thandris, then return to Sentinel Melyria Frostshadow at the Shrine of Aessina.]],
[[Vydej se do Howling Vale, prostuduj svazek Mel'Thandrise a poté se vrať k Sentinel Melyrii Frostshadow ve Shrine of Aessina.]])

add(1031, "The Branch of Cenarius",
[[Anilia puts her hands on your shoulders and draws you close. Gasping, she points towards the arch to the north, before her eyes close and her last wheezing breath leaves her body. "He has taken it... Geltharis..." You know in your heart that Anilia's dying wish is to see the Branch of Cenarius back in dryad hands.]],
[[Anilia ti položí ruce na ramena a přitáhne si tě blíž. S posledním dechem ukáže k oblouku na severu, pak zavře oči a vydechne naposledy. „Vzal ji... Geltharis...“ V hloubi srdce víš, že Aniliiným posledním přáním bylo vrátit Cenariova větev do rukou dryád.]],
[[Kill Geltharis and return the Branch of Cenarius to Illiyana at the Shrine of Aessina.]],
[[Zabij Geltharise a vrať Cenariova větev Illiyaně ve Shrine of Aessina.]])

add(1032, "Satyr Slaying!",
[[I can't believe that Anilia is gone... We used to play together in the forests all the time. I almost feel... sad.$B$BI know something that might make me feel better. Please, slay the satyrs that took Anilia from me! Bring me their horns as proof of your actions and you will forever have my gratitude.$B$B]],
[[Nemohu uvěřit, že je Anilia pryč... Pořád jsme si spolu hrávaly v lesích. Skoro cítím... smutek.$B$BVím, co by mi mohlo trochu ulevit. Prosím, zabij satyry, kteří mi Aniliu vzali! Přines mi jejich rohy jako důkaz a navždy budeš mít mou vděčnost.$B$B]],
[[Bring 16 Satyr Horns to Illiyana in the Shrine of Aessina.]],
[[Přines Illiyaně ve Shrine of Aessina 16 satyrských rohů.]])

add(1036, "Avast Ye, Scallywag",
[[$N... yeah, I've heard of you.I've heard that you're no friend of Booty Bay - just like us Bloodsail Buccaneers.Fleet Master Firallon is looking for hale and hearty $g men : women; just like you for a special mission.$B$BIf you're interested, head on out to the Crimson Veil and speak with him below decks.She's anchored off the Wild Coast east of here, next to the Riptide and the Damsel's Luck.]],
[[$N... ano, slyšel jsem o tobě. Prý nejsi žádný přítel Booty Bay — stejně jako my Bloodsail Buccaneers. Fleet Master Firallon hledá schopné a odolné $gmuže:ženy; jako jsi ty pro zvláštní misi.$B$BMáš-li zájem, vydej se k Crimson Veil a promluv s ním v podpalubí. Loď kotví u Wild Coast východně odsud, vedle Riptide a Damsel's Luck.]],
[[Speak with Fleet Master Firallon aboard the Crimson Vale off the coast of Stranglethorn Vale.]],
[[Promluv s Fleet Masterem Firallonem na palubě Crimson Vale u pobřeží Stranglethorn Vale.]])

add(1037, "Velinde Starsong",
[[Velinde Starsong was my predecessor here in Ashenvale Forest. At first it seemed she had the situation in Felwood under control, but little by little her efforts faltered. One day, she simply disappeared.$b$bI was sent here to continue her work. I'm afraid I know nothing of the priestess, however. Perhaps Thyn'tel Bladeweaver, one of the commanders of the Sentinels, knows further details of her disappearance that I was not a party to.$b$bSurely she will understand the import of such information.]],
[[Velinde Starsong byla mou předchůdkyní tady v Ashenvale Forest. Zpočátku to vypadalo, že má situaci ve Felwoodu pod kontrolou, ale postupně se její úsilí začalo hroutit. Jednoho dne prostě zmizela.$b$bByl jsem sem poslán pokračovat v její práci, ale o samotné kněžce bohužel nic nevím. Thyn'tel Bladeweaver, jedna z velitelek Sentinels, možná zná další podrobnosti o jejím zmizení, ke kterým jsem neměl přístup.$b$bJistě pochopí důležitost takových informací.]],
[[Speak with Thyn'tel Bladeweaver at the Warrior's Terrace in Darnassus.]],
[[Promluv s Thyn'tel Bladeweaver na Warrior's Terrace v Darnassus.]])

add(1038, "Velinde's Effects",
[[The Tome of Mel'Thandris showed you this? I suppose there would be little harm in allowing you to examine her belongings. This key will allow you to open the chest where we stored her things in the Sentinels' bunkhouse. She kept a journal of her duties, if there is anything to be learned, it will be from that.$b$bI should tell you, the Sentinels believe that she had her own reasons for leaving, and expect that she could return at any time. The priestess has done much in the past to earn our trust.]],
[[svazek Mel'Thandrise ti ukázal tohle? Myslím, že nebude na škodu, když si prohlédneš její věci. Tímto klíčem otevřeš truhlu v ubikaci Sentinels, kde jsme její majetek uložili. Vedla si deník o svých povinnostech; pokud se dá něco zjistit, bude to právě z něj.$b$bMěl bych dodat, že Sentinels věří, že k odchodu měla vlastní důvody a může se kdykoli vrátit. V minulosti kněžka udělala mnoho pro to, aby si získala naši důvěru.]],
[[Search through Velinde's chest for her journal, then return it along with the key to Thyn'tel Bladeweaver in Darnassus.]],
[[Prohledej Velindinu truhlu, najdi její deník a potom jej spolu s klíčem vrať Thyn'tel Bladeweaver v Darnassus.]])

add(1039, "The Barrens Port",
[[Ratchet is the only port in the Barrens. Most likely Velinde found a trading vessel in Ratchet to take her to Blackwater Cove in Azeroth. We've had limited dealings with the goblins that run the port, but the master of the dock should have information about the comings and goings of ship passengers.$b$bFollow the road southeast through Ashenvale and you will find yourself in the Barrens. Watch your step, $n, warriors of the Horde patrol the land. You will be safe at the port, though.]],
[[Ratchet je jediný přístav v Barrens. Velinde tam nejspíš našla obchodní loď, která ji odvezla do Blackwater Cove v Azerothu. S gobliny, kteří přístav provozují, máme jen omezené styky, ale správce doků by měl mít informace o cestujících, kteří připlouvají a odplouvají.$b$bVydej se po cestě jihovýchodně přes Ashenvale a dorazíš do Barrens. Dávej pozor, $n, zemí hlídkují bojovníci Hordy. V samotném přístavu bys ale měl být v bezpečí.]],
[[Speak with Wharfmaster Dizzywig in Ratchet.]],
[[Promluv s Wharfmasterem Dizzywigem v Ratchet.]])

add(1040, "Passage to Booty Bay",
[[Ah yes, finally found it. Should have told me she passed through here that long ago. Let's see.$b$bVelinde. Booked passage to Booty Bay on the Black Osprey. I don't have anything here saying otherwise, so I'd assume it arrived in port safely.$b$bNot much more help I can be to you, but she asked about overland travel over on that side of the world, and I mentioned Ruzzgot, a caravan driver based out of Booty Bay. Might be that this Velinde traveled with him.$b$bMove along, now. I haven't all day for you.]],
[[Á ano, konečně jsem to našel. Měl jsi říct, že tudy procházela už tak dávno. Podíváme se.$b$bVelinde. Rezervovala si cestu do Booty Bay na lodi Black Osprey. Nemám tu nic, co by tvrdilo opak, takže předpokládám, že loď bezpečně dorazila do přístavu.$b$bVíc ti asi nepomůžu, ale ptala se na cestování po souši na druhé straně světa. Zmínil jsem jí Ruzzgota, vozku karavany z Booty Bay. Možná cestovala s ním.$b$bA teď běž. Nemám na tebe celý den.]],
[[Take a boat to Booty Bay and speak with Caravaneer Ruzzgot.]],
[[Dopluj lodí do Booty Bay a promluv s Caravaneerem Ruzzgotem.]])

add(1041, "The Caravan Road",
[[Turns out I was wrong about you, and that isn't something that happens everyday.$b$bIt just so happens that I remember this Velinde you're looking for. Isn't every day that a night elf priestess that wants to travel with a dirty old--but great for your shipping needs!--caravan like my own.$b$bWe split up on the way north, she was headed for Darkshire. The clerk there keeps all sorts of records. Might know something useful.$b$bBe careful in the jungle, it is a deadly place even at the best of times.]],
[[Ukazuje se, že jsem se v tobě spletl, a to se mi nestává každý den.$b$bNáhodou si na tu Velinde, kterou hledáš, vzpomínám. Nestává se často, aby kněžka nočních elfů chtěla cestovat se starou špinavou — ale pro přepravu zboží skvělou! — karavanou, jako je ta moje.$b$bCestou na sever jsme se rozdělili. Mířila do Darkshire. Tamní písař vede všemožné záznamy a mohl by vědět něco užitečného.$b$bV džungli buď opatrný, i za nejlepších podmínek je to smrtelně nebezpečné místo.]],
[[Speak with Clerk Daltry in Darkshire.]],
[[Promluv s Clerkem Daltrym v Darkshire.]])

add(1042, "The Carevin Family",
[[No, I don't have any records of a Velinde Starsong staying in Darkshire... though, if you don't mind me saying, I can hardly imagine a night elf priestess taking a room in the inn, if you get my meaning?$b$bThese wolf-men you mentioned though, that's something I've heard about. Just the other day, Calor came into town with a string of their heads. He works with the Carevin family. Hunters of demons, undead, and other monstrosities. Speak with Jonathan, he's the head of the household.]],
[[Ne, nemám žádný záznam o tom, že by Velinde Starsong pobývala v Darkshire... ale pokud dovolíš, těžko si dokážu představit kněžku nočních elfů, jak si bere pokoj v hostinci, rozumíš?$b$bO těch vlčích lidech, které zmiňuješ, jsem ale něco slyšel. Před pár dny přišel Calor do města s celou řadou jejich hlav. Pracuje pro rodinu Carevinů, lovce démonů, nemrtvých a dalších nestvůr. Promluv s Jonathanem, je hlavou rodiny.]],
[[Speak with Jonathan Carevin in Darkshire.]],
[[Promluv s Jonathanem Carevinem v Darkshire.]])

add(1043, "The Scythe of Elune",
[[Your story rings true... I do not entirely understand your motives, but if your business here in Duskwood involves ridding the forest of worgen in any number, then I can forgo understanding for results.$b$bThere is a mine to the south that has been overrun with worgen... They appeared out of nowhere, but from what we know, that is where they first were found.$b$bGo about your business, but I would ask that if you find anything of import, you share it with me. We will accept any aid in our war against evil.]],
[[Tvůj příběh zní věrohodně... Úplně nerozumím tvým pohnutkám, ale pokud tvé záležitosti v Duskwood povedou k tomu, že les zbavíš alespoň části worgenů, výsledky jsou pro mě důležitější než vysvětlení.$b$bNa jihu je důl, který worgeni zcela ovládli. Objevili se zničehonic, ale podle všeho jsme je poprvé zaznamenali právě tam.$b$bPokračuj ve svém pátrání, ale pokud najdeš něco důležitého, poděl se o to se mnou. V boji proti zlu přijmeme každou pomoc.]],
[[Look for signs of the Scythe of Elune then return to Jonathan Carevin in Darkshire.]],
[[Hledej stopy po Elunina kosa a poté se vrať k Jonathanu Carevinovi v Darkshire.]])

add(1044, "Answered Questions",
[[We shall rein in the worgen problem, have no worry of that. This evil that your friend introduced to our woods will be contained, and I bear her no ill will for her actions. Strange events are afoot in these times, $n, and the darkness knows no respite.$b$bI will keep you no longer. I suspect that there are others that should hear of what you have found in the mines of Duskwood.]],
[[Problém s worgeny dostaneme pod kontrolu, o to se neboj. Zlo, které tvá přítelkyně přivedla do našich lesů, bude zadrženo a za její činy k ní nechovám zášť. V těchto časech se dějí podivné věci, $n, a temnota nikdy neodpočívá.$b$bUž tě nebudu zdržovat. Myslím, že jsou další, kteří by měli slyšet o tom, co jsi našel v dolech Duskwoodu.]],
[[Return to Thyn'tel Bladeweaver in Darnassus.]],
[[Vrať se k Thyn'tel Bladeweaver do Darnassus.]])

add(1045, "Raene's Cleansing",
[[The night elves are as old as time, but their arrogance destroys their very world. And now it destroys our lives too. But that can no longer be controlled...$B$BI blame the elves for much, but we are still responsible for our actions. Even beyond the corruption, we are capable of great evil.$B$BRan Bloodtooth is one such evil. Power hungry, lusting... the corruption has only made him stronger. My hatred for the elves burns, but I do not wish ill upon their children, so we must police our own.]],
[[Noční elfové jsou staří jako čas sám, ale jejich pýcha ničí jejich vlastní svět. A teď ničí i naše životy. To už však nedokážeme změnit...$B$BElfům dávám za vinu mnohé, ale za své činy stále neseme odpovědnost sami. I bez zkaženosti jsme schopni velkého zla.$B$BRan Bloodtooth je právě takovým zlem. Touží po moci a po krvi... zkaženost ho jen posílila. Má nenávist k elfům plane, ale jejich dětem nepřeji zlo. Musíme proto udělat pořádek ve vlastních řadách.]],
[[Kill Ran Bloodtooth and 4 Bloodtooth Guards and return to Krolg near Lake Mystral.]],
[[Zabij Rana Bloodtootha a 4 Bloodtooth Guards a vrať se ke Krolgovi poblíž Lake Mystral.]])

add(1047, "The New Frontier",
[[Attention, heroes!$B$BThe Cenarion Circle seeks able bodied individuals to assist them in exploring the vast new frontiers of Kalimdor!A forbidden wasteland of unimaginable dangers lies far to the west of Tanaris and Gadgetzan, and the Circle needs willing and honorable proxies to act in their stead.$B$BAll interested individuals should seek audience with the Cenarion Circle.Speak with the Arch Druid in Darnassus, Fandral Staghelm, for more information!]],
[[Pozor, hrdinové!$B$BCenarion Circle hledá schopné jedince, kteří pomohou s průzkumem rozsáhlých nových končin Kalimdoru! Daleko na západ od Tanaris a Gadgetzanu leží zakázaná pustina plná nepředstavitelných nebezpečí a Circle potřebuje ochotné a čestné zástupce, kteří budou jednat jeho jménem.$B$BVšichni zájemci mají vyhledat Cenarion Circle. Další informace získáš od Arch Druida Fandrala Staghelma v Darnassus!]],
[[Speak with Arch Druid Fandral Staghelm at the Cenarion Enclave of Darnassus about the Cenarion Circle's call to explore the frontiers of Kalimdor.]],
[[Promluv s Arch Druidem Fandralem Staghelmem v Cenarion Enclave v Darnassus o výzvě Cenarion Circle k průzkumu nových končin Kalimdoru.]])

add(1048, "Into The Scarlet Monastery",
[[Whilst the Dark Lady tends to the pressing issue of the Lich King's advance to the north, I am seeing to it that matters closer to home are being taken care of accordingly.$b$bNo doubt, the human pests who call themselves the Scarlet Crusade are proving to be the sharpest thorn in our side domestically. Tirisfal Glades is literally crawling with the little red ants.$b$bTravel to the Monastery, $c, and lay waste to High Inquisitor Whitemane and her top lieutenants.]],
[[Zatímco Dark Lady řeší naléhavou hrozbu postupu Lich Kinga ze severu, já se starám o problémy blíž našemu domovu.$b$bNení pochyb, že lidští škůdci, kteří si říkají Scarlet Crusade, jsou naším největším domácím trnem v oku. Tirisfal Glades je těmi malými červenými mravenci doslova zamořený.$b$bVydej se do Scarlet Monastery, $c, a znič High Inquisitor Whitemane i její nejvyšší poručíky.]],
[[Kill High Inquisitor Whitemane, Scarlet Commander Mograine, Herod, the Scarlet Champion and Houndmaster Loksey and then report back to Varimathras in the Undercity.]],
[[Zabij High Inquisitor Whitemane, Scarlet Commandera Mograinea, Heroda, Scarlet Championa a Houndmastera Lokseyho a potom podej hlášení Varimathrasovi v Undercity.]])

add(1049, "Compendium of the Fallen",
[[The Earthen Ring had pure intentions towards our plagued brethren. But who is to know the motivations of those whispering in the ears of the Elder Council?$b$bThe Forsaken whom we have allied with have a history wrought with deceit. Too hasty was our pact. Perhaps Cairne would have been wise to heed the warnings from Orgrimmar.$b$bDeep within the Scarlet Monastery lies the Compendium of the Fallen, guarded by crazed human zealots. Their method is forged from insanity but their research might prove useful.]],
[[Earthen Ring měl vůči našim morem zasaženým bratřím čisté úmysly. Kdo však může znát skutečné záměry těch, kteří šeptají do uší Elder Council?$b$bForsaken, s nimiž jsme se spojili, mají historii plnou klamu. Naše dohoda byla možná příliš ukvapená. Cairne možná měl vyslyšet varování z Orgrimmaru.$b$bHluboko ve Scarlet Monastery leží Compendium of the Fallen, střežené šílenými lidskými fanatiky. Jejich metody se rodí z pomatenosti, ale jejich výzkum by mohl být užitečný.]],
[[Retrieve the Compendium of the Fallen from the Monastery in Tirisfal Glades and return to Sage Truthseeker in Thunder Bluff.]],
[[Získej Compendium of the Fallen ze Scarlet Monastery v Tirisfal Glades a vrať se k Sage Truthseekerovi do Thunder Bluff.]])

add(1050, "Mythology of the Titans",
[[The future is inevitable! We hurl ourselves towards it like falling raindrops to the Great Sea.$b$bBut perhaps, by studying the past, we can know what to expect and be better prepared for the unknown.$b$bBefore dire troubles fell upon Lordaeron, there was a bastion of knowledge tucked away in the Tirisfal Glades. It is rumored that a book called Mythology of the Titans was housed in the library of the old Monastery.$b$bBring it to me and perhaps together we can unlock the secrets of the past!]],
[[Budoucnost je nevyhnutelná! Řítíme se k ní jako dešťové kapky do Great Sea.$b$bStudium minulosti nám ale možná napoví, co nás čeká, a připraví nás na neznámé.$b$bNež Lordaeron postihlo neštěstí, v Tirisfal Glades stávala bašta vědění. Říká se, že v knihovně starého Monastery byla uložena kniha jménem Mytologie Titánů.$b$bPřines mi ji a možná společně odhalíme tajemství minulosti!]],
[[Retrieve Mythology of the Titans from the Monastery and bring it to Librarian Mae Paledust in Ironforge.]],
[[Získej Mytologie Titánů ze Scarlet Monastery a přines ji Librarian Mae Paledust do Ironforge.]])

add(1051, "Vorrel's Revenge",
[[Even though my will is free, I can serve the Dark Lady no more. I feel my time on Azeroth has come to an end. My life force is shattered.$b$bInterrogator Vishas did this to me! Tortured me for weeks! Took my wedding ring and gave it to his wife. The bastard!$b$bRevenge... I want revenge!$b$bThe pompous fool bragged about his precious wife, Nancy, who lived along Lake Lordamere. Track the wench down, slay her and return my wedding ring to my wife, Monika in Tarren Mill.$b$bHeed my last wishes....]],
[[Přestože je má vůle svobodná, Dark Lady už sloužit nemohu. Cítím, že můj čas na Azerothu končí. Má životní síla je zlomená.$b$bTohle mi udělal Interrogator Vishas! Celé týdny mě mučil! Vzal mi snubní prsten a dal ho své ženě. Ten parchant!$b$bPomsta... chci pomstu!$b$bTen nafoukaný hlupák se chlubil svou drahou ženou Nancy, která žije u Lake Lordamere. Najdi ji, zabij ji a vrať můj snubní prsten mé ženě Monice v Tarren Mill.$b$bSplň mé poslední přání...]],
[[Return Vorrel Sengutz's wedding ring to Monika Sengutz in Tarren Mill.]],
[[Vrať snubní prsten Vorrela Sengutze Monice Sengutz v Tarren Mill.]])

add(1052, "Down the Scarlet Path",
[[We of the Scarlet Crusade lay claim to strongholds from Hearthglen to Tirisfal Glades. We are quite proud of our bastions of cleansing throughout Lordaeron.$b$bYou have proven yourself against the undead in Desolace. But the true threat of the plague lies in Lordaeron.$b$bTravel to the town of Southshore, in the Eastern Kingdoms. Seek out a crusader named Raleigh the Devout. Give him this letter of commendation bearing my seal and he will escort you to a place of honor in our Scarlet Monastery.]],
[[My ze Scarlet Crusade držíme pevnosti od Hearthglenu až po Tirisfal Glades. Na naše bašty očisty po celém Lordaeronu jsme náležitě hrdí.$b$bProti nemrtvým v Desolace ses osvědčil. Skutečná hrozba moru však leží v Lordaeronu.$b$bVydej se do města Southshore v Eastern Kingdoms. Najdi křižáka jménem Raleigh the Devout. Předej mu tento doporučující dopis s mou pečetí a on tě uvede na čestné místo v naší Scarlet Monastery.]],
[[Take Brother Anton's Letter of Commendation to Raleigh the Devout in Southshore.]],
[[Dones doporučující dopis bratra Antona Raleighovi the Devout do Southshore.]])

add(1053, "In the Name of the Light",
[[I once served the Scarlet Crusade with honor, loyalty and pride. I believed their cause to be a noble one: to rid Azeroth of the undead.$b$bBut as I spent time at the Monastery in Tirisfal Glades I realized that their grasp on reality was slipping. They now think everyone is plagued who doesn't wear the tabard of the Crusade. Innocent men and women were tortured because they were supposedly plagued. $b$bThe Scarlet Crusade must be crushed in the name of the Light. You, $n, must destroy the deranged regime.]],
[[Kdysi jsem Scarlet Crusade sloužil se ctí, věrností a hrdostí. Věřil jsem, že jejich cíl je ušlechtilý: zbavit Azeroth nemrtvých.$b$bKdyž jsem ale pobýval v Monastery v Tirisfal Glades, pochopil jsem, že ztrácejí kontakt s realitou. Dnes považují za nakaženého každého, kdo nenosí tabard Crusade. Mučili nevinné muže a ženy jen proto, že je označili za nakažené.$b$bScarlet Crusade musí být ve jménu Světla rozdrcena. Ty, $n, musíš tento pomatený režim zničit.]],
[[Kill High Inquisitor Whitemane, Scarlet Commander Mograine,Herod, the Scarlet Champion and Houndmaster Loksey and then report back to Raleigh the Devout in Southshore.]],
[[Zabij High Inquisitor Whitemane, Scarlet Commandera Mograinea, Heroda, Scarlet Championa a Houndmastera Lokseyho a potom podej hlášení Raleighovi the Devout v Southshore.]])

add(1059, "Reclaiming the Charred Vale",
[[The Bloodfuries have been subdued. But they will regroup soon enough if action is not taken.$b$bFar south of the Barrens lies a land known as Thousand Needles. If you travel west in Thousand Needles until you reach the lush forest's edge of Feralas, you will find a druid named Falfindel Waywarder.$b$bThis great and wise druid is capable of calling forth great forest spirits which can aid in the reclamation of the Charred Vale.$b$bSend word of our need! Seek him out at once!]],
[[Bloodfuries byli potlačeni. Pokud ale nezakročíme, brzy se znovu seskupí.$b$bDaleko na jih od Barrens leží země zvaná Thousand Needles. Když jí budeš putovat na západ až k zelenému okraji lesa Feralas, najdeš druida jménem Falfindel Waywarder.$b$bTento velký a moudrý druid dokáže přivolat mocné lesní duchy, kteří mohou pomoci obnovit Charred Vale.$b$bDones mu zprávu o naší nouzi! Vyhledej ho okamžitě!]],
[[Travel to Falfindel Waywarder on the border of Thousand Needles and Feralas.]],
[[Vydej se za Falfindelem Waywarderem na hranici Thousand Needles a Feralas.]])

add(1081, "Reception from Tyrande",
[[$N, I am sure Tyrande Whisperwind herself would like to thank you for taking part in this mission.$B$BIt may not appear so on the surface, but what you've helped start could very well strengthen our foothold in the Stonetalon Mountains.$B$BIf you consider yourself our ally against these atrocities, go see Tyrande in the Temple of the Moon in Darnassus.]],
[[$N, jsem si jist, že samotná Tyrande Whisperwind by ti ráda poděkovala za účast na této misi.$B$BNa první pohled to možná není patrné, ale to, co jsi pomohl zahájit, může výrazně posílit naši pozici ve Stonetalon Mountains.$B$BPovažuješ-li se za našeho spojence v boji proti těmto zvěrstvům, navštiv Tyrande v Temple of the Moon v Darnassus.]],
[[Find Tyrande Whisperwind in Darnassus.]],
[[Najdi Tyrande Whisperwind v Darnassus.]])

add(1082, "Update for Sentinel Thenysil",
[[$N, you have done a great deed by lending a hand here.$B$BThe Sentinels of Ashenvale will reward you well if you informed them that Gaxim and I are alive. Tell them we are well on our way to stopping the Venture Co. and healing the lands.$B$BFind Tara Thenysil in Astranaar; she will be pleased to see you've returned with good news.]],
[[$N, svou pomocí jsi tu vykonal velký čin.$B$BSentinels z Ashenvale tě dobře odmění, když jim oznámíš, že Gaxim i já žijeme. Řekni jim, že jsme na dobré cestě zastavit Venture Co. a uzdravit zdejší zemi.$B$BNajdi Taru Thenysil v Astranaaru. Bude ráda, že se vracíš s dobrými zprávami.]],
[[Return to Sentinel Thenysil in Ashenvale.]],
[[Vrať se k Sentinel Thenysil v Ashenvale.]])

add(1083, "Enraged Spirits",
[[I'm unsure what the Venture Co. did to the Vale, but it's obvious they were overpowered by the creatures there.$B$BThey set the forest aflame, and used their inventions of destruction to decimate as much of the Vale as possible.$B$BBut in their ignorance they also released something else: burning spirits, elementals of flame, stone and rage.$B$BThe land has no chance to see Elune's smile while these creatures roam free.$B$BBring me their smoldering embers to show you've reduced their numbers.]],
[[Nevím přesně, co Venture Co. ve Vale provedla, ale je zřejmé, že ji tamní tvorové přemohli.$B$BZapálili les a svými ničivými vynálezy zpustošili co největší část Vale.$B$BVe své nevědomosti však uvolnili ještě něco: hořící duchy, elementály plamene, kamene a zuřivosti.$B$BDokud se tito tvorové volně potulují, země nemá šanci znovu spatřit Elunin úsměv.$B$BPřines mi jejich doutnající uhlíky jako důkaz, že jsi jejich počet snížil.]],
[[Bring 8 Smoldering Embers from any of the fire elementals in the Charred Vale to Kaela Shadowspear in Stonetalon.]],
[[Přines Kaele Shadowspear ve Stonetalonu 8 doutnající uhlíky z libovolných ohnivých elementálů v Charred Vale.]])

add(1084, "Wounded Ancients",
[[It seems obvious to me that the protectors of the Vale--the treants--had something to do with the Venture Co. being driven back. Unfortunately, even those once great guardians have now become corrupt.$B$BGaxim thinks their corruption is somehow linked to the weapons the goblins used during their retreat.$B$BI told him I'd collect a sample from a wounded treant and allow him to study it in order to figure out if that's true.$B$BBring me some of the shrapnel so the gnome can tell me more...]],
[[Je mi jasné, že ochránci Vale — treanti — měli něco společného s ústupem Venture Co. Bohužel i tito kdysi velcí strážci jsou nyní zkažení.$B$BGaxim si myslí, že jejich zkaženost nějak souvisí se zbraněmi, které goblini použili při ústupu.$B$BSlíbila jsem mu, že odeberu vzorek ze zraněného treanta, aby jej mohl prozkoumat a zjistit, zda je to pravda.$B$BPřines mi kus šrapnelu, aby nám gnóm mohl říct víc...]],
[[Bring a piece of Corroded Shrapnel to Kaela Shadowspear in Stonetalon.]],
[[Přines Kaele Shadowspear ve Stonetalonu kus Corroded Shrapnel.]])

add(1089, "The Den",
[[The druids built the Talon Den on Stonetalon Peak, where they keep many powerful items.$b$bThey devised a complex scheme to keep them from falling into the wrong hands.$b$bLuckily, I managed to... extract some details from one of them.$b$bHidden in a small lantern at the entrance of the Den, you will find the Gatekeeper's Key--with it you will be able to open caches around the Den. The items from these caches will allow you to open their hoard, located in one of the central areas.]],
[[Druidové vybudovali Talon Den na Stonetalon Peak a ukrývají tam mnoho mocných předmětů.$b$bVymysleli složitý systém, aby se nedostaly do nesprávných rukou.$b$bNaštěstí se mi z jednoho z nich podařilo... vytáhnout několik podrobností.$b$bV malé lucerně u vchodu do Den najdeš Gatekeeper's Key. S ním otevřeš skrýše rozmístěné po doupěti. Předměty z těchto skrýší ti umožní otevřít jejich pokladnici v jedné z centrálních částí.]],
[[Travel to the Den on Stonetalon Peak. Using the Gatekeeper's Key, obtain the druids' hidden items. Use these items to open the Talon Den Hoard.]],
[[Vydej se do Den na Stonetalon Peak. Pomocí Gatekeeper's Key získej skryté předměty druidů a použij je k otevření Talon Den Hoard.]])

add(1091, "Kaela's Update",
[[$N, take these letters to Kaela. I'm sure she'll want to know about this. Or at least the Sentinels will.$B$BMake sure you tell her how successful we were and how we couldn't have done it without a little bit of magic.]],
[[$N, dones tyhle dopisy Kaele. Jsem si jistý, že o tom bude chtít vědět. A když ne ona, tak alespoň Sentinels.$B$BNezapomeň jí říct, jak úspěšní jsme byli a že bez trochy magie bychom to nezvládli.]],
[[Bring the Venture Co. Letters to Kaela Shadowspear.]],
[[Přines Venture Co. Letters Kaele Shadowspear.]])

add(1100, "Lonebrow's Journal",
[[You slowly open the weathered journal of Henrig Lonebrow....]],
[[Pomalu otevíráš ošuntělý deník Henriga Lonebrowa...]],
[[Read Henrig Lonebrow's Journal.]],
[[Přečti si deník Henriga Lonebrowa.]])

add(1101, "The Crone of the Kraul",
[[Poor Heralath! And this dwarf... Lonebrow. What a brave soul he was.$b$bWe must not let their valiance go for naught. This crone... Charlga Razorflank ... must be stopped.$b$bSurely, infiltrating the Kraul will be perilous. There isn't time to send word to Darnassus. $n, assemble a party to slay the crone.$b$bBring me Razorflank's Medallion as proof of demise.]],
[[Ubohý Heralath! A ten trpaslík... Lonebrow. Jak statečná duše.$b$bNesmíme dopustit, aby jejich odvaha přišla nazmar. Ta stařena... Charlga Razorflank... musí být zastavena.$b$bProniknout do Kraulu bude bezpochyby nebezpečné. Na zprávu do Darnassus není čas. $n, sestav družinu a stařenu zabij.$b$bJako důkaz její smrti mi přines Razorflankův medailon.]],
[[Bring Razorflank's Medallion to Falfindel Waywarder in Thalanaar.]],
[[Přines Razorflankův medailon Falfindelu Waywarderovi v Thalanaaru.]])

add(1102, "A Vengeful Fate",
[[Cairne is a noble leader for uniting our people here on Thunder Bluff.$b$bBut I cannot forgive those who drove us from our ancestral lands as easily as some. My people inhabited the southern Barrens for decades. The land was holy to us. But we were driven off by numerous foes.$b$bA vengeful fate awaits the crone, Charlga Razorflank, who musters a foul army from within Razorfen Kraul.$b$bBring me Razorflank's heart and I can die in peace, $n.]],
[[Cairne je ušlechtilý vůdce, který sjednotil náš lid tady v Thunder Bluff.$b$bJá ale nedokážu tak snadno jako jiní odpustit těm, kteří nás vyhnali z půdy našich předků. Můj lid obýval jižní Barrens celá desetiletí. Ta země nám byla posvátná, ale mnoho nepřátel nás z ní vypudilo.$b$bPomstychtivý osud čeká stařenu Charlgu Razorflank, která z Razorfen Kraul shromažďuje odpornou armádu.$b$bPřines mi Razorflankino srdce a budu moci zemřít v pokoji, $n.]],
[[Bring Razorflank's Heart to Auld Stonespire in Thunder Bluff.]],
[[Přines Razorflankovo srdce Auldu Stonespireovi v Thunder Bluff.]])

add(1103, "Call of Water",
[[Greetin's, $g brotha:sista;! Have you too come to purify the waters here and prove your understandin' to Islen?$B$BI've just defeated the corrupt water spirit meself, and I'm just 'bout to put da bracers and remaining drops o' water on the brazier.$B$BWhat's dat? Ahhh. Tiev understan' all too well when somethin' goes wrong. Well, Tiev can help you plenty if you be needin' to see the pure water spirit again.$B$BBring me a water sapta from Islen as proof that you be ready, an' I'll wait to turn in me parts.]],
[[Zdravím tě, $gbratře:sestro;! Taky jsi přišel očistit zdejší vody a dokázat Islenovi, že tomu rozumíš?$B$BPrávě jsem sám porazil zkaženého vodního ducha a chystám se položit nátepníky a zbývající kapky vody na ohniště.$B$BCože? Ááá. Tiev moc dobře ví, jaké to je, když se něco pokazí. Jestli potřebuješ znovu spatřit čistého vodního ducha, Tiev ti může pomoct.$B$BPřines mi od Islena Water Sapta jako důkaz, že jsi připraven, a já s odevzdáním svých věcí počkám.]],
[[Bring a Water Sapta to Tiev Mordune in Silverpine Forest if you failed to speak to the Minor Manifestation of Water.]],
[[Pokud se ti nepodařilo promluvit s Minor Manifestation of Water, přines Water Sapta Tievu Mordunovi v Silverpine Forest.]])

add(1104, "Salt Flat Venom",
[[I have so many designs for our rocket car!So many!And I must try them all!!$B$BI'm working on a new type of fuel.One that burns really really really hot!!I haven't gotten the mixture perfect, but I think I know what I need...$B$BThe scorpids who wander the Shimmering Flats have a venom with lots and lots of salt in it.It's very unique!And it's just what I need!$B$BBring me venom and trust me -- our car will fly!!]],
[[Mám tolik návrhů pro náš raketový vůz! Tolik! A musím je vyzkoušet všechny!!$B$BPracuji na novém typu paliva. Takovém, které hoří opravdu, opravdu, opravdu žhavě!! Směs ještě není dokonalá, ale myslím, že už vím, co potřebuji...$B$BŠkorpióni, kteří se potulují po Shimmering Flats, mají v jedu obrovské množství soli. Je naprosto jedinečný! A přesně to potřebuji!$B$BPřines mi ten jed a věř mi — naše auto poletí!!]],
[[Bring 6 Salty Scorpid Venoms to Fizzle Brassbolts in the Shimmering Flats.]],
[[Přines Fizzleovi Brassboltsovi v Shimmering Flats 6 slaný jed škorpida.]])

add(1105, "Hardened Shells",
[[My brother is working on a new fuel for his rocket car.He's brilliant, he really is.So brilliant that... I think that new fuel he's designing is strong enough to eat right through the car's chassis!$B$BI want to reinforce its fuel tanks before that happens.$B$BThe tortoises out on the flats have very hard shells.I want to use them to create new tanks for our rocket car.Tanks that can hold my brother's new fuel.$B$BYou look responsible enough.Will you get me those shells?]],
[[Můj bratr pracuje na novém palivu pro náš raketový vůz. Je geniální, opravdu. Tak geniální, že... si myslím, že jeho nové palivo je dost silné na to, aby prožralo přímo podvozek auta!$B$BNež k tomu dojde, chci zesílit palivové nádrže.$B$BŽelvy na pláních mají velmi tvrdé krunýře. Chci z nich vyrobit nové nádrže pro náš raketový vůz. Nádrže, které bratrovo nové palivo udrží.$B$BVypadáš dost zodpovědně. Seženeš mi ty krunýře?]],
[[Bring 9 Hardened Tortoise Shells to Wizzle Brassbolts in the Shimmering Flats.]],
[[Přines Wizzleovi Brassboltsovi v Shimmering Flats 9 zpevněné želví krunýře.]])

add(1106, "Martek the Exiled",
[[I'm developing a new engine that'll make the car go so fast!Fast enough to fly, I know it!I just need to make pistons that can handle very very heavy stress.All my trials have failed because I can't make pistons hard enough!$B$BBut there is someone who might know how.$B$BHis name is Martek the Exiled.He is a great smith and knows more about metal than anyone.Take him this letter, I know he can help!$B$BBut he's far far away -- in Azeroth, in the Badlands, in a camp, with a goblin!$B$BFind him!]],
[[Vyvíjím nový motor, díky kterému bude auto tak rychlé! Tak rychlé, že poletí, já to vím! Potřebuji jen vyrobit písty, které vydrží opravdu, opravdu obrovské namáhání. Všechny pokusy zatím selhaly, protože nedokážu vyrobit dost tvrdé písty!$B$BAle znám někoho, kdo by mohl vědět jak.$B$BJmenuje se Martek the Exiled. Je to skvělý kovář a o kovech ví víc než kdokoli jiný. Dones mu tento dopis, určitě nám pomůže!$B$BJe ale daleko, předaleko — v Azerothu, v Badlands, v táboře s goblinem!$B$BNajdi ho!]],
[[Bring Fizzle's Letter to Martek the Exiled in the Badlands.]],
[[Dones Fizzlův dopis Martekovi the Exiled v Badlands.]])

add(1107, "Encrusted Tail Fins",
[[Our rocket car is the fastest thing on the flats!So fast that ... I'm afraid friction is going to tear it apart!$B$BTo prevent that I need to create a composite to coat the car's moving parts.It must be hard but not brittle, and must be resistant to salt corrosion, or time spent on the Shimmering Flats will eat it away.$B$BHave you heard of the Vile Reef, $N?It's off the coast of Stranglethorn Vale.Saltscale murlocs live there, and their tail fins are a crucial ingredient of my composite.]],
[[Náš raketový vůz je nejrychlejší věc na pláních! Tak rychlá, že... se bojím, že ho tření roztrhá na kusy!$B$BAbych tomu zabránil, potřebuji vyrobit kompozitní povlak na pohyblivé části vozu. Musí být tvrdý, ale ne křehký, a odolný proti korozi ze soli, jinak ho pobyt na Shimmering Flats rozežere.$B$BSlyšel jsi o Vile Reef, $N? Leží u pobřeží Stranglethorn Vale. Žijí tam murloci Saltscale a jejich ocasní ploutve jsou zásadní složkou mého kompozitu.]],
[[Bring 10 Encrusted Tail Fins to Wizzle Brassbolts in the Shimmering Flats.]],
[[Přines Wizzleovi Brassboltsovi v Shimmering Flats 10 krustou pokryté ocasní ploutve.]])

add(1108, "Indurium",
[[I'm not out here just to stay away from people.There is a wealth of metal in the Badlands, $N, if you have the guts to get it.$B$BThe metal's called indurium and as luck would have it, it is rumored to possess high resistance to heat and stress.It might work for Fizzle's car.$B$BBut let's make sure.Get me samples of indurium and I'll test its properties.$B$BTrue indurium ore lies deep in Uldaman, but the Stonevault troggs of the Badlands sometimes have flakes of it on them.Bring me those flakes.]],
[[Nejsem tady jen proto, abych byl daleko od lidí. V Badlands je spousta kovu, $N, pokud máš odvahu si pro něj dojít.$B$BTen kov se jmenuje indurium a podle všeho mimořádně odolává teplu i namáhání. Pro Fizzleův vůz by mohl být ideální.$B$BAle ověřme si to. Přines mi vzorky induria a já otestuji jeho vlastnosti.$B$BPravá induriová ruda leží hluboko v Uldamanu, ale troggové Stonevault z Badlands u sebe někdy nosí její úlomky. Přines mi je.]],
[[Bring 10 Indurium Flakes to Martek the Exiled in the Badlands.]],
[[Přines Martekovi the Exiled v Badlands 10 vločky induria.]])

add(1109, "Going, Going, Guano!",
[[As you can see, $n, we're up to some very.... interesting experiments at the Royal Apothecary Society.$b$bAs the Master here, it is my job to oversee the most ambitious of our alchemical attempts. So much work and so little time!$b$bYou look well traveled for a $c. Perhaps you can aid me.$b$bI'm in need of a rare substance. It's foul material; it comes from a rare species of bats only found in the muck-hole known as Razorfen Kraul. Bring to me the guano from the Kraul Bats so we can begin our work...]],
[[Jak vidíš, $n, v Royal Apothecary Society se zabýváme velmi... zajímavými experimenty.$b$bJako zdejší mistr dohlížím na naše nejodvážnější alchymistické pokusy. Tolik práce a tak málo času!$b$bNa $c vypadáš docela zcestovale. Možná bys mi mohl pomoci.$b$bPotřebuji vzácnou látku. Je odporná a pochází z neobvyklého druhu netopýrů, kteří žijí jen v bahnité díře zvané Razorfen Kraul. Přines mi guáno Kraul Bats, abychom mohli začít s prací...]],
[[Bring 1 pile of Kraul Guano to Master Apothecary Faranell in the Undercity.]],
[[Přines 1 hromádku Kraul Guano Master Apothecary Faranellovi v Undercity.]])

add(1110, "Rocket Car Parts",
[[Heh heh, with all the races they're running here, it's no surprise that a few mishaps happen along the way.If you look around the Shimmering Flats then you'll see evidence of past crashes -- scraps of rocket car parts are littered everywhere!$B$BAnd those parts are worth money to the gnomes and goblins.They're always looking for more contraptions to slap onto their cars.$B$BSo go out and get me parts.Bring me a heap and I'll pay you well.]],
[[Heh heh, při všech těch závodech, které se tu jezdí, není divu, že občas dojde k nehodě. Když se rozhlédneš po Shimmering Flats, uvidíš stopy starých havárií — všude se válí součástky raketových vozů!$B$BA ty díly mají pro gnómy a gobliny cenu. Pořád hledají další udělátka, která by mohli přidělat na své vozy.$B$BTak vyraz a nějaké díly mi sežeň. Přines mi pořádnou hromadu a dobře ti zaplatím.]],
[[Bring 30 Rocket Car Parts to Kravel Koalbeard in the Shimmering Flats.]],
[[Přines Kravelu Koalbeardovi v Shimmering Flats 30 dílů raketových vozů.]])

add(1111, "Wharfmaster Dizzywig",
[[I make it my job to get people what they need, and the gnomes over there need a parts order filled.Their parts were shipped to Ratchet a week ago, but I haven't been able to make the trip.$B$BSo, are you ready for some legwork?Go to Ratchet and give this parts order to Wharfmaster Dizzywig -- he'll probably be at the docks.$B$BDo this for me, and I'll have more jobs for you.$B$BJobs, my friend, with serious profit potential...]],
[[Živím se tím, že lidem sháním to, co potřebují, a tamti gnómové potřebují vyřídit objednávku součástek. Jejich díly dorazily do Ratchet už před týdnem, ale já se tam nedokázal dostat.$B$BTak co, zvládneš trochu pochůzek? Vydej se do Ratchet a předej tuto objednávku Wharfmasteru Dizzywigovi. Nejspíš bude v docích.$B$BKdyž to pro mě uděláš, budu pro tebe mít další práci.$B$BPráci, příteli, s pořádným ziskovým potenciálem...]],
[[Bring Kravel's Parts Order to Wharfmaster Dizzywig in Ratchet.]],
[[Dones Kravelova objednávka dílů Wharfmasteru Dizzywigovi do Ratchet.]])

add(1112, "Parts for Kravel",
[[Here's Kravel's package, $N.And when you deliver it, tell him... if he wants more special orders, then he'll have to pay his tab!]],
[[Tady je Kravelův balík, $N. A až mu ho předáš, řekni mu... že jestli chce další zvláštní objednávky, musí nejdřív zaplatit svůj účet!]],
[[Bring Kravel's Parts to Kravel Koalbeard in the Shimmering Flats.]],
[[Přines Kravelovy díly Kravelu Koalbeardovi v Shimmering Flats.]])

add(1113, "Hearts of Zeal",
[[Why do I need a rare type of guano, you might ask. Well, for this experiment I want to see what effect two diametrically opposed chemical substances can have on each other, especially when both are combined with an ever-toxic agent to ensure the most... ghastly results.$b$bIn the northeastern peaks of Tirisfal Glades lies the Scarlet Monastery. There the crazed disciples of the Scarlet Crusade congregate. Slay them and bring me their zealous hearts.$b$bOur concoction will be most wicked!]],
[[Možná se ptáš, proč potřebuji vzácný druh guána. V tomto pokusu chci zjistit, jak na sebe působí dvě chemicky naprosto protikladné látky, zvlášť když je smícháme s vysoce jedovatým činidlem, které má zaručit opravdu... příšerné výsledky.$b$bV severovýchodních výšinách Tirisfal Glades leží Scarlet Monastery. Shromažďují se tam pomatení stoupenci Scarlet Crusade. Zabij je a přines mi jejich horlivá srdce.$b$bNáš výtvor bude skutečně odporný!]],
[[Master Apothecary Faranell in the Undercity wants 20 Hearts of Zeal.]],
[[Master Apothecary Faranell v Undercity chce 20 Hearts of Zeal.]])

add(1114, "Delivery to the Gnomes",
[[Now that I have what I need, give these parts to Fizzle Brassbolts.He's been waiting a long time for them -- I'm sure he won't miss the little piece I removed from his order...$B$BAnd I wouldn't bother mentioning it to him.It was small and worthless.$B$BTrust me.]],
[[Teď, když mám, co jsem potřeboval, dones tyhle součástky Fizzleovi Brassboltsovi. Čeká na ně už dlouho — určitě si ani nevšimne té maličkosti, kterou jsem z objednávky vyndal...$B$BAni bych se mu o tom nezmiňoval. Byla malá a bezcenná.$B$BVěř mi.]],
[[Bring the Delicate Car Parts to Fizzle Brassbolts in Shimmering Flats.]],
[[Přines Delicate Car Parts Fizzleovi Brassboltsovi v Shimmering Flats.]])

add(1115, "The Rumormonger",
[[Now that we've done a service for the gnomes, it's time to do the goblins a favor!$B$BI hear that the goblin racer pilot, Nazz Steamboil, didn't always use that name.I wonder why he changed it.I wonder if it's a secret, and... I wonder if he values that secret.$B$BIf anyone knows the truth, then it's Krazek of Booty Bay, on the southern tip of Stranglethorn.Speak with Krazek and ask him about our goblin pilot.$B$BIf you can get useful information from him, then we might just turn a profit from it.]],
[[Když už jsme udělali službu gnómům, je čas pomoci také goblinům!$B$BSlyšel jsem, že gobliní závodník Nazz Steamboil se tak nejmenoval vždycky. Zajímalo by mě, proč si změnil jméno. Jestli je za tím tajemství a... jak moc si toho tajemství cení.$B$BJestli někdo zná pravdu, bude to Krazek z Booty Bay na jižním cípu Stranglethornu. Promluv s ním a zeptej se na našeho gobliního pilota.$B$BKdyž z něj dostaneš něco užitečného, možná na tom dokážeme vydělat.]],
[[Talk to Krazek in Booty Bay.]],
[[Promluv s Krazekem v Booty Bay.]])

add(1116, "Dream Dust in the Swamp",
[[Getting the information on Nazz is quite a favor, $N.Yes, quite a favor.But you've come all the way from the Shimmering Flats to get it... are you willing to travel some more?$B$BWhile I contact my sources, why don't you gather something for me, eh?$B$BHm... what will it be?How about dream dust, from the dragon whelps of the Swamp of Sorrows.Yes, I'd love some dream dust for my snuff pouch!$B$BGet it for me, $N, and I'll give you the information you seek.]],
[[Sehnat informace o Nazzovi je pořádná laskavost, $N. Opravdu pořádná. Ale když jsi kvůli nim dorazil až ze Shimmering Flats... zvládneš ještě trochu cestování?$B$BZatímco budu kontaktovat své zdroje, mohl bys pro mě něco sehnat, co říkáš?$B$BHm... co by to mohlo být? Třeba dream dust z dračích mláďat ve Swamp of Sorrows. Ano, trochu dream dustu do tabatěrky by mi udělalo radost!$B$BSežeň mi ho, $N, a já ti dám informace, které hledáš.]],
[[Bring 10 Specks of Dream Dust to Krazek in Booty Bay.Dream Dust is gathered from the dragon whelps of the Swamp of Sorrows.]],
[[Přines Krazekovi v Booty Bay 10 zrnka snového prachu. snový prach získáš z dračích mláďat ve Swamp of Sorrows.]])

add(1117, "Rumors for Kravel",
[[I had to use some of my favors, and gave away a rare bottle of elven wine, and did some heavy deducing myself!But I found the information you seek.$B$BHere, I wrote a letter with some very interesting bits on our friend, Nazz Steamboil.Do with it what you will -- it's too dangerous for me to use.$B$BJust don't tell anyone where you got it!]],
[[Musel jsem využít pár laskavostí, rozloučit se se vzácnou lahví elfského vína a pořádně zapojit vlastní hlavu! Ale informace, které hledáš, jsem našel.$B$BTady, sepsal jsem dopis s několika velmi zajímavými podrobnostmi o našem příteli Nazzovi Steamboilovi. Nalož s nimi, jak chceš — pro mě je příliš nebezpečné je využít.$B$BJen nikomu neříkej, odkud je máš!]],
[[Bring the Goblin Rumors to Kravel Koalbeard in the Shimmering Flats.]],
[[Přines Goblin Rumors Kravelu Koalbeardovi v Shimmering Flats.]])

add(1118, "Back to Booty Bay",
[[$N, you're a $c I can trust, both to get the job done and to keep your mouth shut while doing it.$B$BI've been brewing up a new scheme.It's risky, but if it works then we could both make a bundle!And I think you're just the person to see it through.$B$BTo start, you must go back to Booty Bay.I apologize, good $N.I know my last task took you there.But this time, speak with Crank Fizzlebub.$B$BGive him this letter.And if he requires aid, do your best to help him.It will be worth the effort.]],
[[$N, jsi $c, kterému můžu věřit — že práci dokončí a přitom udrží jazyk za zuby.$B$BPřipravuji nový plán. Je riskantní, ale pokud vyjde, můžeme oba pořádně vydělat! A myslím, že právě ty ho dokážeš dotáhnout do konce.$B$BNejdřív se musíš vrátit do Booty Bay. Omlouvám se, $N, vím, že tě tam poslal už můj předchozí úkol. Tentokrát ale promluv s Crankem Fizzlebubem.$B$BDej mu tento dopis. A pokud bude potřebovat pomoc, udělej, co můžeš. Vyplatí se to.]],
[[Bring Kravel's Scheme to Crank Fizzlebub in Booty Bay.]],
[[Dones Kravelův plán Cranku Fizzlebubovi do Booty Bay.]])

add(1119, "Zanzil's Mixture and a Fool's Stout",
[[I figured out how to use Zanzil's mixture with stout to make a powerful libation.A Fool's Stout.I think it'll be just what Kravel needs, but try it out and let me know how it works.$B$BAnd $N, don't keep this stuff too long without using it.Zanzil's mixture has a weird effect on the stout's yeast, kicking it into high gear.So it won't stay fresh forever.]],
[[Přišel jsem na to, jak spojit Zanzilovu směs se stoutem a vyrobit pořádně silný nápoj. Fool's Stout. Myslím, že přesně to Kravel potřebuje, ale vyzkoušej ho a dej mi vědět, jak funguje.$B$BA $N, nenechávej ho příliš dlouho ležet. Zanzilova směs má podivný vliv na kvasnice ve stoutu a pořádně je nakopne. Takže čerstvý nevydrží věčně.]],
[[Bring the Fool's Stout back to Kravel in the Shimmering Flats.]],
[[Dones Fool's Stout zpět Kravelovi v Shimmering Flats.]])

add(1120, "Get the Gnomes Drunk",
[[We need to try the Fool's Stout on one of the pit crews.If you want to try it on the gnomes, then here -- take the stout and give it to the gnome pit boss.$B$BAnd don't wait too long.This stout will go bad eventually.]],
[[Musíme Fool's Stout vyzkoušet na jednom z mechanických týmů. Jestli ho chceš zkusit na gnómech, vezmi ho a dej ho jejich vedoucímu.$B$BA nečekej příliš dlouho. Tenhle stout se časem zkazí.]],
[[Bring the Fool's Stout to the Gnome Pit Boss.]],
[[Dones Fool's Stout Gnome Pit Bossovi.]])

add(1121, "Get the Goblins Drunk",
[[We need to try the Fool's Stout on one of the pit crews.If you want to try it on the goblins, then here -- take the stout and give it to the goblin pit boss.$B$BAnd don't wait too long.This stout will go bad eventually.]],
[[Musíme Fool's Stout vyzkoušet na jednom z mechanických týmů. Jestli ho chceš zkusit na goblinech, vezmi ho a dej ho jejich vedoucímu.$B$BA nečekej příliš dlouho. Tenhle stout se časem zkazí.]],
[[Bring the Fool's Stout to the Goblin Pit Boss.]],
[[Dones Fool's Stout Goblin Pit Bossovi.]])

add(1122, "Report Back to Fizzlebub",
[[That Fool's Stout worked great!I placed a bet on the next race, and... let's hope the crew you got drunk did a number on their car!$B$BThere's only one more task for you -- take this note back to Crank Fizzlebub in Booty Bay.He'll want to know of the successful test.$B$BAnd hopefully we can get more of that Fool's Stout for future races!]],
[[Fool's Stout zafungoval skvěle! Vsadil jsem si na příští závod a... doufejme, že tým, který jsi opil, pořádně zřídil své auto!$B$BČeká tě už jen jeden úkol — dones tuto zprávu zpět Cranku Fizzlebubovi do Booty Bay. Bude chtít vědět, že test dopadl úspěšně.$B$BA snad získáme další Fool's Stout pro budoucí závody!]],
[[Bring the Fool's Stout report to Crank Fizzlebub in Booty Bay.]],
[[Dones hlášení o Fool's Stout Cranku Fizzlebubovi do Booty Bay.]])

add(1123, "Rabine Saturna",
[[For this task, Keeper Remulos' majordomo in Moonglade - Rabine Saturna - seeks aid in exploring the vast wastelands far to the west of Tanaris and Un'Goro.He is located in Nighthaven, the main village of Moonglade.$B$BI want to impart on you the importance of your presence.There are growing tensions between the night elves of Darnassus and the Cenarion Circle in Moonglade.Look beyond racial boundaries and tap into the wisdom of your ancestors in dealings with the Circle there, $N.Good luck.]],
[[Pro tento úkol hledá pomoc Rabine Saturna, majordomus Keepera Remulose v Moonglade. Potřebuje prozkoumat rozsáhlé pustiny daleko na západ od Tanaris a Un'Goro. Najdeš ho v Nighthavenu, hlavní vesnici Moonglade.$B$BChci zdůraznit, jak důležitá je tvá přítomnost. Napětí mezi nočními elfy z Darnassus a Cenarion Circle v Moonglade roste. Při jednání s Circle se povznes nad hranice ras a čerpej z moudrosti svých předků, $N. Hodně štěstí.]],
[[Speak with Rabine Saturna in the village of Nighthaven, Moonglade.Moonglade lies between Felwood and Winterspring, accessible through a path out of Timbermaw Hold.]],
[[Promluv s Rabinem Saturnou ve vesnici Nighthaven v Moonglade. Moonglade leží mezi Felwoodem a Winterspring a dostaneš se tam cestou z Timbermaw Hold.]])

add(1124, "Wasteland",
[[West of Un'Goro Crater, via the northwestern ridge, is a harsh wasteland - Silithus.Few know that an ancient war was waged there between the night elves and a malign, alien power.The evil was sealed, but now we suspect that forces work to stir this... unspeakable horror.$B$BSeek out Layo Starstrike, one of our agents in Silithus; look for him at Valor's Rest, the final resting spot for the fallen of the wastes.Give him this letter, and he will give you his trust accordingly.]],
[[Západně od Un'Goro Crater, za severozápadním hřebenem, leží drsná pustina — Silithus. Jen málokdo ví, že tam kdysi zuřila válka mezi nočními elfy a zhoubnou cizí mocností. Zlo bylo zapečetěno, ale nyní máme podezření, že se někdo snaží probudit tuto... nevyslovitelnou hrůzu.$B$BVyhledáš Laya Starstrikea, jednoho z našich agentů v Silithus. Najdeš ho u Valor's Rest, posledního odpočinku padlých z pustiny. Dej mu tento dopis a získáš jeho důvěru.]],
[[Speak with Layo Starstrike near the Valor's Rest graveyard of Silithus, showing him Rabine's Letter.]],
[[Promluv s Layem Starstrikem poblíž hřbitova Valor's Rest v Silithus a ukaž mu Rabinův dopis.]])

add(1125, "The Spirits of Southwind",
[[To our southwest lies a tragic site - the ruins of Southwind Village.This is where our work should begin, $N.$B$BFrom what we've learned, this village was once a night elf base of operations for Silithus.It's long since overrun by the silithid hives that infest the wastes.I can only imagine the horror of the village's initial sundering...$B$BThe tortured spirits of fallen druids and sentinels wander the ruins aimlessly.Explore this locale, freeing the souls of these wretched beings as needed.]],
[[Jihozápadně od nás leží místo tragédie — ruiny Southwind Village. Právě tam bychom měli začít, $N.$B$BPodle našich zjištění byla vesnice kdysi základnou nočních elfů pro operace v Silithus. Už dávno ji však ovládly silithidí úly zamořující pustinu. Dokážu si jen představit hrůzu, která provázela zkázu vesnice...$B$BMučené duše padlých druidů a sentinelů bezcílně bloudí ruinami. Prozkoumej místo a osvoboď duše těchto nešťastníků.]],
[[Free the spirits of 8 Tortured Druids and 8 Tortured Sentinels in Southwind Village, and then return to Layo Starstrike at the Valor's Rest graveyard of Silithus.]],
[[Osvoboď duchy 8 mučených druidů a 8 mučených Sentinelů v Southwind Village a potom se vrať k Layovi Starstrikeovi u hřbitova Valor's Rest v Silithus.]])

add(1126, "Hive in the Tower",
[[The hive needs to be addressed in Southwind Village, and I think I know a way to get at them.It's been my experience that the silithid hives are very sensitive to their environment; this explains their attacks when hearing the death wails of the spirits.$B$BThe silithid are strongest in the tower - the one with the mass of wasps circling it.Scale the tower and jostle the hive into activity.Report back what you learn, but be careful!If you uncover anything that might help, bring it to me.]],
[[Úl v Southwind Village musíme řešit a myslím, že vím, jak se k němu dostat. Zkušenost mi říká, že silithidí úly jsou velmi citlivé na své okolí. To vysvětluje, proč útočí, když slyší smrtelné nářky duchů.$B$BSilithidi jsou nejsilnější ve věži — v té, kolem které krouží celé hejno vos. Vystoupej nahoru a vyprovokuj úl k aktivitě. Zjisti, co se stane, a podej mi hlášení. Buď ale opatrný! Pokud objevíš něco, co by nám mohlo pomoci, přines to s sebou.]],
[[Scale the tower of Southwind Village and locate a means to stir the silithid hive into activity.Bring back anything unusual you may uncover when doing so to Layo Starstrike at the Valor's Rest graveyard of Silithus.]],
[[Vystoupej na věž v Southwind Village a najdi způsob, jak vyprovokovat silithidí úl k aktivitě. Všechno neobvyklé, co při tom objevíš, přines Layovi Starstrikeovi k hřbitovu Valor's Rest v Silithus.]])

add(1127, "Fool's Stout",
[[So you want some Fool's Stout, eh?Thinking of heading back to the races...?$B$BAll right, bring me more of Zanzil's mixture and I'll make some more stout for you.]],
[[Takže chceš další Fool's Stout, hm? Chystáš se zase na závody...?$B$BDobře, přines mi další Zanzilovu směs a připravím ti další stout.]],
[[Bring 12 of Zanzil's Mixture to Crank Fizzlebub in Booty Bay.]],
[[Přines Cranku Fizzlebubovi v Booty Bay 12 kusů Zanzilova směs.]])

add(1132, "Fiora Longears",
[[Oh, to be at sea once again!To feel the kiss of the wind, and to have the waves rock me like my blessed mother, long ago!$B$BOh, I wish I had your fortune, good $c, for I see the sea in your future!$B$BIt's my job to tell eager souls of the land of Kalimdor, the land of opportunity!If you're willing to try your luck across the sea, then take a ship from here to the lovely port of Theramore.Speak there with my partner, the elf, Fiora Longears.$B$BShe'll start you on your Kalimdor adventure!]],
[[Ach, být zase na moři! Cítit polibek větru a nechat se houpat vlnami jako kdysi v náručí mé požehnané matky!$B$BÓ, kéž bych měl tvé štěstí, dobrý $c, protože ve tvé budoucnosti vidím moře!$B$BMým úkolem je vyprávět dobrodružným duším o zemi Kalimdor, zemi příležitostí! Pokud chceš zkusit štěstí za mořem, nastup zde na loď do krásného přístavu Theramore. Tam promluv s mou společnicí, elfkou Fiorou Longears.$B$BOna tě uvede do tvého kalimdorského dobrodružství!]],
[[Speak with Fiora Longears in Theramore.]],
[[Promluv s Fiorou Longears v Theramore.]])

add(1135, "Highperch Venom",
[[As you may know, wyverns are often tamed by orcs for use as mounts.But what is less known is that the venom of a wyvern, in some circles, is more valuable than the beast itself.So if you're not afraid to do a little wyvern hunting, then... I have a job for you.$B$BThere is a place called Highperch in the land of a Thousand Needles, west of here.The Highperch wyverns have a potent venom.Potent, and valuable.]],
[[Jak možná víš, orkové často krotí wyverny a používají je jako jezdecká zvířata. Méně známé však je, že v některých kruzích má jejich jed větší cenu než samotná bestie. Jestli se tedy nebojíš trochu lovu na wyverny... mám pro tebe práci.$B$BZápadně odsud v Thousand Needles leží místo zvané Highperch. Tamní wyverny mají velmi silný jed. Silný a cenný.]],
[[Bring 10 Highperch Venom Sacs to Fiora Longears in Theramore.]],
[[Přines Fioře Longears v Theramore 10 jedové váčky Highperch.]])

add(1136, "Frostmaw",
[[$N, it is now time for you to travel to far-off lands.You are ready.$B$BYou now hunt Frostmaw, a yeti in the Alterac Mountains.He is elusive, his white coat blending into the snows of his mountain home.He rarely shows himself.$B$BBut I will show you how to entice a creature such as he.Here, take this scroll.On it I have written how Frostmaw may be lured.$B$BNow go, $N.Your journey is long and many challenges lay waiting.When you return with Frostmaw's mane, only then is your task complete.]],
[[$N, nadešel čas vydat se do vzdálených zemí. Jsi připraven.$B$BTeď budeš lovit Frostmawa, yettiho z Alterac Mountains. Je nepolapitelný, jeho bílá srst splývá se sněhem horského domova a ukazuje se jen zřídka.$B$BAle ukážu ti, jak takového tvora vylákat. Vezmi si tento svitek. Napsal jsem na něj postup, jak Frostmawa přivolat.$B$BTeď jdi, $N. Čeká tě dlouhá cesta a mnoho zkoušek. Úkol bude dokončen teprve tehdy, až se vrátíš s Frostmawovou hřívou.]],
[[Bring Frostmaw's Mane to Melor Stonehoof in Thunder Bluff.]],
[[Přines Frostmawova hříva Meloru Stonehoofovi v Thunder Bluff.]])

add(1137, "News for Fizzle",
[[Indurium has an amazing resistance to heat!I'm sure it will work for Fizzle's pistons.But he'll need true indurium ore, not just the flakes.$B$BTo get the ore, it must be mined from deep within Uldaman, on the northern borders of the Badlands.That is the true source of indurium.$B$BSend Fizzle Brassbolts my regards, and tell him what I told you.$B$BSafe travels, $N.And it won't surprise me if we meet again -- once Fizzle learns of indurium he'll probably send you to Uldaman to acquire it!]],
[[Indurium má úžasnou odolnost proti žáru! Jsem si jistý, že pro Fizzleovy písty bude fungovat. Bude ale potřebovat skutečnou induriovou rudu, ne jen úlomky.$B$BRuda se těží hluboko uvnitř Uldamanu na severním okraji Badlands. To je pravý zdroj induria.$B$BPozdravuj ode mě Fizzlea Brassboltse a řekni mu, co jsem ti pověděl.$B$BŠťastnou cestu, $N. A vůbec mě nepřekvapí, když se ještě potkáme — až Fizzle zjistí, co indurium dokáže, nejspíš tě pošle do Uldamanu pro další!]],
[[Speak with Fizzle Brassbolts in the Shimmering Flats.]],
[[Promluv s Fizzlem Brassboltsem v Shimmering Flats.]])

add(1139, "The Lost Tablets of Will",
[[We've slowed the Shadowforge clan by cutting them off from Blackrock Spire, but Hammertoe's quest is still unfulfilled. His death must not be in vain. He dreamt of finding the Tablet of Will: a stone shard inscribed with magic by the titans themselves to help imbue their creations with life--making them have a will of their own, or so the legends say.$B$BWe must still recover the Tablet before the Shadowforge clan finds it.$B$BReturn to Uldaman, find the tablet, and return here immediately.]],
[[Klan Shadowforge jsme zpomalili tím, že jsme ho odřízli od Blackrock Spire, ale Hammertoeův úkol stále není dokončen. Jeho smrt nesmí přijít nazmar. Snil o nalezení Tabulka vůle, kamenného úlomku popsaného magií samotných titánů, která měla jejich výtvorům vdechnout život a vlastní vůli, alespoň podle legend.$B$BMusíme tabulku získat dřív než Shadowforge.$B$BVrať se do Uldamanu, najdi ji a okamžitě se vrať.]],
[[Find the Tablet of Will, and return them to Advisor Belgrum in Ironforge.]],
[[Najdi Tabulka vůle a vrať se s ní k Advisoru Belgrumovi do Ironforge.]])

add(1142, "Mortality Wanes",
[[I have not long to live... so... so... weak.$b$b...the b-b-brave dwarf, Lonebrow, has been sent to w-w-warn Falfindel...$b$bBut before I... d-d-die...$b$b...my wife, Treshala... her pendant of bonding to me... stolen... by one of the f-f-foul aggressors...$b$bFind it p-p-please... and return it to Treshala in Darnassus...$b$b...along with w-w-word of my lonely... death.]],
[[Už mi nezbývá mnoho času... jsem... tak... slabý.$b$b...s-s-statečný trpaslík Lonebrow byl poslán v-v-varovat Falfindela...$b$bAle než... z-z-zemřu...$b$b...má žena Treshala... její přívěsek našeho svazku... ukradl ho... jeden z těch o-o-ohavných útočníků...$b$bNajdi ho p-prosím... a vrať ho Treshale do Darnassus...$b$b...spolu se z-z-zprávou o mé osamělé... smrti.]],
[[Find and return Treshala's Pendant to Treshala Fallowbrook in Darnassus.]],
[[Najdi Treshalin přívěsek a vrať ho Treshale Fallowbrook v Darnassus.]])

add(1144, "Willix the Importer",
[[At last, help has arrived!$b$bYou have no clue how long I've been held prisoner here. I can't remember the last time I saw the outside of this place.$b$bYou see, I am an entrepreneur. Always out for a copper, as they say. I caught wind that Mebok Mizzyrix was paying well for Redleaf Tuber from this here pig pen. I figured it would be an easy in, easy out kind of affair. As you can see, I was a bit wrong!$b$bAnyway, if you'd be so kind as to help me get out of here, I'll make it worth your while.]],
[[Konečně dorazila pomoc!$b$bAni netušíš, jak dlouho mě tu drží jako vězně. Už si ani nepamatuji, kdy jsem naposledy viděl svět venku.$b$bVíš, jsem podnikatel. Jak se říká, vždycky jdu po každém měďáku. Doslechl jsem se, že Mebok Mizzyrix dobře platí za Redleaf Tuber z tohoto prasečince. Myslel jsem, že to bude rychlá akce: dovnitř, ven. Jak vidíš, trochu jsem se spletl!$b$bKaždopádně, jestli budeš tak hodný a pomůžeš mi odsud, odměna tě nemine.]],
[[Escort Willix the Importer out of Razorfen Kraul.]],
[[Doprovod Willixe the Importer ven z Razorfen Kraul.]])

add(1145, "The Swarm Grows",
[[Many travelers who've come through the Crossroads helped me gather eggs from the Field of Giants, and many of them have tales of how deadly the creatures are. I've heard enough to consider them insects a much larger threat than my masters first thought.$B$BI need a courier to travel to Orgrimmar to meet Belgrom Rockmaul. It be no simple matter, and someone who would take the task seriously should go.$B$BBelgrom usually be found outside the warriors' guild house.]],
[[Mnoho cestovatelů, kteří prošli Crossroads, mi pomáhalo sbírat vejce ve Field of Giants a mnozí vyprávěli, jak smrtelně nebezpeční tamní tvorové jsou. Slyšel jsem už dost, abych tyto hmyzáky považoval za mnohem větší hrozbu, než si mí nadřízení původně mysleli.$B$BPotřebuji kurýra, který se vydá do Orgrimmaru za Belgromem Rockmaulem. Není to lehký úkol a měl by ho vzít někdo, kdo ho bude brát vážně.$B$BBelgroma obvykle najdeš před domem cechu válečníků.]],
[[Deliver Korran's Sealed Note to Belgrom Rockmaul in Orgrimmar.]],
[[Doruč Korranova zapečetěná zpráva Belgromu Rockmaulovi v Orgrimmaru.]])

add(1146, "The Swarm Grows",
[[So, Korran has come to a similar conclusion about these insects--they seem to be a larger threat than we assumed.$B$BA few days ago a hunter returned to me from Thousand Needles nearly dead. He was with a raiding party sent to drive a dwarven excavation team out of the Shimmering Flats. During the attack, more of these insects erupted from a cave in the dig site and nearly killed the party.$B$BThey were led by Moktar Krin, and they've taken refuge on the border of the Shimmering Flats. Bring him this note.]],
[[Takže Korran došel ohledně těch hmyzáků ke stejnému závěru. Zdá se, že představují větší hrozbu, než jsme si mysleli.$B$BPřed několika dny se ke mně z Thousand Needles vrátil lovec, sotva živý. Byl součástí útočné skupiny, která měla vyhnat trpasličí výpravu ze Shimmering Flats. Během útoku se z jeskyně na nalezišti vyrojili další tito tvorové a skupinu málem vyhladili.$B$BVedl je Moktar Krin a teď se ukrývají na hranici Shimmering Flats. Dones mu tento dopis.]],
[[Deliver Belgrom's Sealed Note to Moktar Krin in Thousand Needles.]],
[[Doruč Belgromova zapečetěná zpráva Moktaru Krinovi v Thousand Needles.]])

add(1147, "The Swarm Grows",
[[Hmm. Seems Belgrom thinks those monsters are a threat. He wants them pushed back into whatever depths they crawled up out of.$B$BI guess killing the dwarves sent by the Explorers' League wasn't enough--now I have to send a half-dead war party into another battle. We won't be able to do it ourselves; not while we're in this condition. The dig site's to the south of here. There shouldn't be anymore dwarves to deal with. Feel up to wielding a blade or staff and doing your part to aid us?]],
[[Hmm. Zdá se, že Belgrom považuje ty příšery za hrozbu. Chce je zahnat zpět do hlubin, odkud vylezly.$B$BZřejmě nestačilo zabít trpaslíky vyslané Explorers' League. Teď mám poslat napůl mrtvou bojovou skupinu do další bitvy. V tomhle stavu to sami nezvládneme. Naleziště je jižně odsud a žádní další trpaslíci by tam už být neměli. Troufáš si popadnout čepel nebo hůl a pomoci nám?]],
[[Kill 5 Silithid Searchers, 5 Silithid Hive Drones, and 5 Silithid Invaders and return to Moktar Krin in Thousand Needles.]],
[[Zabij 5 silithidí průzkumníky, 5 silithidí dělníky úlu a 5 silithidí vetřelce a vrať se k Moktaru Krinovi v Thousand Needles.]])

add(1148, "Parts of the Swarm",
[[You inspect the carapace carefully. As you turn it over in your hands you realize that the chitinous plating is interlaced in such a way that makes it incredibly strong. It's unlike anything you've ever seen. You inspect the rest of the corpse further and realize that these creatures are very powerful and highly evolved.$B$BLooking down at the carapace again, you think that Korran would enjoy studying more of these creatures. It could help him figure out what these creatures are, and where they come from.]],
[[Pečlivě si prohlížíš krunýř. Když ho obracíš v rukou, všimneš si, že chitinové pláty jsou propletené tak, že vytvářejí neuvěřitelně pevnou ochranu. Nic podobného jsi ještě neviděl. Při prohlídce zbytku těla zjišťuješ, že tito tvorové jsou mimořádně silní a vysoce vyvinutí.$B$BKdyž se znovu podíváš na krunýř, napadne tě, že Korran by rád prozkoumal další části těchto tvorů. Mohlo by mu to pomoci zjistit, co jsou zač a odkud pocházejí.]],
[[Bring 1 Silithid Heart, 5 Silithid Talons, and 3 Intact Silithid Carapaces, to Korran at the Crossroads.]],
[[Přines Korranovi v Crossroads 1 srdce silithida, 5 drápy silithidů a 3 neporušené silithidí krunýře.]])

add(1149, "Test of Faith",
[[So, you have sought me out, or perhaps destiny brings you to me? No matter. You are here now, and so your journey will begin anew.$B$BMany facets make up a being: the spirit, the body, the mind. Some of these can be measured by a culture's traditions. Others we can only hope exist within ourselves. If you agree, I shall test some of the facets within you.$B$BIf you pass, then you shall become stronger. If you fail, then you will realize the vastness of the Nether.$B$BThe first is a Test of Faith.]],
[[Takže jsi mě vyhledal... nebo tě ke mně přivedl osud? Na tom nezáleží. Teď jsi tady a tvá cesta začne znovu.$B$BBytost tvoří mnoho stránek: duch, tělo a mysl. Některé lze měřit podle tradic našeho lidu. U jiných můžeme jen doufat, že je v sobě máme. Pokud souhlasíš, několik těchto stránek v tobě vyzkouším.$B$BProjedeš-li zkouškou, zesílíš. Selžeš-li, poznáš nekonečnost Netheru.$B$BPrvní je Zkouška víry.]],
[[If you have faith, leap from the planks overlooking Thousand Needles.]],
[[Pokud máš víru, skoč z prken nad Thousand Needles.]])

add(1150, "Test of Endurance",
[[I'm pleased to see your courage remains steadfast in light of what you've already done. Since your faith is intact, the time has come to test your body.$B$BFirst isa test of endurance. Go with friends to the Roguefeather Den west of Freewind Post. Make your way to the depths of their lair and destroy their foodstuffs. By then you should have provoked their fury, and if you are able to survive long enough, Grenka Bloodscreech herself will come for you--kill her and bring me her claw to complete your test.]],
[[Těší mě, že po tom všem, co jsi už dokázal, zůstává tvá odvaha pevná. Když tvá víra obstála, je čas prověřit tělo.$B$BPrvní je zkouška vytrvalosti. Vydej se s přáteli do Roguefeather Den západně od Freewind Post. Probojuj se hluboko do jejich doupěte a znič jejich zásoby jídla. Tím je rozzuříš a pokud vydržíš dost dlouho, přijde si pro tebe samotná Grenka Bloodscreech. Zabij ji a přines mi její dráp jako důkaz dokončení zkoušky.]],
[[Bring Grenka's Claw to Dorn Plainstalker in Thousand Needles.]],
[[Přines Grenčin dráp Dornu Plainstalkerovi v Thousand Needles.]])

add(1151, "Test of Strength",
[[During the time of the Old Gods, elementals inhabited much of this world. They worshipped the Old Gods, and the Gods, through their power, kept the elementals bound to this world. When the Old Gods were banished, the elementals faded from our world and now only return at the bidding of powerful mages.$B$BThere are exceptions though. Some elementals were powerful enough to remain here on their own. One such elemental is Rok'Alim.$B$BTo test your strength, find Rok'Alim in Thousand Needles and slay him.]],
[[Za časů Old Gods obývali elementálové velkou část tohoto světa. Uctívali Old Gods a ti je svou mocí poutali k našemu světu. Když byli Old Gods vyhnáni, elementálové z našeho světa zmizeli a dnes se většinou vracejí jen na příkaz mocných mágů.$B$BExistují ale výjimky. Někteří byli natolik silní, že dokázali zůstat sami. Jedním z nich je Rok'Alim.$B$BAby ses podrobil zkoušce síly, najdi Rok'Alima v Thousand Needles a zabij ho.]],
[[Bring Fragments of Rok'Alim to Dorn Plainstalker in Thousand Needles.]],
[[Přines úlomky Rok'Alima Dornu Plainstalkerovi v Thousand Needles.]])

add(1152, "Test of Lore",
[[Your time with me is just about finished. I am knowledgeable, but the Test of Lore is not mine to give. There are lessons to be learned and places to visit that others claim domain over.$B$BIf you are prepared, then seek out Braug Dimspirit--he is a shaman of great wisdom. He will test you further, so heed his words, $N.$B$BWhen you are ready, find the tunnel that connects the Stonetalon Mountains with Ashenvale: Braug dwells near there. And be careful, $N, the night elves may wish to impede your test.]],
[[Tvůj čas se mnou se chýlí ke konci. Mám mnoho vědomostí, ale Zkoušku vědomostí ti nemohu zadat já. Jsou lekce, které musíš přijmout od jiných, a místa, která spadají do jejich působnosti.$B$BJsi-li připraven, vyhledej Brauga Dimspirita, šamana velké moudrosti. Bude tě zkoušet dál, proto dobře poslouchej jeho slova, $N.$B$BAž budeš připraven, najdi tunel spojující Stonetalon Mountains s Ashenvale. Braug žije poblíž. A buď opatrný, $N, noční elfové se mohou pokusit tvou zkoušku překazit.]],
[[Find Braug Dimspirit near the entrance to Talondeep Path in Stonetalon Mountains.]],
[[Najdi Brauga Dimspirita poblíž vstupu do Talondeep Path ve Stonetalon Mountains.]])

add(1153, "A New Ore Sample",
[[$C, you have done well in helping me in the past. The warchief is pleased thus far with what I've accomplished, and asks me to continue with renewed determination. My honor dictates that I give you proper recognition to the warchief for all you have done, but first I would ask you for your help again.$B$BTravelers recently came from the south from a place called Thousand Needles. There they killed a kobold who had an unusual ore sample, but they would not sell it. I want a sample of that ore to examine.]],
[[$C, v minulosti jsi mi velmi pomohl. Warchief je zatím spokojený s tím, čeho jsem dosáhl, a žádá mě, abych pokračoval s novým odhodláním. Čest mi velí, abych před ním náležitě ocenil vše, co jsi vykonal, ale nejdřív tě musím znovu požádat o pomoc.$B$BNedávno dorazili cestovatelé z jihu, z místa zvaného Thousand Needles. Zabily tam kobolda, který u sebe měl neobvyklý vzorek rudy, ale odmítli ho prodat. Chci takový vzorek prozkoumat.]],
[[Find an Unrefined Ore Sample on a Gravelsnout Digger or Surveyor and bring it to Tatternack Steelforge at Camp Taurajo in the Barrens.]],
[[Najdi vzorek nerafinované rudy u Gravelsnout Diggera nebo Surveyora a přines ho Tatternacku Steelforgeovi do Camp Taurajo v Barrens.]])

add(1154, "Test of Lore",
[[You have passed Dorn's tests, and now you seek to pass your next trial. Very good. But up until now, your challenges have been childish. It is easy to test your body--your mind is another matter completely.$B$BI shall explain it simply: find the book I name, study it, and answer my question about its contents.$B$BWhat book, you must be asking? The Legacy of the Aspects. It can be found at the bottom of Dor'danil in southern Ashenvale, protected by the dead druids and their slayers.]],
[[Prošel jsi Dornovými zkouškami a teď hledáš další výzvu. Velmi dobře. Dosud však byly tvé zkoušky téměř dětské. Tělo se zkouší snadno — mysl je něco docela jiného.$B$BVysvětlím ti to jednoduše: najdi knihu, kterou jmenuji, prostuduj ji a odpověz na mou otázku o jejím obsahu.$B$BPtáš se, jakou knihu? Odkaz Aspektů. Najdeš ji na dně Dor'danilu v jižním Ashenvale, kde ji střeží mrtví druidové a jejich vrazi.]],
[[Find the Legacy of the Aspects and return it to Braug Dimspirit near the entrance to Talondeep Path in Stonetalon Mountains.]],
[[Najdi Odkaz Aspektů a vrať ji Braugu Dimspiritovi poblíž vstupu do Talondeep Path ve Stonetalon Mountains.]])

add(1159, "Test of Lore",
[[Well done, $N. You have passed the first portion of the Test of Lore, but there is still another question to be answered. But that question is not mine to ask.$B$BSeek out Parqual Fintallas in Lordaeron City. He was a great historian for the humans before the Plague overtook him. Now he continues to seek enlightenment, but of a different nature.$B$BHe will have another requirement of you before he asks you anything, but you have done masterfully thus far--I'm sure you will overcome his obstacle.]],
[[Dobrá práce, $N. Prošel jsi první částí Zkoušky vědomostí, ale ještě zbývá jedna otázka. Tu však nemohu položit já.$B$BVyhledáš Parquala Fintallase v Lordaeron City. Než ho zasáhl mor, byl mezi lidmi významným historikem. Nyní dál hledá poznání, byť jiného druhu.$B$BNež ti položí svou otázku, bude od tebe něco požadovat. Dosud sis vedl výborně, takže nepochybuji, že překonáš i jeho překážku.]],
[[Find Parqual Fintallas in Undercity.]],
[[Najdi Parquala Fintallase v Undercity.]])

add(1160, "Test of Lore",
[[I will tell you what you must seek, and I will even ask you my question, but not because you wish to prove yourself. Knowledge is far more important than strength. Even as others seem to pass you by in ability, your knowledge of the world will be more valuable.$B$BGo to the Monastery in the north of Tirisfal Glades. In the library there, a book called Beginnings of the Undead Threat resides. It was used by the now-corrupt paladins there to train them to fight my kind.$B$BBring it to me.]],
[[Povím ti, co musíš hledat, a položím ti i svou otázku, ale ne proto, že se chceš předvést. Vědění je mnohem důležitější než síla. I když tě ostatní mohou schopnostmi předčit, znalost světa bude mít větší cenu.$B$BJdi do Monastery na severu Tirisfal Glades. V tamní knihovně leží kniha Počátky nemrtvé hrozby. Dnes zkažení paladinové ji kdysi používali při výcviku v boji proti mému druhu.$B$BPřines mi ji.]],
[[Find The Beginnings of the Undead Threat, and return it to Parqual Fintallas in Undercity.]],
[[Najdi Počátky nemrtvé hrozby a přines ji Parqualu Fintallasovi do Undercity.]])

add(1164, "To Steal From Thieves",
[[The harlot! The swine! Kenata still lives; her family healthy and prospering while I suffer. Forsaken indeed!$B$BMy family is gone, taken by the plague. Our estate also forfeit; looted and burned during the war. And after all that, her and her lousy children had the audacity to steal the only precious belongings I had left.$B$BI don't care about the things they stole any more. What I want now are their heads!$B$BKill them for me! Go to the Dabyrie Farmstead in Arathi, northeast of Refuge Point.]],
[[Ta coura! Ta svině! Kenata pořád žije, její rodina je zdravá a prosperuje, zatímco já trpím. Forsaken, vskutku!$B$BMou rodinu vzal mor. O náš statek jsme také přišli, během války ho vyplenili a vypálili. A po tom všem měla ona i její mizerné děti tu drzost ukrást poslední cennosti, které mi zůstaly.$B$BUž mi nezáleží na věcech, které ukradli. Teď chci jejich hlavy!$B$BZabij je pro mě! Vydej se na Dabyrie Farmstead v Arathi, severovýchodně od Refuge Point.]],
[[Bring Kenata, Fardel, and Marcel Dabyrie's Heads to Genavie Callow in Undercity.]],
[[Přines hlavy Kenaty, Fardela a Marcela Dabyrie Genavii Callow v Undercity.]])

add(1166, "Overlord Mok'Morokk's Concern",
[[Bow before Overlord Mok'Morokk!$b$bRexxar make me mighty leader of Stonemaul Clan!$b$bMe good leader. Me keep clan safe.$b$bBig dragons come and make fire at old home. Me smart ogre. Find new home for clan here.$b$bLeave old home so fast, me forget stuff. Tiny $r, go get my things. Go south and find my yummy grog, my snuff and my strongbox. Me like you after you do that. You look in Den of Flame and Stonemaul Ruins... they be there, me sure!]],
[[Pokloň se před Overlordem Mok'Morokkem!$b$bRexxar udělat mě mocný vůdce Stonemaul Clan!$b$bJá dobrý vůdce. Já držet klan v bezpečí.$b$bVelcí draci přijít a dělat oheň ve starém domově. Já chytrý ogr. Najít klanu nový domov tady.$b$bMy utéct ze starého domova tak rychle, že já zapomenout věci. Malý $r, jdi pro moje věci. Jdi na jih a najdi můj dobrý grog, můj šňupací tabák a mou truhlu. Pak tě já mít rád. Hledej v Den of Flame a Stonemaul Ruins... tam budou, já si jistý!]],
[[Overlord Mok'Morokk in Brackenwall Village wants you to retrieve his grog, snuff and strongbox in Dustwallow Swamp.]],
[[Overlord Mok'Morokk v Brackenwall Village chce, abys v Dustwallow Swamp získal jeho grog, šňupací tabák a truhlu.]])

add(1168, "Army of the Black Dragon",
[[Mok'Morokk was made Overlord by Rexxar. He care more for power than he care for ogres.$b$bBlack dragons kill many ogre. Kill Tharg's wife. Mok'Morokk tell us to run. Make us come here.$b$bOgre should fight. Ogres not good at running. Mok'Morokk care only about Mok'Morokk.$b$bMe call Stonemaul Ruins home. Me like it in the south. This place not home.$b$bHelp ogres fight army of the black dragon. Me want revenge. Me want to go home.]],
[[Rexxar udělat Mok'Morokka Overlordem. On starat víc o moc než o ogry.$b$bČerní draci zabít mnoho ogrů. Zabít Thargovu ženu. Mok'Morokk říct nám utéct. Přivést nás sem.$b$bOgři mají bojovat. Ogři nejsou dobří v utíkání. Mok'Morokk starat jen o Mok'Morokka.$b$bJá říkat Stonemaul Ruins domov. Já mít rád jih. Tohle není domov.$b$bPomoz ogrům bojovat proti armádě černého draka. Já chtít pomstu. Já chtít domů.]],
[[Tharg in Brackenwall Village wants you to kill 15 Firemane Scouts, 10 Firemane Ash Tails, and 5 Firemane Guards.]],
[[Tharg v Brackenwall Village chce, abys zabil 15 průzkumníky Firemane, 10 popelavé ocasy Firemane a 5 strážce Firemane.]])

add(1169, "Identifying the Brood",
[[Whilst that craven fool, Mok'Morokk, wallows in power and Tharg wrestles the demons of sorrow and vengeance and vies for leadership of the clan, I seem to be the only one concerned with identifying the source of aggression on our old home.$b$bWhy the puzzled stare, $n? Expecting me to speak like an uncouth ruffian merely because I am an ogre?$b$bNow back to business, bring to me the hearts and tongues from the whelps and hatchlings. I shall trace the root of this evil...]],
[[Zatímco ten zbabělý hlupák Mok'Morokk se opájí mocí a Tharg zápasí se smutkem, touhou po pomstě a snahou převzít vedení klanu, zdá se, že jen mě zajímá skutečný původ útoku na náš starý domov.$b$bProč ten zmatený pohled, $n? Čekal jsi, že budu mluvit jako nevychovaný rváč jen proto, že jsem ogr?$b$bAle zpět k věci. Přines mi srdce a jazyky mláďat a vylíhlých dráčků. Vystopuji kořen tohoto zla...]],
[[Draz'Zilb in Brackenwall Village would like you to bring him 15 Searing Tongues and 15 Searing Hearts.]],
[[Draz'Zilb v Brackenwall Village chce, abys mu přinesl 15 žhnoucí jazyky a 15 žhnoucí srdce.]])

add(1170, "The Brood of Onyxia",
[[Stonemaul Village was invaded by the brood of Onyxia. But why would the daughter of the black dragonlord, Deathwing, descend upon our lands?$b$bThis is most troubling. Surely, Onyxia was driven here for a purpose beyond laying siege to a small band of ogres.$b$bNotify Mok'Morokk at once! Action must be taken.]],
[[Stonemaul Village napadlo potomstvo Onyxie. Proč by ale dcera pána černých draků Deathwinga sestupovala právě do našich zemí?$b$bTo je velmi znepokojivé. Onyxii sem určitě přivedlo něco důležitějšího než obléhání malé skupiny ogrů.$b$bOkamžitě uvědom Mok'Morokka! Musíme jednat.]],
[[Speak with Overlord Mok'Morokk in Brackenwall Village.]],
[[Promluv s Overlordem Mok'Morokkem v Brackenwall Village.]])

add(1171, "The Brood of Onyxia",
[[You leave me alone now. Go tell Draz'Zilb we stay here. No black dragon here.]],
[[Teď mě nechat na pokoji. Jdi říct Draz'Zilbovi, že my zůstat tady. Tady žádný černý drak.]],
[[Speak with Draz'Zilb in Brackenwall Village.]],
[[Promluv s Draz'Zilbem v Brackenwall Village.]])

add(1172, "The Brood of Onyxia",
[[Onyxia's brood has been scattered across the Dragonmurk. It is imperative that no more whelps be permitted to hatch.$b$bMake haste to Wyrmbog in the south of Dustwallow Marsh. Surely, she has made her lair there. Track down the evil dragon's eggs and destroy them.$b$bWe will never reclaim Stonemaul Village if the surrounding area remains a breeding ground.$b$bAs for Mok'Morokk... I have other plans for the sod.]],
[[Onyxiino potomstvo je rozptýlené po celém Dragonmurku. Nesmíme dovolit, aby se vylíhla další mláďata.$b$bPospěš do Wyrmbogu na jihu Dustwallow Marsh. Jistě si tam zřídila doupě. Najdi vejce té zlé dračice a znič je.$b$bStonemaul Village nikdy nezískáme zpět, dokud okolí zůstane líhní draků.$b$bA co se týče Mok'Morokka... s tím bídákem mám jiné plány.]],
[[Draz'Zilb in Brackenwall Village wants you to destroy 5 Eggs of Onyxia.]],
[[Draz'Zilb v Brackenwall Village chce, abys zničil 5 vajec Onyxie.]])

add(1173, "Challenge Overlord Mok'Morokk",
[[You dare challenge Overlord Mok'Morokk?$b$bHaw!$b$bMe crush tiny $r!$b$bYou tell me when ready for good beating.]],
[[Ty odvážit vyzvat Overlorda Mok'Morokka?$b$bHa!$b$bJá rozdrtit malý $r!$b$bŘekni, až připraven na pořádný výprask.]],
[[Defeat Mok'Morokk and report the news to Draz'Zilb in Brackenwall Village.]],
[[Poraz Mok'Morokka a oznam to Draz'Zilbovi v Brackenwall Village.]])

add(1175, "A Bump in the Road",
[[After the big crash with the goblins' Red Thunder racer and a basilisk, Kronkrider hired me on to take care of the track. I don't know what all the animals out on the flats are feeding on to grow so big, but we have to be careful to thin them out so they won't wander onto the track when a race is going on.$b$bTell you what. If you want to go out and make a little profit, go out and remove the basilisks from the area.]],
[[Po velké havárii gobliního závodního vozu Red Thunder s baziliškem mě Kronkrider najal, abych se staral o trať. Nevím, čím se všechna ta zvířata na pláních krmí, že rostou do takových rozměrů, ale musíme jejich počty držet nízko, aby nám během závodů nelezla na trať.$b$bTak co, chceš si trochu vydělat? Vyraz a zbav okolí bazilišků.]],
[[Kill 10 Saltstone Basilisks, 10 Saltstone Crystalhides and 6 Saltstone Gazers for Trackmaster Zherin on the Shimmering Flats.]],
[[Zabij pro Trackmastera Zherina v Shimmering Flats 10 bazilišky Saltstone, 10 krystalokožce Saltstone a 6 pozorovatele Saltstone.]])

add(1176, "Load Lightening",
[[When it comes to racing, every bit counts! Whether it's a minor tweaking on the power output, a slight slackening on the tension coils, or lightening the weight of the frame, you have to take everything into account.$b$bWe use vulture bones for a lot of the minor structural tweaks we make to our racers, which offer the perfect balance of strength and weight. Even better, it's easy for us to get more, as the salt flats are littered with vultures.$b$bBring me some and I'll give you a good price on them.]],
[[V závodech záleží na každé maličkosti! Ať už jde o drobnou úpravu výkonu, lehké povolení napínacích cívek nebo snížení hmotnosti rámu, musíš počítat se vším.$b$bPro drobné konstrukční úpravy našich závodních vozů často používáme supí kosti, protože nabízejí skvělý poměr pevnosti a hmotnosti. A navíc se snadno shánějí, protože solné pláně jsou supů plné.$b$bPřines mi nějaké a dobře ti za ně zaplatím.]],
[[Get 10 Hollow Vulture Bones for Pozzik in the Shimmering Flats.]],
[[Sežeň pro Pozzika v Shimmering Flats 10 duté supí kosti.]])

add(1177, "Hungry!",
[[Mud big ogre.$b$bMe hungry.$b$bGo bash fishy. Bring Mud food.$b$bYou feed Mud or Mud eat you.]],
[[Mud velký ogr.$b$bJá hlad.$b$bJdi praštit rybáky. Přines Mudovi jídlo.$b$bTy nakrmit Muda, nebo Mud sníst tebe.]],
[[Mudcrush Durtfeet in northern Dustwallow wants 12 Mirefin Heads.]],
[[Mudcrush Durtfeet v severním Dustwallow chce 12 hlavy Mirefinů.]])

add(1178, "Goblin Sponsorship",
[[Our racing team is the pride of goblins everywhere. You'd be surprised at some of the people who contribute in one way or another to our team.$b$bYou know Gazlowe? He tracks down parts from around the world for us. He even came down to work on one of our rigs once!$b$bA few weeks ago, he said he'd send us a new prototype fuel regulator but it hasn't come yet. He's usually very prompt... Maybe you wouldn't mind going to Ratchet to ask him about it? I wouldn't be so pushy, but the gnomes are gaining on us!]],
[[Náš závodní tým je chloubou goblinů po celém světě. Divili byste se, kdo všechno nám nějakým způsobem pomáhá.$b$bZnáš Gazlowea? Shání pro nás součástky z celého světa. Jednou dokonce přijel osobně pracovat na jednom z našich vozů!$b$bPřed pár týdny slíbil, že nám pošle nový prototyp regulátoru paliva, ale stále nedorazil. Obvykle je velmi spolehlivý... Nevadilo by ti zajít do Ratchet a zeptat se ho? Netlačil bych na něj, ale gnómové nás začínají dohánět!]],
[[Speak to Gazlowe in Ratchet.]],
[[Promluv s Gazloweem v Ratchet.]])

add(1179, "The Brassbolts Brothers",
[[You ever heard of the Shimmering Flats?It's a stretch of salt flats way over in Kalimdor, just south of the Thousand Needles canyon.It's a great place for racing because, well, it's so flat!$B$BA couple of gnome brothers are out there, friends of mine, trying out their new rocket car, and from what I hear it's fast!Heh, so fast that their pilots keep crashing.Giving themselves concussions.$B$BSo they asked me for some Siege Engine helmets, but I have duties here.I can't make the trip!$B$BCan you?]],
[[Slyšel jsi někdy o Shimmering Flats? Je to rozlehlá solná pláň daleko v Kalimdoru, jižně od kaňonu Thousand Needles. Je to skvělé místo pro závody, protože... je prostě dokonale rovná!$B$BMám tam dva známé gnómské bratry, kteří zkoušejí nový raketový vůz, a prý je pořádně rychlý! Heh, tak rychlý, že jejich piloti pořád havarují a přivodí si otřes mozku.$B$BPožádali mě proto o několik helem ze Siege Engine, jenže já mám povinnosti tady a nemůžu tam vyrazit.$B$BMůžeš ty?]],
[[Bring the crate of crash helmets to Wizzle Brassbolts in the Shimmering Flats.]],
[[Dones bednu ochranných helem Wizzleovi Brassboltsovi do Shimmering Flats.]])

add(1180, "Goblin Sponsorship",
[[Back to what you came here about. I know I promised Pozzik that I'd deliver a new fuel regulator for him, but I still haven't received it yet. Revilgaz over in Booty Bay said he'd have it shipped over, but it might be it slipped through the cracks somehow.$b$bIf that's true, there's not much we can do about it. We can at least find out if it was dispatched from Booty Bay.$b$bCheck in with Wharfmaster Lozgil over there, he should be able to check the cargo records.]],
[[Zpět k tomu, proč jsi přišel. Vím, že jsem Pozzikovi slíbil nový regulátor paliva, ale pořád mi nedorazil. Revilgaz z Booty Bay říkal, že ho pošle, ale možná se zásilka někde ztratila.$b$bJestli je to tak, moc s tím nenaděláme. Můžeme alespoň zjistit, zda byl z Booty Bay skutečně odeslán.$b$bZajdi tam za Wharfmasterem Lozgilem. Měl by být schopný zkontrolovat záznamy o nákladu.]],
[[Speak with Wharfmaster Lozgil in Booty Bay.]],
[[Promluv s Wharfmasterem Lozgilem v Booty Bay.]])

add(1181, "Goblin Sponsorship",
[[I'm afraid I can't be of much more help to you, $n. If you'd like to follow up on it more, I'd suggest you go hit up the Baron himself. If there's anyone who knows Revilgaz's business, it's Revilgaz.$b$bYou'll find him at the tavern across the harbor, top floor.]],
[[Obávám se, že ti už moc nepomohu, $n. Jestli chceš pátrat dál, doporučuji zajít přímo za Baronem. Jestli někdo zná Revilgazovy obchody, pak je to sám Revilgaz.$b$bNajdeš ho v hostinci naproti přes přístav, v horním patře.]],
[[Speak with Baron Revilgaz in Booty Bay.]],
[[Promluv s Baronem Revilgazem v Booty Bay.]])

add(1182, "Goblin Sponsorship",
[[See, the Venture Company shredders out in Lake Nazferiti (in northern Stranglethorn) have been equipped with a new model fuel regulator. I was thinking that Pozzik would be able to take advantage of it, if he could get some details. Unfortunately, Cozzle, the foreman out there, appears to be a little more clever than I gave him credit for.$b$bYou seem like you might have more luck finding the blueprints though. I know he keeps them in his house, but they're almost certainly under lock and key.]],
[[Shreddery Venture Company u Lake Nazferiti v severním Stranglethornu dostaly nový model regulátoru paliva. Napadlo mě, že Pozzik by z něj mohl něco vytěžit, kdyby získal podrobnosti. Bohužel tamní předák Cozzle je zřejmě chytřejší, než jsem čekal.$b$bTy bys ale mohl mít při hledání plánů větší štěstí. Vím, že je uchovává ve svém domě, ale téměř jistě je má zamčené.]],
[[Bring the Fuel Regulator Blueprints to Baron Revilgaz in Booty Bay.]],
[[Přines plány regulátoru paliva Baronu Revilgazovi do Booty Bay.]])

add(1183, "Goblin Sponsorship",
[[You should be all set to go. Give Pozzik my regards and tell him that if he ever needs anything, not to hesitate to ask. I'll be waiting for the news that he breaks the track record soon!]],
[[Máš všechno, co potřebuješ. Pozdravuj ode mě Pozzika a řekni mu, že kdyby někdy něco potřeboval, ať se neváhá ozvat. Budu čekat na zprávu, že brzy překonal rekord trati!]],
[[Deliver the Fuel Regulator Blueprints to Pozzik on the Shimmering Flats.]],
[[Doruč plány regulátoru paliva Pozzikovi v Shimmering Flats.]])

add(1184, "Parts of the Swarm",
[[Head back to Belgrom in Orgrimmar and tell him Moktar be doing his bidding well out in the Thousand Needles. Tell him also, that me studies progress, and I hope to be havin' learned more soon. That should please him greatly.]],
[[Vrať se k Belgromovi do Orgrimmaru a řekni mu, že Moktar plní jeho příkazy v Thousand Needles dobře. Řekni mu také, že můj výzkum pokračuje a doufám, že brzy zjistím víc. To ho jistě potěší.]],
[[Return to Belgrom Rockmaul in Orgrimmar.]],
[[Vrať se k Belgromu Rockmaulovi do Orgrimmaru.]])

add(1186, "The Eighteenth Pilot",
[[I'm going to be busy with working on integrating this new fuel regulator to our racer designs, but if you'd like to help out the team some more, talk to Razzeric. He's our pilot--well, our eighteenth pilot, to be exact--and he likes to add his own little modifications to the racers.$b$bHe's a little off his rocker, though, so try not to act too surprised.]],
[[Budu mít plné ruce práce se zabudováním nového regulátoru paliva do našich závodních vozů. Jestli chceš týmu pomoci ještě víc, promluv s Razzericem. Je to náš pilot — přesněji řečeno osmnáctý pilot — a rád si na vozech dělá vlastní drobné úpravy.$b$bJe ale trochu praštěný, tak se snaž nevypadat příliš překvapeně.]],
[[Speak with Razzeric on the Shimmering Flats.]],
[[Promluv s Razzericem v Shimmering Flats.]])

add(1187, "Razzeric's Tweaking",
[[Pozzik's a great mechanic, I know that, but he's afraid to just load on the firepower and grab on for the ride. Not me, though.$b$bAfter Pozzik finishes with a racer, I take a little time to put my own modifications on--you know, loosening up the controls, removing parts of the frame, and adding more juice!$b$bI ordered a seaforium booster from Shreev at the Gizmorium in Gadgetzan, but apparently the zeppelin it was being sent on crashed in Dustwallow Marsh! I gotta have it, $n!]],
[[Pozzik je skvělý mechanik, to vím, ale bojí se prostě napálit výkon na maximum a držet se za jízdy. Já ne.$b$bKdyž Pozzik dokončí závodní vůz, vezmu si chvíli a přidám vlastní úpravy — trochu povolím řízení, odstraním pár částí rámu a přidám víc šťávy!$b$bObjednal jsem seaforiový booster od Shreeva z Gizmorium v Gadgetzanu, ale zeppelin, kterým ho posílali, prý havaroval v Dustwallow Marsh! Musím ho mít, $n!]],
[[Retrieve the Seaforium Booster for Razzeric in the Shimmering Flats.]],
[[Získej seaforiový posilovač pro Razzerica v Shimmering Flats.]])

add(1188, "Safety First",
[[But wait, what's this? Shreev left the safety on. That will limit the amount of power I can draw from the booster at any time. I told him I wanted it off! This is no good.$b$bYou have to take this to the Gadgetzan Gizmorium in the Tanaris Desert and have Shreev remove this.]],
[[Počkej, co je tohle? Shreev tam nechal pojistku. Ta omezuje výkon, který z boosteru můžu dostat. Říkal jsem mu, že ji chci pryč! Takhle je to k ničemu.$b$bMusíš to vzít do Gizmorium v Gadgetzanu v Tanaris Desert a nechat Shreeva pojistku odstranit.]],
[[Bring the Seaforium Booster to Shreev in Gadgetzan.]],
[[Přines seaforiový posilovač Shreevovi do Gadgetzanu.]])

add(1189, "Safety First",
[[There, I did what Razzeric wanted. Just tell him to be careful when he sets this off. If he makes the slightest mistake, he won't be moving forward, he'll just be a burnt spot on the track.$b$bWould be a shame, too, if that happened. Who knows if our nineteenth driver would be any good?]],
[[Tak, udělal jsem, co Razzeric chtěl. Jen mu řekni, ať je při spuštění opatrný. Pokud udělá sebemenší chybu, nepojede dopředu — zůstane po něm jen spálená skvrna na trati.$b$bA byla by to škoda. Kdo ví, jestli by náš devatenáctý pilot byl vůbec k něčemu?]],
[[Return the Modified Seaforium Booster to Razzeric on the Shimmering Flats.]],
[[Vrať upravený seaforiový posilovač Razzericovi v Shimmering Flats.]])

add(1190, "Keeping Pace",
[[The Brassbolts brothers have discovered a new building material, that's the only explanation that makes sense. Their cars have been operating faster than before, but their designs, and all the other data we've gathered from their runs is identical.$b$bWhat we do know, is that Rizzle Brassbolts has been focused on the plans for this new discovery almost constantly.$b$bZamek can create a diversion for you, so that you can steal those plans from them.]],
[[Bratři Brassboltsovi museli objevit nový stavební materiál, jiné vysvětlení nedává smysl. Jejich vozy jezdí rychleji než dřív, ale konstrukce i všechna ostatní data, která jsme z jízd získali, jsou stejná.$b$bVíme jen, že Rizzle Brassbolts se téměř neustále zabývá plány tohoto nového objevu.$b$bZamek pro tebe může vytvořit rozptýlení, abys jim ty plány mohl ukrást.]],
[[Have Zamek create a diversion, then steal Rizzle's plans for Pozzik on the Shimmering Flats.]],
[[Nech Zameka vytvořit rozptýlení a potom ukradni Rizzleovy plány pro Pozzika v Shimmering Flats.]])

add(1194, "Rizzle's Schematics",
[[Rizzle's schematics describe the process of the refinement of indurium ore. From his scrawls, it is apparent that indurium ore is being obtained from the dwarven excavation site of Uldaman in the Badlands.$b$bMuch of the other notes relate to the heat resistant properties.$b$bUsed as a paperweight for the plans is a hunk of what appears to be unrefined indurium ore.]],
[[Rizzleovy plány popisují postup rafinace induriové rudy. Z jeho poznámek je zřejmé, že indurium získávají na trpasličím nalezišti Uldaman v Badlands.$b$bVelká část dalších poznámek se věnuje odolnosti materiálu proti žáru.$b$bJako těžítko na plánech leží kus, který vypadá jako nezpracovaná induriová ruda.]],
[[Bring the Sample of Indurium Ore to Pozzik on the Shimmering Flats.]],
[[Přines vzorek induriové rudy Pozzikovi v Shimmering Flats.]])

add(1201, "Theramore Spies",
[[The Horde and Alliance hold an uneasy truce.Outlying skirmishes and covert actions are taken by one side against the other, and it is our duty to ensure the Horde is on top!$B$BNow is the chance to do just that.$B$BAlliance infiltrators have taken positions east of Brackenwall Village.They spy on the village and report our movements to Theramore, which we cannot allow.$B$BHunt down the infiltrators and slay them.Send a clear message to their superiors that we will not tolerate their spies' presence!]],
[[Horda a Aliance udržují nejisté příměří. Na okrajích však obě strany vedou potyčky a tajné operace a naší povinností je zajistit, aby Horda měla navrch!$B$BTeď k tomu máme příležitost.$B$BInfiltrátoři Aliance zaujali pozice východně od Brackenwall Village. Špehují vesnici a hlásí naše pohyby do Theramore, což nemůžeme dovolit.$B$BVystopuj infiltrátory a zabij je. Pošli jejich nadřízeným jasný vzkaz, že přítomnost špionů tolerovat nebudeme!]],
[[Kill 9 Theramore Infiltrators, then return to Nazeer Bloodpike in Brackenwall Village.]],
[[Zabij 9 infiltrátory z Theramore a potom se vrať k Nazeeru Bloodpikeovi do Brackenwall Village.]])

add(1202, "The Theramore Docks",
[[$N, two of our spies were sent to steal documents from a ship at the Theramore docks.They gained the papers but were discovered, and were forced to throw the documents into the sea.$B$BOne spy later escaped, but was unable to recover the prize.He reported his failure to me, and I now charge the task to you.$B$BThe documents are in a footlocker, in the waters somewhere beneath the Theramore docks.Find those documents, $N, and bring them to me.]],
[[$N, dva naši špioni byli posláni ukrást dokumenty z lodi v docích Theramore. Papíry získali, ale byli odhaleni a museli je hodit do moře.$B$BJednomu špionovi se později podařilo uniknout, ale dokumenty už nedokázal získat. Ohlásil mi své selhání a teď tím úkolem pověřuji tebe.$B$BDokumenty jsou v truhle někde ve vodě pod doky Theramore. Najdi je, $N, a přines mi je.]],
[[Bring the Captain's Documents to Nazeer Bloodpike in Brackenwall Village.]],
[[Přines kapitánovy dokumenty Nazeeru Bloodpikeovi do Brackenwall Village.]])

add(1203, "Jarl Needs a Blade",
[[I have cutting to do.I can't tell you what I'm going to cut, but... I need myself a blade.A certain blade...$B$BSome people call it a moonsteel broadsword.I call it a swing blade.$B$BYou help me?Maybe you find it in town, maybe you talk to a blacksmith and he'll make it special.$B$BBut don't sleep on this.What I'm cutting won't keep forever...]],
[[Mám něco na řezání. Nemůžu ti říct, co budu řezat, ale... potřebuji čepel. Jednu konkrétní čepel...$B$BNěkteří jí říkají moonsteel broadsword. Já jí říkám sekací čepel.$B$BPomůžeš mi? Možná ji najdeš ve městě, možná promluvíš s kovářem a necháš ji vyrobit.$B$BAle neodkládej to. To, co chci řezat, nevydrží věčně...]],
[[Bring a Moonsteel Broadsword to Jarl in Dustwallow Marsh.]],
[[Přines Jarlovi v Dustwallow Marsh měsíční ocelový široký meč.]])

add(1204, "Mudrock Soup and Bugs",
[[I'm working on a dish I call "Mudrock Soup and Bugs."I still need the major ingredients, and... well, I don't think I'd last long trudging through Dustwallow Marsh!$B$BSo, $N, can you do some hunting for me?First, I need the tongues of Mudrock turtles.You can find Mudrocks along the coast, mostly around the bay.$B$BBut I don't want just any tongues!I hear that the tongues of some Mudrocks are forked...$B$BThey say the forked tongues have a distinct flavor, and I want that flavor in my dish...]],
[[Pracuji na jídle, kterému říkám „Mudrock Soup and Bugs“. Stále potřebuji hlavní suroviny a... no, myslím, že bych v Dustwallow Marsh dlouho nepřežil!$B$BTakže, $N, mohl bys pro mě něco ulovit? Nejdřív potřebuji jazyky želv Mudrock. Najdeš je podél pobřeží, hlavně kolem zálivu.$B$BAle nechci jen tak ledajaké jazyky! Slyšel jsem, že některé Mudrock mají jazyk rozeklaný...$B$BPrý mají ty rozeklané zvláštní chuť a přesně tu chci ve svém jídle...]],
[[Bring 8 Forked Mudrock Tongues to Morgan Stern in Theramore.]],
[[Přines Morganu Sternovi v Theramore 8 rozeklané jazyky Mudrocků.]])

add(1205, "Deadmire",
[[Deadmire is an ancient crocolisk in Dustwallow marsh.And it is his time to die.$B$BOld bones grind as he pulls his huge body through the swamp, and although he still moves with the strength and speed of youth, his aging body tortures the great spirit within it, a spirit whose flame will not waver.$B$BYet now he lives in constant, maddening pain.You must end the life of this noble creature, $N.You must lead Deadmire to peace.]],
[[Deadmire je prastarý crocolisk z Dustwallow Marsh. A nastal jeho čas zemřít.$B$BJeho staré kosti skřípou, když vláčí obrovské tělo bažinou. Přestože se stále pohybuje se silou a rychlostí mládí, stárnoucí tělo mučí velkého ducha uvnitř, ducha, jehož plamen neuhasíná.$B$BTeď však žije v neustálé, šílené bolesti. Musíš ukončit život tohoto vznešeného tvora, $N. Doved Deadmirea k pokoji.]],
[[Bring Deadmire's Tooth to Melor in Thunder Bluff.]],
[[Přines Deadmirův zub Melorovi do Thunder Bluff.]])

add(1206, "Jarl Needs Eyes",
[[Eye juice is good juice for drinking.Too bad most critters only have two eyes.$B$BBut spiders have lots of eyes.Lots and lots.And Darkmist eye juice is tasty.Smooth and salty!Unpopped spider eyes... I taste them already.$B$BDarkmist spiders are west of here, in the Darkmist Cavern.You figure the spiders are named after the cave... or is it the other way around?]],
[[Šťáva z očí je dobrá na pití. Škoda, že většina potvor má jen dvě oči.$B$BAle pavouci mají očí spoustu. Opravdu spoustu. A šťáva z očí Darkmist je lahodná. Jemná a slaná! Neprasklé pavoučí oči... už je skoro cítím na jazyku.$B$BPavouci Darkmist jsou západně odsud v Darkmist Cavern. Myslíš, že pavouci dostali jméno podle jeskyně... nebo jeskyně podle nich?]],
[[Bring 40 Unpopped Darkmist Eyes to "Swamp Eye" Jarl at the Swamplight Manor.]],
[[Přines 40 neprasklé oči Darkmist „Swamp Eye“ Jarlovi do Swamplight Manor.]])

add(1218, "Soothing Spices",
[[I like cooking.Good swamp cooking.Fried green frog legs and the like.$B$BAnd for cooking, I need spice.Soothing spice.Then I'll make a stew and stew it up and suck it down and give you some too.$B$BDo you like stew?]],
[[Rád vařím. Dobré bažinné jídlo. Smažená zelená žabí stehýnka a podobně.$B$BA k vaření potřebuji koření. uklidňující koření. Pak uvařím guláš, nechám ho pořádně probublat, sním ho a trochu dám i tobě.$B$BMáš rád guláš?]],
[[Bring 3 Soothing Spices to "Swamp Eye" Jarl in Dustwallow Marsh.]],
[[Přines 3 uklidňující koření „Swamp Eye“ Jarlovi v Dustwallow Marsh.]])

add(1219, "The Orc Report",
[[Sifting through the loose dirt, the severed hand of an orc is found.And clutched in the hand is a bone-carved tube.And in the tube is a dirt-stained parchment.$B$BThe parchment is written in orcish... and it looks important.]],
[[Při prohrabávání sypké hlíny najdeš uťatou ruku orka. V ruce svírá trubici vyřezanou z kosti a uvnitř trubice je hlínou potřísněný pergamen.$B$BPergamen je napsaný orkštinou... a vypadá důležitě.]],
[[Bring the Spy's Report to a Theramore Lieutenant.]],
[[Přines špionovu zprávu některému poručíkovi v Theramore.]])

add(1220, "Captain Vimes",
[[Captain Vimes should see the orc report you found, $N.He knows the orcish language better than most.And he should know that there are Horde spies near Theramore!$B$BThe captain is in the barracks, on the northeastern side of Theramore Isle.]],
[[Captain Vimes by měl vidět orkskou zprávu, kterou jsi našel, $N. Orkštinu zná lépe než většina ostatních. A měl by vědět, že poblíž Theramore jsou špioni Hordy!$B$BKapitán je v kasárnách na severovýchodní straně Theramore Isle.]],
[[Bring the Spy's Report to Captain Garran Vimes.]],
[[Přines špionovu zprávu Captainu Garranu Vimesovi.]])

add(1222, "Stinky's Escape",
[[Great, finally something that doesn't want to eat me!$B$BI need help handling the critters around here, and you fit the mold, $gbuddy:lady;.$B$BThe cook Morgan Stern is researching a new recipe, and he sent me out here to gather bogbean leaves.I guess he thinks they're tasty.$B$BAnyway, while looking for a bogbean plant... I got myself surrounded!Can you help me out of here, and watch my back as I look for the bogbean?]],
[[Skvělé, konečně něco, co mě nechce sežrat!$B$BPotřebuji pomoc s potvorami v okolí a ty jsi přesně ten správný $gparťák:parťačka;.$B$BKuchař Morgan Stern zkoumá nový recept a poslal mě sem nasbírat listy bogbeanu. Asi mu připadají chutné.$B$BKaždopádně, při hledání rostliny... jsem se nechal obklíčit! Pomůžeš mi odsud a budeš mi krýt záda, zatímco budu hledat bogbean?]],
[[Escort "Stinky" Ignatz, then speak with Morgan Stern in Theramore.]],
[[Doprovod „Stinky“ Ignatze a potom promluv s Morganem Sternem v Theramore.]])

add(1238, "The Lost Report",
[[Sifting through the loose dirt, the severed hand of an orc is found.And clutched in the hand is a bone-carved tube.And in the tube is a dirt-stained parchment.$B$BThe parchment is a report made by an orc who spent weeks spying on the city of Theramore.$B$BAfter scanning the parchment, it is clear that it must be brought to the orc spymaster in Brackenwall Village.]],
[[Při prohrabávání sypké hlíny najdeš uťatou ruku orka. V ruce svírá trubici vyřezanou z kosti a uvnitř je hlínou potřísněný pergamen.$B$BJe to zpráva orka, který strávil celé týdny špehováním města Theramore.$B$BPo rychlém přečtení je zřejmé, že zpráva musí být doručena orkému veliteli špionů v Brackenwall Village.]],
[[Bring the Spy's Report to Nazeer Bloodpike in Brackenwall Village.]],
[[Přines špionovu zprávu Nazeeru Bloodpikeovi do Brackenwall Village.]])

add(1239, "The Severed Head",
[[Vigorous digging reveals the head of a male orc, raggedly severed at the neck.His lips are frozen in a snarl, and its dark eyes stare defiantly.]],
[[Po usilovném kopání odkryješ hlavu orčího muže, hrubě useknutou v krku. Rty má strnulé v zavrčení a tmavé oči vzdorovitě hledí vpřed.]],
[[Bring the Defiant Orc Head to Nazeer Bloodpike in Brackenwall Village.]],
[[Přines hlavu vzdorovitého orka Nazeeru Bloodpikeovi do Brackenwall Village.]])

add(1240, "The Troll Witchdoctor",
[[We must know the events surrounding Marg's death!And the only way to do that, $N, is through the witch-magic of trolls.$B$BBring Marg's head to Kin'weelay in Stranglethorn Vale, at the Grom'gol Base Camp.$B$BKin'weelay is the most powerful witchdoctor of the Darkspear trolls.If anyone can speak to Marg Nighteye's spirit, it is he.]],
[[Musíme zjistit, co se stalo při Margově smrti! A jediný způsob, $N, vede přes trollí čarodějnou magii.$B$BPřines Margovu hlavu Kin'weelayovi v Grom'gol Base Camp ve Stranglethorn Vale.$B$BKin'weelay je nejmocnější witchdoctor trollů Darkspear. Jestli někdo dokáže promluvit s duchem Marga Nighteye, je to on.]],
[[Take the Defiant Orc Head to Kin'weelay in the Grom'gol Base Camp in Stranglethorn Vale.]],
[[Dones hlavu vzdorovitého orka Kin'weelayovi do Grom'gol Base Camp ve Stranglethorn Vale.]])

add(1241, "The Missing Diplomat",
[[Recently a diplomat was sent to Theramore to meet with Jaina Proudmoore. That diplomat never arrived.$B$BI believe the Defias are involved in this plot, but I'm not sure how. The diplomat's disappearance still eludes public attention, but it can't remain that way for long.$B$BAgents of the king are already scouring the city for clues, but I have my own contacts I would like involved.$B$BIn the Valley of Heroes is an old friend of mine named Jorgen. Find him, give him this note, and follow his instructions.]],
[[Nedávno byl do Theramore vyslán diplomat na setkání s Jainou Proudmoore. Nikdy tam však nedorazil.$B$BVěřím, že do spiknutí jsou zapleteni Defias, ale nevím jak. Zmizení diplomata zatím uniká pozornosti veřejnosti, ale dlouho to tak nezůstane.$B$BKrálovi agenti už pročesávají město a hledají stopy, já ale chci zapojit i své vlastní kontakty.$B$BVe Valley of Heroes je můj starý přítel Jorgen. Najdi ho, dej mu tuto zprávu a řiď se jeho pokyny.]],
[[Find Jorgen in Stormwind City.]],
[[Najdi Jorgena ve Stormwind City.]])

add(1242, "The Missing Diplomat",
[[Take this here note to Elling Trias. Don't say nothin' else to him. Just be polite and wait for him to respond. And don't worry, he will.$B$BI'm gonna only impress this on ya once more, $N: treat this matter seriously, and keep your yapper shut.$B$BYa can find Trias at his cheese shop, Trias' Cheese, in the Trade District. Good luck.]],
[[Dones tuhle zprávu Ellingu Triasovi. Nic dalšího mu neříkej. Jen buď zdvořilý a počkej, až odpoví. A neboj, odpoví.$B$BJeště jednou ti to zdůrazním, $N: ber tuhle záležitost vážně a drž jazyk za zuby.$B$BTriase najdeš v jeho obchodě se sýry, Trias' Cheese, v Trade District. Hodně štěstí.]],
[[Delivery Jorgen's Sealed Note to Elling Trias in Stormwind City.]],
[[Doruč Jorgenovu zapečetěnou zprávu Ellingu Triasovi ve Stormwind City.]])

add(1243, "The Missing Diplomat",
[[Jorgen, you ol' sonuva.... So, that's how it's going to be, huh?$B$BAll right, I can deal with that. I hope he finds the Twisting Nether that much sooner!$B$BHere's what's gonna happen, $N. I'll start using my contacts here, but you're doing most of the footwork so I save some coin.$B$BHead to Darkshire in Duskwood and find Watcher Backus--he usually patrols the north road right outside of town. Just tell him you're looking into any Defias activity for me and he'll help you out with any information he can.]],
[[Jorgene, ty starý... Tak takhle to bude, co?$B$BDobře, s tím si poradím. Doufám, že se do Twisting Netheru dostane o něco dřív!$B$BTeď poslouchej, $N. Já zapojím své kontakty tady, ale většinu běhání uděláš ty, ať ušetřím pár mincí.$B$BVydej se do Darkshire v Duskwoodu a najdi Watchera Backuse. Obvykle hlídkuje na severní cestě těsně za městem. Řekni mu, že pro mě vyšetřuješ činnost Defias, a poskytne ti všechny informace, které může.]],
[[Give the Sealed Note to Watcher Backus in Duskwood.]],
[[Předej zapečetěnou zprávu Watcheru Backusovi v Duskwoodu.]])

add(1244, "The Missing Diplomat",
[[Defias activity? Well, there's always some activity; even if they keep to themselves we consider them a threat.$B$BBut now that I think about it, there was a recent sighting that seemed odd. It must have been a couple weeks ago, but some of their agents had gathered around Addle's Stead. From the report, I'd guessed something big went down.$B$BWhy don't you check there first and bring me back anything you find?$B$BThe farmstead is south of the road from Westfall just as you enter Duskwood.]],
[[Činnost Defias? Nějaká je pořád. I když se drží stranou, stále je považujeme za hrozbu.$B$BKdyž o tom přemýšlím, nedávno jsme zaznamenali něco zvláštního. Bylo to asi před pár týdny. Několik jejich agentů se shromáždilo kolem Addle's Stead. Podle hlášení se tam muselo stát něco velkého.$B$BProč to nejdřív neprověříš a nepřineseš mi všechno, co najdeš?$B$BFarma leží jižně od cesty z Westfallu, hned po vstupu do Duskwoodu.]],
[[Find the Defias Docket and return it to Watcher Backus in Duskwood.]],
[[Najdi spis Defias a vrať ho Watcheru Backusovi v Duskwoodu.]])

add(1245, "The Missing Diplomat",
[[Whoa, this looks way too complex to be something to just lead you astray. I shouldn't even be looking at this stuff. Take it to Trias--he'll be able to make sense of it. And DON'T let anyone get in your way. This is bigger than me. It might even be bigger than him, but we'll see.$B$BAnd do me a favor, $N, don't tell anyone I helped you. If my superiors found out I knew about any of this and didn't share it with them they'd probably hang me.]],
[[Páni, tohle je příliš složité na obyčejnou falešnou stopu. Vlastně bych se na to ani neměl dívat. Odnes to Triasovi, ten tomu dokáže přijít na kloub. A NEDOVOL, aby ti někdo stál v cestě. Tohle je větší než já. Možná dokonce větší než on, ale uvidíme.$B$BA udělej mi laskavost, $N. Nikomu neříkej, že jsem ti pomohl. Kdyby mí nadřízení zjistili, že jsem o tom věděl a nic jim neřekl, nejspíš by mě oběsili.]],
[[Bring the Defias Docket to Elling Trias in Stormwind.]],
[[Přines spis Defias Ellingu Triasovi do Stormwindu.]])

add(1246, "The Missing Diplomat",
[[Yeah, now that I think about it... Dashel... Dashel something... What was his name? FIST! Dashel Stonefist. They call him Fist in some circles--probably on account that he likes to get in brawls.$B$BYou can find him in Old Town usually--right smack dab in the center of it. Go talk to him. If you have to, use a sword or something heavy and blunt to persuade him to open up some. And don't hesitate. If he's in this as deep as these papers suggest, then he's not going to give you any information willingly.]],
[[Jo, teď když o tom přemýšlím... Dashel... Dashel něco... Jak že se jmenuje? FIST! Dashel Stonefist. V některých kruzích mu říkají Fist, nejspíš proto, že se rád pere.$B$BObvykle ho najdeš přímo uprostřed Old Town. Jdi si s ním promluvit. Pokud bude potřeba, použij meč nebo něco těžkého a tupého, abys ho přesvědčil, že má být sdílnější. A neváhej. Jestli v tom jede tak hluboko, jak naznačují ty papíry, informace dobrovolně nedá.]],
[[Speak to Dashel Stonefist in Stormwind.]],
[[Promluv s Dashelem Stonefistem ve Stormwindu.]])

add(1247, "The Missing Diplomat",
[[So yeah... um... I might know something 'bout that meeting at Addle's Stead. Happened a few weeks back I think. I really didn't have any part in it. Me part was done when plan A failed... damn adventurers.$B$BThe guy we got on the inside for plan B came out of Menethil; guy called Slim. That's all I know regarding their backup plan.]],
[[Tak jo... ehm... možná něco vím o tom setkání u Addle's Stead. Myslím, že to bylo před pár týdny. Já s tím vážně neměl nic společného. Moje část skončila, když selhal plán A... zatracení dobrodruzi.$B$BČlověk, kterého jsme měli uvnitř pro plán B, přišel z Menethilu. Říkali mu Slim. To je všechno, co o jejich záložním plánu vím.]],
[[Speak to Elling Trias in Stormwind.]],
[[Promluv s Ellingem Triasem ve Stormwindu.]])

add(1248, "The Missing Diplomat",
[[A contact of mine retired in the Wetlands at the harbor city of Menethil. He should be willing to help on your word alone if you tell him you're working for me. His name is Mikhail. He mentioned becoming a bartender before leaving Stormwind a few years ago.$B$BSpeak to him, find this Slim, and find out if there's anything else to know about this kidnapped diplomat. We need to find out where they've taken him, or at least who he is. The docket doesn't mention anything about their plans after he's captured.]],
[[Jeden můj kontakt odešel do výslužby ve Wetlands, v přístavním městě Menethil. Když mu řekneš, že pracuješ pro mě, měl by ti pomoci jen na mé slovo. Jmenuje se Mikhail. Než před několika lety opustil Stormwind, říkal, že se chce stát barmanem.$B$BPromluv s ním, najdi toho Slima a zjisti všechno další o uneseném diplomatovi. Musíme zjistit, kam ho odvezli, nebo alespoň kdo vlastně je. Dokumenty totiž neříkají nic o jejich plánu po únosu.]],
[[Speak to Mikhail in the Wetlands.]],
[[Promluv s Mikhailem ve Wetlands.]])

add(1249, "The Missing Diplomat",
[[You say Elling sent you here? Well then, the hospitality I expressed is now tenfold. Anything you need, just ask. I will do my best to aid you.$B$BHmm, Slim, you say? Not sure the name sounds familiar, but I'll keep my eyes out for him.$B$BDon't look now, $N, but the gentleman over by the exit is looking over here. He's listening to our conversation a little too intently if you catch my meaning? If I were you, I'd do what you can to subdue him before he makes a break for the door.]],
[[Říkáš, že tě poslal Elling? V tom případě platí má pohostinnost desetinásobně. Cokoli potřebuješ, stačí říct. Udělám vše, co budu moct.$B$BHm, Slim, říkáš? To jméno mi nic neříká, ale budu se po něm dívat.$B$BTeď se neotáčej, $N, ale ten muž u východu se dívá naším směrem. Poslouchá náš rozhovor až příliš pozorně, jestli mi rozumíš. Na tvém místě bych ho zkusil zneškodnit dřív, než se rozběhne ke dveřím.]],
[[Subdue Tapoke Jahn before he escapes, and then return to Mikhail in Menethil.]],
[[Zneškodni Tapoke Jahna dřív, než uteče, a potom se vrať k Mikhailovi v Menethilu.]])

add(1250, "The Missing Diplomat",
[[The Defias didn't pay me well enough to die for their cause. They took the king. Yeah, the king of Stormwind, not some lowly diplomat. He was on his way to Theramore to meet with Jaina Proudmore--it was a big deal apparently, and a big secret. But it's not just the Defias that are involved. They're working with someone. I think they knew this was bigger than them.$B$BMy part was just to get their man on board the king's ship while it was in the harbor. The guy's name was Hendel. That's all I know. I swear!]],
[[Defias mi nezaplatili dost na to, abych za jejich věc zemřel. Unesli krále. Ano, krále Stormwindu, ne nějakého bezvýznamného diplomata. Mířil do Theramore na setkání s Jainou Proudmoore. Zřejmě šlo o velkou věc a ještě větší tajemství. Ale nejsou v tom jen Defias. S někým spolupracují. Myslím, že věděli, že tohle je nad jejich síly.$B$BMým úkolem bylo jen dostat jejich člověka na královu loď, když byla v přístavu. Jmenoval se Hendel. To je všechno, co vím. Přísahám!]],
[[Speak to Mikhail in the Wetlands.]],
[[Promluv s Mikhailem ve Wetlands.]])

add(1251, "The Black Shield",
[[An iron shield, blackened by the fire that raged through the inn, is affixed to the crumbling chimney, one of the few remaining parts of the structure that once made up the Shady Rest Inn.$b$bThe shield can be removed from the brick of the chimney.]],
[[Na rozpadajícím se komíně, jednom z mála pozůstatků někdejšího Shady Rest Inn, je připevněný železný štít očazený požárem, který hostinec zničil.$b$bŠtít lze z cihel komína uvolnit.]],
[[Bring the Blackened Iron Shield to Krog in Brackenwall Village.]],
[[Přines zčernalý železný štít Krogovi do Brackenwall Village.]])

add(1252, "Lieutenant Paval Reethe",
[[A glint of light on the ground catches your eye from underneath the rubble. Brushing away debris and ash caked onto the object reveals the insignia of a gold anchor on white enameled on the surface: the sign of Theramore.$b$bUnderneath the anchor is embossed the name "Lieutenant Paval Reethe".]],
[[Pod sutinami tě upoutá záblesk světla. Když z předmětu setřeš popel a nečistoty, objeví se na bílém smaltovaném povrchu znak zlaté kotvy — symbol Theramore.$b$bPod kotvou je vyraženo jméno „Lieutenant Paval Reethe“.]],
[[Bring Reethe's Badge to Captain Garran Vimes in Theramore.]],
[[Přines Reetheův odznak Captainu Garranu Vimesovi v Theramore.]])

add(1253, "The Black Shield",
[[An iron shield, blackened by the fire that raged through the inn, is affixed to the crumbling chimney, one of the few remaining parts of the structure that once made up the Shady Rest Inn.$b$bThe shield can be removed from the brick of the chimney.]],
[[Na rozpadajícím se komíně, jednom z mála pozůstatků někdejšího Shady Rest Inn, je připevněný železný štít očazený požárem, který hostinec zničil.$b$bŠtít lze z cihel komína uvolnit.]],
[[Bring the Blackened Iron Shield to Captain Garran Vimes in Theramore.]],
[[Přines zčernalý železný štít Captainu Garranu Vimesovi v Theramore.]])

add(1258, "... and Bugs",
[[Another component of my new recipe is the shelled leg of a giant crab.And the crabs they have in Dustwallow -- Muckshells they call them -- just won't do!I'm afraid the only suitable crabs live far away, in the Swamp of Sorrows.$B$BThe shell of the crab leg is a key element of the dish's presentation so I need pristine, unscarred legs.An adult crab might only have one or two such legs, and I need a lot in order to research my dish.$B$BSo, $N... are you willing to travel?]],
[[Další složkou mého nového receptu je krunýřovitá noha obřího kraba. Jenže krabi z Dustwallow, kterým říkají Muckshells, se vůbec nehodí! Obávám se, že vhodní krabi žijí až daleko ve Swamp of Sorrows.$B$BKrunýř na krabí noze je klíčový pro vzhled jídla, takže potřebuji dokonale nepoškozené nohy. Dospělý krab může mít jen jednu nebo dvě takové a já jich k výzkumu receptu potřebuji hodně.$B$BTakže, $N... jsi ochoten cestovat?]],
[[Bring 12 Pristine Crawler Legs to Morgan Stern in Theramore.]],
[[Přines Morganu Sternovi v Theramore 12 nepoškozené krabí nohy.]])

add(1259, "Lieutenant Paval Reethe",
[[I don't recognize the name of Lieutenant Paval Reethe. Your best bet would be to check with Adjutant Tesoran. He keeps track of all the records for the Theramore guard, from personnel to their equipment.$b$bHe should be able to tell you who this Reethe is with a quick check of his books.]],
[[Jméno Lieutenant Paval Reethe nepoznávám. Nejlepší bude zeptat se Adjutanta Tesorana. Vede všechny záznamy theramorské stráže, od personálu až po vybavení.$b$bStačí, aby nahlédl do knih, a měl by ti říct, kdo ten Reethe je.]],
[[Find out more about Reethe from Adjutant Tesoran in Theramore.]],
[[Zjisti více o Reetheovi od Adjutanta Tesorana v Theramore.]])

add(1260, "Morgan Stern",
[[I'm developing a new menu for the restaurant.It will be filled with rural dishes with a "bayou" theme.I think my clientele at the Blue Recluse will love them!$B$BI sent my nephew Morgan to Theramore, a city on the edge of the Dustwallow Marsh.He's there gathering recipes from the locals, and I must know what he found so far.$B$BThe trip to Theramore is long.Too long for me.But I bet a young $c like yourself would jump at the chance to travel, yes?]],
[[Připravuji pro restauraci nové menu. Bude plné venkovských jídel v bažinném stylu. Myslím, že hosté v Blue Recluse je budou milovat!$B$BPoslal jsem svého synovce Morgana do Theramore, města na okraji Dustwallow Marsh. Sbírá tam recepty od místních a já musím vědět, co zatím objevil.$B$BCesta do Theramore je dlouhá. Pro mě až příliš. Ale mladý $c jako ty určitě rád využije příležitost cestovat, že?]],
[[Speak with Morgan Stern in Theramore.]],
[[Promluv s Morganem Sternem v Theramore.]])

add(1261, "Marg Speaks",
[[Cursed muckshell!You can't kill Marg!Ah, but I am dead.So it must have slain me...$B$BBut my mission!My mission!You, $N, must complete it.$B$BWhile near Theramore, I spied a group of Alliance soldiers camped on the beach.And one soldier wore a pendant... a pendant laden with more gems than any soldier could afford!$B$BThat night I snuck into their camp and stole the pendant, but on my return to base a muckshell crab-man killed me!$B$B$N, you must find that muckshell and recover the pendant!]],
[[Prokletý muckshell! Marga nemůžeš zabít! Ach... ale já jsem mrtvý. Takže mě přece jen zabil...$B$BAle moje mise! Moje mise! Ty, $N, ji musíš dokončit.$B$BKdyž jsem byl poblíž Theramore, sledoval jsem skupinu vojáků Aliance tábořících na pláži. Jeden z nich měl přívěsek... přívěsek posetý víc drahokamy, než by si obyčejný voják mohl dovolit!$B$BTé noci jsem se vplížil do tábora a přívěsek ukradl, ale cestou zpět na základnu mě zabil muckshellí krabí muž!$B$B$N, musíš toho muckshella najít a přívěsek získat!]],
[[Bring the Jeweled Pendant to Nazeer in Brackenwall Village.]],
[[Přines zdobený přívěsek Nazeerovi do Brackenwall Village.]])

add(1262, "Report to Zor",
[[It is strange that the pendant Marg stole was in the hands of common soldiers.Perhaps its owner was in disguise, or perhaps the soldiers themselves stole it!$B$BRegardless of which is true, this is a noble's pendant and we must discover its true owner if we are to unravel its mystery.$B$BTake the pendant to Zor Lonetree in Orgrimmar.He is well schooled in Alliance politics, and will know if this pendant has a history among the nobles of Stormwind.]],
[[Je zvláštní, že přívěsek, který Marg ukradl, měli obyčejní vojáci. Možná byl jeho majitel v přestrojení, nebo ho vojáci sami ukradli!$B$BAť je pravda jakákoli, jde o šlechtický přívěsek a pokud chceme rozluštit jeho tajemství, musíme zjistit skutečného vlastníka.$B$BDones přívěsek Zoru Lonetreeovi do Orgrimmaru. Dobře se vyzná v politice Aliance a bude vědět, zda má přívěsek nějakou historii mezi šlechtou Stormwindu.]],
[[Bring the Jeweled Pendant to Zor Lonetree in Orgrimmar.]],
[[Přines zdobený přívěsek Zoru Lonetreeovi do Orgrimmaru.]])

add(1264, "The Missing Diplomat",
[[The beginning of every month the Kul Tiras Marines all get paid and usually leave Theramore for somewhere else. A lot of them come here to womanize, carouse, and just have a good time. One of those groups I'd consider regulars here at the tavern, and I believe this Hendel is among them.$B$BCommander Samaul in Theramore would be able to help you find him if Hendel's still stationed there. He's completely loyal to Proudmoore, but if you drop Elling's name, he should help you out... discretely.]],
[[Na začátku každého měsíce dostanou Kul Tiras Marines výplatu a většinou Theramore na chvíli opustí. Mnozí přijdou sem za ženami, pitím a zábavou. Jedna taková skupina patří mezi naše stálé hosty a myslím, že ten Hendel je mezi nimi.$B$BCommander Samaul v Theramore ti pomůže ho najít, pokud tam Hendel stále slouží. Je naprosto věrný Proudmoore, ale když zmíníš Ellingovo jméno, měl by ti pomoci... diskrétně.]],
[[Find Commander Samaul in Dustwallow Marsh.]],
[[Najdi Commandera Samaula v Dustwallow Marsh.]])

add(1265, "The Missing Diplomat",
[[Hendel? Yes, I know the man. But why would you need one of my soldiers?$B$BElling sent you to find him? Hmm, I don't like the sound of that. Elling wouldn't have you come to me first if your business wasn't troubling. I understand if you can't tell me what this is about, but know this: I have a duty to protect these lands. If you're going to cause a disturbance, then I suggest you inform me of whatever you can.$B$BI believe Hendel was stationed at the first tower outside of Theramore. Be cautious.]],
[[Hendel? Ano, toho muže znám. Ale proč potřebuješ jednoho z mých vojáků?$B$BElling tě poslal, abys ho našel? Hm, to se mi nelíbí. Elling by tě neposlal nejdřív za mnou, kdyby nešlo o něco znepokojivého. Chápu, že mi možná nemůžeš říct všechno, ale věz, že mám povinnost chránit tuto zemi. Pokud hodláš způsobit rozruch, měl bys mě informovat alespoň o tom, o čem můžeš.$B$BMyslím, že Hendel byl přidělen k první věži za Theramore. Buď opatrný.]],
[[Search Sentry Point for any sign of Private Hendel.]],
[[Prohledej Sentry Point a hledej známky přítomnosti Private Hendela.]])

add(1266, "The Missing Diplomat",
[[Private Hendel is to the west of here. He's currently on guard duty protecting some of Theramore's infiltrators while they rest. They've been keeping tabs on the Horde base, Brackenwall, and looking for anything else that might threaten our borders.$B$BYou should have no problem finding him; just look for the tents along the road.$B$BI have another matter to attend to, but I shall catch up to you soon enough. You can always find me in the Lady Proudmoore's tower if you have any problems.]],
[[Private Hendel je západně odsud. Právě drží stráž a chrání několik theramorských infiltrátorů, zatímco odpočívají. Sledují základnu Hordy v Brackenwall a hledají všechno další, co by mohlo ohrozit naše hranice.$B$BNeměl bys mít problém ho najít. Hledej stany podél cesty.$B$BMusím se teď věnovat jiné záležitosti, ale brzy tě doženu. Pokud budeš mít potíže, vždy mě najdeš ve věži Lady Proudmoore.]],
[[Find Private Hendel in Dustwallow Marsh.]],
[[Najdi Private Hendela v Dustwallow Marsh.]])

add(1268, "Suspicious Hoofprints",
[[Rows of hoofprints lead away from the still-smoking skeleton of the Shady Rest Inn. There are at least a few visible impressions, with more rows of prints almost imperceptible in the soft mud of the marsh.]],
[[Od stále doutnajících trosek hostince Shady Rest Inn vedou řady otisků kopyt. Několik stop je jasně viditelných a další řady otisků jsou v měkkém bahně bažiny sotva patrné.]],
[[Report about the suspicious prints at the Shady Rest Inn to Krog in Brackenwall Village.]],
[[Podej Krogovi v Brackenwall Village zprávu o podezřelých stopách u Shady Rest Inn.]])

for id, entry in pairs(entries) do A.QuestEntries[id] = entry end

local targets = {
    ["befouled water globe"]="koule znečištěné vody",
    ["beginnings of the undead threat"]="Počátky nemrtvé hrozby",
    ["bel'dugur's note"]="Bel'dugurova poznámka",
    ["belgrom's sealed note"]="Belgromova zapečetěná zpráva",
    ["blackened iron shield"]="zčernalý železný štít",
    ["blacklash's bindings"]="Blacklashova pouta",
    ["bonegrip's note"]="Bonegripova poznámka",
    ["bottle of disease"]="láhev nákazy",
    ["branch of cenarius"]="Cenariova větev",
    ["brother anton's letter of commendation"]="doporučující dopis bratra Antona",
    ["captain's documents"]="kapitánovy dokumenty",
    ["chains of hematus"]="Hematovy řetězy",
    ["deadmire's tooth"]="Deadmirův zub",
    ["defiant orc head"]="hlavu vzdorovitého orka",
    ["defias docket"]="spis Defias",
    ["dream dust"]="snový prach",
    ["encrusted tail fin"]="krustou pokrytá ocasní ploutev",
    ["encrusted tail fins"]="krustou pokryté ocasní ploutve",
    ["firemane ash tails"]="popelavé ocasy Firemane",
    ["firemane guards"]="strážce Firemane",
    ["firemane scouts"]="průzkumníky Firemane",
    ["fizzle's letter"]="Fizzlův dopis",
    ["flute of xavaric"]="Xavaricova flétna",
    ["forked mudrock tongue"]="rozeklaný jazyk Mudrocka",
    ["forked mudrock tongues"]="rozeklané jazyky Mudrocků",
    ["fragments of rok'alim"]="úlomky Rok'Alima",
    ["frost oil"]="mrazivý olej",
    ["frostmaul shard"]="střep Frostmaul",
    ["frostmaul shards"]="střepy Frostmaul",
    ["frostmaw's mane"]="Frostmawova hříva",
    ["fuel regulator blueprints"]="plány regulátoru paliva",
    ["grenka's claw"]="Grenčin dráp",
    ["gyrochronatom"]="gyrochronatom",
    ["hardened tortoise shell"]="zpevněný želví krunýř",
    ["hardened tortoise shells"]="zpevněné želví krunýře",
    ["healing potion"]="léčivý lektvar",
    ["highperch venom sac"]="jedový váček Highperch",
    ["highperch venom sacs"]="jedové váčky Highperch",
    ["hollow vulture bone"]="dutá supí kost",
    ["hollow vulture bones"]="duté supí kosti",
    ["indurium flake"]="vločka induria",
    ["indurium flakes"]="vločky induria",
    ["intact silithid carapace"]="neporušený silithidí krunýř",
    ["intact silithid carapaces"]="neporušené silithidí krunýře",
    ["jeweled pendant"]="zdobený přívěsek",
    ["jorgen's sealed note"]="Jorgenovu zapečetěnou zprávu",
    ["kodo liver"]="játra koda",
    ["korran's sealed note"]="Korranova zapečetěná zpráva",
    ["kravel's parts"]="Kravelovy díly",
    ["kravel's parts order"]="Kravelova objednávka dílů",
    ["kravel's scheme"]="Kravelův plán",
    ["legacy of the aspects"]="Odkaz Aspektů",
    ["lesser invisibility potion"]="slabší lektvar neviditelnosti",
    ["lightning gland"]="blesková žláza",
    ["lightning glands"]="bleskové žlázy",
    ["lotwil's shackles of elemental binding"]="Lotwilova pouta živlového spoutání",
    ["mirefin heads"]="hlavy Mirefinů",
    ["modified seaforium booster"]="upravený seaforiový posilovač",
    ["moonsteel broadsword"]="měsíční ocelový široký meč",
    ["moontouched feather"]="pero dotčené měsíčním svitem",
    ["moontouched feathers"]="pera dotčená měsíčním svitem",
    ["mythology of the titans"]="Mytologie Titánů",
    ["patterned bronze bracers"]="vzorované bronzové nátepníky",
    ["pillars of amethyst"]="Ametystový pilíř",
    ["pillars of diamond"]="Diamantový pilíř",
    ["pillars of opal"]="Opálový pilíř",
    ["pristine crawler leg"]="nepoškozená krabí noha",
    ["pristine crawler legs"]="nepoškozené krabí nohy",
    ["rabine's letter"]="Rabinův dopis",
    ["razorflank's heart"]="Razorflankovo srdce",
    ["razorflank's medallion"]="Razorflankův medailon",
    ["reethe's badge"]="Reetheův odznak",
    ["saltstone basilisks"]="bazilišky Saltstone",
    ["saltstone crystalhides"]="krystalokožce Saltstone",
    ["saltstone gazers"]="pozorovatele Saltstone",
    ["salty scorpid venom"]="slaný jed škorpida",
    ["salty scorpid venoms"]="slaný jed škorpida",
    ["sample of indurium ore"]="vzorek induriové rudy",
    ["scythe of elune"]="Elunina kosa",
    ["seaforium booster"]="seaforiový posilovač",
    ["seal of the earth"]="Pečeť země",
    ["sealed field testing kit"]="zapečetěná terénní testovací souprava",
    ["sealed note"]="zapečetěnou zprávu",
    ["searing hearts"]="žhnoucí srdce",
    ["searing tongues"]="žhnoucí jazyky",
    ["sigil of the hammer"]="Pečeť kladiva",
    ["sign of the earth"]="Znamení země",
    ["silithid heart"]="srdce silithida",
    ["silithid hive drones"]="silithidí dělníky úlu",
    ["silithid invaders"]="silithidí vetřelce",
    ["silithid searchers"]="silithidí průzkumníky",
    ["silithid talon"]="dráp silithida",
    ["silithid talons"]="drápy silithidů",
    ["smoldering embers"]="doutnající uhlíky",
    ["soothing spices"]="uklidňující koření",
    ["speck of dream dust"]="zrnko snového prachu",
    ["specks of dream dust"]="zrnka snového prachu",
    ["spy's report"]="špionovu zprávu",
    ["tablet of will"]="Tabulka vůle",
    ["tear of the moons"]="Slza měsíců",
    ["the beginnings of the undead threat"]="Počátky nemrtvé hrozby",
    ["the legacy of the aspects"]="Odkaz Aspektů",
    ["theramore infiltrators"]="infiltrátory z Theramore",
    ["thunderhawk saliva gland"]="slinná žláza thunderhawka",
    ["tome of mel'thandris"]="svazek Mel'Thandrise",
    ["tortured druids"]="mučených druidů",
    ["tortured sentinels"]="mučených Sentinelů",
    ["treshala's pendant"]="Treshalin přívěsek",
    ["unpopped darkmist eye"]="neprasklé oko Darkmist",
    ["unpopped darkmist eyes"]="neprasklé oči Darkmist",
    ["unrefined ore sample"]="vzorek nerafinované rudy",
    ["wastewander water pouches"]="měchy s vodou nomádů Wastewander",
    ["yagyin's digest"]="Yagyinův spis",
    ["zanzil's mixture"]="Zanzilova směs",
}
for en, cs in pairs(targets) do
    if A.QuestTargetTranslations[en] == nil then A.QuestTargetTranslations[en] = cs end
end

local titles = {
    ["The Black Box"]="Černá skříňka",
    ["Solution to Doom"]="Řešení zkázy",
    ["Study of the Elements: Rock"]="Studium živlů: kámen",
    ["Coolant Heads Prevail"]="Chladná hlava vítězí",
    ["Gyro... What?"]="Gyro... co?",
    ["Liquid Stone"]="Tekutý kámen",
    ["Stone Is Better than Cloth"]="Kámen je lepší než látka",
    ["Tremors of the Earth"]="Otřesy země",
    ["Mirages"]="Přeludy",
    ["A Dwarf and His Tools"]="Trpaslík a jeho nástroje",
    ["A Sign of Hope"]="Znamení naděje",
    ["Amulet of Secrets"]="Amulet tajemství",
    ["Prospect of Faith"]="Naděje víry",
    ["Passing Word of a Threat"]="Zpráva o hrozbě",
    ["To Ironforge for Yagyin's Digest"]="Do Ironforge pro Yagyinův souhrn",
    ["To the Undercity for Yagyin's Digest"]="Do Undercity pro Yagyinův souhrn",
    ["Scrounging"]="Shánění zásob",
    ["This Is Going to Be Hard"]="Tohle bude těžké",
    ["The Star, the Hand and the Heart"]="Hvězda, ruka a srdce",
    ["Forbidden Knowledge"]="Zakázané vědění",
    ["Find Agmond"]="Najdi Agmonda",
    ["Murdaloc"]="Murdaloc",
    ["An Ambassador of Evil"]="Vyslanec zla",
    ["Broken Alliances"]="Rozbitá spojenectví",
    ["Finding the Antidote"]="Hledání protijedu",
    ["Chen's Empty Keg"]="Chenův prázdný soudek",
    ["Je'neu of the Earthen Ring"]="Je'neu z Earthen Ring",
    ["Rescue OOX-09/HL!"]="Zachraň OOX-09/HL!",
    ["Scholomance"]="Scholomance",
    ["Another Power Source?"]="Další zdroj energie?",
    ["Guile of the Raptor"]="Raptorova lest",
    ["The Tear of the Moons"]="Slza měsíců",
    ["Return to Apothecary Zinge"]="Návrat k Apothecary Zinge",
    ["Down at the Docks"]="Dole v docích",
    ["Gateway to the Frontier"]="Brána na hranici",
    ["You Scream, I Scream..."]="Ty křičíš, já křičím...",
    ["Cairne's Hoofprint"]="Cairnův otisk kopyta",
    ["Assisting Arch Druid Runetotem"]="Pomoc Arch Druidovi Runetotemovi",
    ["Flute of Xavaric"]="Xavaricova flétna",
    ["Skeletal Fragments"]="Kostěné úlomky",
    ["Luck Be With You"]="Ať tě provází štěstí",
    ["Finding the Source"]="Hledání pramene",
    ["Cache of Mau'ari"]="Mau'ariina skrýš",
    ["Are We There, Yeti?"]="Už jsme tam, yetti?",
    ["Moontouched Wildkin"]="Měsícem dotčení wildkini",
    ["Find Ranshalla"]="Najdi Ranshallu",
    ["The New Springs"]="Nové prameny",
    ["The Tower of Althalaxx"]="Věž Althalaxx",
    ["Gadgetzan Water Survey"]="Průzkum vody v Gadgetzanu",
    ["The New Frontier"]="Nová hranice",
    ["Forsaken Diseases"]="Nemoci Forsaken",
    ["Insane Druids"]="Šílení druidové",
    ["Vile Satyr! Dryads in Danger!"]="Ohavní satyrové! Dryády v nebezpečí!",
    ["The Howling Vale"]="Vyjící údolí",
    ["The Branch of Cenarius"]="Cenariova větev",
    ["Satyr Slaying!"]="Zabíjení satyrů!",
    ["Avast Ye, Scallywag"]="Stůj, ty mizero!",
    ["Velinde Starsong"]="Velinde Starsong",
    ["Velinde's Effects"]="Velindiny věci",
    ["The Barrens Port"]="Přístav v Barrens",
    ["Passage to Booty Bay"]="Plavba do Booty Bay",
    ["The Caravan Road"]="Karavanní cesta",
    ["The Carevin Family"]="Rodina Carevinů",
    ["The Scythe of Elune"]="Elunina kosa",
    ["Answered Questions"]="Zodpovězené otázky",
    ["Raene's Cleansing"]="Raenina očista",
    ["Into The Scarlet Monastery"]="Do Scarlet Monastery",
    ["Compendium of the Fallen"]="Kompendium padlých",
    ["Mythology of the Titans"]="Mytologie titánů",
    ["Vorrel's Revenge"]="Vorrelova pomsta",
    ["Down the Scarlet Path"]="Po šarlatové stezce",
    ["In the Name of the Light"]="Ve jménu Světla",
    ["Reclaiming the Charred Vale"]="Znovuzískání Charred Vale",
    ["Reception from Tyrande"]="Přijetí u Tyrande",
    ["Update for Sentinel Thenysil"]="Zpráva pro Sentinel Thenysil",
    ["Enraged Spirits"]="Rozzuření duchové",
    ["Wounded Ancients"]="Zranění prastaří",
    ["The Den"]="Doupě",
    ["Kaela's Update"]="Zpráva pro Kaelu",
    ["Lonebrow's Journal"]="Lonebrowův deník",
    ["The Crone of the Kraul"]="Stařena z Kraulu",
    ["A Vengeful Fate"]="Pomstychtivý osud",
    ["Call of Water"]="Volání vody",
    ["Salt Flat Venom"]="Jed ze solné pláně",
    ["Hardened Shells"]="Ztvrdlé krunýře",
    ["Martek the Exiled"]="Martek Vyhnanec",
    ["Encrusted Tail Fins"]="Krustou pokryté ocasní ploutve",
    ["Indurium"]="Indurium",
    ["Going, Going, Guano!"]="Jednou, dvakrát, guáno!",
    ["Rocket Car Parts"]="Díly raketového vozu",
    ["Wharfmaster Dizzywig"]="Wharfmaster Dizzywig",
    ["Parts for Kravel"]="Díly pro Kravela",
    ["Hearts of Zeal"]="Srdce horlivosti",
    ["Delivery to the Gnomes"]="Dodávka gnómům",
    ["The Rumormonger"]="Šiřitel drbů",
    ["Dream Dust in the Swamp"]="Snový prach v bažině",
    ["Rumors for Kravel"]="Drby pro Kravela",
    ["Back to Booty Bay"]="Zpět do Booty Bay",
    ["Zanzil's Mixture and a Fool's Stout"]="Zanzilova směs a Bláznův stout",
    ["Get the Gnomes Drunk"]="Opij gnómy",
    ["Get the Goblins Drunk"]="Opij gobliny",
    ["Report Back to Fizzlebub"]="Podej hlášení Fizzlebubovi",
    ["Rabine Saturna"]="Rabine Saturna",
    ["Wasteland"]="Pustina",
    ["The Spirits of Southwind"]="Duchové Southwindu",
    ["Hive in the Tower"]="Úl ve věži",
    ["Fool's Stout"]="Bláznův stout",
    ["Fiora Longears"]="Fiora Longears",
    ["Highperch Venom"]="Jed z Highperch",
    ["Frostmaw"]="Frostmaw",
    ["News for Fizzle"]="Zprávy pro Fizzlea",
    ["The Lost Tablets of Will"]="Ztracené tabulky vůle",
    ["Mortality Wanes"]="Smrtelnost slábne",
    ["Willix the Importer"]="Willix Dovozce",
    ["The Swarm Grows"]="Roj roste",
    ["Parts of the Swarm"]="Části roje",
    ["Test of Faith"]="Zkouška víry",
    ["Test of Endurance"]="Zkouška vytrvalosti",
    ["Test of Strength"]="Zkouška síly",
    ["Test of Lore"]="Zkouška vědomostí",
    ["A New Ore Sample"]="Nový vzorek rudy",
    ["To Steal From Thieves"]="Okrást zloděje",
    ["Overlord Mok'Morokk's Concern"]="Starost Overlorda Mok'Morokka",
    ["Army of the Black Dragon"]="Armáda černého draka",
    ["Identifying the Brood"]="Určení rodu",
    ["The Brood of Onyxia"]="Onyxiino potomstvo",
    ["Challenge Overlord Mok'Morokk"]="Vyzvi Overlorda Mok'Morokka",
    ["A Bump in the Road"]="Překážka na cestě",
    ["Load Lightening"]="Odlehčení nákladu",
    ["Hungry!"]="Hlad!",
    ["Goblin Sponsorship"]="Gobliní sponzorství",
    ["The Brassbolts Brothers"]="Bratři Brassboltsovi",
    ["The Eighteenth Pilot"]="Osmnáctý pilot",
    ["Razzeric's Tweaking"]="Razzericovy úpravy",
    ["Safety First"]="Bezpečnost především",
    ["Keeping Pace"]="Držet krok",
    ["Rizzle's Schematics"]="Rizzleovy plány",
    ["Theramore Spies"]="Špioni z Theramore",
    ["The Theramore Docks"]="Doky v Theramore",
    ["Jarl Needs a Blade"]="Jarl potřebuje čepel",
    ["Mudrock Soup and Bugs"]="Mudrocková polévka s brouky",
    ["Deadmire"]="Deadmire",
    ["Jarl Needs Eyes"]="Jarl potřebuje oči",
    ["Soothing Spices"]="Uklidňující koření",
    ["The Orc Report"]="Orkská zpráva",
    ["Captain Vimes"]="Kapitán Vimes",
    ["Stinky's Escape"]="Stinkyho útěk",
    ["The Lost Report"]="Ztracená zpráva",
    ["The Severed Head"]="Uťatá hlava",
    ["The Troll Witchdoctor"]="Trollí šaman",
    ["The Missing Diplomat"]="Ztracený diplomat",
    ["Suspicious Hoofprints"]="Podezřelé stopy kopyt",
    ["The Black Shield"]="Černý štít",
    ["Lieutenant Paval Reethe"]="Poručík Paval Reethe",
    ["... and Bugs"]="... a brouci",
    ["Morgan Stern"]="Morgan Stern",
    ["Marg Speaks"]="Marg promlouvá",
    ["Report to Zor"]="Podej hlášení Zorovi",
}
for en, cs in pairs(titles) do
    if A.QuestTitleTranslations[en] == nil then A.QuestTitleTranslations[en] = cs end
end
